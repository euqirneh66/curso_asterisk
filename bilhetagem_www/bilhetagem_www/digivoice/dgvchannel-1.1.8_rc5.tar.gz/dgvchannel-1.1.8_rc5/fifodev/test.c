
/****************************************************************************
 *                                                                          * 
 *   Linux Device Driver DGVFIFO											*
 *   Userspace test program													*
 *                                                                          *
 *	 Copyright (c) 2007 Digivoice Eletronica								*
 *                                                                          *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                        *
 *   desenvolvimento@digivoice.com.br                                       *
 *                                                                          *
 *   This program is free software; you can redistribute it and/or modify   *
 *   it under the terms of the GNU General Public License as published by	*
 *   the Free Software Foundation; either version 2 of the License, or		*
 *   (at your option) any later version.									*
 *                                                                          *
 *   This program is distributed in the hope that it will be useful,		*
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of			*
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the			*		
 *   GNU General Public License for more details.							*
 *                                                                          *
 *   You should have received a copy of the GNU General Public License		*
 *   along with this program; if not, write to the Free Software			*
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 				*
 *                                                                          *  
 ****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <stdio.h>
#include <signal.h>
#include <pthread.h>

#define CASE1 1
#define CASE2 2

#define TAM_STR	255

#define MAX_FIFO	2

int fd[MAX_FIFO];

void
sighandler(int sig)
{
	int i;
	
	/* force clean exit */
	switch (sig) {
	case SIGSTOP:
	case SIGQUIT:
	case SIGKILL:
	case SIGINT:
		for (i=0;i<MAX_FIFO;i++)
			close(fd[i]);
        printf("Clean exit forced!\n");
		exit(0);
	}
}

static void *read_thread(void *data)
{
	int fifo = *(int *)data;
	int ret;
	char r_str[100];
	int i=0;

	printf("Reading thread for fifo %d!\n", fifo);

	while(1)
	{
		ret = read(fd[fifo],r_str,100);
		printf("%d - Data readed from %d= %s!\n", i++, fifo, r_str);

		if (fifo==0)
			write(fd[0],"resposta",8);
	}
}

main() {

	pthread_t thd_read[64];
	pthread_attr_t attr;

	int fifo;
	int i,j;
	int len, wlen;
	char string[] = "Digivoice Fifo Kernel Module Test\0";
	char szTemp[TAM_STR];
	int data, rdata;

    /* catches up for clean exit */
    signal(SIGSTOP, sighandler);
    signal(SIGQUIT, sighandler);
    signal(SIGKILL, sighandler);
    signal(SIGINT, sighandler);

	for (i=0;i<MAX_FIFO;i++)
	{
		sprintf(szTemp,"/dev/dgvfifo%d",i);	
		fd[i] = open(szTemp, O_RDWR /*| O_NONBLOCK*/);
		if( fd[i] == -1) {
			printf("open error...\n");
			for (j=0;j<i;i++)
				close(fd[j]);
			exit(0);
		}
	}
    //starts read thread for fifo 0
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
	for (fifo=0;fifo<2;fifo++)
	{
		if (pthread_create(&thd_read[fifo], &attr, read_thread, &fifo)) {
			printf("Cannot start socket thread!!!\n");
		}
		else
			printf("Starting socket thread - fifo %d!!!\n", fifo);

		sleep(1);
	}

	for (i=0;i<10;i++)
	{
//		for (j=1;j<10;j+=2)
	//	{
			sprintf(szTemp,"Teste de Escrita %d",i);
			write(fd[1],szTemp,strlen(szTemp));
		//}

		usleep(50000);
	}

	sleep(2);
	for (i=0;i<MAX_FIFO;i++)
		close(fd[i]);

}

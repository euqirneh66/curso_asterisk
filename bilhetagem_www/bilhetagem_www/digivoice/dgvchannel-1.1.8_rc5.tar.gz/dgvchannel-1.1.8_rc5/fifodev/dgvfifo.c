
/****************************************************************************
 *																		    *
 *	 Digivoice DgvFifo device 											    *
 *																		    *
 *	 Copyright (c) 2007 - Digivoice Eletronica Ltda  					    * 	
 * 																		    *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                        *
 *   desenvolvimento@digivoice.com.br                                       *
 *                                                                          *
 *	 This program was adapted from: 										*
 *	 simplefifo.c sample - Module (C) 2005 www.captain.at 				    *
 * 																		    *
 *	 This implementation allow two full-duplex access using 				*
 * 																		    *
 *	 /proc/dgvfifo/data1 and /proc/dgvfifo/data2 						    *
 * 																		    *
 *	 USAGE: 														        *
 *	 * Compile the kernel module with "make" 							    *
 *	 * Execute script create_inodes.sh (or make install) 				    *
 * 																		    *
 *   This program is free software; you can redistribute it and/or modify   *
 *   it under the terms of the GNU General Public License as published by   *
 *   the Free Software Foundation; either version 2 of the License, or      *
 *   (at your option) any later version.                                    *
 *																		    *
 *   This program is distributed in the hope that it will be useful,  	    *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of  	    *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the  		    *
 *   GNU General Public License for more details.  						    *
 *   																	    *
 *   You should have received a copy of the GNU General Public License  	*
 *   along with this program; if not, write to the Free Software  		    *
 *   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  	   		* 
 *  																	    *
 ****************************************************************************/
  

// Linux Device Driver Template/Skeleton
// Kernel Module


#include <linux/errno.h>
#include <linux/poll.h>
#include <linux/module.h>
#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  #include <linux/wrapper.h>
#else
	#include <linux/sched.h>
#endif


#define DGVFIFO_NAME "dgvfifo"


#define MAX_FIFOS			64
#define FIFO_LINES			64

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,26)
	#define FIFO_DATA_SIZE  1024 /* isdn max */
#else
	#define FIFO_DATA_SIZE  128 /* isdn max */
#endif

//#define DEBUG_KERNEL	1


/* FIFO DEFINITION */
typedef  struct
{
  volatile unsigned short  rp;
  volatile unsigned short  wp;
  unsigned char 	data[FIFO_LINES][FIFO_DATA_SIZE];		//fifo data
  unsigned char 	data_size[FIFO_LINES];					//element data size
} DGVFIFO;

static short major_number = 0;

static short driver_running = 0; 

//defines two fifos
DGVFIFO		dgv_fifo[MAX_FIFOS];

wait_queue_head_t dgvfifo_wait[MAX_FIFOS];	

//-------------------------------------------------------------------------------
// open function - called when the "file" /dev/dgfifoN is opened in userspace
//-------------------------------------------------------------------------------
static int dgvfifo_open (struct inode *inode, struct file *filp) {

	short fifo_id = MINOR(filp->f_dentry->d_inode->i_rdev);

	if (fifo_id<MAX_FIFOS) {
#ifdef DEBUG_KERNEL 		
		printk("dgvfifo_open - minor %d\n", fifo_id);
#endif
		//initialize fifo pointers
		dgv_fifo[fifo_id].wp = 0;
		dgv_fifo[fifo_id].rp = 0;
		driver_running = 1;
		return 0;
	}
	else {
		printk("Error while open dgvfifo - minor %d\n", fifo_id);
		return -EINVAL;
	}
	
}

// close function - called when the "file" /dev/skeleton is closed in userspace  
static int dgvfifo_release (struct inode *inode, struct file *filp) 
{
	driver_running = 0;
	printk("DgvFIFO: dgvfifo_release - minor %d\n", MINOR(filp->f_dentry->d_inode->i_rdev));
	return 0;
}

// read function called when from /dev/dgvfifo* is read
static ssize_t dgvfifo_read (struct file *filp, char *buf,
                                                size_t count, loff_t *ppos)
{
#ifdef DEBUG_KERNEL
    char data2[1000];
    char data1[255];
	int j;    
#endif
	int err, len;
	short fifo_id = MINOR(filp->f_dentry->d_inode->i_rdev);
	
	while (dgv_fifo[fifo_id].rp==dgv_fifo[fifo_id].wp)
	{
		if (filp->f_flags & O_NONBLOCK)
		{
#ifdef DEBUG_KERNEL
			printk("dgvfifo_read: return empty\n");
#endif
			return -EAGAIN;
		}
#ifdef DEBUG_KERNEL
		printk("dgvfifo_read: waiting fifo_id %d - wp=%d - rp=%d\n", fifo_id,
									dgv_fifo[fifo_id].wp,dgv_fifo[fifo_id].rp);
#endif

		//wait when there is no data available
		wait_event_interruptible(dgvfifo_wait[fifo_id], dgv_fifo[fifo_id].rp!=dgv_fifo[fifo_id].wp);

	}
	if (driver_running)
	{
		len = dgv_fifo[fifo_id].data_size[dgv_fifo[fifo_id].rp];
		err = copy_to_user(buf, 
						dgv_fifo[fifo_id].data[dgv_fifo[fifo_id].rp], len);
		if (err != 0)
		{
			printk("dgvfifo_read: ERROR reading from fifo %d!!!!!!!!\n", fifo_id);
			return -EFAULT;
		}
						
#ifdef DEBUG_KERNEL
		printk("dgvfifo_read: reading %d - wp=%d - rp=%d - len=%d\n", fifo_id,
										dgv_fifo[fifo_id].wp,dgv_fifo[fifo_id].rp, len);

		sprintf(data2,"dgvfifo_read: ");
		for (j=0; j< len; j++) 
		{
			sprintf(data1,"%02x ",dgv_fifo[fifo_id].data[dgv_fifo[fifo_id].rp][j]);
			strcat(data2,data1);
		}
		printk("%s\n", data2);
#endif
		//increment retrieve pointer
		dgv_fifo[fifo_id].rp++;
		if (dgv_fifo[fifo_id].rp>=FIFO_LINES)
			dgv_fifo[fifo_id].rp =0;
		
		return len;
	}
	else
		return 0;
}

// write function called when to /dev/dgvfifoN is written
// Important!! When writes to dgvfifo0, the dgv_fifo[1] will be filled
//             and vice-versa
static ssize_t dgvfifo_write (struct file *filp, const char *buf,
                                                  size_t count, loff_t *ppos)
{
#ifdef DEBUG_KERNEL
    char data2[1000];
    char data1[255];
	int j;
#endif

	int err;
	short fifo_id = MINOR(filp->f_dentry->d_inode->i_rdev);
	short fifo_target;
	short mywpcount;

	if (count>FIFO_DATA_SIZE)
		return -EFAULT;

	//gets fifo target number
	if ((fifo_id%2)==0)
		fifo_target = fifo_id+1;
	else
		fifo_target = fifo_id-1;


#ifdef DEBUG_KERNEL
	printk("dgvfifo_write: writing to fifo %d - wp=%d - rp=%d\n", fifo_target,
									dgv_fifo[fifo_target].wp,dgv_fifo[fifo_target].rp);
#endif
	if (driver_running)
	{
		mywpcount = dgv_fifo[fifo_target].wp;
		mywpcount++;

		if (mywpcount>=FIFO_LINES)
			mywpcount=0;

		if (mywpcount == dgv_fifo[fifo_target].rp)
		{
			printk("dgvfifo_write: ERROR writing to fifo %d!!!!!!!!(FIFO FULL - wp: %d/%d - rp: %d)\n", fifo_target, dgv_fifo[fifo_target].wp, mywpcount, dgv_fifo[fifo_target].rp);
			return -EFAULT;
		}

		err = copy_from_user(dgv_fifo[fifo_target].data[dgv_fifo[fifo_target].wp],buf,count);
		if (err != 0)
		{
			printk("dgvfifo_write: ERROR writing to fifo %d!!!!!!!!\n", fifo_target);
			return -EFAULT;
		}
		//save size
		dgv_fifo[fifo_target].data_size[dgv_fifo[fifo_target].wp] = count;
	
#ifdef DEBUG_KERNEL
		sprintf(data2,"dgvfifo_write: ");
		for (j=0; j< count; j++) 
		{
			sprintf(data1,"%02x ",dgv_fifo[fifo_target].data[dgv_fifo[fifo_target].wp][j]);
			strcat(data2,data1);
		}
		printk("%s\n", data2);
#endif

		//increment insertion pointer
		dgv_fifo[fifo_target].wp++;
		if (dgv_fifo[fifo_target].wp>=FIFO_LINES)
			dgv_fifo[fifo_target].wp=0;

		//wake up read function
		wake_up(&dgvfifo_wait[fifo_target]);
	
		return count;
	}
	else
		return -EFAULT;
	
}

//-------- poll/select function -----------
static unsigned int dgvfifo_poll(struct file *filp, struct poll_table_struct *wait_table)
{
	unsigned int mask=0;
	short fifo_id = MINOR(filp->f_dentry->d_inode->i_rdev);	

	poll_wait(filp,&dgvfifo_wait[fifo_id], wait_table);

	if (dgv_fifo[fifo_id].rp!=dgv_fifo[fifo_id].wp)
	{
#ifdef DEBUG_KERNEL
		printk("dgvfifo_poll: there are data (fifoid: %d)\n", fifo_id);
#endif
		mask |= POLLIN | POLLRDNORM;	//readeable
	}
	return mask;
}

// define which file operations are supported
struct file_operations dgvfifo_fops = {
	.owner	=	THIS_MODULE,
	.llseek	=	NULL,
	.read	=	dgvfifo_read,
	.write	=	dgvfifo_write,
	.poll	=	dgvfifo_poll,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36)
        .unlocked_ioctl = NULL,
#else
        .ioctl  =       NULL,
#endif
	.mmap	=	NULL,
	.open	=	dgvfifo_open,
	.flush	=	NULL,
	.release	=	dgvfifo_release,
	.fsync	=	NULL,
	.fasync	=	NULL,
	.lock	=	NULL,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
	.readv	=	NULL,
	.writev	=	NULL,
#endif
};

// initialize module (and interrupt)
static int __init dgvfifo_init_module (void) {
	int i;
	printk("DgvFIFO: Initializing module.\n");

	driver_running = 0;
	//initializes all stuffs
	for (i=0;i<MAX_FIFOS;i++)
	{	
		//initializes signal to use in wait_event_interruptible
		init_waitqueue_head(&dgvfifo_wait[i]);	
		//fifo initialization
		dgv_fifo[i].wp = 0;
		dgv_fifo[i].rp = 0;
	}
	major_number = register_chrdev (0, DGVFIFO_NAME, &dgvfifo_fops);
	printk("DgvFIFO: Registering %s Major number %d.\n", DGVFIFO_NAME, major_number);
	if (major_number < 0) return - EIO;
	
	return 0;
}

// close and cleanup module
static void __exit dgvfifo_cleanup_module (void) {
	printk("DgvFIFO: Cleaning up module.\n");
	driver_running = 0;
	unregister_chrdev (major_number, DGVFIFO_NAME);
}

module_init(dgvfifo_init_module);
module_exit(dgvfifo_cleanup_module);
MODULE_AUTHOR("Digivoice Eletronica");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Linux Device Driver implementing FIFO Full-duplex");
MODULE_VERSION("1.2.0.0");

#!/bin/bash

#is24=`uname -a | grep 2.4`

#[ "${is24}" ] && KERNELVERSION=24 || KERNELVERSION=26

#if [ ${KERNELVERSION} -lt 26 ];
#then
#    echo "Kernel 2.4....";
#    module="dgvfifo"
#    device="dgvfifo"
#    mode=666
#else
echo "Kernel 2.X...";
module="dgvfifo.ko"
device="dgvfifo"
mode=666
#fi

#eventually unload previous driver
rmmod $module 2> /dev/null

#invoke insmod
echo "Loading $module..."
/sbin/insmod ./$module $* || exit 1

#remove stale inodes
rm -f /dev/${device}*

major=`awk "\\$2==\"${device}\" {print \\$1}" /proc/devices`

if [ ! $major ]; then
	echo "Error getting major number ${major}! Aborted!"
	exit 1
fi

echo "Allocating major number = $major"

echo "Creating /dev/${device}..."
###########################################################
# Create Signal inodes
###########################################################
echo "Creating fifo inodes..."
PORTS=64
COUNT=0
MINOR=0
while [ ${COUNT} -lt ${PORTS} ]; do
    mknod /dev/${device}${COUNT}  c  $major ${MINOR}
    chmod a+w /dev/${device}${COUNT}
    COUNT=$[${COUNT}+1]
    MINOR=$[${MINOR}+1]
done

echo "Done!"


/***************************************************************************
 *                                                                         *
 *   app_dgsendsms.c - DgSendSMS application for DigiVoice Cards.          *
 *                                                                         *
 *   Copyright (c) 2009-2015, DigiVoice Tecnologia em Eletronica Ltda      *
 *                                                                         *
 *   Author: Luciano Alves Barroso                                         *
 *   luciano@digivoice.com.br                                              *
 *                                                                         *
 *   This software is licensed under GPL                                   *
 *   Check LICENSE file for details                                        *
 *                                                                         *
 *-------------------------------------------------------------------------*/
 
#include "asterisk.h"
#include "config.h"

ASTERISK_FILE_VERSION(__FILE__, "$Revision: 5623 $")

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <voicerlib/voicerlib.h>

#include "asterisk/lock.h"
#include "asterisk/file.h"
#include "asterisk/logger.h"
#include "asterisk/channel.h"
#include "asterisk/pbx.h"
#include "asterisk/module.h"
#include "asterisk/translate.h"
#include "asterisk/image.h"
#include "asterisk/options.h"
#include "asterisk/config.h"
#include "asterisk/app.h"

#include "dgvchannel.h"

#define AST_MODULE "ael"

#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	#define AST_DECLARE_APP_ARGS(name, arglist) \
		struct { \
			unsigned int argc; \
			char *argv[0]; \
			arglist \
		} name
#endif//#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#define AST_APP_ARG(name) char *name

/*#define AST_STANDARD_APP_ARGS(args, parse) \
	args.argc = ast_app_separate_args(parse, '|', args.argv, (sizeof(args) - sizeof(args.argc)) / sizeof(args.argv[0]))*/

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	static char *tdesc = "Send SMS for dgv GSM application";
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

static char *app = "DgSendSMS";

static char *synopsis = "Send SMS on a GSM channel";

static char *descrip = 
"  DgSendSMS(resource,send_to,text_message[,lock_dialplan[,custom_id]]): Send SMS on a GSM channel. \n\n";

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	STANDARD_LOCAL_USER;

	LOCAL_USER_DECL;
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#ifdef CC_AST_HAS_VERSION_1_8
	static int sendsms_exec(struct ast_channel *chan, const char *data)
#else//#ifdef CC_AST_HAS_VERSION_1_8
	static int sendsms_exec(struct ast_channel *chan, void *data)
#endif//#ifdef CC_AST_HAS_VERSION_1_8
{
	int res = -1;
	char *parse;

    char resource[20];
	char send_to[40];
	char text_message[200];
	char lock_dialplan[5];
	char custom_id[40];
	
	const struct ast_channel_tech *chan_tech;
	char texttosend[305];
	
	static const char type[] = "DGV";
	static const char sms_header[] = "DGV_GSM_SMS";
	static const char sms_sep[] = "~";

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    struct ast_module_user *u;
    
    u = ast_module_user_add(chan);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	struct localuser *u;
	
    LOCAL_USER_ADD(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

    AST_DECLARE_APP_ARGS(args,
                         AST_APP_ARG(resource);
                         AST_APP_ARG(send_to);
                         AST_APP_ARG(text_message);
                         AST_APP_ARG(lock_dialplan);
                         AST_APP_ARG(custom_id);
    );

    if (ast_strlen_zero(data)) {
        ast_log(LOG_WARNING, "SendSMS requires 3 arguments \n");
        return -1;
    }

    if (!(parse = ast_strdupa(data))) {
        ast_log(LOG_WARNING, "Memory allocation failure\n");        
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    AST_STANDARD_APP_ARGS(args, parse);

    if (args.argc!=3 && args.argc!=4 && args.argc!=5) {
        ast_log(LOG_ERROR, "Wrong arguments\n");
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    //receive arguments
    ast_copy_string(resource    , args.argv[0], sizeof(resource));
    ast_copy_string(send_to     , args.argv[1], sizeof(send_to));
    ast_copy_string(text_message, args.argv[2], sizeof(text_message));
    if (args.argc==4 || args.argc==5)
    	ast_copy_string(lock_dialplan, args.argv[3], sizeof(lock_dialplan));
    if (args.argc==5)
    	ast_copy_string(custom_id, args.argv[4], sizeof(custom_id));

	chan_tech = ast_get_channel_tech(type);
	
	if (!chan_tech)
	{
		ast_log(LOG_WARNING, "There is not a DGV channel running\n");
		res = -1;
	}
	else
	{
		if (option_verbose >= 3)
			ast_log(LOG_NOTICE, "Calling dgv_sendtext...\n");

		ast_copy_string(texttosend, sms_header, sizeof(texttosend));
		strcat(texttosend, sms_sep);
		strcat(texttosend, resource);
		strcat(texttosend, sms_sep);
		strcat(texttosend, send_to);
		strcat(texttosend, sms_sep);
		strcat(texttosend, text_message);
		if (args.argc==4 || args.argc==5)
		{
			strcat(texttosend, sms_sep);
			strcat(texttosend, lock_dialplan);
		}
		if (args.argc==5)
		{
			strcat(texttosend, sms_sep);
			strcat(texttosend, custom_id);
		}
		strcat(texttosend, "\0");
		
		res = chan_tech->send_text(chan, texttosend);
	}
    
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    
    iffirst = iffirst;
	iflast = iflast;

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int unload_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int unload_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	int res;

	res = ast_unregister_application(app);
	
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    	ast_module_user_hangup_all();
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
		STANDARD_HANGUP_LOCALUSERS;
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int load_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int load_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	return ast_register_application(app, sendsms_exec, synopsis, descrip);
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	AST_MODULE_INFO_STANDARD(ASTERISK_GPL_KEY, "Send SMS for dgv GSM application");
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	char *description(void)
	{
		return tdesc;
	}
	
	int usecount(void)
	{
		int res;
		STANDARD_USECOUNT(res);
		return res;
	}
	
	char *key()
	{
		return ASTERISK_GPL_KEY;
	}
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)


/***************************************************************************
 *                                                                         *
 *   app_dgflash.c - DgFlash application for DigiVoice Cards.              *
 *                                                                         *
 *   Copyright (c) 2007-2010, DigiVoice Tecnologia em Eletronica Ltda      *
 *                                                                         *
 *   Author: Luciano Alves Barroso                                         *
 *   luciano@digivoice.com.br                                              *
 *                                                                         *
 *   This software is licensed under GPL                                   *
 *   Check LICENSE file for details                                        *
 *                                                                         *
 *-------------------------------------------------------------------------*/
 
#include "asterisk.h"
#include "config.h"

ASTERISK_FILE_VERSION(__FILE__, "$Revision: 8261 $")

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <voicerlib/voicerlib.h>

#include "asterisk/lock.h"
#include "asterisk/file.h"
#include "asterisk/logger.h"
#include "asterisk/channel.h"
#include "asterisk/pbx.h"
#include "asterisk/module.h"
#include "asterisk/translate.h"
#include "asterisk/image.h"
#include "asterisk/options.h"
#include "asterisk/config.h"
#include "asterisk/app.h"

#include "dgvchannel.h"

#define AST_MODULE "ael"

#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	#define AST_DECLARE_APP_ARGS(name, arglist) \
		struct { \
			unsigned int argc; \
			char *argv[0]; \
			arglist \
		} name
#endif//#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#define AST_APP_ARG(name) char *name

/*#define AST_STANDARD_APP_ARGS(args, parse) \
	args.argc = ast_app_separate_args(parse, '|', args.argv, (sizeof(args) - sizeof(args.argc)) / sizeof(args.argv[0]))*/

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	static char *tdesc = "Flash for dgv trunk application";
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

static char *app = "DgFlash";

static char *synopsis = "Flash on a Dgv Trunk";

static char *descrip = 
"  DgFlash(flash_pause, pause_after): Flash on a Dgv Trunk. \n\n";

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	STANDARD_LOCAL_USER;

	LOCAL_USER_DECL;
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#ifdef CC_AST_HAS_VERSION_1_8
	static int flash_exec(struct ast_channel *chan, const char *data)
#else//#ifdef CC_AST_HAS_VERSION_1_8
	static int flash_exec(struct ast_channel *chan, void *data)
#endif//#ifdef CC_AST_HAS_VERSION_1_8
{

    struct dgv_pvt *p = (struct dgv_pvt *)dgv_channel_tech_pvt(chan);

	int res = -1;
	char *parse;

    short flash_pause;
    short pause_after;

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    struct ast_module_user *u;
    
    u = ast_module_user_add(chan);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	struct localuser *u;
	
    LOCAL_USER_ADD(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

    AST_DECLARE_APP_ARGS(args,
                         AST_APP_ARG(flash_pause);
                         AST_APP_ARG(pause_after);
    );


    if (ast_strlen_zero(data)) {
        ast_log(LOG_WARNING, "Flash requires 2 arguments \n");
        return -1;
    }

    if (!(parse = ast_strdupa(data))) {
        ast_log(LOG_WARNING, "Memory allocation failure\n");        
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    AST_STANDARD_APP_ARGS(args, parse);

    if (args.argc!=2) {
        ast_log(LOG_ERROR, "Wrong arguments\n");
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    //receive times
    flash_pause = atoi(args.argv[0]);
    pause_after = atoi(args.argv[1]);

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    if (!strcasecmp(dgv_channel_tech(chan)->type, "DGV")) {
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	if (!strcasecmp(chan->type, "DGV")) {
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        //flash_pause = 250;
        //pause_after = 500;

        p->flashing=1;

        //check if channel is still up
        if (!p->ast_ch)
            return -1;

        dg_HangUp(p->port);

        usleep(flash_pause*1000);

        //check if channel is still up
        if (!p->ast_ch)
            return -1;

        dg_PickUp(p->port,100);

        p->flashing=0;

        usleep(pause_after*1000);

        //check if channel is still up
        if (!p->ast_ch)
            return -1;

        if (p->ast_ch)
        {
            res = 0;
        }
        else
        {
            res = -1;
        }
                
	} else
		ast_log(LOG_WARNING, "%s is not a Dgv channel\n", dgv_channel_name(chan));

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    
    iffirst = iffirst;
	iflast = iflast;

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int unload_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int unload_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	int res;

	res = ast_unregister_application(app);
	
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    	ast_module_user_hangup_all();
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
		STANDARD_HANGUP_LOCALUSERS;
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int load_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int load_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	return ast_register_application(app, flash_exec, synopsis, descrip);
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	AST_MODULE_INFO_STANDARD(ASTERISK_GPL_KEY, "Flash for dgv trunk application");
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	char *description(void)
	{
		return tdesc;
	}
	
	int usecount(void)
	{
		int res;
		STANDARD_USECOUNT(res);
		return res;
	}
	
	char *key()
	{
		return ASTERISK_GPL_KEY;
	}
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

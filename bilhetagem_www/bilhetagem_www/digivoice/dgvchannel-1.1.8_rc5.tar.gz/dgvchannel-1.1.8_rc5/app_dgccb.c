
/***************************************************************************
 *                                                                         *
 *   DgCollectCallBlock - Asterisk Application for DigiVoice Cards         *
 *                                                                         *
 *   Copyright (c) 2007-2010, DigiVoice Tecnologia em Eletronica Ltda      *
 *                                                                         *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                       *
 *   desenvolvimento@digivoice.com.br                                      *
 *                                                                         *
 *   This software is licensed under GPL                                   *
 *   Check LICENSE file for details                                        *
 *                                                                         *
 ***************************************************************************/

#include "asterisk.h"
#include "config.h"

ASTERISK_FILE_VERSION(__FILE__, "$Revision: 8261 $")

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <voicerlib/voicerlib.h>

#include "asterisk/lock.h"
#include "asterisk/file.h"
#include "asterisk/logger.h"
#include "asterisk/channel.h"
#include "asterisk/pbx.h"
#include "asterisk/module.h"
#include "asterisk/translate.h"
#include "asterisk/image.h"
#include "asterisk/options.h"
#include "asterisk/config.h"

#include "dgvchannel.h"

#define AST_MODULE "ael"

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	static char *tdesc = "Collect Call Block for DGV Trunk Application";
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

static char *app = "DgCollectCallBlock";

static char *synopsis = "Block Collect Call on a DGV Trunk";

static char *descrip = 
"  DgCollectCallBlock(): Block collect Call on a DGV Trunk. \n\n";

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	STANDARD_LOCAL_USER;

	LOCAL_USER_DECL;
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#ifdef CC_AST_HAS_VERSION_1_8
	static int ccb_exec(struct ast_channel *chan, const char *data)
#else//#ifdef CC_AST_HAS_VERSION_1_8
	static int ccb_exec(struct ast_channel *chan, void *data)
#endif//#ifdef CC_AST_HAS_VERSION_1_8
{
    struct dgv_pvt *p = (struct dgv_pvt *)dgv_channel_tech_pvt(chan);

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    struct ast_module_user *u;
    
    u = ast_module_user_add(chan);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	struct localuser *u;
	
    LOCAL_USER_ADD(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	if (!strcasecmp(dgv_channel_tech(chan)->type, "DGV"))
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	if (!strcasecmp(chan->type, "DGV")) 
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        p->flashing = 1;
	else
		ast_log(LOG_WARNING, "%s is not a DGV channel\n", dgv_channel_name(chan));

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    
    iffirst = iffirst;
	iflast = iflast;

	return 0;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int unload_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int unload_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	int res;

	res = ast_unregister_application(app);
	
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    ast_module_user_hangup_all();
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	STANDARD_HANGUP_LOCALUSERS;
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int load_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int load_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	return ast_register_application(app, ccb_exec, synopsis, descrip);
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	AST_MODULE_INFO_STANDARD(ASTERISK_GPL_KEY, "Collect Call Block for DGV Trunk Application");
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	char *description(void)
	{
		return tdesc;
	}
	
	int usecount(void)
	{
		int res;
		STANDARD_USECOUNT(res);
		return res;
	}
	
	char *key()
	{
		return ASTERISK_GPL_KEY;
	}
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)


/*-------------------------------------------------------------------------
 
    FILE....: auto_conf_dgv.c
    AUTHOR..: Luciano Alves Barroso - desenvolvimento@digivoice.com.br
    DATE....: 24/11/2006
 
    auto-configuration(digivoice.conf) for DigiVoice cards

-------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef __LINUX__
	#include <pthread.h>
	#include <getopt.h>
	#include <ctype.h>
	#include <termios.h>
	#include <unistd.h>
#else
	#include <conio.h>
	#include <windows.h>
	#define DllImport   __declspec(dllimport)
#endif

#include <voicerlib/voicerlib.h>

//function prototypes
void CopyFileToFile(char *szSourceFile, char *szTargetFile);
void ConfigGroups(short nCard);
void ConfigPorts(short nCard);
void ConfigE1(int nCardsCount);

#define MAX_PATH 	255
#define MAX_CH		360

int nLastGroup;
short is_complete;

#ifdef __LINUX__
	int getch(void);
	int getch(void) {
		struct termios oldt, newt;
		int ch;

		/* We can't necessarily trust POSIX's STDIN_FILENO */
		int stdin_fd = fileno(stdin);

		/* Get and save the current terminal flags */
		tcgetattr(stdin_fd, &oldt);

		/* Copy the old settings and turn off echo/canonical mode */
		newt = oldt;
		newt.c_lflag &= ~(ICANON | ECHO);

		/* Apply the new settings */
		tcsetattr(stdin_fd, TCSANOW, &newt);

		/* Call the standard getchar() function */
		ch = getchar();

		/* Restore the original settings */
		tcsetattr(stdin_fd, TCSANOW, &oldt);

		return ch;
	}
#endif

void CopyFileToFile(char *szSourceFile, char *szTargetFile)
{
    FILE *SourceFile;
    FILE *TargetFile;    
    char szData[MAX_PATH];
    char szTmpSourceFile[MAX_PATH] = "";
    char szNewSourceFile[MAX_PATH] = "";

    sprintf(szNewSourceFile, "%s", szSourceFile);

    if (is_complete == 1)
    	sprintf(szTmpSourceFile, "%s", "_complete.conf");
    else
    	sprintf(szTmpSourceFile, "%s", "_simple.conf");

    strcat(szNewSourceFile, szTmpSourceFile);

    if ((SourceFile = fopen(szNewSourceFile, "r")) == NULL)
    {
        printf("\n\nError Reading SourceFile\n");
        exit(1);
    }

	if (!strncmp(szSourceFile, "step_1.conf", 11)) //if (szSourceFile == "step_1.conf")
    {
		if ((TargetFile = fopen(szTargetFile, "w")) == NULL)
		{
    	    printf("\n\nError Reading TargetFile\n");
            exit(1);
        }
	}
	else
    {
		if ((TargetFile = fopen(szTargetFile, "a")) == NULL)
		{
    	    printf("\n\nError Reading TargetFile\n");
            exit(1);
        }
    }

    while (fgets(szData, MAX_PATH - 1, SourceFile) != NULL)
    {
        if (fputs(szData, TargetFile) == -1)    
        {
		    printf("\n\nError Writing TargetFile\n");
	        exit(1);
	    }
    }	

    //printf("Copy File '%s' To File '%s'...OK\n", szSourceFile, szTargetFile);    
    fclose(SourceFile);
    fclose(TargetFile); 
}

void ConfigGroups(short nCard)
{
    FILE *TargetFile;    
    int nCardInterface, nCardPortsCount, nFirstPort, nLastPort;

    nCardInterface = dg_GetCardInterface(nCard);
    nCardPortsCount = dg_GetCardPortsCount(nCard);
    nFirstPort = dg_GetAbsolutePortNumber(nCard, 1); 
    nLastPort = dg_GetAbsolutePortNumber(nCard, nCardPortsCount); 

    if ((TargetFile = fopen("digivoice.conf", "a")) == NULL)
    {
        printf("\n\nError Reading TargetFile-ConfigGroups\n");
        exit(1);
    }

    switch(nCardInterface)
    {
		case DG_DIGITAL_INTERFACE:
		    printf("Card Interface - Ports: DIGITAL_INTERFACE - %d\n", nCardPortsCount);
	
		    if (nCardPortsCount == 60)
		    {	    
				nLastGroup++;
		
				//write group
	    	    printf("[groups]\n");
				printf("group=%d\n", nLastGroup);
		        printf("ports=>%d-%d\n", nFirstPort, nLastPort - 30);
				printf("\n");
			
				fprintf(TargetFile, "group=%d\n", nLastGroup);
				fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort - 30);	        	
				fprintf(TargetFile, "\n");    	    
			
				nLastGroup++;
		
				//write group
	    	    printf("[groups]\n");
				printf("group=%d\n", nLastGroup);
		        printf("ports=>%d-%d\n", nLastPort - 29, nLastPort);
				printf("\n");

				fprintf(TargetFile, "group=%d\n", nLastGroup);
				fprintf(TargetFile, "ports=>%d-%d\n", nLastPort - 29, nLastPort);
				fprintf(TargetFile, "\n");
	    	}
	    	else
	    	{
				nLastGroup++;
	    
				//write group
				printf("[groups]\n");
				printf("group=%d\n", nLastGroup);
				printf("ports=>%d-%d\n", nFirstPort, nLastPort);
				printf("\n");

				fprintf(TargetFile, "group=%d\n", nLastGroup);
				fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);	        	
				fprintf(TargetFile, "\n");	    
	    	}	    
	    	break;			
		case DG_FXO_INTERFACE:
		    printf("Card Interface - Ports: FXO_INTERFACE - %d\n", nCardPortsCount);

		    nLastGroup++;

		    //write group
		    printf("[groups]\n");
	    	printf("group=%d\n", nLastGroup);
		    printf("ports=>%d-%d\n", nFirstPort, nLastPort);
		    //printf("\n");
	
		    fprintf(TargetFile, "group=%d\n", nLastGroup);
		    fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);	        	
	    	fprintf(TargetFile, "\n");    	    
		    break;
		case DG_FX_INTERFACE:
		    printf("Card Interface - Ports: FX_INTERFACE - %d\n", nCardPortsCount);

		    nLastGroup++;

		    //write group
		    printf("[groups]\n");
	    	printf("group=%d\n", nLastGroup);
		    printf("ports=>%d-%d\n", nFirstPort, nLastPort);
		    //printf("\n");
	
		    fprintf(TargetFile, "group=%d\n", nLastGroup);
		    fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);	        	
	    	fprintf(TargetFile, "\n");    	    
		    break;			
		case DG_GSM_INTERFACE:
		    printf("Card Interface - Ports: GSM_INTERFACE - %d\n", nCardPortsCount);

		    nLastGroup++;

		    //write group
		    printf("[groups]\n");
	    	printf("group=%d\n", nLastGroup);
		    printf("ports=>%d-%d\n", nFirstPort, nLastPort);
		    //printf("\n");
	
		    fprintf(TargetFile, "group=%d\n", nLastGroup);
		    fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);	        	
	    	fprintf(TargetFile, "\n");    	    
		    break;
    }
    
    fclose(TargetFile);
}

void ConfigPorts(short nCard)
{
    FILE *TargetFile;    
    int nCardInterface, nCardPortsCount, nFirstPort, nLastPort;

    nCardInterface = dg_GetCardInterface(nCard);
    nCardPortsCount = dg_GetCardPortsCount(nCard);
    nFirstPort = dg_GetAbsolutePortNumber(nCard, 1); 
    nLastPort = dg_GetAbsolutePortNumber(nCard, nCardPortsCount); 

    if ((TargetFile = fopen("digivoice.conf", "a")) == NULL)
    {
        printf("\n\nError Reading TargetFile-ConfigPorts\n");
        exit(1);
    }

    switch(nCardInterface)
    {
		case DG_DIGITAL_INTERFACE:
	    	printf("\nCard Interface - Ports: DIGITAL_INTERFACE - %d\n", nCardPortsCount);
	    
		    if (nCardPortsCount == 60)
		    {
	    	    //step_4 = default file for DIGITAL card type
	        	//printf("step_4/9...\n");
		        CopyFileToFile("step_4", "digivoice.conf");
		
	    	    //write port_config
				printf("[port_config]\n");
				printf("ports=>%d-%d\n", nFirstPort, nLastPort - 30);		
				printf("\n");
		
				fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort - 30);    	    		
				fprintf(TargetFile, "\n");		
		
				fclose(TargetFile);
		
	        	if ((TargetFile = fopen("digivoice.conf", "a")) == NULL)
	        	{
	            	printf("\n\nError Reading TargetFile-ConfigPorts\n");
	            	exit(1);
				}		
	    
	        	//step_5 = default file for DIGITAL card type
	        	//printf("step_5/9...\n");
	        	CopyFileToFile("step_5", "digivoice.conf");
		
	        	//write port_config
				printf("[port_config]\n");
				printf("ports=>%d-%d\n", nLastPort - 29, nLastPort);
		
				fprintf(TargetFile, "ports=>%d-%d\n", nLastPort - 29, nLastPort);
				fprintf(TargetFile, "\n");
	    	}
	    	else
	    	{
	        	//step_4 = default file for DIGITAL card type
	        	//printf("step_4/9...\n");
	        	CopyFileToFile("step_4", "digivoice.conf");
		
	        	//write port_config
				printf("[port_config]\n");
				printf("ports=>%d-%d\n", nFirstPort, nLastPort);
		
				fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);
				fprintf(TargetFile, "\n");
	    	}	    
		    break;
		case DG_FXO_INTERFACE:
		    printf("\nCard Interface - Ports: FXO_INTERFACE - %d\n", nCardPortsCount);

		    //step_6 = default file for FXO card type
		    //printf("step_6/9...\n");
		    CopyFileToFile("step_6", "digivoice.conf");
		
		    //write port_config
		    printf("[port_config]\n");
	    	printf("ports=>%d-%d\n", nFirstPort, nLastPort);
	    	
	    	fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);
			fprintf(TargetFile, "\n");
	    
	    	break;	    
		case DG_FX_INTERFACE:
		    printf("\nCard Interface - Ports: FX_INTERFACE - %d\n", nCardPortsCount);

		    //step_7 = default file for FXS card type
		    //printf("step_7/9...\n");
		    CopyFileToFile("step_7", "digivoice.conf");
		
		    //write port_config
		    printf("[port_config]\n");
	    	printf("ports=>%d-%d\n", nFirstPort, nLastPort);
		
	    	fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);
			fprintf(TargetFile, "\n");
	    
	    	break;    
		case DG_GSM_INTERFACE:
		    printf("\nCard Interface - Ports: GSM_INTERFACE - %d\n", nCardPortsCount);

		    //step_8 = default file for GSM card type
		    //printf("step_8/9...\n");
		    CopyFileToFile("step_8", "digivoice.conf");
		
		    //write port_config
		    printf("[port_config]\n");
	    	printf("ports=>%d-%d\n", nFirstPort, nLastPort);
		
	    	fprintf(TargetFile, "ports=>%d-%d\n", nFirstPort, nLastPort);
			fprintf(TargetFile, "\n");
	    
	    	break;	    	
    }
	
    fclose(TargetFile);     
}

void ConfigE1(int nCardsCount)
{
    FILE *TargetFile;    
    int nForCardsCount;
    char szCards[MAX_PATH];
    char szTemp[MAX_PATH];    
    
    if ((TargetFile = fopen("digivoice.conf", "a")) == NULL)
    {
        printf("\n\nError Reading TargetFile-ConfigE1\n");
        exit(1);
    }

    szCards[0] = '\0';    
    for (nForCardsCount=1; nForCardsCount<=nCardsCount; nForCardsCount++)
    {       
	if (dg_GetCardInterface(nForCardsCount) == DG_DIGITAL_INTERFACE)
	{
	    sprintf(szTemp, "%d,", nForCardsCount);
	    strcat(szCards, szTemp);
	}	
    }	
	
    szCards[strlen(szCards) - 1] = '\0';
    
    CopyFileToFile("step_9", "digivoice.conf");
    		
    //write e1_config
    printf("\n[e1_config]\n");
    printf("e1_sync=1\n");
    printf("use_crc4=0\n");
    printf("cards=>%s\n", szCards);
		
    fprintf(TargetFile, "cards=>%s\n", szCards);
	fprintf(TargetFile, "\n");
	    
    fclose(TargetFile);     
}

int main(int argc, char *argv[])
{
    int nRetStartVLib;
    int nCardsCount = 0;
    int nForCardsCount;
    int nE1CardsCount;
    char get_param;

    is_complete = -1;

    while (is_complete == -1)
    {
        if (argc == 2)
        {
        	if (toupper(argv[1][0]) == 'S')
        	{
        		is_complete = 0;
        		break;
        	}
        	else
        		if (toupper(argv[1][0]) == 'C')
            	{
            		is_complete = 1;
            		break;
            	}
        }

    	printf("\nDigite 's' ou 'c' para criar seu arquivo de configuracao 'digivoice.conf':\n");
    	printf("\ts (Simples, apenas os parametros obrigatorios)\n");
    	printf("\tc (Completa, todos os parametros existentes)\n");

    	get_param = getch();
    	switch (get_param)
    	{
    		case 's':
    		case 'S':
    			is_complete = 0;
    			break;
    		case 'c':
    		case 'C':
    			is_complete = 1;
    			break;
    	}
    }

    if (is_complete == 1)
    	printf("\nModo Completo selecionado...\n");
    else
    	printf("\nModo Simples selecionado...\n");

    //Start VoicerLib
    if ((nRetStartVLib = dg_StartVoicerlib(NULL)) != DG_EXIT_SUCCESS)
    {
    	printf("\n\nError Starting VoicerLib (code %d)\n", nRetStartVLib);
    	exit(EXIT_FAILURE);
    }
    printf("\nVoicerLib Started!\n");
	
    //CardsCount
    nCardsCount = dg_GetCardsCount();
    printf("\n%d Card(s) Detected...\n\n", nCardsCount);

    //step_1 = default file for any card type
    //printf("\n----- step 1/9 -----\n");
    CopyFileToFile("step_1", "digivoice.conf");
	
    //step_2 = config groups
    //printf("\n----- step 2/9 -----\n");        
    nLastGroup = 0;    
    for (nForCardsCount=1; nForCardsCount<=nCardsCount; nForCardsCount++)
    {
    	//printf("Auto Group Configuration: %d\n", nForCardsCount);
    	ConfigGroups(nForCardsCount);
    }
	
    //step_3 = default file for any card type
    //printf("----- step 3/9 -----\n");    
    CopyFileToFile("step_3", "digivoice.conf");
    
    //step4-6 = config port_config
    //printf("\n----- step 4-6/9 -----");        
    for (nForCardsCount=1; nForCardsCount<=nCardsCount; nForCardsCount++)
    {
    	//printf("\nAuto Port Configuration: %d\n", nForCardsCount);
    	ConfigPorts(nForCardsCount);
    }
    
    //step_9 = config e1_config
    nE1CardsCount = 0;
    for (nForCardsCount=1; nForCardsCount<=nCardsCount; nForCardsCount++)
    {
    	if (dg_GetCardInterface(nForCardsCount) == DG_DIGITAL_INTERFACE)
    		nE1CardsCount++;
    }        
    if (nE1CardsCount >= 1)
    {
    	//printf("\n----- step 9/9 -----");
        //printf("\nAuto E1 Configuration: %d Card(s)\n", nE1CardsCount);		
    	ConfigE1(nCardsCount);
    }	

    dg_ShutdownVoicerlib();

    printf("\n\n* * * Goodbye! * * *\n\n");
    return DG_EXIT_SUCCESS;
}

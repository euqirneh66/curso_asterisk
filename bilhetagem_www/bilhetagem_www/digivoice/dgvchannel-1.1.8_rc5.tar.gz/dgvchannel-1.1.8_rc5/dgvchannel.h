
/***************************************************************************
 *                                                                         *
 *   dgvchannel.h - Channel Driver for Asterisk (c)                        *
 *                                                                         *
 *   Copyright (c) 2006-2015, DigiVoice Tecnologia em Eletronica Ltda      *
 *                                                                         *
 *   Module: Asterisk Channel for DigiVoice Cards                          *
 *                                                                         *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                       *
 *   desenvolvimento@digivoice.com.br                                      *
 *                                                                         *
 *   This program is free software, distributed under the terms of         * 
 *   the GNU General Public License Version 2. See the LICENSE file        *
 *   at the top of the source tree.                                        *
 *                                                                         *
 ***************************************************************************/

#ifndef __DGVCHANNEL_H__
#define __DGVCHANNEL_H__

void *dgv_channel_tech_pvt(const struct ast_channel *chan);
void dgv_channel_tech_pvt_set(struct ast_channel *chan, void *value);
int dgv_channel_hangupcause(const struct ast_channel *chan);
void dgv_channel_hangupcause_set(struct ast_channel *chan, int value);
enum ast_channel_state dgv_channel_state(const struct ast_channel *chan);
void dgv_channel_state_set(struct ast_channel *chan, enum ast_channel_state value);
const char *dgv_channel_name(const struct ast_channel *chan);
struct ast_party_id dgv_channel_connected_effective_id(struct ast_channel *chan);
const struct ast_channel_tech *dgv_channel_tech(const struct ast_channel *chan);
void dgv_channel_tech_set(struct ast_channel *chan, const struct ast_channel_tech *value);
const char *dgv_channel_context(const struct ast_channel *chan);
const char *dgv_channel_exten(const struct ast_channel *chan);
void dgv_channel_exten_set(struct ast_channel *chan, const char *value);
unsigned short dgv_channel_transfercapability(const struct ast_channel *chan);
struct ast_channel *dgv_bridged_channel(struct ast_channel *chan);
int dgv_channel_is_bridged(struct ast_channel *chan);
#ifdef CC_AST_HAS_VERSION_13
	#include "asterisk/format_compatibility.h"
	uint64_t dgv_format_cap_to_old_bitfield(const struct ast_format_cap *cap);
#else//#ifdef CC_AST_HAS_VERSION_13
	#ifdef CC_AST_HAS_VERSION_10
		int dgv_format_cap_to_old_bitfield(const struct ast_format_cap *cap);
	#endif//#ifdef CC_AST_HAS_VERSION_10
#endif//#ifdef CC_AST_HAS_VERSION_13
/*
void ConvCodeGSM(unsigned char *szMessage);
*/

void *dgv_channel_tech_pvt(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_tech_pvt(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->tech_pvt;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
void dgv_channel_tech_pvt_set(struct ast_channel *chan, void *value)
{
	#ifdef CC_AST_HAS_VERSION_11
		ast_channel_tech_pvt_set(chan, value);
	#else//#ifdef CC_AST_HAS_VERSION_11
		chan->tech_pvt = value;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
int dgv_channel_hangupcause(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_hangupcause(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->hangupcause;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
void dgv_channel_hangupcause_set(struct ast_channel *chan, int value)
{
	#ifdef CC_AST_HAS_VERSION_11
		ast_channel_hangupcause_set(chan, value);
	#else//#ifdef CC_AST_HAS_VERSION_11
		chan->hangupcause = value;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
enum ast_channel_state dgv_channel_state(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_state(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->_state;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
void dgv_channel_state_set(struct ast_channel *chan, enum ast_channel_state value)
{
	#ifdef CC_AST_HAS_VERSION_11
		ast_channel_state_set(chan, value);
	#else//#ifdef CC_AST_HAS_VERSION_11
		chan->_state = value;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
const char *dgv_channel_name(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_name(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->name;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
#ifdef CC_AST_HAS_VERSION_11
	struct ast_party_id dgv_channel_connected_effective_id(struct ast_channel *chan)
	{
		return ast_channel_connected_effective_id(chan);
	}
#endif//#ifdef CC_AST_HAS_VERSION_11
const struct ast_channel_tech *dgv_channel_tech(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_tech(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->tech;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
void dgv_channel_tech_set(struct ast_channel *chan, const struct ast_channel_tech *value)
{
	#ifdef CC_AST_HAS_VERSION_11
		ast_channel_tech_set(chan, value);
	#else//#ifdef CC_AST_HAS_VERSION_11
		chan->tech = value;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
const char *dgv_channel_context(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_context(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->context;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
const char *dgv_channel_exten(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_exten(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->exten;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
void dgv_channel_exten_set(struct ast_channel *chan, const char *value)
{
	#ifdef CC_AST_HAS_VERSION_11
		ast_channel_exten_set(chan, value);
	#else//#ifdef CC_AST_HAS_VERSION_11
		ast_copy_string(chan->exten, value, sizeof(chan->exten));
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
unsigned short dgv_channel_transfercapability(const struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_11
		return ast_channel_transfercapability(chan);
	#else//#ifdef CC_AST_HAS_VERSION_11
		return chan->transfercapability;
	#endif//#ifdef CC_AST_HAS_VERSION_11
}
struct ast_channel *dgv_bridged_channel(struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_12
		return ast_channel_bridge_peer(chan);
	#else//#ifdef CC_AST_HAS_VERSION_12
		return ast_bridged_channel(chan);
	#endif//#ifdef CC_AST_HAS_VERSION_12
}
int dgv_channel_is_bridged(struct ast_channel *chan)
{
	#ifdef CC_AST_HAS_VERSION_12
		return ast_channel_is_bridged(chan);
	#else//#ifdef CC_AST_HAS_VERSION_12
		return ast_bridged_channel(chan) != NULL;
	#endif//#ifdef CC_AST_HAS_VERSION_12
}
#ifdef CC_AST_HAS_VERSION_10
	#ifdef CC_AST_HAS_VERSION_13
		uint64_t dgv_format_cap_to_old_bitfield(const struct ast_format_cap *cap)
	#else//#ifdef CC_AST_HAS_VERSION_13
		int dgv_format_cap_to_old_bitfield(const struct ast_format_cap *cap)
	#endif//#ifdef CC_AST_HAS_VERSION_13
{
	#ifdef CC_AST_HAS_VERSION_13
		uint64_t bitfield = 0;
		int x;

		for (x = 0; x < ast_format_cap_count(cap); x++)
		{
			struct ast_format *format = ast_format_cap_get_format(cap, x);

			//bitfield |= ast_format_compatibility_format2bitfield(format);
			ast_format_compatibility_format2bitfield(format);

			ao2_ref(format, -1);
		}

		return bitfield;
	#else//#ifdef CC_AST_HAS_VERSION_13
			return ast_format_cap_to_old_bitfield(cap);
	#endif//#ifdef CC_AST_HAS_VERSION_13
}
#endif//#ifdef CC_AST_HAS_VERSION_10

#ifdef CC_AST_HAS_VERSION_10
	struct ast_format_cap *dgv_channel_nativeformats(const struct ast_channel *chan);
	struct ast_format *dgv_channel_rawreadformat(struct ast_channel *chan);
	struct ast_format *dgv_channel_readformat(struct ast_channel *chan);

	struct ast_format_cap *dgv_channel_nativeformats(const struct ast_channel *chan)
	{
		#ifdef CC_AST_HAS_VERSION_11
			return ast_channel_nativeformats(chan);
		#else//#ifdef CC_AST_HAS_VERSION_11
			return chan->nativeformats;
		#endif//#ifdef CC_AST_HAS_VERSION_11
	}
	struct ast_format *dgv_channel_rawreadformat(struct ast_channel *chan)
	{
		#ifdef CC_AST_HAS_VERSION_11
			return ast_channel_rawreadformat(chan);
		#else//#ifdef CC_AST_HAS_VERSION_11
			return &chan->rawreadformat;
		#endif//#ifdef CC_AST_HAS_VERSION_11
	}
	struct ast_format *dgv_channel_readformat(struct ast_channel *chan)
	{
		#ifdef CC_AST_HAS_VERSION_11
			return ast_channel_readformat(chan);
		#else//#ifdef CC_AST_HAS_VERSION_11
			return &chan->readformat;
		#endif//#ifdef CC_AST_HAS_VERSION_11
	}
#endif//#ifdef CC_AST_HAS_VERSION_10

/*
void ConvCodeGSM(unsigned char *szMessage)
{
	int i;
	int nLen = strlen((char *)szMessage);
	for (i = 0; i < nLen; i++)
	{
		if (szMessage[i] > 127)
		{
			switch (szMessage[i])
			{
				case 0xE4: //�
					szMessage[i] = 0xE4;
					break;
				case 0xC4: //�
					szMessage[i] = 0xC4;
					break;
				case 0xE0: //�
					szMessage[i] = 0xE0;
					break;
				case 0xC0: //�
					szMessage[i] = 'A';
					break;
				case 0xE1: //�
					szMessage[i] = 'a';
					break;
				case 0xC1: //�
					szMessage[i] = 'A';
					break;
				case 0xE2: //�
					szMessage[i] = 'a';
					break;
				case 0xC2: //�
					szMessage[i] = 'A';
					break;
				case 0xE3: //�
					szMessage[i] = 'a';
					break;
				case 0xC3: //�
					szMessage[i] = 'A';
					break;
				case 0xe8: //�
					szMessage[i] = 0xE8;
					break;
				case 0xc8: //�
					szMessage[i] = 'E';
					break;
				case 0xe9: //�
					szMessage[i] = 0xE9;
					break;
				case 0xc9: //�
					szMessage[i] = 0xC9;
					break;
				case 0xea: //�
					szMessage[i] = 'e';
					break;
				case 0xca: //�
					szMessage[i] = 'E';
					break;
				case 0xeb: //�
					szMessage[i] = 'e';
					break;
				case 0xcb: //�
					szMessage[i] = 'E';
					break;
				case 0xec: //�
					szMessage[i] = 0xEC;
					break;
				case 0xcc: //�
					szMessage[i] = 'I';
					break;
				case 0xed: //�
					szMessage[i] = 'i';
					break;
				case 0xcd: //�
					szMessage[i] = 'I';
					break;
				case 0xef: //�
					szMessage[i] = 'i';
					break;
				case 0xcf: //�
					szMessage[i] = 'I';
					break;
				case 0xee: //�
					szMessage[i] = 'i';
					break;
				case 0xce: //�
					szMessage[i] = 'I';
					break;
				case 0xf2: //�
					szMessage[i] = 0xF2;
					break;
				case 0xd2: //�
					szMessage[i] = 'O';
					break;
				case 0xf6: //�
					szMessage[i] = 0xF6;
					break;
				case 0xd6: //�
					szMessage[i] = 0xD6;
					break;
				case 0xf3: //�
					szMessage[i] = 'o';
					break;
				case 0xd3: //�
					szMessage[i] = 'O';
					break;
				case 0xf4: //�
					szMessage[i] = 'o';
					break;
				case 0xd4: //�
					szMessage[i] = 'O';
					break;
				case 0xf9: //�
					szMessage[i] = 0xF9;
					break;
				case 0xd9: //�
					szMessage[i] = 'U';
					break;
				case 0xfc: //�
					szMessage[i] = 0xFC;
					break;
				case 0xdc: //�
					szMessage[i] = 0xDC;
					break;
				case 0xfa: //�
					szMessage[i] = 'u';
					break;
				case 0xda: //�
					szMessage[i] = 'U';
					break;
				case 0xfb: //�
					szMessage[i] = 'u';
					break;
				case 0xdb: //�
					szMessage[i] = 'U';
					break;
				case 0xe7: //�
					szMessage[i] = 0xE7;
					break;
				case 0xc7: //�
					szMessage[i] = 0xE7;
					break;
				case 0xf1: //�
					szMessage[i] = 0xF1;
					break;
				case 0xd1: //�
					szMessage[i] = 0xD1;
					break;
				case 0xff: //�
					szMessage[i] = 'y';
					break;
				default:
					szMessage[i] = '?';
			}
		}
	}
}
*/

#define TAMSTR				255
#define MAX_SAMPLE_SIZE 	320

#define DGV_SAMPLES         160 
#define DGV_MAX_BUF         DGV_SAMPLES*25 + AST_FRIENDLY_OFFSET

#define NUM_SPANS_PER_CARD              2
#define NUM_DCHANS  (MAX_CARDS*NUM_SPANS_PER_CARD)

#define    TX      1
#define    RX      0

#define NUM_SMSCHANNEL      20
#define NUM_MAXDIALOPT      20

/* dgv ports states */
enum {
	DG_AST_NONE,
	DG_AST_RINGING,
	DG_AST_INCOMING_CALL,
	DG_AST_WAITFORDIALTONE,
	DG_AST_DIALING,
	DG_AST_CALLING,
	DG_AST_CONVERSATION,
	DG_AST_R2_SIGNALLING,
    DG_AST_FLASHING,
    DG_AST_HANGINGUP
};

/* Signalling types */
/* These types will be used to differentiate cards and signalling types of
the same card */
enum {
	DG_SIG_FXO,
	DG_SIG_R2_NDIS_FIXED,
    DG_SIG_R2_NDIS_VARIABLE,
    DG_SIG_PRI,
    DG_SIG_CUSTOMCAS,
    DG_SIG_FXS,
    DG_SIG_CB_FXS,
    DG_SIG_CB_FXO,
    DG_SIG_GSM
};

/* dgv log control */
enum
{
	DG_LOG_ALL_DISABLED      = 0x00000000, /*   0 */
	DG_LOG_START_END_CALL    = 0x00000001, /*  10 */
    DG_LOG_FIND_PORT         = 0x00000002, /*  20 */
    DG_LOG_ISDN_EVENTS       = 0x00000004, /*  30 */
	DG_LOG_THREADS           = 0x00000008, /*  40 */
	DG_LOG_GENERAL_EVENTS    = 0x00000010, /*  50 */
	DG_LOG_READ_SAMPLES      = 0x00000020, /*  60 */
	DG_LOG_AST_QUEUE_FRAME   = 0x00000040, /*  70 */
	DG_LOG_WRITE_SAMPLES     = 0x00000080, /*  80 */
	DG_LOG_LOAD_RESET_UNLOAD = 0x00000100, /*  90 */
	DG_LOG_AST_INDICATE      = 0x00000200, /* 100 */
	DG_LOG_PAUSEINPUTBUFFER  = 0x00000400, /* 110 */
};

#ifdef USE_LIBPRI
//--------------------------------------
// structure that holds pri information
//--------------------------------------
/* struct that holds pri information */
struct dgv_dchan {
    short card;
    short span;
    short pritype;
    short switchtype;
    short resetting;
    short alarmed;
    short overlapdial;
    unsigned int pridialplan;
    unsigned int prilocaldialplan;
    short facilityenable;                        /*!< Enable facility IEs */
    int discardremoteholdretrieval;              /*!< shall remote hold or remote retrieval notifications be discarded? */
    struct pri *pri;
    int fds[2];						             /*!< FD's for d-channels - using socketpairs */
};

struct dgv_dchan dchans[MAX_CARDS*NUM_SPANS_PER_CARD];
int dchans_count = 0;
static int fdmax=-1;                             // maximum file descriptor number

/* ISDN global variables */
//int pritype = PRI_CPE;
//int switchtype = PRI_SWITCH_EUROISDN_E1;
#endif//#ifdef USE_LIBPRI

struct dgv_pvt *round_robin[240];

struct dgv_statistics {
	struct timeval answer;
	struct timeval last_answered;
	struct timeval total_time;
	int calls_answered;
	int sms_sent;
	char last_reset[256];
};

static struct dgv_pvt {

	ast_mutex_t lock;			                 /* private lock */
	
#ifdef DEBUG_LAST_LOCK
	int  lock_last_lineno;
	char lock_last_func[256];
	char lock_last_mutex_name[256];
	int  lock_last_port;	
	int  lock_last_res;
#endif//#ifdef DEBUG_LAST_LOCK

#ifdef DEBUG_Q
	FILE *rec;
	FILE *play;
#endif


	char dev[256];				                 /* Device name, eg vpb/1-1 */
	short board;					             /* board number */
	int serial_num;                              /* board Serial Number */
	int firmware_vr_board;                       /* The firmware version by board (DGV-2E1F and DGV-1E1F) */
	int lec_count_board;                         /* The LEC count by board (DGV-2E1F and DGV-1E1F) */
	int irq_num;                                 /* board IRQ Number */
	short ch_board;				                 /* relative port number - within the card*/

    /* debug purposes */
    int force_drop_tx;
    int force_drop_rx;

	short last_dtmf;			                 /* stores last dtmf and send it when receive silence */

    int pipe[2];

    short sig;            /* signalling used */

    char buf[DGV_MAX_BUF];			/* Static buffer for reading frames */

	char accountcode[AST_MAX_ACCOUNT_CODE];		//Account code
    char language[MAX_LANGUAGE];		/* language being used */

	short port;						/* absolute port number */
	short group;					/* group this port belongs to */

#ifdef CC_AST_HAS_VERSION_13
		uint64_t write_last_format; /* hold last play format */
		uint64_t read_last_format;  /* hold last record format */
#else//#ifdef CC_AST_HAS_VERSION_13
		int write_last_format;      /* hold last play format */
		int read_last_format;       /* hold last record format */
#endif//#ifdef CC_AST_HAS_VERSION_13

	int nativeformats;

	ast_mutex_t play_lock;			/* mutex for playing */
	ast_mutex_t record_lock;		/* mutex for recording */

    pthread_t tone_thread_id;			/* pthread_t is unsigned long int */
	short tone_thread_running;		//flag indicating thread is running or not
	short tone_thread_type;				//type of tone - busy or ringback
	short setting_tone_thread_values;                //control flag
	int tone_thread_timevalues[4];
	int tone_thread_tonetype[2];

  	//call control sctructure
	short call_state;

    short gen_ringback;             /* indicates if use or not ringback tone */
    short gen_busy;                 /* indicates if use or not busy tone */

    short flashing;                              //used into DgvChannel and DgCollectCallBlock

	char szNumberToDial[TAMSTR];

    char callprogress[TAMSTR];

	char context[AST_MAX_CONTEXT];
	int amaflags;

    char musicclass[MAX_MUSICCLASS];

	ast_group_t callgroup;
	ast_group_t pickupgroup;    
	char callgroupcfg[AST_MAX_EXTENSION];
	char pickupgroupcfg[AST_MAX_EXTENSION];

	char exten[AST_MAX_EXTENSION];
	char rdnis[AST_MAX_EXTENSION];
	char dnid[AST_MAX_EXTENSION];
	char cid_num[AST_MAX_EXTENSION];
	char cid_name[AST_MAX_EXTENSION];
	char pri_cid_num[AST_MAX_EXTENSION];
	char pri_cid_name[AST_MAX_EXTENSION];
	char cid_category[AST_MAX_EXTENSION];

	//individual port configuration
	char szPortID[AST_MAX_EXTENSION];
	char szPortName[AST_MAX_EXTENSION];
	short category;
	short category_pass_through;                 /* send the received category to the other side */
	short max_digits_rx;
    short min_digits_rx;
    //short auto_r2dmfc;
	short interdigit_timeout;
	short tx_gain;
	short rx_gain;
	short ask_for_cid_position;
	short echo_can;
	short echo_type;
	short echo_training;
    short echo_nlp;
    short dialplan_echocan;                      //set dialplan var (DGV_ECHOTAPS)
    short dialplan_echotraining;                 //set dialplan var (DGV_ECHOTRAINING)
    char dialplan_senddtmf[20];                  //set dialplan var (DGV_SENDDTMF)
    char dialplan_group_b[20];                   //set dialplan var (DGV_GROUP_B_...)

    short drop_tx_samples_factor;                //factor to drop tx samples (8 = 160ms, etc..)

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
		struct ast_jb_conf jbconf;
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

    short gen_dtmf;                              /* 0 - don't generate, 1 - generate */

    short dtmf_to_asterisk;                      /* 0 - don't generate, 1 - generate */

    short relaxdtmf;

    short b_subscriber_hangup;                   /* b subscriber can hangs up */
    short ccb_pass_through;                      /* send the ccb signal received to pstn side */
    short auto_dgccb;                            /* enable ccb for all incoming calls */
    char deny_prefix[AST_MAX_EXTENSION];         /* this dialed prefix will be denied */
    
    short vconf_pass_through;                    /* old vconf signalling (lb) */
	short vconf_port_bridged;                    /* vconf port bridged with ... */
	short vconf_established;                     /* port has a vconf established */

    short group_b_value;                         /* group b to be sent when using ndis variable */
    short r2_country;                            /* set r2 country */
    short group_b_received;                      /* group b received */

    short wait_group_b;                          /* wait for group b received from the other side */
    short group_b_port_bridged;                  /* send group b to port bridged ... */
    short category_port_bridged;                 /* send category to port bridged ... */

	short audio_debug;

	unsigned short verbosity;                    /* specific port verbosity */

	int   faxhandled;                            /* Has a fax tone already been handled? */
	int   fax_tone_state;                        /* Has a fax tone CNG or CED detected? */
	int   fxo_bridged_dial;                      /* don't generate dtmf and silence(mute) when setted */

#ifdef CC_AST_HAS_VERSION_10
		#ifdef CC_AST_HAS_VERSION_13
			struct ast_format *pref_format;      //stores audio format
		#else//#ifdef CC_AST_HAS_VERSION_13
			struct ast_format pref_format;       //stores audio format
		#endif//#ifdef CC_AST_HAS_VERSION_13
#else//#ifdef CC_AST_HAS_VERSION_10
		int pref_format;                         //stores audio format
#endif//#ifdef CC_AST_HAS_VERSION_10

	short reserved;            					 /* channel reserved */
	short alarmed;            					 /* channel in alarm */
	short locked;            					 /* channel locked */

	int last_r2_signal;                          /* save last r2 */
	
    short dialtone_timeout;                      //time to wait linetone
    short wait_dialtone;                         //wait for dialtone?
    short fax_detection;                         //enable fax detection?

    short fax_pass_through;                      /* fax pass through enabled */
	short fax_port_bridged;                      /* fax port bridged with ... */
	short fax_established;                       /* port has a fax established */

	int digit_timeout_sched;
    int linetone_timeout_sched;
    int alarmNDT_timeout_sched;
	int ring_timeout_sched;                      //ast_sched to ring on FXO card
	//int fxss_digit_timeout_sched;
	int all_echotraining_sched;
	int second_call_sched;
	int need_sc_ring_sched;
	int senddtmf_dialtone_timeout_sched;
	int reserved_timeout_sched;
	int gsmerror_timeout_sched;
	int gsmgetsignal_timeout_sched;
	int gsmclearsms_timeout_sched;
	int gsmsendsms_timeout_sched;                /* Used only when we don't have the lock_console function during SMS send function */
    
    short silence_threshold;                     /* value of silence threshold during conversation */
    short polarity;                              /* polarity detection/generation on FXO or FXS signalling */
    short cid_detection_type;                    /* fxo signalling detects DTMF or FSK CID */

	struct ast_channel *ast_ch;		             /* store asterisk channel pointer or NULL */
	struct ast_frame f;							 /* send voice frame on queue_frame */

	struct dgv_pvt *next;					     /* Next channel in list */
	struct dgv_pvt *previous;			         /* previous channel in list */

	//buffers to use in SamplesFromCard
	char  BufferRec8[MAX_SAMPLE_SIZE/2 + AST_FRIENDLY_OFFSET];
	short BufferRec16[MAX_SAMPLE_SIZE + AST_FRIENDLY_OFFSET];

	struct timeval tlastdigit;		/* used for digit timeout */

	unsigned long		samples_rx_count;

	struct dgv_statistics statistics;

#ifdef USE_LIBPRI
	q931_call *call;
    struct pri *pri;
    char internationalprefix[10];				 /*!< country access code ('00' for european dialplans) */
    char nationalprefix[10];					 /*!< area access code ('0' for european dialplans) */
    char localprefix[20];						 /*!< area access code + area code ('0'+area code for european dialplans) */
    char privateprefix[20];						 /*!< for private dialplans */
    char unknownprefix[20];						 /*!< for unknown dialplans */
	int cid_ton;								 /*!< Type Of Number (TON) */
	//int immediate;
	int pri_channel;
    int alreadyhungup;              			 //controls if isdn channel is already hangup
    int stripmsd;
    int alerting;								 //controls the ALERTING message
    int outgoing;								 //controls the ALERTING message
	int proceeding;                              //controls the PROCEEDING message
	int progress;                                //controls the PROGRESS message
	int reverse_charging;                        //read reversecharge libpri ring variable
	char useruserinfo[256];                      //read user user information libpri ring variable

	int alerting_sig_timeout_sched;              //controls the ALERTING message by application app_dgsendisdnsig.c
	int proceeding_sig_timeout_sched;            //controls the PROCEEDING message by application app_dgsendisdnsig.c
	int progress_sig_timeout_sched;              //controls the PROGRESS message by application app_dgsendisdnsig.c
#endif//#ifdef USE_LIBPRI

    int digital;
    int use_callerid;
    char customcascfg[TAMSTR];
    
    short need_ringback;						 /* generate ringback thread after EV_AFTERDIAL */
    
//for fxs cards
	int ring_type;
    int flash_min_time;	    		
	int flash_max_time;
	int immediate;
    char mailbox[AST_MAX_EXTENSION];    
    pthread_t stuttertone_thread_id;			 /* pthread_t is unsigned long int */
	short stuttertone_thread_running;		     //flag indicating if thread is running or not
	short fxss_thread_running;				     //flag indicating if thread is running or not
	int fv_thread_timeout;						 //timeout to fv thread
	short need_fv_thread;						 //1 before ast_pbx_run, 0 after ast_pbx_run

	struct dgv_pvt *subchannel;			         /* store subchannel's pointer or NULL */
	int channel_index;                           /* subchannel or smschannel ??? */
	int subchannel_audio_index;                  /* audio from ??? channel */
    pthread_t subchanneltone_thread_id;			 /* pthread_t is unsigned long int */
	short subchanneltone_thread_running;		 //flag indicating thread is running or not
	int subchanneltone_thread_timevalues[4];
	int subchanneltone_thread_tonetype[2];
	short second_call;                           /* use second call/subchannel */
	char second_call_digits[5];                  /* digits to exchange between first and second call */
	int scd_step;                                /* control the feature step */
	char sc_save_digits[5];                      /* save digits to dial after know if we'll not bridged second call */
	pthread_t beeptone_thread_id;			     /* pthread_t is unsigned long int */
	short need_sc_ring;                          /* control flag when b hangup and need a second call */
	
//for gsm cards
	char gsm_operator_name[20];                  /* operator name */
	char gsm_simcard_id[40];                     /* sim card id */
	short gsm_hide_number;                       /* control flag to show/hide my number(CID) */
	short gsm_sms_confirmation;                  /* control flag to enable/disable sms confirmation */
	short gsm_sms_flashsms;                      /* control flag to enable/disable flash sms */
	short gsm_displaycallwaiting;                /* control flag to enable/disable display call waiting information */
	char gsm_pin_number[5];                      /* set the pin number */
	short sms_reserved;            				 /* sms channel reserved */
	char sms_send_to[40];            			 /* sending sms to */
	short sms_send_messagereference;             /* temporary variable to store message reference (MR) number after success sending a sms */
	char sms_send_custom_id[40];                 /* temporary variable to store a custom id during send sms message */
	short sms_sent_status;            			 /* sms sent status (-1 for Timeout, 0 for Not Set and 1 for Sucess) */
	struct dgv_pvt *smschannel[NUM_SMSCHANNEL];	 /* store smschannel's pointer or NULL */
	struct dgv_pvt *iffirstsmschannel;
	struct dgv_pvt *iflastsmschannel;
	int smschannel_index;                        /* Who am I */
	short gsm_need_reload;                       /* controls a future reload when a channel is sending a sms or is dialing */
	short gsm_start_log;                         /* if there is not a SIM card, do not show the "MODULE START ERROR..." message */
	pthread_t gsm_getsignal_thread_id;           /* Id used in thread */
	char sms_sent_tmpMessageError[TAMSTR];       /* temporary variable to store vlibd sms sent error */

	char sms_received_from[40];                  /* SMS message received */
	char sms_received_simcardid[40];             /* SMS message received */
	char sms_received_date[20];                  /* SMS message received */
	char sms_received_time[20];                  /* SMS message received */
	char sms_received_text[200];                 /* SMS message received */
	char sms_received_st_cod[200];               /* SMS message received */
	char sms_received_mr[20];                    /* SMS message received */
	char ussd_received_text[200];                /* USSD message received */

} *iflast = NULL, *iffirst = NULL;

#endif

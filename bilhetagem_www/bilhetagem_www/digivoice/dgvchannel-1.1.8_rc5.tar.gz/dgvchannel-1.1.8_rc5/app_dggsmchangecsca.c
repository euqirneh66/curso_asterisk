
/*****************************************************************************
 *                                                                           *
 *   app_dggsmchangecsca.c - DgGSMChangeCSCA application for DigiVoice Cards.*
 *                                                                           *
 *   Copyright (c) 2015, DigiVoice Tecnologia em Eletronica Ltda             *
 *                                                                           *
 *   Author: Luciano Alves Barroso                                           *
 *   l.barroso@digivoice.com.br                                              *
 *                                                                           *
 *   This software is licensed under GPL                                     *
 *   Check LICENSE file for details                                          *
 *                                                                           *
 *****************************************************************************/
 
#include "asterisk.h"
#include "config.h"

ASTERISK_FILE_VERSION(__FILE__, "$Revision: 5623 $")

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <voicerlib/voicerlib.h>
#include <voicerlib/vlibdef.h>

#include "asterisk/lock.h"
#include "asterisk/file.h"
#include "asterisk/logger.h"
#include "asterisk/channel.h"
#include "asterisk/pbx.h"
#include "asterisk/module.h"
#include "asterisk/translate.h"
#include "asterisk/image.h"
#include "asterisk/options.h"
#include "asterisk/config.h"
#include "asterisk/app.h"

#include "dgvchannel.h"

#define AST_MODULE "ael"

#define DEFAULT_GSM_READ_SMSC_ADDRESS "AT+CSCA?"
#define DEFAULT_GSM_WRITE_SMSC_ADDRESS "AT+CSCA="

#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	#define AST_DECLARE_APP_ARGS(name, arglist) \
		struct { \
			unsigned int argc; \
			char *argv[0]; \
			arglist \
		} name
#endif//#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#define AST_APP_ARG(name) char *name

/*#define AST_STANDARD_APP_ARGS(args, parse) \
	args.argc = ast_app_separate_args(parse, '|', args.argv, (sizeof(args) - sizeof(args.argc)) / sizeof(args.argv[0]))*/

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	static char *tdesc = "Change GSM CSCA (SMSC Address) for a dgv GSM application";
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

static char *app = "DgGSMChangeCSCA";

static char *synopsis = "Change GSM CSCA on a GSM channel";

static char *descrip = 
"  DgGSMChangeCSCA(port,read/write[,service_center_address]): Change GSM CSCA on a GSM channel. \n\n";

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	STANDARD_LOCAL_USER;

	LOCAL_USER_DECL;
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#ifdef CC_AST_HAS_VERSION_1_8
	static int changegsmcsca_exec(struct ast_channel *chan, const char *data)
#else//#ifdef CC_AST_HAS_VERSION_1_8
	static int changegsmcsca_exec(struct ast_channel *chan, void *data)
#endif//#ifdef CC_AST_HAS_VERSION_1_8
{
	int res = -1;
	char *parse;

	short port;
    char rw[10] = "";
    char sca[30] = "";
    const struct ast_channel_tech *chan_tech;

    static const char type[] = "DGV";

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    struct ast_module_user *u;
    
    u = ast_module_user_add(chan);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	struct localuser *u;
	
    LOCAL_USER_ADD(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

    AST_DECLARE_APP_ARGS(args,
                         AST_APP_ARG(channel);
                         AST_APP_ARG(rw);
                         AST_APP_ARG(sca);
    );

    if (ast_strlen_zero(data)) {
        ast_log(LOG_WARNING, "DgGSMChangeCSCA requires 2 arguments \n");
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    if (!(parse = ast_strdupa(data))) {
        ast_log(LOG_WARNING, "app_DgGSMChangeCSCA: Memory allocation failure\n");
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    AST_STANDARD_APP_ARGS(args, parse);

    if (args.argc <= 1 || args.argc > 3) {
        ast_log(LOG_ERROR, "app_DgGSMChangeCSCA: Wrong argument\n");
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    //receive parameters
    port = atoi(args.argv[0]);
    ast_copy_string(rw, args.argv[1], sizeof(rw));

	chan_tech = ast_get_channel_tech(type);
	if (!chan_tech)
		ast_log(LOG_WARNING, "app_DgGSMChangeCSCA: There is not a DGV channel running\n");
	else
	{
		if (port <= 0)
			ast_log(LOG_WARNING, "app_DgGSMChangeCSCA: Invalid port -> %d\n", port);
		else
		{
			if (dg_GetPortInterface(port) == DG_GSM_INTERFACE)
			{
				if ((!strncmp(rw, "read", 4)) || (!strncmp(rw, "r", 1)))
				{
					res = dg_GSMSendCommand(port, DEFAULT_GSM_READ_SMSC_ADDRESS);

					if (option_verbose >= 3)
						ast_verbose(VERBOSE_PREFIX_3 "app_DgGSMChangeCSCA is reading SMSC address on port %d.\n", port);
				}
				else
				{
					if ((!strncmp(rw, "write", 5)) || (!strncmp(rw, "w", 1)))
					{
						if (args.argc < 3)
							ast_log(LOG_ERROR, "app_DgGSMChangeCSCA: Wrong argument\n");
						else
						{
							char szGSMCMD[10] = "";

							ast_copy_string(sca, args.argv[2], sizeof(sca));
							sprintf(szGSMCMD, "%s%s", DEFAULT_GSM_WRITE_SMSC_ADDRESS, sca);
							res = dg_GSMSendCommand(port, szGSMCMD);

							if (option_verbose >= 3)
								ast_verbose(VERBOSE_PREFIX_3 "app_DgGSMChangeCSCA is writing SMSC address (%s) on port %d.\n", sca, port);
						}
					}
					else
					{
						ast_log(LOG_WARNING, "app_DgGSMChangeCSCA: Error, the second parameter must be read or write\n\n", port);
					}
				}
			}
			else
			{
				ast_log(LOG_WARNING, "app_DgGSMChangeCSCA: Error, Port %d is not a GSM port!\n\n", port);
			}
		}
	}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    
    if (res != 0)
		if (option_verbose >= 3)
		    ast_log(LOG_WARNING, "app_DgGSMChangeCSCA did not read/write SMSC address...(err %d)\n", res);

    iffirst = iffirst;
	iflast = iflast;

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int unload_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int unload_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	int res;

	res = ast_unregister_application(app);
	
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    	ast_module_user_hangup_all();
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
		STANDARD_HANGUP_LOCALUSERS;
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int load_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int load_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	return ast_register_application(app, changegsmcsca_exec, synopsis, descrip);
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	AST_MODULE_INFO_STANDARD(ASTERISK_GPL_KEY, "Change GSM CSCA (SMSC Address) for a dgv GSM application");
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	char *description(void)
	{
		return tdesc;
	}
	
	int usecount(void)
	{
		int res;
		STANDARD_USECOUNT(res);
		return res;
	}
	
	char *key()
	{
		return ASTERISK_GPL_KEY;
	}
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)


/***************************************************************************
 *                                                                         *
 *   app_dgsendisdnsig.c - DgSendISDNSig application for DigiVoice Cards.  *
 *                                                                         *
 *   Copyright (c) 2013, DigiVoice Tecnologia em Eletronica Ltda           *
 *                                                                         *
 *   Author: Luciano Alves Barroso                                         *
 *   l.barroso@digivoice.com.br                                              *
 *                                                                         *
 *   This software is licensed under GPL                                   *
 *   Check LICENSE file for details                                        *
 *                                                                         *
 *-------------------------------------------------------------------------*/
 
#define USE_LIBPRI

#include "asterisk.h"
#include "config.h"

ASTERISK_FILE_VERSION(__FILE__, "$Revision: 5623 $")

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <voicerlib/voicerlib.h>

#include "asterisk/lock.h"
#include "asterisk/file.h"
#include "asterisk/logger.h"
#include "asterisk/channel.h"
#include "asterisk/pbx.h"
#include "asterisk/module.h"
#include "asterisk/translate.h"
#include "asterisk/image.h"
#include "asterisk/options.h"
#include "asterisk/config.h"
#include "asterisk/app.h"

#ifdef USE_LIBPRI
    #include <libpri.h>
#endif//#ifdef USE_LIBPRI

#include "dgvchannel.h"

#define AST_MODULE "ael"

#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	#define AST_DECLARE_APP_ARGS(name, arglist) \
		struct { \
			unsigned int argc; \
			char *argv[0]; \
			arglist \
		} name
#endif//#if !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#define AST_APP_ARG(name) char *name

/*#define AST_STANDARD_APP_ARGS(args, parse) \
	args.argc = ast_app_separate_args(parse, '|', args.argv, (sizeof(args) - sizeof(args.argc)) / sizeof(args.argv[0]))*/

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	static char *tdesc = "Send ISDN Signal for a dgv trunk application";
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

static char *app = "DgSendISDNSig";

static char *synopsis = "Send ISDN Signal on a Dgv Trunk";

static char *descrip = 
"  DgSendISDNSig(signal, pause_before_send): Send ISDN Signal on a Dgv Trunk. \n\n";

#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)
	STANDARD_LOCAL_USER;

	LOCAL_USER_DECL;
#endif//#if !defined(CC_AST_HAS_VERSION_1_4) && !defined(CC_AST_HAS_VERSION_1_6) && !defined(CC_AST_HAS_VERSION_1_8)

#ifdef CC_AST_HAS_VERSION_1_8
	static int sendisdnsig_exec(struct ast_channel *chan, const char *data)
#else//#ifdef CC_AST_HAS_VERSION_1_8
	static int sendisdnsig_exec(struct ast_channel *chan, void *data)
#endif//#ifdef CC_AST_HAS_VERSION_1_8
{
	struct dgv_pvt *p = (struct dgv_pvt *)dgv_channel_tech_pvt(chan);
	const struct ast_channel_tech *chan_tech;

    static const char type[] = "DGV";
    static const char cmd_header[] = "DGV_SEND_INDICATE";
    static const char cmd_sep[] = "~";

	int res = -1;
	char *parse;

	char get_isdn_signal[20] = "";
    int pause_before_send;

    char texttosend[30];
    char szPauseTime[30];

	chan_tech = ast_get_channel_tech(type);

	if (!chan_tech)
	{
		ast_log(LOG_WARNING, "There is not a DGV channel running\n");
		return -1;
	}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    struct ast_module_user *u;
    
    u = ast_module_user_add(chan);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	struct localuser *u;
	
    LOCAL_USER_ADD(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

    AST_DECLARE_APP_ARGS(args,
                         AST_APP_ARG(get_isdn_signal);
                         AST_APP_ARG(pause_before_send);
    );

    if (ast_strlen_zero(data)) {
        ast_log(LOG_WARNING, "DgSendISDNSig requires 2 arguments \n");
        return -1;
    }

    if (!(parse = ast_strdupa(data))) {
        ast_log(LOG_WARNING, "Memory allocation failure\n");        
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    AST_STANDARD_APP_ARGS(args, parse);

    if (args.argc!=2) {
        ast_log(LOG_ERROR, "Wrong argument\n");
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }

    //receive parameters
	ast_copy_string(get_isdn_signal, args.argv[0], sizeof(get_isdn_signal));
    pause_before_send = atoi(args.argv[1]);

    if ((pause_before_send < 1) || (pause_before_send > 600))
    {
        ast_log(LOG_ERROR, "Wrong pause_before_send argument\n");
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
        return -1;
    }
    else
    	pause_before_send = pause_before_send*1000;

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	if (!strcasecmp(dgv_channel_tech(chan)->type, "DGV")) {
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	if (!strcasecmp(chan->type, "DGV")) {
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

#ifdef USE_LIBPRI
		if (p)
	        if (p->ast_ch)
	        	if (p->sig == DG_SIG_PRI)
	        		if (!p->outgoing)
	        			if (p->pri)
	        				if (p->call)
	        					if (p->call_state != DG_AST_CONVERSATION)
	        						if (dgv_channel_state(p->ast_ch) != AST_STATE_UP)
	        						{
										if ((!strncmp(get_isdn_signal, "ALERTING", 8)) && (!p->alerting))
										{
		        		            		if (((p->verbosity & DG_LOG_ISDN_EVENTS) != 0) || (((p->verbosity & DG_LOG_AST_INDICATE) != 0)))
		        		            			ast_log(LOG_NOTICE, "app_DgSendISDNSig: Creating isdn alerting signal schedule on port %d (after %d ms)\n", p->port, pause_before_send);

		        		            		ast_copy_string(texttosend, cmd_header, sizeof(texttosend));
		        		            		sprintf(szPauseTime, "%d", pause_before_send);
		        		            		strcat(texttosend, cmd_sep);
		        		            		strcat(texttosend, szPauseTime);
		        		            		strcat(texttosend, "\0");

		        		            		res = chan_tech->indicate(p->ast_ch, AST_CONTROL_RINGING, texttosend, strlen(texttosend));
										}
										else
											if ((!strncmp(get_isdn_signal, "PROCEEDING", 10)) && (!p->proceeding))
											{
			        		            		if (((p->verbosity & DG_LOG_ISDN_EVENTS) != 0) || (((p->verbosity & DG_LOG_AST_INDICATE) != 0)))
			        		            			ast_log(LOG_NOTICE, "app_DgSendISDNSig: Creating isdn proceeding signal schedule on port %d (after %d ms)\n", p->port, pause_before_send);

			        		            		ast_copy_string(texttosend, cmd_header, sizeof(texttosend));
			        		            		sprintf(szPauseTime, "%d", pause_before_send);
			        		            		strcat(texttosend, cmd_sep);
			        		            		strcat(texttosend, szPauseTime);
			        		            		strcat(texttosend, "\0");

			        		            		res = chan_tech->indicate(p->ast_ch, AST_CONTROL_PROCEEDING, texttosend, strlen(texttosend));
											}
											else
												if ((!strncmp(get_isdn_signal, "PROGRESS", 8)) && (!p->progress))
												{
				        		            		if (((p->verbosity & DG_LOG_ISDN_EVENTS) != 0) || (((p->verbosity & DG_LOG_AST_INDICATE) != 0)))
				        		            			ast_log(LOG_NOTICE, "app_DgSendISDNSig: Creating isdn progress signal schedule on port %d (after %d ms)\n", p->port, pause_before_send);

				        		            		ast_copy_string(texttosend, cmd_header, sizeof(texttosend));
				        		            		sprintf(szPauseTime, "%d", pause_before_send);
				        		            		strcat(texttosend, cmd_sep);
				        		            		strcat(texttosend, szPauseTime);
				        		            		strcat(texttosend, "\0");

				        		            		res = chan_tech->indicate(p->ast_ch, AST_CONTROL_PROGRESS, texttosend, strlen(texttosend));
												}
	        						}
#endif//#ifdef USE_LIBPRI
	} else
		ast_log(LOG_WARNING, "%s is not a Dgv channel\n", dgv_channel_name(chan));

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    ast_module_user_remove(u);
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    LOCAL_USER_REMOVE(u);
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    
    if (res != 0)
		if (option_verbose >= 3)
		    ast_log(LOG_WARNING, "app_DgSendISDNSig did not send ISDN Signal...\n");

    iffirst = iffirst;
	iflast = iflast;
	fdmax = fdmax;

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int unload_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int unload_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	int res;

	res = ast_unregister_application(app);
	
#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
    	ast_module_user_hangup_all();
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
		STANDARD_HANGUP_LOCALUSERS;
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

	return res;
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	static int load_module(void)
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	int load_module(void)
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
{
	return ast_register_application(app, sendisdnsig_exec, synopsis, descrip);
}

#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	AST_MODULE_INFO_STANDARD(ASTERISK_GPL_KEY, "Send ISDN Signal for a dgv trunk application");
#else//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)
	char *description(void)
	{
		return tdesc;
	}
	
	int usecount(void)
	{
		int res;
		STANDARD_USECOUNT(res);
		return res;
	}
	
	char *key()
	{
		return ASTERISK_GPL_KEY;
	}
#endif//#if defined(CC_AST_HAS_VERSION_1_4) || defined(CC_AST_HAS_VERSION_1_6) || defined(CC_AST_HAS_VERSION_1_8)

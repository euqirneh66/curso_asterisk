
/***************************************************************************
 *                                                                         *
 *   VoicerLib - Linux Version                                             *
 *                                                                         *
 *   Copyright (c) 2004, Digivoice Tecnologia em Eletr�ica Ltda          *
 *                                                                         *
 *   Module: Linux Specific functions                                      *
 *                                                                         *
 *   Description:                                                          *
 *                                                                         *
 *   Author: Paulo Garcia                                                  
 *   Email: paulo@digivoice.com.br                                                
 *                                                                         
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *   
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *   
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************/
 

#include <assert.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <linux/version.h>

#define MAX_MSGLEN 80

#include "../src_common/voicerlib.h"
#include "../src_common/vlibdef.h"
#include "../src_common/generic.h"
#include "../src_common/shmem.h"
#include "../src_common/dg_api.h"
#include "linux_api.h"

#ifndef       min
#define min(a,b) (((a)<(b))?(a):(b))
#endif

#ifdef DEBUG
#define output(s, args...)  do{printf (s , ## args); fflush (stdout);} while(0)

#else
#define output(s, args...)
#endif

#ifdef __LINUX__
	extern void write_debug(char *fmt, ...);
#endif


extern DIGIVOICE_CRITICAL_SECTION cmd_mutex;
extern DIGIVOICE_CRITICAL_SECTION event_mutex;


//shared memory structures
DG_RECMEM			*rm[MAX_CARDS*MAX_CHANNELS_CARD];	/* pointer to channel-oriented struct */
DG_GROUPED_RECMEM	*grm[MAX_REC_GROUP];

DG_PLAYBACKMEM			*pm[MAX_CARDS*MAX_CHANNELS_CARD];	/* pointer to channel-oriented struct */
DG_GROUPED_PLAYMEM		*gpm[MAX_PLAY_GROUP];

DG_CCS_MEMORY           *ccsm;           //pointer to CCS_MEMORY

//--------------------------------------------------------------------------------
// Opens main device and put filedescriptor in hWinDriver
//--------------------------------------------------------------------------------
int WD_Open()
{
	short i;
	
	hWinDriver = open (VLIB_DEVICE, O_WRONLY);
	write_debug("WD_Open: Opening %s with handle %x",VLIB_DEVICE,hWinDriver);
	if (hWinDriver<0) 
		return 0;     //error
	else
	{
		//initializes file descriptors for future shared memory
		for (i=0; i< MAX_REC_GROUP;i++)
			fd_rec[i] = -1;
		
		return hWinDriver;
	}
	
}

//--------------------------------------------------------------------------------
// Closes Main device
//--------------------------------------------------------------------------------
short WD_Close(HANDLE hWd)
{
	close(hWinDriver);
	return 1;
}

//--------------------------------------------------------------------------------
// Find how many cards are installed into the system
//--------------------------------------------------------------------------------
u32 dgAPI_CountCards (u32 dwVendorID, u32 dwDeviceID)
{
	return ioctl(hWinDriver, VLIB_IOCTL_COUNTCARDS,dwDeviceID);
}

//----------------------------------------------------------------------
// Cria a memoria compartilhada
//----------------------------------------------------------------------
short CreateSharedMemory()
{
	int i;

	//todo: testar retorno
	write_debug("CreateSharedMemory: Calling ioctl");
	if (ioctl(hWinDriver,VLIB_IOCTL_DMALOCK, 0) == -EINVAL)
		return 0;

	write_debug("CreateSharedMemory: Opening %s",VLIB_SHM_DEVICE);
	//Initializes shared memory - this sm holds all global informations
	fd_shm = open(VLIB_SHM_DEVICE, O_RDWR | O_SYNC);	//novo O_SYNC
	if( fd_shm == -1)
		return 0;			/* error */

	// test mmap
	write_debug("CreateSharedMemory: MMaping %s",VLIB_SHM_DEVICE);
	sm = (DG_SHAREDMEMORY *)mmap(0, sizeof(DG_SHAREDMEMORY), PROT_READ | PROT_WRITE, MAP_FILE | MAP_SHARED, fd_shm, 0);
	if(sm == MAP_FAILED) {
		write_debug("CreateSharedMemory: ERROR MMaping %s",VLIB_SHM_DEVICE);
		close(fd_shm);
		return 0;
	}
		
	//insert initial values into shared memory
	sm->hWD_Global = hWinDriver;
	write_debug("CreateSharedMemory: WD_GLOBAL= %x",sm->hWD_Global);
	//call ioctl to open card, probe plx, etc...
	if (ioctl(hWinDriver, VLIB_IOCTL_OPENBOARDS,0)<0)
	{
		write_debug("CreateSharedMemory : ERROR while VLIB_IOCTL_OPENBOARDS");
		munmap(sm, sizeof(DG_SHAREDMEMORY));
		return 0;
	}

	//Initializes play and rec pointers with NULL
	for (i=0; i < MAX_REC_GROUP; i++)
	{
		grm[i] = NULL;
		gpm[i] = NULL;
		//todo - play
	}
	write_debug("CreateSharedMemory: Exit %s",VLIB_SHM_DEVICE);
	return 99;
}
//----------------------------------------------------------------------
// Closes shared memory device
//----------------------------------------------------------------------
void CloseSharedMemory()
{
	//close card resources
	write_debug("CloseSharedMemory: VLIB_IOCTL_CLOSEBOARDS");
	ioctl(hWinDriver, VLIB_IOCTL_CLOSEBOARDS,0);
	write_debug("CloseSharedMemory: VLIB_IOCTL_CLOSEBOARDS - OK");

	//unmap memory
	write_debug("CloseSharedMemory: DG_SHAREDMEMORY");
	munmap(sm, sizeof(DG_SHAREDMEMORY));
	write_debug("CloseSharedMemory: DG_SHAREDMEMORY - OK");

	/* calls ioctl message to allocate memory into device driver*/
	write_debug("CloseSharedMemory: VLIB_IOCTL_DMAUNLOCK");
	ioctl(hWinDriver,VLIB_IOCTL_DMAUNLOCK, 0);
	write_debug("CloseSharedMemory: VLIB_IOCTL_DMAUNLOCK - OK");
	close(fd_shm);
	write_debug("CloseSharedMemory: close fd_shm");

}
//---------------------------------------------------
//Sets default values to shared memory structure
//---------------------------------------------------
short InitializesSharedMemory()
{
	int i,ch;

	for(i=0;i<sm->nCardsCount;i++)
	{
		//Initializes buffers pointers
		//reset tx and rx pointers
		sm->Cards[i].Fifo_Cmd_Rx.rp = 0;
		sm->Cards[i].Fifo_Cmd_Rx.wp = 0;
		sm->Cards[i].Fifo_Cmd_Tx.wp = 0;
		sm->Cards[i].Fifo_Cmd_Tx.rp = 0;
        write_debug("InitializesSharedMemory: card %d channels %d",i+1, sm->Cards[i].numchannels);
        //ccs mode is disabled by default
        sm->Cards[i].ccs_enabled[0] = 0 ;
        sm->Cards[i].ccs_enabled[1] = 0 ;


		//ports initialization
		for (ch=0; ch < sm->Cards[i].numchannels; ch++)
		{
			sm->Cards[i].playing[ch] = PLAY_OFF;
			sm->Cards[i].input_buffer[ch] = INPUT_BUFFER_OFF;
		}
	}
	return 99;
}

// Creates CCS Shared memory
//todo: 
short InitCCSSharedMem()
{

    write_debug("InitCCSSharedMem: Testing fd_ccs_shm:%d",fd_ccs_shm);
    if (fd_ccs_shm<0) {
    
        if (ioctl(hWinDriver,VLIB_IOCTL_CCS_LOCK, 0) == -EINVAL)
            return DG_EXIT_FAILURE;
    
        write_debug("InitCCSSharedMem: Opening %s",VLIB_SHM_CCS);
        //Initializes shared memory - this sm holds all global informations
        fd_ccs_shm = open(VLIB_SHM_CCS, O_RDWR | O_SYNC);	//novo O_SYNC
        if( fd_ccs_shm == -1)
            return 0;			// error 
    
        // test mmap
        write_debug("InitCCSSharedMem: MMaping %s",VLIB_SHM_CCS);
        ccsm = (DG_CCS_MEMORY *)mmap(0, sizeof(DG_CCS_MEMORY), PROT_READ | PROT_WRITE, MAP_FILE | MAP_SHARED, fd_ccs_shm, 0);
        if(ccsm == MAP_FAILED) {
            write_debug("InitCCSSharedMem: ERROR MMaping %s",VLIB_SHM_CCS);
            close(fd_ccs_shm);
            return DG_EXIT_FAILURE;
        }
    }
    return DG_EXIT_SUCCESS;

}
//Closes CCS Shared memory
//todo: 
void CloseCCSSharedMem()
{
    //unmap memory
    munmap(ccsm, sizeof(DG_CCS_MEMORY));

    close(fd_ccs_shm);

    // calls ioctl message to allocate memory into device drive
    ioctl(hWinDriver,VLIB_IOCTL_CCS_UNLOCK, 0);
    
    fd_ccs_shm = -1;

    write_debug("CloseCCSSharedMem: close fd_ccs_shm");
   
}


//-----------------------------------------------------------------------------
// Cria a memoria compartilhada de grava�o por canal
//-----------------------------------------------------------------------------
short InitRecSharedMem(short port, HANDLE hWD, u32 hKernelPlugIn)
{
	int i;
	ALLOC_STRUCT 	mem_data;
	char			szFD[DG_MAX_PATH];

	mem_data.group = port / MAX_REC_PORTS_PER_GROUP;
	mem_data.port = port;
	mem_data.size = sizeof(DG_GROUPED_RECMEM);
	
	//call device driver to call kmalloc
	if (ioctl(hWinDriver,VLIB_IOCTL_REC_LOCK, &mem_data) == -EINVAL)
		return DG_ERROR_MEMORY_ALLOCATION;
	
	//open control inode
	sprintf(szFD,"%s%d", VLIB_SHM_REC , mem_data.group);
	if (fd_rec[mem_data.group]<=0)
	{
		write_debug("InitRecSharedMem: Opening %s...",szFD);
		fd_rec[mem_data.group] = open(szFD, O_RDWR);
		if( fd_rec[mem_data.group] == -1)
		{
			write_debug("InitRecSharedMem: Error! Cannot open %s!",szFD);	
			return DG_ERROR_MEMORY_ALLOCATION;			/* error */
		}
	}

	if (grm[mem_data.group]==NULL) /* call only one time */
	{
		write_debug("InitRecSharedMem: Calling mmap for group %d..", mem_data.group);
		grm[mem_data.group] = (DG_GROUPED_RECMEM *)mmap(0, sizeof(DG_GROUPED_RECMEM), PROT_READ | PROT_WRITE, MAP_FILE | MAP_SHARED, fd_rec[mem_data.group], 0);
		if(grm[mem_data.group] == MAP_FAILED) 
		{
			write_debug("InitRecSharedMem: Failed do allocate shared memory");
			close(fd_rec[mem_data.group]);
			return DG_ERROR_MEMORY_ALLOCATION;
		}
		write_debug("InitRecSharedMem: rec shared memory for group %d allocated!", mem_data.group);
	}
	
	//Here we set the rm pointer to the correct place into DG_GROUPED_RECMEM structure
	for (i=0; i < grm[mem_data.group]->max_port; i++)
	{
		if (grm[mem_data.group]->ch[i] == port)
		{
			rm[port-1] = &(grm[mem_data.group]->rec[i]);
			write_debug("InitRecSharedMem: rm pointer to port %d is %x", port,  (size_t)rm[port-1]);
		}
	}
	
	
	
	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------------------
// Finaliza a memoria compartilhada de grava�o por canal
//-----------------------------------------------------------------------------
void CloseRecSharedMem(short port)
{

	ALLOC_STRUCT 	mem_data;	

	mem_data.group = port / MAX_REC_PORTS_PER_GROUP;
	mem_data.port = port;
	mem_data.size = sizeof(DG_GROUPED_RECMEM);

	
	if (fd_rec[mem_data.group]>0)
	{	
		write_debug("CloseRecSharedMem: grupo %d",mem_data.group);
		//unmap memory
		munmap(grm[mem_data.group], sizeof(DG_GROUPED_RECMEM));

		ioctl(hWinDriver,VLIB_IOCTL_REC_UNLOCK, &mem_data);
	
		close(fd_rec[mem_data.group]);
		fd_rec[mem_data.group] = -1;

	}
	
}

//-----------------------------------------------------------------------------
// Cria a memoria compartilhada de reprodu�o por canal
//-----------------------------------------------------------------------------
short InitPlaySharedMem(short port, HANDLE hWD, u32 hKernelPlugIn)
{
	int i;
	ALLOC_STRUCT 	mem_data;
	char			szFD[DG_MAX_PATH];

	write_debug("InitPlaySharedMem: Starting 1...%x\n", hWinDriver);

	mem_data.group = port / MAX_PLAY_PORTS_PER_GROUP;
	mem_data.port = port;
	mem_data.size = sizeof(DG_GROUPED_PLAYMEM);
	write_debug("InitPlaySharedMem: Starting 2...");
	//call device driver to call kmalloc
	if (ioctl(hWinDriver,VLIB_IOCTL_PLAY_LOCK, &mem_data) == -EINVAL)
		return DG_ERROR_MEMORY_ALLOCATION;

	write_debug("InitPlaySharedMem: Starting 3...");	
	//open control inode
	sprintf(szFD,"%s%d", VLIB_SHM_PLAY , mem_data.group);
	if (fd_play[mem_data.group]<=0)
	{
		write_debug("InitPlaySharedMem: Opening %s...",szFD);
		fd_play[mem_data.group] = open(szFD, O_RDWR);
		if( fd_play[mem_data.group] == -1)
		{
			write_debug("InitPlaySharedMem: Error! Cannot open %s!",szFD);	
			return DG_ERROR_MEMORY_ALLOCATION;			/* error */
		}
	}

	if (gpm[mem_data.group]==NULL) /* call only one time */
	{
		write_debug("InitPlaySharedMem: Calling mmap for group %d..", mem_data.group);
		gpm[mem_data.group] = (DG_GROUPED_PLAYMEM *)mmap(0, sizeof(DG_GROUPED_PLAYMEM), PROT_READ | PROT_WRITE, MAP_FILE | MAP_SHARED, fd_play[mem_data.group], 0);
		if(gpm[mem_data.group] == MAP_FAILED) 
		{
			write_debug("InitPlaySharedMem: Failed do allocate shared memory");
			close(fd_play[mem_data.group]);
			return DG_ERROR_MEMORY_ALLOCATION;
		}
		write_debug("InitPlaySharedMem: rec shared memory for group %d allocated!", mem_data.group);
	}
	
	//Here we set the pm pointer to the correct place into DG_GROUPED_RECMEM structure
	for (i=0; i < gpm[mem_data.group]->max_port; i++)
	{
		if (gpm[mem_data.group]->ch[i] == port)
		{
			pm[port-1] = &(gpm[mem_data.group]->play[i]);
			write_debug("InitPlaySharedMem: rm pointer to port %d is %x", port,  (size_t)pm[port-1]);
		}
	}
	
	return DG_EXIT_SUCCESS;

}

//-----------------------------------------------------------------------------
// Finaliza a memoria compartilhada de reprodu�o por canal
//-----------------------------------------------------------------------------
void ClosePlaySharedMem(short port)
{
	ALLOC_STRUCT 	mem_data;	

	mem_data.group = port / MAX_PLAY_PORTS_PER_GROUP;
	mem_data.port = port;
	mem_data.size = sizeof(DG_GROUPED_PLAYMEM);

	if (fd_play[mem_data.group]>0)
	{	
		//unmap memory
		munmap(gpm[mem_data.group], sizeof(DG_GROUPED_PLAYMEM));

		ioctl(hWinDriver,VLIB_IOCTL_PLAY_UNLOCK, &mem_data);

		close(fd_play[mem_data.group]);
		fd_play[mem_data.group] = -1;

	}
}

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
short dgAPI_LocateAndOpenBoard(u32 dwVendorID, u32 dwDeviceID, u16 wCardOffset)
{
	u32 cards, my_card;

	cards = dgAPI_CountCards(dwVendorID, dwDeviceID);
	write_debug("dgAPI_LocateAndOpenBoard: %d cards found", cards);
	
	if (cards > 0)
	{
		for (my_card = 0; my_card < MAX_CARDS; my_card++)
		{
			if (sm->Cards[my_card].PlxType == dwDeviceID)
			{
				if (!dgAPI_Open(&hPlxHandle[my_card], dwVendorID, dwDeviceID, my_card))
				{
					return (short)cards;
				}
				else
				{
					hPlxHandle[my_card]->PlxType = dwDeviceID;
					write_debug("dgAPI_LocateAndOpenBoard: hPlxHandle[%d]->PlxType: %x", my_card, hPlxHandle[my_card]->PlxType);
				}
			}
		}		
		
		/*
		for (my_card = wCardOffset; my_card < cards + wCardOffset; my_card++)
		{
			if (!dgAPI_Open(&hPlxHandle[my_card], dwVendorID, dwDeviceID, my_card))
			{
				return (short)cards;
			}
			else
			{
				hPlxHandle[my_card]->PlxType = dwDeviceID;
				write_debug("dgAPI_LocateAndOpenBoard: hPlxHandle[%d]->PlxType: %x", my_card, hPlxHandle[my_card]->PlxType);
			}
		}
		*/
	}
	return (short)cards;
}

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
short dgAPI_Open(VLIB_HANDLE *phE1, u32 dwVendorID, u32 dwDeviceID, u32 nCardNum)
{
  	VLIB_HANDLE hE1 = (VLIB_HANDLE)malloc(sizeof(PLX_STRUCT));

	*phE1 = NULL;

	if (!hE1)
	{
			//Failed allocating memory
			return 0;
	}
	hE1->card = (u8)nCardNum;


	//returns pointer
	*phE1 = hE1;

	return 1;
}
//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------

void dgAPI_Close(VLIB_HANDLE hE1)
{
    // disable interrupts
    /*if (dgAPI_IntIsEnabled(hE1))
        dgAPI_IntDisable(hE1);

    // unregister card
    if (hE1->cardReg.hCard) 
        WD_CardUnregister(hE1->hWD, &hE1->cardReg);

    // close WinDriver
    WD_Close(hE1->hWD);*/
    free (hE1);
}


//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void digivoice_sleep(unsigned int ms)
{
	long ms_l = ms;
	struct timespec ts;
	ts.tv_sec = ms_l/1000;
	ts.tv_nsec = (ms_l-ts.tv_sec*1000)*1000000l;
	nanosleep(&ts, NULL); 
/*	write_debug("Sleep ON= %d",ms);
	usleep(ms*1000);
	write_debug("Sleep OFF= %d",ms);*/
}

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void digivoice_starttimer()
{
	//Initializes the global timer control
	/*memset(&sa_timer,0,sizeof(sa_timer));
	//Start virtual timer
	sa_timer.sa_handler = &TimerProc;
	// Conf timer to expire after 100ms
	global_timer.it_value.tv_sec = 0;
	global_timer.it_value.tv_usec = 100000;
	//and each 100ms after that
	global_timer.it_interval.tv_sec = 0;
	global_timer.it_interval.tv_usec = 100000;
	sigaction(SIGALRM, &sa_timer, &sa_timer_old);
	setitimer(ITIMER_REAL, &global_timer, &global_timer_old);*/

	//inicializa timer thread
    timer_thread_running  = 1;
    digivoice_beginthread(&thread_timer,TimerProc,0,NULL);

}

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void digivoice_stoptimer(void)
{
	int ctime;
 	//back old sigalrm handler
	/*setitimer(ITIMER_REAL,&global_timer_old,NULL);
    sigaction(SIGALRM,&sa_timer_old,NULL);*/

    timer_thread_running = -999;

    ctime = 100;
	do
	{
		ctime--;

		digivoice_sleep(10);

		if (timer_thread_running==0)
			ctime = 0;

	} while(ctime > 0);

#ifdef LINUX24
    pthread_cond_signal(&timer_cond);
#else
    #ifdef LINUX26 || LINUX3
        digivoice_cancelthread(thread_timer);
    #endif
#endif
}

//---------------------------------------------------------------------------
// starts pthread
// the thread must be started with detached attribute to avoid memory lack
// also we set the stack size with DG_MIN_STACKSIZE (256K)
//---------------------------------------------------------------------------
int  WCDECL  digivoice_beginthread(void *thread_id,void(*func)(void*), int stack, void *data)
{
    int ret;
	int err=0;
	pthread_attr_t attr;


	//Set thread to be unattached - auto cleanup at finish
	pthread_attr_init(&attr);	
	pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);                

    //voicerlib need at least 256K stack size
    if (pthread_attr_setstacksize(&attr, DG_MIN_STACKSIZE)!=0)
    {
        //system does not allow modify the stack size
        write_debug("********************** digivoice_beginthread: Error setting thread stack!!!\n");
    }
	
	err = pthread_create(thread_id, &attr, (void*(*)(void*))func, data);
	pthread_attr_destroy(&attr);
	write_debug("begin_thread: return value=%d!!!\n",err);


    

    if(err!=0)
	   ret = (size_t)thread_id;
	else
   	   ret  = 0;


    pthread_attr_getstacksize(&attr, &err);
    write_debug("NEW thread stack = %d!!!\n",err);
   	   
   	return ret;
}

//---------------------------------------------------------------------------
//
//---------------------------------------------------------------------------
void digivoice_endthread()
{
	pthread_detach(pthread_self());
}


void digivoice_cancelthread(void  *thread_id)
{
  pthread_cancel((pthread_t)thread_id);
}

//Generic gettickcount
u32 digivoice_gettick(void)
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec*1000L+tv.tv_usec/1000L;
}

//---------------------------------------------------------------------------------------
// Enables interrupts for all cards
//---------------------------------------------------------------------------------------
void digivoice_enableinterrupts()
{
	int ct;

	for (ct=0;ct< sm->nCardsCount ;ct++)
	{
		ioctl(hWinDriver,VLIB_IOCTL_ENABLE_ISR, &ct);
        digivoice_sleep(100);
	}
}

//---------------------------------------------------------------------------------------
// Disables interrupts for all cards
//---------------------------------------------------------------------------------------
void digivoice_disableinterrupts()
{
	int ct;

	for (ct=0;ct<sm->nCardsCount;ct++)
	{
		ioctl(hWinDriver,VLIB_IOCTL_DISABLE_ISR, &ct);
	}
}


// Function: VLIB_ReadDword()
//   Read a Dword from the card's memory/IO.
u32 dgAPI_ReadDword (VLIB_HANDLE hE1, VLIB_ADDR addrSpace, u32 dwOffset)
{
	u32 ret;
	struct MEM_CMD		cmd;
	//set addr space and offset to read
	cmd.card = hE1->card;
	cmd.dwAddrSpace = addrSpace;
	cmd.dwOffSet = dwOffset;
	//write_debug("dgAPI_ReadDword: card=%d",cmd.card);	
	ret = ioctl(hWinDriver,VLIB_IOCTL_READU32, &cmd);
	//write_debug("dgAPI_ReadDword: card=%d addrspace=%x offset=%x value=%x ret=%x",cmd.card,cmd.dwAddrSpace,cmd.dwOffSet,cmd.dwData,ret);
	return cmd.dwData;
}

// Function: dgAPI_WriteDword()
//   Write a Dword to the card's memory/IO.
void dgAPI_WriteDword (VLIB_HANDLE hE1, VLIB_ADDR addrSpace, u32 dwOffset, u32 data)
{
	struct MEM_CMD	cmd;
	//set addr space and offset to read
	cmd.card = hE1->card;
	cmd.dwAddrSpace = addrSpace;
	cmd.dwOffSet = dwOffset;
	cmd.dwData = data;
//	write_debug("dgAPI_WriteDword: card=%d addrspace=%x offset=%x value=%x",cmd.card,cmd.dwAddrSpace,cmd.dwOffSet, cmd.dwData);
	ioctl(hWinDriver,VLIB_IOCTL_WRITEU32, &cmd);

}

// Function: dgAPI_WriteWord()
void dgAPI_WriteWord (VLIB_HANDLE hE1, VLIB_ADDR addrSpace, u32 dwOffset, u16 data)
{
	struct MEM_CMD	cmd;
	//set addr space and offset to read
	cmd.card = hE1->card;
	cmd.dwAddrSpace = addrSpace;
	cmd.dwOffSet = dwOffset;
	cmd.dwData = (u16)data;
	//write_debug("dgAPI_WriteDword: card=%d addrspace=%x offset=%x value=%x",cmd.card,cmd.dwAddrSpace,cmd.dwOffSet, cmd.dwData);
	ioctl(hWinDriver,VLIB_IOCTL_WRITEU16, &cmd);

}

//------------------------------------------------
// UdpPort - in linux is the port of the board
//------------------------------------------------
short dg_EnableDebug(short port)
{
    char szFifo[DG_MAX_PATH];

    sprintf(szFifo,"%s/debug-%d",DG_FIFO_PATH,port);

	//tries to open fifo
	/*ports_info[port-1].fifo_to_debug = fopen(szFifo,"a+");
	if (ports_info[port-1].fifo_to_debug==NULL)
		return DG_ERROR_FIFO_UNAVAILABLE;*/

    DebugEnabled = 1;	

    write_debug("Porta (%d) : Criando arquivo  %s", port,szFifo);

    return DG_EXIT_SUCCESS;

}

short dg_DisableDebug()
{
    //int i=0;

/*    for (i=1;i<=dg_GetPortsCount();i++) {
        fclose(ports_info[i-1].fifo_to_debug);
    }*/
    DebugEnabled = 0;
    return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------
// rcvd
//-------------------------------------------------------------------
short dg_write_rcvd_msg(void *rx_command)
{
	char szMsg[MAX_MSGLEN];
    char szTime[MAX_MSGLEN];

	dg_signal_from_device *received;
    char szFifo[DG_MAX_PATH];
    
    FILE *f;
    static u32 last_time = 0;
    time_t curSecs;
    struct tm *now_dbg;


    received = (dg_signal_from_device *)rx_command;

    


    sprintf(szFifo,"%s/debug-%d",DG_LOG_PATH,received->port);
    //tries to open fifo
    f = fopen(szFifo,"a+");
    if (f!=NULL) {
        curSecs = time(NULL);				
        now_dbg = localtime(&curSecs);	
        //sprintf(szTime,"<%02d:%02d:%02d.%05d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec,digivoice_gettick()-last_time);
		sprintf(szTime,"<%02d:%02d:%02d.%05u>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec,  (unsigned short)digivoice_gettick()/* ,digivoice_gettick()-last_time*/);
        last_time = digivoice_gettick();

        switch(received->command)
        {
            case C_CAS:
                sprintf(szMsg,"%s\t R2(rx): <<-....%x",szTime, ((received->data & 0xd) | 0x01) );
                fprintf(f,"%s\n",szMsg);
                break;
            case C_AUDIO:
                if (received->data<20) {
                    sprintf(szMsg,"%s\t MF(rx): <<-......%x",szTime, received->data);
                    fprintf(f,"%s\n",szMsg);
                }
                break;
        }

    	//Monta mensagem
    	//sprintf(szMsg,"<%02x,%02x,%03x",received->command,received->data,received->port);
        
        write_debug("dg_write_rcvd_msg (%d) : %s to %d", received->port, szMsg, ports_info[received->port-1].fifo_to_debug);

        fclose(f);
    }
    else
        write_debug("dg_write_rcvd_msg (%d) : ERRO ", received->port);

	return DG_EXIT_SUCCESS;
}

short dg_write_tx_msg(void *tx_command)
{
	char szMsg[MAX_MSGLEN];
//	dg_signal_from_device *received;
    dg_cmd_tx *tx;
    static u32 last_time = 0;
    time_t curSecs;
    struct tm *now_dbg;
    char szTime[MAX_MSGLEN];



    char szFifo[DG_MAX_PATH];
    FILE *f;


    tx = (dg_cmd_tx *)tx_command;
    tx->port++;

    write_debug("dg_write_tx_msg (%d) : ", tx->port);
    sprintf(szFifo,"%s/debug-%d",DG_LOG_PATH,tx->port);
    //tries to open fifo
    f = fopen(szFifo,"a+");
    if (f!=NULL) {

        curSecs = time(NULL);				
        now_dbg = localtime(&curSecs);	
        sprintf(szTime,"<%02d:%02d:%02d.%05u>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec, (unsigned short)digivoice_gettick() /*,digivoice_gettick()-last_time*/);
        last_time = digivoice_gettick();

        switch(tx->command)
        {
            case CMD_R2:    //R2 TX
                if (tx->param2<0x10) {
                    sprintf(szMsg,"%s\t R2(tx): ->>..................%x",szTime, ((tx->param2 & 0xd) | 0x01) );
                    fprintf(f,"%s\n",szMsg);
                }
                break;
            case CMD_DIAL:  //MF TX
                if (tx->param2 != GENERATE_OFF) {
                    sprintf(szMsg,"%s\t MF(tx): ->>............%x",szTime, tx->param3);
                    fprintf(f,"%s\n",szMsg);
                }
                break;
        }

    	//Monta mensagem
    	//sprintf(szMsg,"<%02x,%02x,%03x",received->command,received->data,received->port);
        
//        write_debug("dg_write_tx_msg (%d) : %s to %d", received->port, szMsg, ports_info[received->port-1].fifo_to_debug);

        fclose(f);
    }
    
	return DG_EXIT_SUCCESS;
}


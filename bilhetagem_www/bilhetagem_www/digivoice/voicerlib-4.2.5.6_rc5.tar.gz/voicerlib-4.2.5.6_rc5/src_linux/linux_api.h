#ifndef _LINUX_API_H
#define _LINUX_API_H

// linux_api.h
#include "../src_common/voicerlib.h"
#include "../src_common/vlibdef.h"
#include "../src_common/shmem.h"

//shared memory pointers
DG_SHAREDMEMORY *sm;	//pointer to shared memory
DG_PLAYBACKMEM	*pmk[MAX_CARDS*MAX_CHANNELS_CARD];
DG_RECMEM		*rmk[MAX_CARDS*MAX_CHANNELS_CARD];

extern pthread_cond_t timer_cond;

typedef struct PLX_STRUCT
{
		short  card;	//sequence number of the drive
		unsigned short  CardType;
		u32 PlxType;
} PLX_STRUCT;

typedef PLX_STRUCT *VLIB_HANDLE;

// internal data structures
typedef struct
{
    u32 index;
    u8  fIsMemory;
    u8  fActive;
} VLIB_ADDR_DESC;

typedef unsigned int VLIB_ADDR;
typedef u32 VLIB_MODE;


int fd_shm;		//file descriptor for shared memory

int fd_ccs_shm;		//file descriptor for shared memory

int fd_rec[MAX_REC_GROUP];		//file descriptor for rec shared mem
int fd_play[MAX_PLAY_GROUP];		//file descriptor for playback shared mem


HANDLE hWinDriver;
VLIB_HANDLE hPlxHandle[MAX_CARDS];
VLIB_HANDLE *hPlx;


//functions prototypes
short WD_Close(HANDLE hWd);
int WD_Open(void);

short CreateSharedMemory(void);
void  CloseSharedMemory(void);
short InitializesSharedMemory(void);

void dgAPI_Close(VLIB_HANDLE hE1);
u32 dgAPI_CountCards (u32 dwVendorID, u32 dwDeviceID);
short dgAPI_LocateAndOpenBoard(u32 dwVendorID, u32 dwDeviceID, u16 wCardOffset);
// Function: dgAPI_Open()
short dgAPI_Open (VLIB_HANDLE *phE1, u32 dwVendorID, u32 dwDeviceID, u32 nCardNum);
// Function: VLIB_ReadDword()
//   Read a Dword from the card's memory/IO.
u32 dgAPI_ReadDword (VLIB_HANDLE hE1, VLIB_ADDR addrSpace, u32 dwOffset);
// Function: dgAPI_WriteDword()
//   Write a Dword to the card's memory/IO.
void dgAPI_WriteDword (VLIB_HANDLE hE1, VLIB_ADDR addrSpace, u32 dwOffset, u32 data);
void dgAPI_WriteWord (VLIB_HANDLE hE1, VLIB_ADDR addrSpace, u32 dwOffset, u16 data);

void digivoice_enableinterrupts(void);


short InitRecSharedMem(short port, HANDLE hWD, u32 hKernelPlugIn);
void CloseRecSharedMem(short port);

short InitPlaySharedMem(short port, HANDLE hWD, u32 hKernelPlugIn);
void ClosePlaySharedMem(short port);

short dg_write_rcvd_msg(void *rx_command);
short dg_write_tx_msg(void *tx_command);

short InitCCSSharedMem(void);
void CloseCCSSharedMem(void);

const char *GetLinuxVLibVersion(void);
const char *GetLinuxVLibVersionNumber(void);

#endif




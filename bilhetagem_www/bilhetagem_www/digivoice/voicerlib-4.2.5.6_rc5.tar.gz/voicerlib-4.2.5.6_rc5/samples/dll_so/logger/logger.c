
/****************************************************************************
 *																		    *
 *   File: logger.c                                                         *
 *   Date: 31/10/2008                                                       *   
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                        *
 *   desenvolvimento@digivoice.com.br                                       *    
 *																		    *
 *   Copyright (c) 2008 Digivoice Eletronica                                *
 *																		    * 
 *   This file contains the logger_control functions for Digivoice Cards    *
 *																		    * 
 *   This program requires ncurses                                          *
 *																		    *
 *   This program is free software; you can redistribute it and/or modify   *
 *   it under the terms of the GNU General Public License as published by   *
 *   the Free Software Foundation; either version 2 of the License, or      *
 *   (at your option) any later version.                                    *
 *																		    *
 *   This program is distributed in the hope that it will be useful,  	    *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of  	    *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the  		    *
 *   GNU General Public License for more details.  						    *
 *  																	    *
 ****************************************************************************/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include <pthread.h>
#include <getopt.h>

#include <vlibdef.h>
#include <voicerlib.h>

#define MAX_PATH 255
#define MAX_CANAIS		600

WINDOW *win;
int count=0;
int current_channel=1;

int file_format = 0;

char *szFF[] = { "ffWaveULaw\0","ffSig\0","ffWavePCM\0", "ffGsm610\0", "ffWaveALaw\0" };

char szFileName[255];

char szNumberToDial[255];

short answer_state = 0;
int card_type;

dg_event_data_structure event_context;

char szSamples[320];

WINDOW *win_ev;	//windows events

//-------------------------------------------------------------------
// Functions to manage ncurses windows
//-------------------------------------------------------------------
WINDOW *create_newwin(int height, int width, int starty, int startx)
{
	WINDOW *local_win;

	local_win = newwin(height, width, starty, startx);
	box(local_win, 0 , 0);		/* 0, 0 gives default characters 
					 * for the vertical and horizontal
					 * lines			*/
	wrefresh(local_win);		/* Show that box 		*/

	return local_win;
}

void destroy_win(WINDOW *local_win)
{	
	/* box(local_win, ' ', ' '); : This won't produce the desired
	 * result of erasing the window. It will leave it's four corners 
	 * and so an ugly remnant of window. 
	 */
	wborder(local_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
	/* The parameters taken are 
	 * 1. win: the window on which to operate
	 * 2. ls: character to be used for the left side of the window 
	 * 3. rs: character to be used for the right side of the window 
	 * 4. ts: character to be used for the top side of the window 
	 * 5. bs: character to be used for the bottom side of the window 
	 * 6. tl: character to be used for the top left corner of the window 
	 * 7. tr: character to be used for the top right corner of the window 
	 * 8. bl: character to be used for the bottom left corner of the window 
	 * 9. br: character to be used for the bottom right corner of the window
	 */
	wrefresh(local_win);
	delwin(local_win);
}

//---------- NCURSES screen functions -----------

void print_event(char *szMsg, int port)
{
	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);				
	now = localtime(&curSecs);
	
	attron(COLOR_PAIR(2));
	wprintw(win_ev,"<%02d:%02d:%02d> (%d): %s\n",now->tm_hour, now->tm_min, now->tm_sec, port,szMsg);
	attroff(COLOR_PAIR(2));
	wrefresh(win_ev);	
}

/* Print Main Screen */
void print_screen()
{
    /* Print Main Screen */
    attron(COLOR_PAIR(1));
    box(win, '|', '-');    
    mvprintw(0, 30, "[ DigiVoice Logger Control Diagnostic Tool ]");
    refresh();
    attroff(COLOR_PAIR(1));
    mvprintw(1, 1, "Card(s) Count  : %d", dg_GetCardsCount());
	mvprintw(2, 1, "Current Channel: %d", current_channel);    
    attron(COLOR_PAIR(3));

    /* Print Menu */    
    mvprintw(3, 1, "<q>Quit             <c>Clear Screen     <+>Channel     <->Channel        ");
    mvprintw(4, 1, "<r>RecordFile       <s>Stop Record      <e>Pause Rec On/Off              ");    
    mvprintw(5, 1, "</>Enable Logger Thread Control         <\\>Disable Logger Thread Control");
    mvprintw(6, 1, "<w>Change Record/Play Format                                             ");

    attroff(COLOR_PAIR(3));
}
//---------- end of NCURSES screen functions -----------

//------------------------------------------------------------------------------------------
// Function that will be receive events from library 
//------------------------------------------------------------------------------------------
void ReceiveEvents(void *context_data)
{

    dg_event_data_structure *EventContext;
    char data[255];
    char szDig[MAX_PATH];
    char szDig2[MAX_PATH];
    int InOut = 0;//INCOMINGCALL 1, OUTGOINGCALL 2
    
    data[0] = 0;

    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);
    dg_signal_e1_thread_structure *p_e1_thread_structure;
 
	switch (EventContext->command)
	{
		case EV_E1_ALARM:
			//port means E1_A ou E1_B
			switch(EventContext->data)
			{
				case ALARM_RSLIP:		//escorregamento 
					sprintf(data,"Card %d E1-%d ALARM - RSLIP - Count=%d", EventContext->card, EventContext->port,EventContext->data_aux);
					break;
				case ALARM_RAIS:		//alarme remoto
					sprintf(data,"Card %d E1-%d ALARM - RAIS - State=%d", EventContext->card,EventContext->port,EventContext->data_aux);
					break;
				case ALARM_AISS:		//indica�o de alarme
					sprintf(data,"Card %d E1-%d ALARM - AISS - State=%d", EventContext->card,EventContext->port,EventContext->data_aux);
					break;
				case ALARM_AIS16S:		//indica�o de alarme canal  16
					sprintf(data,"Card %d E1-%d ALARM - AIS16S - State=%d", EventContext->card,EventContext->port,EventContext->data_aux);
					break;
				case ALARM_LOSS:		//perda de sinal
					sprintf(data,"Card %d E1-%d ALARM - LOSS - State=%d", EventContext->card,EventContext->port,EventContext->data_aux);
					break;
				case ALARM_CRC4SYNC:		//crc4
					sprintf(data,"Card %d E1-%d ALARM - RESERVED - State=%d", EventContext->card,EventContext->port,EventContext->data_aux);
					break;
				case ALARM_MFSYNC:		//sincronismo de multiquadro
					sprintf(data,"Card %d E1-%d ALARM - MFSYNC - State=%d", EventContext->card,EventContext->port,EventContext->data_aux);
					break;
				case ALARM_SYNC:		//sincronismo de quadro
					sprintf(data,"Card %d E1-%d ALARM - SYNC - State=%d", EventContext->card,EventContext->port,EventContext->data_aux);
					break;
			}
			break;
		case EV_R2:
		    sprintf(szDig,"R2 - %x", EventContext->data);			
		    sprintf(data,szDig);
		    break;
		case EV_PLAYSTART:
			sprintf(data, "Play Start EVENT");
			break;
		case EV_PLAYSTOP:
			sprintf(data, "Play Stop EVENT");
			break;
		case EV_RECORDSTART:
			sprintf(data, "Record Start EVENT");
			break;
		case EV_RECORDSTOP:
			sprintf(data, "Record Stop EVENT");
		    if (dg_DisableInputBuffer(EventContext->port) != DG_EXIT_SUCCESS)
		    	print_event("Error destroying InputBuffer!!!", EventContext->port);
		    else
		    	print_event("InputBuffer destroyed!!!", EventContext->port);
			break;
		case EV_RECORDING:
			sprintf(data, "Recording %ds...", EventContext->data);
			break;			
		case EV_LOGGEREVENT:
			sprintf(data, "Logger EVENT...");
			
			switch (EventContext->data)
			{
				case LOGGER_FREE_WITH_BILLING:
					sprintf(data, "LoggerEvent: LOGGER_FREE_WITH_BILLING");
					break;
				case LOGGER_BUSY:                   
					sprintf(data, "LoggerEvent: LOGGER_BUSY");
					break;
				case LOGGER_NUMBER_CHANGED:         
					sprintf(data, "LoggerEvent: LOGGER_NUMBER_CHANGED");
					break;
				case LOGGER_CONGESTION:             
					sprintf(data, "LoggerEvent: LOGGER_CONGESTION");
					break;
				case LOGGER_FREE_WITHOUT_BILLING:   
					sprintf(data, "LoggerEvent: LOGGER_FREE_WITHOUT_BILLING");
					break;
				case LOGGER_FREE_RETENTION:         
					sprintf(data, "LoggerEvent: LOGGER_FREE_RETENTION");
					break;
				case LOGGER_LEVEL_NUMBER_AVAILABLE: 
					sprintf(data, "LoggerEvent: LOGGER_LEVEL_NUMBER_AVAILABLE");
					break;
				case LOGGER_B_ENDCALL:             
					sprintf(data, "LoggerEvent: LOGGER_B_ENDCALL");
					break;
				case LOGGER_B_RETURN:
					sprintf(data, "LoggerEvent: LOGGER_B_RETURN");
					break;					
				case LOGGER_LINEREADY:
					sprintf(data, "LoggerEvent: LOGGER_LINEREADY, please START your record...");
					print_event(data, EventContext->port);
					
					dg_GetE1Number(EventContext->port, szDig);
					dg_GetCallerId(EventContext->port, szDig2);

					sprintf(data, "E1Number: %s", szDig);
					print_event(data, EventContext->port);
					
					sprintf(data, "CallerId: %s", szDig2);
					print_event(data, EventContext->port);
					
					if (dg_GetLoggerCallType(EventContext->port) == 1)
						sprintf(data, "...INcomingCALL");
				    else
				    	sprintf(data, "...OUTgoingCALL");
					break;
				case LOGGER_LINEOFF:
					sprintf(data, "LoggerEvent: LOGGER_LINEOFF, please STOP your record...");
					break;
			}
			break;
	}
		
	if (data[0]!=0)
		print_event(data, EventContext->port);
}

//----------------------------------------------------------
//Shows help messages
//----------------------------------------------------------
void show_help()
{
		printf("\nInvalid Parameters!");
		printf("\nUsage: vlib_diag -c <num_cards> -t <card_type> -p <firmware_path>");
		printf("\n       Where: num_cards - Number of installed cards     ");
		printf("\n              card_type - vbox or vppci     ");
		printf("\n              firm_path - Path to the firmware path\n");
}

//------------------------------------------------------------------------------------------
// Main Function 
//------------------------------------------------------------------------------------------
int main (int argc, char *argv[])
{
	char ch;

	char szNumber[2];
	char szTemp[255];
	char szMsg[255];
	const char* program_name;
	int next_option,ret;
	int ncards, i;
	short cc,j,paused=0;
  
	WINDOW *wndH100;    
		
	/* Parse Command line arguments */
	/* parameters: no_cards , card_type, szFirmwarePath */ 
	const char* const short_options = "p:";
	
	const struct option long_options[] = {
		{ "path", 1, NULL, 'p'}, 		
		{ NULL, 0, NULL, 0 }
		};
		
	const char output_filename = (const char)NULL;

	//-------------------------------------------------------------------
	// command line parser
	//-------------------------------------------------------------------
	program_name = argv[0]; /* Saves program name*/
		
	do {
		next_option = getopt_long(argc, argv, short_options, long_options, NULL);
		
		switch(next_option)
		{		
			case 'p':		/* -p or --path */
				
				sscanf(optarg,"%s",&szTemp);				
				if (strlen(szTemp)==0)
				{
						show_help();
						exit(EXIT_FAILURE);
				}
				break;
		}
	}
	while (next_option != -1);
	//-------------------------------------------------------------------
		
	/* Start VoicerLib engine */
	if ((ret = dg_StartVoicerlib(NULL)) != EXIT_SUCCESS)
	{
		printf("\nError starting voicerlib (code %d)\n",ret);
		exit(EXIT_FAILURE);
	}
	printf("OK....\n",szTemp);
	digivoice_sleep(500);

	ncards = dg_GetCardsCount();
	
	//CONFIGURE CARDS BEHAVIOUR
	
	//sync mode for all cards
	
	for (i = 1; i <= ncards; i++) 
	{
    	printf("Setting Sync for card %d - EXTERNAL LINE_A....\n",i);
	    dg_SetCardSyncMode(i, SYNC_LINE_A);
	}

    digivoice_sleep(4000);

	printf("Setting General Defaults....\n");

	current_channel=1;
	
	printf("Starting GUI....\n");	
	/* initialize ncurses stuff */
	win = initscr();
	start_color();  /* Start the color functionality */
	cbreak();       /* Line buffering disabled, Pass on
										* every thing to me         */
	keypad(stdscr, TRUE);        /* I need that nifty F1     */
	noecho();
	
	/* Initialize used colors */
	init_pair(1, COLOR_CYAN, COLOR_BLACK);        
	init_pair(2, COLOR_RED, COLOR_WHITE);            
	init_pair(3, COLOR_GREEN, COLOR_BLACK);            

	/* print initial screen */
	print_screen();
	
	/* disable getch wait */
	nodelay(win, TRUE);


	//create event window
	win_ev = create_newwin(7,78,7,1);
	wbkgd(win_ev,A_REVERSE | A_BOLD);
	scrollok(win_ev, TRUE);
	wrefresh(win_ev);

    /* Set events function callback */
    dg_SetEventCallback(ReceiveEvents,&event_context);
    
    for (j=1;j<=dg_GetCardsCount();j++)
        dg_SetAlarmMode(j, ALARM_AUTOMATIC_NOTIFY);

	for (i = 1; i <= ncards; i++)
	{
		sprintf(szTemp, "Firmware version card %d - %xh", i, dg_GetVersion(i));
		print_event(szTemp, i);
	}
	
	strcpy(szFileName,"./grava%d.wav\0");

	/* Main Loop */
	while((ch = getch()) != 'q')
	{
		if (ch == 'Q')
			break;

		switch(ch)
		{
			case 'w': case 'W':		//change file format
				file_format++;
				if (file_format>4)
					file_format=0;
				dg_SetPlayFormat(current_channel,file_format);
				dg_SetRecordFormat(current_channel,file_format);
				sprintf(szTemp,"Current file format is %s",szFF[file_format]);
				print_event(szTemp,current_channel);
				break;

			case 'r': case 'R':	    // record
				switch(file_format)
				{
					case 0:case 2:case 4:
						sprintf(szTemp,"./grava%d.wav\0",current_channel);
						break;
					case 1:
						sprintf(szTemp,"./grava%d.sig\0",current_channel);
						break;
					case 3:
						sprintf(szTemp,"./grava%d.gsm\0",current_channel);
						break;
				}
				dg_SetRecordFormat(current_channel,file_format);

				if (dg_EnableInputBuffer(current_channel, DG_DISABLE)==DG_EXIT_SUCCESS)
				{
					if (dg_RecordFile(current_channel,szTemp,"*")==0)
					{
						sprintf(szMsg,"Recording...%s",szTemp);
						print_event(szMsg,current_channel);
					}
					else
						print_event("Could not open rec file",current_channel); 
				}
				else
					print_event("Error creating input buffer",current_channel); 

				break;
				
			case 's': case 'S':
				print_event("Record stopped",current_channel);
				dg_StopRecordFile(current_channel);
				break;
				
			case 'e': case 'E':
				if (paused==0)
				{
                    paused=1;
                    dg_PauseInputBuffer(current_channel,paused);
					print_event("Rec Paused On",current_channel);
				}
				else
				{
                    paused=0;
                    dg_PauseInputBuffer(current_channel,paused);
					print_event("Rec Paused Off",current_channel);
				}
				break;

			case 'c': case 'C':
				clear();
				print_screen();
				break;
				
			case ',':
				current_channel-=30;
				if (current_channel < 1)
					current_channel = 1;
				mvprintw(2, 1, "Current Channel: %d    ",current_channel);
				break;
				
			case '.':
				current_channel+=30;
				if (current_channel > dg_GetPortsCount())
					current_channel = dg_GetPortsCount();
				mvprintw(2, 1, "Current Channel: %d    ",current_channel);
				break;

			case '-':
				if (current_channel > 1)
					current_channel--;
				mvprintw(2, 1, "Current Channel: %d    ",current_channel);
				break;
				
			case '+':
				if (current_channel < dg_GetPortsCount())
					current_channel++;               
				//Test E1 Calls
				mvprintw(2, 1, "Current Channel: %d    ",current_channel);
				break;
				
			case '/': //create Logger control to current_port
				if (dg_CreateLoggerControl(current_channel, 0) != DG_EXIT_SUCCESS)
					print_event("Error creating Logger Control!!!", current_channel);
				else
					print_event("Logger Control Created!!!", current_channel);
				break;
				
			case '\\': //destroy Logger control to current_port
			    if (dg_DisableInputBuffer(current_channel) != DG_EXIT_SUCCESS)
			    	print_event("Error destroying InputBuffer!!!", current_channel);
			    else
			    	print_event("InputBuffer destroyed!!!", current_channel);				
				
				if (dg_DestroyLoggerControl(current_channel) != EXIT_SUCCESS)
					print_event("Error destroying Logger Control!!!", current_channel);
				else
					print_event("Logger Control destroyed!!!", current_channel);
				break;
        }		
		count++;  //Remove in the future
    } /* while */     
	destroy_win(win_ev);
    endwin();
    /* Stops voicerlib engine */
    dg_ShutdownVoicerlib();
    printf("\n\n* * * Goodbye! * * *\n\n");
    return EXIT_SUCCESS;
}

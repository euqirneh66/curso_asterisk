
/****************************************************************************
 *                                                                          *
 *   File: MonitorDeSinal.c                                                 *
 *   Date: 18/11/2010                                                       *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                        *
 *   desenvolvimento@digivoice.com.br                                       *    
 *                                                                          *
 *   Copyright (c) 2010 Digivoice Eletronica                                *
 *                                                                          * 
 *   This file contains the logger_control functions for Digivoice Cards    *
 *                                                                          * 
 *   This program requires ncurses                                          *
 *                                                                          *
 *   This program is free software; you can redistribute it and/or modify   *
 *   it under the terms of the GNU General Public License as published by   *
 *   the Free Software Foundation; either version 2 of the License, or      *
 *   (at your option) any later version.                                    *
 *                                                                          *
 *   This program is distributed in the hope that it will be useful,  	    *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of  	    *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the           *
 *   GNU General Public License for more details.                           *
 *                                                                          *
 ****************************************************************************/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include <pthread.h>
#include <getopt.h>
#include <math.h>

#include <vlibdef.h>
#include <voicerlib.h>

#define MAX_PATH 255

WINDOW *win;
WINDOW *win_ev;	//windows events

int count=0;
int current_channel=1;

typedef unsigned long DWORD;

float fNivel, fNivel1, fSinal, fNiveldB = 0;
short nFlagAudio = 0;

short nSilenceThreshold=-30;
short nFrequency = 425;
short cAmostras[400];
int nEstado = 0;
int nTOM, nSilencio = 0;

DWORD TempTickIni   = 0;
DWORD TempTickFim   = 0;
DWORD TempTickDiff  = 0;
DWORD TempTickDiffS = 0;

dg_event_data_structure event_context;

//-------------------------------------------------------------------
// Functions to manage ncurses windows
//-------------------------------------------------------------------
WINDOW *create_newwin(int height, int width, int starty, int startx)
{
	WINDOW *local_win;

	local_win = newwin(height, width, starty, startx);
	box(local_win, 0 , 0);		/* 0, 0 gives default characters 
					 * for the vertical and horizontal
					 * lines			*/
	wrefresh(local_win);		/* Show that box 		*/

	return local_win;
}

void destroy_win(WINDOW *local_win)
{	
	/* box(local_win, ' ', ' '); : This won't produce the desired
	 * result of erasing the window. It will leave it's four corners 
	 * and so an ugly remnant of window. 
	 */
	wborder(local_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
	/* The parameters taken are 
	 * 1. win: the window on which to operate
	 * 2. ls: character to be used for the left side of the window 
	 * 3. rs: character to be used for the right side of the window 
	 * 4. ts: character to be used for the top side of the window 
	 * 5. bs: character to be used for the bottom side of the window 
	 * 6. tl: character to be used for the top left corner of the window 
	 * 7. tr: character to be used for the top right corner of the window 
	 * 8. bl: character to be used for the bottom left corner of the window 
	 * 9. br: character to be used for the bottom right corner of the window
	 */
	wrefresh(local_win);
	delwin(local_win);
}

void print_event(char *szMsg, int port)
{
	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);				
	now = localtime(&curSecs);
	
	attron(COLOR_PAIR(2));
	wprintw(win_ev,"<%02d:%02d:%02d> (%d): %s\n", now->tm_hour, now->tm_min, now->tm_sec, port, szMsg);
	attroff(COLOR_PAIR(2));
	wrefresh(win_ev);
}

/* Print Main Screen */
void print_screen()
{
    /* Print Main Screen */
    attron(COLOR_PAIR(1));
    box(win, '|', '-');    
    mvprintw(0, 30, "[ DigiVoice Signal Monitor Tool ]");
    refresh();
    attroff(COLOR_PAIR(1));
    mvprintw(1, 1, "Card(s) Count  : %d", dg_GetCardsCount());
    mvprintw(2, 1, "Current Channel: %d", current_channel);    
    attron(COLOR_PAIR(3));

    /* Print Menu */    
    mvprintw(3 , 1, "<q>Quit              <c>Clear Screen    <+>Channel     <->Channel");
    mvprintw(4 , 1, "<p>Pickup            <h>Hangup          <d>Dial");
    mvprintw(5 , 1, "<f>Set Frequency     <s>Set Silence Threshold");

    attroff(COLOR_PAIR(3));

    mvprintw(6 , 1, "------------------------------------------------------------------------------");

    mvprintw( 8, 1 , "Frequency........: ");
    mvprintw( 9, 1 , "Silence Threshold: ");
    mvprintw(10, 1 , "Audio (Tone1)....: ");

    mvprintw(12, 1 , "Tone (ms)........: ");
    mvprintw(13, 1 , "Silence (ms).....: ");
}

void CallSignal(short port, int size, void *Samples)
{
	short i, tempInt = 0;

	if (port == current_channel)
	{
		if ((size>0) || (size<400))
		{
			memcpy(cAmostras,Samples,(size*2));

			for (i=0;i<size;i++)
			{
				tempInt = cAmostras[i];
				fSinal = tempInt;
				fNivel = ((0.98f * fNivel1) + (0.02f * abs(fSinal/4096.0f)));
				fNivel1 = fNivel;

				if (fNivel < 0.001)
					fNivel = +0.001;

				fNiveldB = (20.0f * (log10(fNivel)))-10.0f;
			}
		}
	}
}

void ReceiveEvents(void *context_data)
{
    dg_event_data_structure *EventContext;
    char data[MAX_PATH];
    char szDig[MAX_PATH];

    //zera string
    data[0] = 0;
    szDig[0] = 0;

    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);

	switch (EventContext->command)
	{
		/*
		case EV_LINEREADY:
	                if ((dg_GetCardType(dg_GetCardNumber(EventContext->port) == VB0404FX) ||
	                    (dg_GetCardType(dg_GetCardNumber(EventContext->port) == VB0404FX_R))))
	                {
		                sprintf(data, "Generating Tone1...");
		                dg_GenerateMF(EventContext->port, GENERATE_TONE1, 0);
		        }
		        break;
                case EV_LINEOFF:
                        if ((dg_GetCardType(dg_GetCardNumber(EventContext->port) == VB0404FX) ||
                           (dg_GetCardType(dg_GetCardNumber(EventContext->port) == VB0404FX_R))))
                                dg_GenerateMF(EventContext->port, GENERATE_OFF, 0);
                        break;
		*/
		case EV_AUDIO_SIGNAL:
			switch (EventContext->data)
			{
				case 32://Silencio
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
						TempTickIni = digivoice_gettick();
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Silence 0x%x ", EventContext->data);
					break;
				case 33://Audio
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Audio 0x%x ", EventContext->data);
					break;
				case 34://Tone 1
					if (nEstado == 0)
					{
						TempTickDiffS = (digivoice_gettick() - TempTickIni);
						nSilencio = (int)(TempTickDiffS);
						TempTickIni = digivoice_gettick();
					}
					nEstado = 1;
					nFlagAudio = 1;
					sprintf(data, "Tone 1 0x%x ", EventContext->data);
					break;
				case 35://Tone 2
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Tone 2 0x%x ", EventContext->data);
					break;
				case 36://Tone 3
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Tone 3 0x%x ", EventContext->data);
					break;

				case 37://Tone 4
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Tone 4 0x%x ", EventContext->data);
					break;
				case 38://Tone 5
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Tone 5 0x%x ", EventContext->data);
					break;
				case 39://Tone 6
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Tone 6 0x%x ", EventContext->data);
					break;
				case 40://Tone 7
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Tone 7 0x%x ", EventContext->data);
					break;
				case 41://Tone 8
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "Tone 8 0x%x ", EventContext->data);
					break;
				default:
					if (nEstado == 1)
					{
						TempTickDiff = (digivoice_gettick() - TempTickIni);
						nTOM = (int)(TempTickDiff);
					}
					nEstado = 0;
					nFlagAudio = 0;
					sprintf(data, "0x%x ", EventContext->data);
			}
	}
		
	if (data[0]!=0)
		print_event(data, EventContext->port);
}

//----------------------------------------------------------
//Shows help messages
//----------------------------------------------------------
void show_help()
{
	printf("\nInvalid Parameters!\n");
}

//------------------------------------------------------------------------------------------
// Main Function 
//------------------------------------------------------------------------------------------
int main (int argc, char *argv[])
{
	char szNumber[2];
	int next_option;
	int i, nProcessedCount;
	short j=0;
	short ret=0;
	char ch;
	char szTemp[255];
	int nPortsCount, nCardCount = 0;
	short nRet1 = 0;
	short nForPorts, nForCards = 0;

	fNivel			= 0;
	fNivel1			= 0;
	TempTickIni		= 0;
	TempTickFim		= 0;
	TempTickDiff	= 0;
	TempTickDiffS	= 0;

	WINDOW *wndH100;    
		
	/* Parse Command line arguments */
	/* parameters: no_cards , card_type, szFirmwarePath */ 
	const char* const short_options = "p:";
	
	const struct option long_options[] = {
		{ "path", 1, NULL, 'p'}, 		
		{ NULL, 0, NULL, 0 }
		};
		
	const char output_filename = (const char)NULL;

	do {
		next_option = getopt_long(argc, argv, short_options, long_options, NULL);
		
		switch(next_option)
		{		
			case 'p':		/* -p or --path */
				
				sscanf(optarg,"%s",&szTemp);				
				if (strlen(szTemp)==0)
				{
						show_help();
						exit(EXIT_FAILURE);
				}
				break;
		}
	}
	while (next_option != -1);
	//-------------------------------------------------------------------
		
	/* Start VoicerLib engine */
	if ((ret = dg_StartVoicerlib(NULL)) != EXIT_SUCCESS)
	{
		printf("\nError starting voicerlib (code %d)\n",ret);
		exit(EXIT_FAILURE);
	}
	digivoice_sleep(500);

	printf("\nStartVoicerLib = OK...\n");
	nPortsCount = dg_GetPortsCount();
	nCardsCount = dg_GetCardsCount();

	for (nForPorts = 1; nForPorts <= nPortsCount; nForPorts++)
	{
		//Seta o limiar de silencio
		nRet1 = dg_SetSilenceThreshold(nForPorts,nSilenceThreshold);
		if (nRet1 != DG_EXIT_SUCCESS)
			printf("dg_SetSilenceThreshold error. Port: %d, nRet %d", nForPorts, nRet1);

		//Habilita o input buffer
		nRet1 = dg_EnableInputBuffer(nForPorts,DG_DISABLE_AGC);
		if (nRet1 != DG_EXIT_SUCCESS)
			printf("dg_EnableInputBuffer error. Port: %d, nRet %d", nForPorts, nRet1);

		//Seta formato de gravacao
		nRet1 = dg_SetRecordFormat(nForPorts,ffWavePCM);
		if (nRet1 != DG_EXIT_SUCCESS)
			printf("dg_SetRecordFormat error. Port: %d, nRet %d", nForPorts, nRet1);

		//Seta o ganho de gravacao
		nRet1 = dg_SetRecordGain(nForPorts,0);
		if (nRet1 != DG_EXIT_SUCCESS)
			printf("dg_SetRecordGain error. Port: %d, nRet %d", nForPorts, nRet1);

		nRet1 = dg_SetDetectionType(nForPorts,DETECT_TONE1,DG_ENABLE);
		if (nRet1 != DG_EXIT_SUCCESS)
			printf("dg_SetDetectionType error. Port: %d, nRet %d", nForPorts, nRet1);
	}

	//CONFIGURE CARDS BEHAVIOUR
	
	//sync mode for all cards
	for (i = 1; i <= nCardsCount; i++)
	{
    	printf("Setting Sync for card %d - EXTERNAL LINE_A....\n",i);
	    dg_SetCardSyncMode(i, SYNC_LINE_A);
	}

	printf("Setting General Defaults....\n");

	current_channel=1;
	
	printf("Starting GUI....\n");	
	/* initialize ncurses stuff */
	win = initscr();
	start_color();  /* Start the color functionality */
	cbreak();       /* Line buffering disabled, Pass on
										* every thing to me         */
	keypad(stdscr, TRUE);        /* I need that nifty F1     */
	noecho();
	
	/* Initialize used colors */
	init_pair(1, COLOR_CYAN, COLOR_BLACK);        
	init_pair(2, COLOR_RED, COLOR_WHITE);            
	init_pair(3, COLOR_GREEN, COLOR_BLACK);            

	/* print initial screen */
	print_screen();
	
	/* disable getch wait */
	nodelay(win, TRUE);


	//create event window
	win_ev = create_newwin(15,78,15,1);
	wbkgd(win_ev,A_REVERSE | A_BOLD);
	scrollok(win_ev, TRUE);
	wrefresh(win_ev);

    /* Set events function callback */
    dg_SetEventCallback(ReceiveEvents,&event_context);
    dg_SetAudioInputCallback(&CallSignal);
    
    for (j=1;j<=dg_GetCardsCount();j++)
        dg_SetAlarmMode(j, ALARM_AUTOMATIC_NOTIFY);

	for (i = 1; i <= nCardsCount; i++)
	{
		sprintf(szTemp, "Firmware version card %d - %xh", i, dg_GetVersion(i));
		print_event(szTemp, i);
	}
	
	/* Main Loop */
	while((ch = getch()) != 'q')
	{
		digivoice_sleep(10);//200);

		if (ch == 'Q')
			break;

		switch(ch)
		{
			case 'f': case 'F':
				print_event("New Frequency: ", 0);
				echo();
				wscanw(win_ev, "%s", &szTemp);
				noecho();
				nFrequency = atoi(szTemp);

				for (nForCards=1; nForCards <= nCardsCount; nForCards++)
				{
					//Set frequency
					nRet1 = dg_SetCardDetections(nForCards, CFG_DETECT_FREQTONE1, nFrequency, 0);
					if (nRet1 != DG_EXIT_SUCCESS)
						sprintf(szTemp, "Set frequency error for card %d. nRet.: %d\n", nForCards, nRet1);
					else
						sprintf(szTemp, "Frequency set for card %d with success\n", nForCards);
					print_event(szTemp, nForCards);
				}
				break;
			case 'p': case 'P':
				nRet1 = dg_PickUp(current_channel, 100);
				if (nRet1 != DG_EXIT_SUCCESS)
					sprintf(szTemp, "Pickup error. nRet.: %d\n", nRet1);
				else
					sprintf(szTemp, "Picked Up!");
				print_event(szTemp, current_channel);
				break;
			case 'h': case 'H':
				nRet1 = dg_HangUp(current_channel);
				if (nRet1 != DG_EXIT_SUCCESS)
					sprintf(szTemp, "HangUp error. nRet.: %d\n", nRet1);
				else
					sprintf(szTemp, "HungUp!");
				print_event(szTemp, current_channel);
				break;
			case 'c': case 'C':
				clear();
				print_screen();
				break;
			case '-':
				if (current_channel > 1)
					current_channel--;
				mvprintw(2, 1, "Current Channel: %d    ",current_channel);
				break;
			case '+':
				if (current_channel < dg_GetPortsCount())
					current_channel++;
				//Test E1 Calls
				mvprintw(2, 1, "Current Channel: %d    ",current_channel);
				break;
			case 's': case 'S':
				print_event("New Silence Threshold: ", 0);
				echo();
				wscanw(win_ev, "%s", &szTemp);
				noecho();
				nSilenceThreshold = atoi(szTemp);

				for (nForPorts=1;nForPorts<=nPortsCount;nForPorts++)
				{
					nRet1 = dg_SetSilenceThreshold(nForPorts, nSilenceThreshold);
					if (nRet1 != DG_EXIT_SUCCESS)
						printf("Set Silence Threshold error. nRet.: %d \n", nRet1, current_channel);
				}
				break;
			case 'd': case 'D':
				print_event("Number to Dial: ", current_channel);
				echo();
				wscanw(win_ev, "%s", &szTemp);
				noecho();

				nRet1 = dg_PickUp(current_channel, 100);
				if (nRet1 != DG_EXIT_SUCCESS)
				{
					sprintf(szTemp, "Pickup error. nRet.: %d\n", nRet1);
					print_event(szTemp, current_channel);
				}

				sleep(1);

				nRet1 = dg_Dial(current_channel, szTemp, 100, dtTone);
				if (nRet1 != DG_EXIT_SUCCESS)
					sprintf(szTemp, "Dial error. nRet.: %d\n", nRet1);
				else
					sprintf(szTemp, "Dialing to '%d'", atoi(szTemp));
				print_event(szTemp, current_channel);

				break;
			case '1': case '2': case '3': case '4': case '5': case '6':
			case '7': case '8': case '9': case '0': case '#': case '*':
					szNumber[0] = ch;
					szNumber[1] = 0;
					sprintf(szTemp,"Dialing: %c", ch);
					print_event(szTemp, current_channel);
					dg_Dial(current_channel, szNumber, 1000, dtTone);
					break;
			default:
		    	nProcessedCount = count;
		    	if (nProcessedCount < 10) nProcessedCount = 10;

		    	if (nProcessedCount % 10 == 1)
		    	{
					mvprintw( 7,  1, "Signal Level (dB): %.02f", fNiveldB);
					mvprintw( 7, 30, "<                                               >");

					for(i=1; i< (80+(int)fNiveldB)/2;i++)
						mvprintw( 7, 30+i, "|");

					for(i=8; i < 14;i++)
						for(j=20; j < 40; j++)
							mvprintw( i,  j, " ");

					mvprintw( 8, 20, "%d", nFrequency);
					mvprintw( 9, 20, "%d", nSilenceThreshold);
					mvprintw(10, 20, "%d", nFlagAudio);

					mvprintw(12, 20, "%d", nTOM);
					mvprintw(13, 20, "%d", nSilencio);
					//mvprintw(14, 1, "fNivel %f, count %d, fSinal %f",fNivel, count, fSinal);
		    	}
        }
		count++;  //Remove in the future
    } /* while */     
	destroy_win(win_ev);
    endwin();
    /* Stops voicerlib engine */
    dg_ShutdownVoicerlib();
    printf("\n\n* * * Goodbye! * * *\n\n");
    return EXIT_SUCCESS;
}

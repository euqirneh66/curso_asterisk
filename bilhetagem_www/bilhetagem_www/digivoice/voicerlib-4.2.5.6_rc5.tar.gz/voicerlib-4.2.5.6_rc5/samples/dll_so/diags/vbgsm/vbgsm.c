//---------------------------------------------------------------------------------------------------------------------
//Digivoice Tecnologia em eletronica Ltda.
//Exemplo para placa GSM
//
//configuracoes para Windoes MS VS8
//Project->Properties->C/C++->Genereal->Aditional Include Directories->c:\Arquivos de Programas\VoicerLib4\include
//Project->Properties->Linker->General->Aditional Library Directories->c:\Arquivos de Programas\VoicerLib4\lib
//Project->Properties->Linker->Input->Aditional Dependencies->voicerlib.lib
//
//---------------------------------------------------------------------------------------------------------------------


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef DG_WIN
#include <conio.h>
#include <windows.h>
#include <io.h>
#else
#include <termios.h>
#include <unistd.h>
#endif
#include <vlibdef.h>
#ifdef DG_WIN
#define DllImport   __declspec(dllimport)
#endif
#include <voicerlib.h>

#define DEBUG 1
#define MAX_CANAIS			240			//maximo de canais do sistema
#define MAX_RINGS				6

//estados de atendimento
#define REPOUSO					1
#define ATENDEU					2
#define FALANDO					3
#define DESLIGANDO				4


//estrutura de controle dos canais
struct stCanais 
{
	int nChanState;
	int nRingsCount;
	FILE *fFala;
	char szNumero[50];
	char szNumeroA[50];
	int nFirstTime;
}Canais[MAX_CANAIS];

//variaveis globais
FILE *play_stream;
int nConta[20];			//contadores de eventos
char szTemp[255];		//armazenagem de string de caracteres temporaria
int file_format = 3;	    //ffWave,ffSig,ffWavePCM, ffGsm610
int play=0;
char szMsg[255];
int nVerbose=0;			//flag de verbose

dg_event_data_structure event_context;

#ifndef DG_WIN
int getch(void) {
  struct termios oldt, newt;
  int ch;
 
  /* We can't necessarily trust POSIX's STDIN_FILENO */
  int stdin_fd = fileno(stdin);
 
  /* Get and save the current terminal flags */
  tcgetattr(stdin_fd, &oldt);
 
  /* Copy the old settings and turn off echo/canonical mode */
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
 
  /* Apply the new settings */
  tcsetattr(stdin_fd, TCSANOW, &newt);
 
  /* Call the standard getchar() function */
  ch = getchar();
 
  /* Restore the original settings */
  tcsetattr(stdin_fd, TCSANOW, &oldt);
 
  return ch;
}
#endif

//----------------------------------------
//Prints help menu
//----------------------------------------
void print_menu(void)
{
	printf("\n---------------------------------\n");
	printf("|            Menu               |\n");
	printf("---------------------------------\n");
	printf("<c> Mudar o canal\n");
	printf("<d> Discar \n");
	printf("<e> Deletar SMS \n");
	printf("<g> Ler SMS\n");
	printf("<h> Desligar\n");
	printf("<k> Enviar comando generico \n");
	printf("<l> Lista de mensagens SMS\n");
	printf("<m> Menu\n");
	printf("<n> Nivel de Sinal \n"); 
	printf("<p> Atender \n");
	printf("<r> Reiniciar canal \n");
	printf("<s> Enviar SMS (uma linha)\n");
	printf("<t> Le e Deleta todas mensagens SMS\n");
	printf("<y> Enviar SMS (multilinhas)\n");	
	printf("<v> Verbose - Logs \n");
	printf("<q> Sair \n\n");
}

//----------------------------------------
//imprime evento
//----------------------------------------
void print_event(char *szMsg, int port)
{

	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);
	now = localtime(&curSecs);
	printf("<%02d:%02d:%02d> <%d>: %s\n",now->tm_hour, now->tm_min, now->tm_sec, port,szMsg);
}

//----------------------------------------
//Call back de eventos
//----------------------------------------
#ifndef __LINUX__
void CALLBACK ReceiveEvents(void *context_data)
#else
void ReceiveEvents(void *context_data)
#endif
{
    dg_event_data_structure *EventContext;
    char data[512];
    char szDig[256];
	char szTemp[256];
	char szTemp2[256];
	int nSignalQ,nSignalP;
	int ret=0;
    data[0] = 0;

    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);

	szDig[0] = 0;
 	
	switch (EventContext->command)
	{
			case EV_SILENCE:
			break;

			//case EV_AUDIO_SIGNAL:
			//	sprintf(data,"EV_AUDIO_SIGNAL Porta = %d - DATA=%x",EventContext->port, EventContext->data);
			//	break;

			case EV_ERRORDETECTED:
				sprintf(data,"(EV_ERRORDETECTED) - Erro na placa. Ret= 0x%x ", EventContext->data);
				//dg_ResetError(1,DONTSEND_ERROR);
			break;

			case EV_CALLPROGRESS_TIMEOUT:
				sprintf(data,"(EV_CALLPROGRESS_TIMEOUT) - Timeout na Supervisao de Linha da porta ");
				//Desabilita supervisao de linha
				ret = dg_DisableCallProgress(EventContext->port);				
				if (ret != DG_EXIT_SUCCESS) 
					sprintf(data,"(EV_CALLPROGRESS_TIMEOUT) - Erro ao desabilitar Supervisao de Linha. Ret %d", ret);
				else
					sprintf(data,"(EV_CALLPROGRESS_TIMEOUT) - Supervisao de Linha desabilitada ");	
				//Desliga o canal	
				ret = dg_HangUp(EventContext->port);
				if (ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_CALLPROGRESS_TIMEOUT) - Erro ao desligar o canal. Ret %d",ret);
				else
					sprintf(data,"(EV_CALLPROGRESS_TIMEOUT) - Desligou o canal ");
			break;

			case EV_LINEREADY:
				sprintf(data,"(EV_LINEREADY) Line Ready...");
			break;

			case EV_LINEOFF:
				sprintf(data,"(EV_LINEOFF) - Line OFF...");
			break;

			case EV_CALLERID:
				//Salva o numero de quem ligou
				dg_GetCallerId(EventContext->port,Canais[EventContext->port].szNumeroA);
				sprintf(data,"(EV_CALLERID) - BINA: %s", Canais[EventContext->port].szNumeroA);
			break;

			case EV_GSMOTHERCALL:
				//salva o n�mero de quem ligou
				dg_GetCallerId(EventContext->port,Canais[EventContext->port].szNumeroA);
				sprintf(data,"(EV_GSMOTHERCALL) - BINA da nova chamada: %s", Canais[EventContext->port].szNumeroA);
			break;

			case EV_RINGS:
				sprintf(data,"(EV_RINGS) - Ring....");
				Canais[EventContext->port].nRingsCount++;
				if((Canais[EventContext->port].nRingsCount >= MAX_RINGS)&&(Canais[EventContext->port].nChanState != ATENDEU))
				{
					//Atende a porta
					ret = dg_PickUp(EventContext->port,1000);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_RINGS) - Erro ao atender o canal. Ret %d",ret);
					else
					{
						sprintf(data,"(EV_RINGS) - Atendeu...");
						Canais[EventContext->port].nChanState = ATENDEU;				    
					}
				}
				break;

			case EV_DTMF:
				//sprintf(data,"DTMF Number: %c", EventContext->data);
				break;

			case EV_BUSY:
				sprintf(data,"(EV_BUSY) - Ocupado....");

				//registra evento de busy e salva numero discado
				if (Canais[EventContext->port].nChanState == FALANDO)
				{					
					if (dg_IsPlaying(EventContext->port))
					{
						//Para reproducao 
						ret = dg_StopPlayFile(EventContext->port);
						if (ret != DG_EXIT_SUCCESS)
							sprintf(data,"(EV_BUSY) - Erro ao interromper a reproducao do arquivo. Ret %d",ret);
						else
							sprintf(data,"(EV_BUSY) - Interrompeu a reproducao do arquivo...");

					}
					//aguarda ev_playstop
					Canais[EventContext->port].nChanState = DESLIGANDO;
				}
				else
					if (Canais[EventContext->port].nChanState == REPOUSO)
					{
						Canais[EventContext->port].szNumeroA[0]='\0';
						Canais[EventContext->port].szNumero[0]='\0';
					}
				break;

			case EV_CALLING:
				sprintf(data,"(EV_CALLING) - Chamando...");
				break;

			case EV_DIALTONE:
				sprintf(data,"(EV_DIALTONE) - Tom de linha... ");
			break;

			case EV_AFTERDIAL:
				sprintf(data,"(EV_AFTERDIAL) - Terminou de discar ");
				//Habilita supervisao de linha
				ret = dg_EnableCallProgress(EventContext->port,CP_ENABLE_ALL);
				if (ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_AFTERDIAL) - Erro ao habilitar supervisao de linha. Ret %d ",ret);
				else
					sprintf(data,"(EV_AFTERDIAL) - Habilitou supervisao de linha");
			break;

			case EV_PLAYSTOP:
				sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir ");
				//Desliga o canal
				ret = dg_HangUp(EventContext->port);
				if (ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_PLAYSTOP) - Erro ao desligar a porta. Ret %d",ret);
				else
					sprintf(data,"(EV_PLAYSTOP) - Desligou a porta ");
				
				//Volta ao repouso
				Canais[EventContext->port].nChanState = REPOUSO ;
				Canais[EventContext->port].nRingsCount = 0;
				Canais[EventContext->port].szNumeroA[0]='\0';
				Canais[EventContext->port].szNumero[0]='\0';
			break;

			case EV_AFTERPICKUP:
				sprintf(data,"(EV_AFTERPICKUP) - Atendeu com sucesso");

				if( Canais[EventContext->port].nChanState == ATENDEU)
				{
						sprintf(szTemp,"mensagem.wav");
						//Reproduz a mensagem
						ret = dg_PlayFile(EventContext->port,szTemp,"",0);
						if (ret!=DG_EXIT_SUCCESS)
						{
							sprintf(data,"(EV_AFTERPICKUP) - Erro ao reproduzir arquivo. Ret %d", ret);

							//volta ao repouso
							Canais[EventContext->port].nChanState = REPOUSO ;
							Canais[EventContext->port].nRingsCount = 0;
							Canais[EventContext->port].szNumeroA[0]='\0';
							Canais[EventContext->port].szNumero[0]='\0';

							//Desliga o canal
							ret = dg_HangUp(EventContext->port);
							if (ret != DG_EXIT_SUCCESS)
								sprintf(data,"(EV_AFTERPICKUP) - Erro ao desligar o canal. Ret %d", ret);
							else							
								sprintf(data,"(EV_AFTERPICKUP) - Desligou a porta");
							exit(0);
						}
						else
						{
							Canais[EventContext->port].nChanState = FALANDO;
							sprintf(data,"(EV_AFTERPICKUP) - Reproduzindo mensagem...");
						}
					}
			break;

			case EV_GSMTIMEOUT:
				sprintf(data,"(EV_GSMTIMEOUT) - Timeout no modulo GSM");
			break;

			case EV_GSMSMSRECEIVED:
				dg_GSMGetSMS(EventContext->port,szTemp);
				printf("\n---------------------------------------------------------------------------\n");
				printf("\n(EV_GSMSMSRECEIVED) - Recebeu mensagem SMS: %s",szTemp);
				printf("\n---------------------------------------------------------------------------\n");

			break;

			case EV_GSMMESSAGE:
				if(nVerbose !=0)
				{
					dg_GSMGetLastCommand(EventContext->port,szTemp2);
					dg_GSMGetMessage(EventContext->port,szTemp);
					sprintf(data,"(EV_GSMMESSAGE) - Mensagem Recebida: %s \t\tUltima Mensagem Recebida: %s\r\n",szTemp2,szTemp);
				}
			break;

			case EV_GSMSMSSENT:
				dg_GSMGetMessage(EventContext->port,szTemp);
				sprintf(data,"(EV_GSMSMSSENT) - Enviou a mensagem SMS - %s",szTemp);
			break;

			case EV_GSMERROR:
				dg_GSMGetMessage(EventContext->port,szTemp);
				sprintf(data,"(EV_GSMERROR) - Erro na porta ou sinalizacao: %s ",szTemp);
			break;

			case EV_GSMREADY:
				if (EventContext ->data == 1 )
					sprintf(data,"(EV_GSMREADY) - ***Canal Pronto***\r\n ");
				else
					sprintf(data,"(EV_GSMREADY) - ***Canal nao iniciado ***\r\n");	
				break;

			case EV_GSMSIGNALQUALITY:
				dg_GSMGetSignalQuality(EventContext->port,szTemp);
				if(atoi(szTemp) != 99)
				{
					nSignalP = 100 * atoi(szTemp)/31;
					nSignalQ = -113 + 2* atoi(szTemp);
					sprintf(data,"(EV_GSMSIGNALQUALITY) - Sinal:%s  SQ: %d dBm, SQP: %d%c\n",szTemp,nSignalQ,nSignalP,37);
				}else
					sprintf(data,"(EV_GSMSIGNALQUALITY) - Nao foi possivel medir o sinal");

			break;

			case EV_ANSWERED:
				sprintf(data,"(EV_ANSWERED) - Atendeu o canal");
				//Desabilita a Supervisao de Linha
				ret = dg_DisableCallProgress(EventContext->port);
				if (ret != DG_EXIT_SUCCESS) 
					sprintf(data,"(EV_ANSWERED) - Erro ao desabilitar a supervisao de linha. Ret %d",ret);
				else
					sprintf(data,"(EV_ANSWERED) - Desabilitou supervisao de linha");
			break;

			case EV_FAX:
				sprintf(data,"(EV_FAX) - Detectou tom de FAX...");
			break;

			case EV_DIGITSRECEIVED:
				sprintf(data,"(EV_DIGITSRECEIVED) - Status: ",EventContext->data);
			break;

			case EV_GSMRETURNOK:
				if (EventContext->data == GSM_LIST)
				{
					dg_GSMGetIndexList(EventContext->port,szTemp);
					sprintf(data,"(EV_GSMRETURNOK) - Recupera o indice de mensagens. Status: %s",szTemp);
				}
				else
					sprintf(data,"(EV_GSMRETURNOK) - Retorno do modulo: %d",EventContext->data);	
			break;

			case EV_GSMMEMORYFULL:
				sprintf(data,"(EV_GSMMEMORYFULL) - Memoria cheia!");	
				break;

			case EV_GSMSIM:
				if (EventContext->data == 0)
					sprintf(data,"(EV_GSMSIM) - ***** Retirou SIM Card ***** ");	
				else
				{
					sprintf(data,"(EV_GSMSIM) - ***** Inseriu SIM Card *****");	
					//Reinicia o modulo
					dg_GSMRestartPort(EventContext->port); 
				}
				break;

			default:
				EventContext->command = 0xff;
		}
#ifdef DEBUG
	if (strlen(data)>0)
		print_event(data, EventContext->port);
#endif
}

int main(int argc, char* argv[])
{
	short ret;
	char ch;
	char szTemp[255];
	char szTemp1[255];
	int cc;
	short card;
	int nPortsCount;
	int nRunningStatus = 0;
	int c=1;
	int nIndex;
	int flag=1;

	printf("-------------------------------------------\n");
	printf("- Programa de Diagnostico interface GSM   -\n");
	printf("-------------------------------------------\n");

	//Passa para a dll o ponteiro da callback que tratara os eventos
	dg_SetEventCallback(ReceiveEvents,&event_context);

	printf("\nIniciando VoicerLib...Aguarde...\n");

	//Inicia Voicerlib
	ret = dg_StartVoicerlib(NULL);
	if (ret!=DG_EXIT_SUCCESS)
	{
		printf("\n**************************************************\n");
		printf(" Erro ao inicializar a Voicerlib. Ret = %d			                       \n",ret);		
		printf("**************************************************\n");
		printf("\nAperte uma tecla para sair...");
		ch = getch();
		exit(0);
	}
	else	
		printf("\nVoicerlib inicializada com sucesso");

	//Armazena quantidade de portas 
	nPortsCount = dg_GetPortsCount();

	printf("\nFormato de reproducao: WaveULaw\n\n");
	
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		//Seta formato de reproducao
		ret = dg_SetPlayFormat(cc,ffWaveULaw);
		if (ret != DG_EXIT_SUCCESS)
			printf("\nErro ao setar o formato de reproducao. Ret %d\n", ret);
		Canais[cc].nChanState = REPOUSO;
		Canais[cc].nRingsCount=0;
		Canais[cc].nFirstTime=0;
	}
    
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		card = dg_GetCardNumber(cc);
		//Testa interface da placa
		if(dg_GetCardInterface(card) == DG_GSM_INTERFACE)
		{
			dg_ConfigGSMThread(cc,GSMCFG_CALL_WAITING_ENABLE,0);
			//Configura timeout entre os digitos
			dg_ConfigGSMThread(cc,GSMCFG_DIGIT_TIMEOUT,10000);
			//Restringe o envio de calledid - BINA
			dg_ConfigGSMThread(cc,GSMCFG_ID_RESTRICTION,0);
			//Cria threads GSM
			if ((ret=dg_CreateGSMThread(cc)) != DG_EXIT_SUCCESS)
			{	
				printf("**************************************************\n");
				printf("(%d) Erro ao criar thread GSM. Ret = %d !!!! \n",cc,ret);
				printf("**************************************************\n\n");
	     		//Finaliza Voicerlib
				ret = dg_ShutdownVoicerlib();
				if (ret != DG_EXIT_SUCCESS)
					printf("\nErro ao finalizar a Voicerlib. Ret %d\n",ret);
				cc=getch();
				exit(0);
			}
			else
				printf("(%d) Thread GSM criada com sucesso\n",cc-1);
			
		}
	}	

	//Cria thread de supervisao de linha
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		if ((ret=dg_CreateCallProgress(cc,"cp_default.cfg")) != DG_EXIT_SUCCESS)
		{
			printf("**************************************************************\n");
			printf("(%d) Erro ao criar thread de Supervisao de Linha. Ret = %d!!!\n",cc,ret);
			printf("**************************************************************\n\n");
	     	//Finaliza a VoicerLib
            dg_ShutdownVoicerlib();
			cc=getch();
			exit(0);
		}
		else
			printf("(%d) Thread de Supervisao de Linha criada com sucesso\n",cc);
	}	

	for(cc=0;cc<dg_GetCardsCount();cc++)
		printf("\n\nVersao do Firmware: %x \n",dg_GetVersion(cc+1));

	print_menu();

	while(flag)
	{
		ch = getch();
#ifndef DG_WIN
		digivoice_sleep(10);
#endif
		switch(ch)
		{
		case 'q': //Sair
		case 'Q':
			flag=0;
			break;

		case 'd': //Discar
		case 'D':
			printf("\nEntre com o numero: ");
			fflush(stdin);
			scanf("%s",szTemp);
			//Disca
			ret = dg_Dial(c,szTemp,100,dtDTMF);
			if (ret != DG_EXIT_SUCCESS)
				printf("\nErro ao discar %s pelo canal %d. Ret %d \n",szTemp,c,ret);
			else
				printf("\nDiscando %s pelo canal %d....\n",szTemp,c);
			break;

		case 'p': //Atender
		case 'P':
			//Atende o canal
			ret = dg_PickUp(c,100);
			if (ret != DG_EXIT_SUCCESS)
				printf("\nErro ao atender o canal %d. Ret %d \n", c, ret);
			else
				printf("\nAtendeu o canal %d....\n" , c);
			break;

		case 'h': //Desligar
		case 'H':
			//Desliga
			ret = dg_HangUp(c);
			if (ret != DG_EXIT_SUCCESS)
				printf("\nErro ao desligar o canal %d. Ret %d \n" , c, ret);	
			else
				printf("\nDesligou o canal %d....\n" , c);
			break;

		case 'c': //Mudar o canal 
		case 'C':			
			c++;
			if(c>dg_GetPortsCount())
				c=1;
			printf("\nTrocou o canal %d....\n" , c);
			break;

		case 'm': //Menu
		case 'M':			
			print_menu();
			break;

		case 's': //Enviar SMS
		case 'S':
			printf("\nEntre com o numero: ");
			fflush(stdin);
			scanf("%s",szTemp);

			printf("\nEntre com a mensagem: ");
			fflush(stdin);
			scanf("%s",szTemp1);
			//Envia a mensagem SMS
			dg_GSMSendSMS(c, szTemp, szTemp1);
			break;

		case 'y': //Enviar SMS multilinha
		case 'Y':
			printf("\nEntre com o numero: ");
			fflush(stdin);

			scanf("%s",szTemp);
			sprintf(szTemp1,"Este eh um teste de envio de SMS pela placa Vb0404GSM\r\nA nova solucao de GSM da Digivoice\r\n");
			//Envia a mensagem SMS
			dg_GSMSendSMS(c, szTemp, szTemp1);
			break;

		case 'k': //Enviar comando generico
		case 'K':
			printf("\nEntre com o comando: ");
			fflush(stdin);
			scanf("%s",szTemp);
			if(szTemp[strlen(szTemp)-1]== 0xa)
			{
				szTemp[strlen(szTemp)-1] = '\0';
			}
			sprintf(szTemp1,"Envio de comando generico\r\n");
			//Envia omando para placa 
			dg_GSMSendCommand(c, szTemp);
			break;

		case 'l': //Lista de mensagens SMS
		case 'L':
			dg_GSMListSMS(c,ALL);
			break;

		case 't': //Le e Deleta todas mensagens SMS
		case 'T':
			dg_GSMClearAllSMS(c,1);
			break;

		case 'e': //Deleta SMS
		case 'E':
			printf("\nEntre com o index: ");
			fflush(stdin);
			scanf("%s",szTemp);
			nIndex = atoi(szTemp);
			//Apaga as mensagens SMS 
			ret = dg_GSMDeleteSMS(c,nIndex);
			if (ret != DG_EXIT_SUCCESS)
				printf("\nErro ao deletar mensagem SMS. Ret %d\n", ret); 
			else
				printf("\nDeletou mensagem SMS com sucesso...\n");
			break;

		case 'g': //Ler SMS
		case 'G':
			printf("\nEntre com o index: ");
			fflush(stdin);
			scanf("%s",szTemp);
			nIndex = atoi(szTemp);
			ret = dg_GSMReadAndDeleteSMS(c,nIndex);
			if (ret != DG_EXIT_SUCCESS)
				printf("Erro ao ler e apagar a mensagem do modulo GSM. Ret %d\n", ret);
			else
				printf("Leu e Apagou a mensagem do modulo GSM com sucesso\n");
			break;

		case 'n': //Nivel de Sinal
		case 'N':
			//Verifica a qualidade do sinal
			dg_GSMCheckSignalQuality(c);
			break;

		case 'r': //Reiniciar canal
		case 'R':
			printf("\n\n!!!!!!Reiniciando o modulo!!!!!!!!!!!!\n\n");
			//Reinicia a porta GSM
			dg_GSMRestartPort(c);
			break;

		case 'v': //Verbose - Logs
		case 'V':
			if(nVerbose == 0)
				nVerbose = 1;
			else
				nVerbose = 0;
			printf("\nVerbose - Logs = %d\n",nVerbose);
			break;
		}
	}//fim do while

	for (cc=1;cc<=nPortsCount;cc++) 
	{
		card = dg_GetCardNumber(cc);		
		if(dg_GetCardInterface(card) == DG_GSM_INTERFACE)
			//Destroi threads GSM
			if ((ret=dg_DestroyGSMThread(cc)) != DG_EXIT_SUCCESS)
				printf("\nErro ao destruir a thread GSM - %d\n!!!!",cc);
	}	
	//Finaliza a Voicerlib
	ret = dg_ShutdownVoicerlib();
	if (ret != DG_EXIT_SUCCESS)
		printf("\nErro ao finalizar a Voicerlib\n");
	return 0;
}

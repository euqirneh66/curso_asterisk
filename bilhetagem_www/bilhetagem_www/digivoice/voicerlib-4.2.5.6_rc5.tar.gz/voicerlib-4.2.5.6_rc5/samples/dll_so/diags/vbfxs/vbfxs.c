//---------------------------------------------------------------------------------------------------------------------
//Digivoice Tecnologia em eletronica Ltda.
//Exemplo da placa FXS
//
//configuracoes para Windoes MS VS8
//Project->Properties->C/C++->General->Aditional Include Directories->c:\Arquivos de Programas\VoicerLib4\include
//Project->Properties->Linker->General->Aditional Library Directories->c:\Arquivos de Programas\VoicerLib4\lib
//Project->Properties->Linker->Input->Aditional Dependencies->voicerlib.lib
//
//---------------------------------------------------------------------------------------------------------------------


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef DG_WIN
#include <conio.h>
#include <windows.h>
#include <io.h>
#else
#include <termios.h>
#include <unistd.h>
#endif
#include <vlibdef.h>
#ifdef DG_WIN
#define DllImport   __declspec(dllimport)
#endif
#include <voicerlib.h>

#define DEBUG 1
#define MAX_CANAIS			240			//maximo de canais do sistema
#define MAX_RINGS				6

//estados de atendimento
#define REPOUSO					1
#define ATENDEU					2
#define FALANDO					3
#define DESLIGANDO				4


//estrutura de controle dos canais
struct stCanais 
{
	int nChanState;
	int nRingsCount;
	FILE *fFala;
	char szNumero[50];
	char szNumeroA[50];
}Canais[MAX_CANAIS];

//variaveis globais
FILE *play_stream;
int nConta[20];			//contadores de eventos
char szTemp[255];		//armazenagem de string de caracteres temporaria
int file_format = 3;	    //ffWave,ffSig,ffWavePCM, ffGsm610
int play=0;
char szMsg[255];
int nVerbose=0;			//flag de verbose

dg_event_data_structure event_context;

#ifndef DG_WIN
int getch(void) {
  struct termios oldt, newt;
  int ch;
 
  /* We can't necessarily trust POSIX's STDIN_FILENO */
  int stdin_fd = fileno(stdin);
 
  /* Get and save the current terminal flags */
  tcgetattr(stdin_fd, &oldt);
 
  /* Copy the old settings and turn off echo/canonical mode */
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
 
  /* Apply the new settings */
  tcsetattr(stdin_fd, TCSANOW, &newt);
 
  /* Call the standard getchar() function */
  ch = getchar();
 
  /* Restore the original settings */
  tcsetattr(stdin_fd, TCSANOW, &oldt);
 
  return ch;
}
#endif

//----------------------------------------
//Prints help menu
//----------------------------------------
void print_menu(void)
{
	printf("\n---------------------------------\n");
	printf("|            Menu               |\n");
	printf("---------------------------------\n");
	printf("<c> Mudar o canal\n");
	printf("<i> Verificar interface\n");
	printf("<p> Atender \n");
	printf("<d> Discar \n");
	printf("<h> Desligar\n");
	printf("<k> Reproduzir mensagem\n");
	printf("<l> Interromper reproducao da mensagem\n");
	printf("<r> Gravar ligacao\n");
	printf("<t> Interromper gravacao\n");
	printf("<f> Habilitar deteccao FSK\n");
	printf("<g> Desabilitar deteccao FSK\n");
	printf("<z> Inicia ring\n");
	printf("<x> Desliga ring\n");
	printf("<m> Menu\n");
	printf("<q> Sair \n\n");
}

//----------------------------------------
//imprime evento
//----------------------------------------
void print_event(char *szMsg, int port)
{

	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);
	now = localtime(&curSecs);
	printf("<%02d:%02d:%02d> <%d>: %s\n",now->tm_hour, now->tm_min, now->tm_sec, port,szMsg);
}

//----------------------------------------
//Call back de eventos
//----------------------------------------
#ifndef __LINUX__
void CALLBACK ReceiveEvents(void *context_data)
#else
void ReceiveEvents(void *context_data)
#endif
{
    dg_event_data_structure *EventContext;
    char data[512];
    char szDig[256];
	int nSignalQ;
	int ret=0;
    data[0] = 0;

    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);

	szDig[0] = 0;
 	
	switch (EventContext->command)
	{
			case EV_AFTERDIAL:
				if (dg_GetPortInterface(EventContext->port) == DG_FXS_INTERFACE)
				{
					//Inicia o ring
					ret = dg_SetRing(EventContext-> port, DG_ENABLE, 1);
					if(ret != DG_EXIT_SUCCESS)
						sprintf(EventContext-> port, "(EV_AFTERDIAL) - Erro ao iniciar ring. Ret %d", ret);
					else
						sprintf(EventContext-> port, "(EV_AFTERDIAL) - Iniciou ring com sucesso!");
				}
				else
				{
					if (dg_GetPortInterface(EventContext->port) == DG_FXO_INTERFACE)
					{						
						//Habilita supervisao de linha
						ret = dg_EnableCallProgress(EventContext->port,CP_ENABLE_ALL);
						if (ret != DG_EXIT_SUCCESS)
							sprintf(data,"(EV_AFTERDIAL) - Erro ao habilitar supervisao de linha. Ret %d ",ret);
						else
							sprintf(data,"(EV_AFTERDIAL) - Terminou de discar ");
					}	
				}
				break;

			case EV_CALLERID:
				//Salva o numero de quem ligou
				dg_GetCallerId(EventContext->port,Canais[EventContext->port].szNumeroA);
				sprintf(data,"(EV_CALLERID) - BINA: %s", Canais[EventContext->port].szNumeroA);
				break;


			case EV_DTMF:
				if(dg_GetPortInterface(EventContext->port) == DG_FXS_INTERFACE) //FXS
					dg_GenerateMF(EventContext->port, GENERATE_OFF, 0);
				sprintf(data, "(EV_DTMF) - Recebeu Digito %d", EventContext->data);        
				break;

			case EV_DIGITSRECEIVED:

				switch (EventContext->data)
				{
					case edOff:
						sprintf(data,"(EV_DIGITSRECEIVED) - Desligado");
						break;

					case edWaiting:
						sprintf(data,"(EV_DIGITSRECEIVED) - Em espera");
						break;

					case edMaxDigits:
						sprintf(data,"(EV_DIGITSRECEIVED) - Alcancou m�ximo de digitos");
						break;

					case edTermDigit:
						sprintf(data,"(EV_DIGITSRECEIVED) - Recebeu digito finalizador");
						break;

					case edDigitTimeOut:
						sprintf(data,"(EV_DIGITSRECEIVED) - Timeout global");
						break;

					case edInterDigitTimeOut:
						sprintf(data,"(EV_DIGITSRECEIVED) - Timeout interdigito");
						break;	
				}
				break;

			case EV_ERRORDETECTED:
				sprintf(data,"(EV_ERRORDETECTED) - Erro na placa. Ret= 0x%x ", EventContext->data);
			break;

			case EV_FAX:
				sprintf(data,"(EV_FAX) - Detectou tom de FAX...");
			break;

			case EV_LINEREADY:
				sprintf(data,"(EV_LINEREADY) - Line Ready...");
			break;

			case EV_LINEOFF:
				sprintf(data,"(EV_LINEOFF) - Line OFF...");
			break;

			case EV_PLAYSTART:
				sprintf(data,"(EV_PLAYSTART) - Reproduzindo...");
				break;

			case EV_PLAYSTOP:

				switch (EventContext->data)
				{
					case ssStopped:
					case ssNormal:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir");
						break;
					case ssDigitReceived:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir pois recebeu digito finalizador");
						break;
					case ssAbnormal:
						sprintf(data,"(EV_PLAYSTOP) - Erro indeterminado ao interromper a reproducao");
						break;
					default:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir a mensagem");
				}		
			break;

			case EV_RECORDING:
				sprintf(data,"(EV_RECORDING) - Gravando (%d) segundo(s)...", EventContext ->data );
				break;

			case EV_RECORDSTOP:
				switch (EventContext->data)
				{
					case ssNormal:
						sprintf(data,"(EV_RECORDSTOP) - Parou de gravar com sucesso");
						break;

					case ssStopped:
						sprintf(data,"(EV_RECORDSTOP) - Gravacao interrompida");
						break;

					case ssDigitReceived:
						sprintf(data,"(EV_RECORDSTOP) - Gravacao interrompida por digito");
						break;

					case ssAbnormal:
						sprintf(data,"(EV_RECORDSTOP) - Erro indeterminado ao parar gravacao");
						break;
				}		

				//Desabilita InputBuffer
				ret = dg_DisableInputBuffer(EventContext ->port);
				if(ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_RECORDSTOP) - Erro ao desabilitar InputBuffer. Ret %d", ret);
				break;

			case EV_RINGS:
				sprintf(data,"(EV_RINGS) - Ring....");
				Canais[EventContext->port].nRingsCount++;
				if(Canais[EventContext->port].nRingsCount >= MAX_RINGS)
				{
					//Atende a porta
					ret = dg_PickUp(EventContext->port,1000);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_RINGS) - Erro ao atender o canal. Ret %d",ret);
					else
					{
						sprintf(data,"(EV_RINGS) - Atendeu...");		    
					}
				}
				break;

			default:
				EventContext->command = 0xff;
		}
#ifdef DEBUG
	if (strlen(data)>0)
		print_event(data, EventContext->port);
#endif
}

int main(int argc, char* argv[])
{
	short ret;
	char ch;
	int cc,i;
	int nPortsCount;
	int nRunningStatus = 0;
	int c=1;
	int flag=1;

	printf("-------------------------------------------\n");
	printf("- Programa de Diagnostico interface FXS   -\n");
	printf("-------------------------------------------\n");

	//Passa para a dll o ponteiro da callback que tratara os eventos
	dg_SetEventCallback(ReceiveEvents,&event_context);

	printf("\nIniciando VoicerLib...Aguarde...\n");

	//Inicia Voicerlib
	ret = dg_StartVoicerlib(NULL);
	if (ret!=DG_EXIT_SUCCESS)
	{
		printf("\n**************************************************\n");
		printf(" Erro ao inicializar a Voicerlib. Ret = %d			                       \n",ret);		
		printf("**************************************************\n");
		printf("\nAperte uma tecla para sair...");
		ch = getch();
		exit(0);
	}
	else	
		printf("\nVoicerlib inicializada com sucesso\n");

	//Armazena quantidade de portas 
	nPortsCount = dg_GetPortsCount();
	
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		//Seta formato de reproducao
		ret = dg_SetPlayFormat(cc,ffWaveULaw);
		if (ret != DG_EXIT_SUCCESS)
			printf("\n(%d)Erro ao setar o formato de reproducao. Ret %d\n", cc, ret);
		//Seta formato de gravacao
		ret = dg_SetRecordFormat(cc,ffWaveULaw);
		if (ret != DG_EXIT_SUCCESS)
			printf("\n(%d)Erro ao setar o formato de gravacao. Ret %d\n", cc, ret);
		Canais[cc].nRingsCount=0;
	}

	printf("\nFormato de gravacao e reproducao: WaveULaw\n\n");
	
	for (cc=1;cc<=nPortsCount;cc++)  
	{
        //Detecta Tons DTMF
        ret = dg_SetDetectionType(cc, DETECT_MFF, DG_DISABLE);
        if(ret != DG_EXIT_SUCCESS)
			printf("\n(%d)Erro ao desabilitar deteccao de MF. Ret %d\n", cc, ret);
		//Habilita deteccao de DTMF
        ret = dg_SetDetectionType(cc, DETECT_DTMF, DG_ENABLE);
        if(ret != DG_EXIT_SUCCESS)
            printf("\n(%d)Erro ao habilitar detec��o de DTMF. Ret %d\n", cc, ret);
        //Configura limiar para detectar atendimento
        ret = dg_SetSilenceThreshold(cc,-30);
        if(ret != DG_EXIT_SUCCESS)
            printf("\n(%d)Erro ao setar limiar para detec��o de atendimento. Ret %d\n", cc, ret);

		//Cria thread de supervisao de linha	
		if ((ret=dg_CreateCallProgress(cc,"cp_default.cfg")) != DG_EXIT_SUCCESS)
		{
			printf("**************************************************************\n");
			printf("(%d)Erro ao criar thread de Supervisao de Linha. Ret = %d!!!\n",cc,ret);
			printf("**************************************************************\n\n");
	     	//Finaliza a VoicerLib
            dg_ShutdownVoicerlib();
			cc=getch();
			exit(0);
		}
		else
			printf("(%d)Thread de Supervisao de Linha criada com sucesso\n",cc);
	}	

	for(cc=0;cc<dg_GetCardsCount();cc++)
		printf("\n\nVersao do Firmware: %x \n",dg_GetVersion(cc+1));

	print_menu();

	while(flag)
	{
		ch = getch();
#ifndef DG_WIN
		digivoice_sleep(10);
#endif
		switch(ch)
		{

			case 'c': //Mudar o canal 
			case 'C':			
				c++;
				if(c>dg_GetPortsCount())
					c=1;
				printf("\nTrocou o canal %d....\n" , c);
				break;

			case 'i': //Verificar a interface
			case 'I':			
				for(i=1;i<=dg_GetPortsCount();i++)
				{
					if(dg_GetPortInterface(i) == DG_FXO_INTERFACE)
						printf("\n(%d)Canal FXO\n" ,i);
					else
						if((dg_GetPortInterface(i) == DG_FX_INTERFACE) || (dg_GetPortInterface(i) == DG_FXS_INTERFACE))
							printf("\n(%d)Canal FXS\n" ,i);	
						else
							printf("\n(%d)Canal nao e' FXO nem FXS\n" ,i);	
				}
				break;

			case 'p': //Atender
			case 'P':
				//Atende o canal
				ret = dg_PickUp(c,100);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao atender o canal. Ret %d \n", c, ret);
				else
				{
					printf("\n(%d)Atendeu o canal...\n" , c);
					//Habilita supervisao de linha
					ret = dg_EnableCallProgress(c,CP_ENABLE_LINETONE_OR_BUSY);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao habilitar supervisao de linha. Ret %d\n" , c, ret);
				}
				break;

			case 'd': //Discar
			case 'D':
				if(dg_GetPortInterface(c) == DG_FXO_INTERFACE)
				{
					printf("\nEntre com o numero: ");
					fflush(stdin);
					scanf("%s",szTemp);
					//Disca
					ret = dg_Dial(c,szTemp,100,dtDTMF);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao discar %s. Ret %d \n",c,szTemp,ret);
					else
						printf("\n(%d)Discando %s....\n",c,szTemp);
				}
				else
					printf("\n(%d)Escolha um canal FXO\n",c);
				break;

			case 'h': //Desligar
			case 'H':
				//Desliga o canal
				ret = dg_HangUp(c);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao desligar o canal. Ret %d \n" , c, ret);	
				else
					printf("\n(%d)Desligou o canal...\n" , c);
				//Desabilita supervisao de linha
				ret = dg_DisableCallProgress(c);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao desabilitar supervisao de linha. Ret %d \n" , c, ret);
				break;

			case 'k': //Reproduzir mensagem
			case 'K':
				if (dg_IsPlaying(c) == FALSE)
				{
					//Inicia a reproducao de um arquivo atraves da placa
					ret = dg_PlayFile(c, "teste.wav", "", 0);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao inicializar a reproducao. Ret %d \n" , c, ret);
					else
						printf("\n(%d)Reproducao inicializada com sucesso!\n" , c);				
				}
				break;				

			case 'l': //Interromper reproducao da mensagem
			case 'L':
				if(dg_IsPlaying(c))
				{
					//Interrompe a reproducao de um arquivo
					ret = dg_StopPlayFile(c);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao interromper a reproducao. Ret %d \n" , c, ret);
					else
						printf("\n(%d)Reproducao interrompida com sucesso!\n" , c);	
				}
				else
					printf("\n(%d)Nao ha reproducao em curso para interromper\n",c);
				break;

			case 'r': //Gravar ligacao
			case 'R':
				//Habilita o envio de amostras
				ret =  dg_EnableInputBuffer(c, DG_ENABLE_AGC);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao habilitar inputbuffer. Ret %d \n", c, ret);
			
		        //Grava mensagem
				ret = dg_RecordFile(c, "teste.wav","");
				if(ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao inicializar a gravacao. Ret %d \n", c, ret);
				else
					printf("\n(%d)Gravacao inicializada com sucesso!\n",c);					
				break;

			case 't': //Interromper gravacao 
			case 'T':
				if (dg_IsRecording(c))
				{
					//Interrompe a gravacao
					ret = dg_StopRecordFile(c);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao finalizar a gravacao. Ret %d\n", c, ret);	
					else
						printf("\n(%d)Gravacao finalizada com sucesso!\n",c);
				}
				else
					printf("\n(%d)Nao ha gravacoes em curso para interromper\n",c);
				break;

			case 'f': //Habilitar deteccao FSK
			case 'F': 
				if(dg_GetPortInterface(c) == DG_FXO_INTERFACE)
				{
					ret = dg_EnableFSKDetection(c, 0, 0);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao habilitar FSK. Ret %d\n", c, ret);		
					else
						printf("\n(%d)Habilitou deteccao FSK\n", c);	
				}
				else	
					printf("\n(%d)Nao e' interface FXO\n", c);	
				break;

			case 'g': //Desabilitar deteccao FSK
			case 'G': 
				if(dg_GetPortInterface(c) == DG_FXO_INTERFACE)
				{
					ret = dg_EnableFSKDetection(c, 1, 0);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao desabilitar FSK. Ret %d\n", c, ret);		
					else
						printf("\n(%d)Desabilitou deteccao FSK\n", c);	
				}
				else
					printf("\n(%d)Nao e' interface FXO...\n", c);	
				break;

			case 'z': //Inicia ring
			case 'Z':	
				if((dg_GetPortInterface(c) == DG_FXS_INTERFACE)||(dg_GetPortInterface(c) == DG_FX_INTERFACE))
				{
					//Manda o Bina antes de comecar a discar
					ret = dg_Dial(c, "A21916363C", 20, dtTone);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao executar Dial. Ret %d\n", c, ret);                          

					//Inicia o envio do Ring
					ret = dg_SetRing(c, DG_ENABLE, 1);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao iniciar ring. Ret %d\n", c, ret);  
					else
						printf("\n(%d)Iniciou ring com sucesso!\n",c);
				}
				else
					printf("\n(%d)Escolha um canal FXS\n",c);
				break;

			case 'x': //Desliga ring
			case 'X':	
				if((dg_GetPortInterface(c) == DG_FXS_INTERFACE)||(dg_GetPortInterface(c) == DG_FX_INTERFACE))
				{
					ret = dg_SetRing(c, DG_DISABLE, 1);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao desligar ring. Ret %d\n", c, ret);
					else
						printf("\n(%d)Desligou ring com sucesso!\n",c);           
				}
				else
					printf("\n(%d)Escolha um canal FXS...\n",c);
				break;

			case 'm': //Menu
			case 'M':			
				print_menu();
				break;

			case 'q': //Sair
			case 'Q':
				flag=0;
				break;
		}
	}//fim do while

	for(i=1;i>=dg_GetPortsCount();i++)
	{
		//Destroi thread de Supervisao de Linha
		ret = dg_DestroyCallProgress(i);
		if (ret != DG_EXIT_SUCCESS)
			printf("\nErro ao destruir thread de Supervisao de Linha. Ret %d\n",ret);
	}

	//Finaliza a Voicerlib
	ret = dg_ShutdownVoicerlib();
	if (ret != DG_EXIT_SUCCESS)
		printf("\nErro ao finalizar a Voicerlib .Ret (%d)\n",ret);
	return 0;
}

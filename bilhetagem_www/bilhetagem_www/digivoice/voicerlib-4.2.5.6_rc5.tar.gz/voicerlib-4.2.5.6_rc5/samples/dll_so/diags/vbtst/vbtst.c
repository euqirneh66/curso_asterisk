//---------------------------------------------------------------------------------------------------------------------
//Digivoice Tecnologia em eletronica Ltda.
//Exemplo de teste de subida da voicerlib
//
//configuracoes para Windoes MS VS8
//Project->Properties->C/C++->General->Aditional Include Directories->c:\Arquivos de Programas\VoicerLib4\include
//Project->Properties->Linker->General->Aditional Library Directories->c:\Arquivos de Programas\VoicerLib4\lib
//Project->Properties->Linker->Input->Aditional Dependencies->voicerlib.lib
//
//---------------------------------------------------------------------------------------------------------------------


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef DG_WIN
#include <conio.h>
#include <windows.h>
#include <io.h>
#else
#include <termios.h>
#include <unistd.h>
#endif
#include <vlibdef.h>
#ifdef DG_WIN
#define DllImport   __declspec(dllimport)
#endif
#include <voicerlib.h>

#define DEBUG 1
#define MAX_CANAIS			240			//maximo de canais do sistema




//variaveis globais
char szTemp[255];		//armazenagem de string de caracteres temporaria

dg_event_data_structure event_context;

#ifndef DG_WIN
int getch(void) {
  struct termios oldt, newt;
  int ch;
 
  /* We can't necessarily trust POSIX's STDIN_FILENO */
  int stdin_fd = fileno(stdin);
 
  /* Get and save the current terminal flags */
  tcgetattr(stdin_fd, &oldt);
 
  /* Copy the old settings and turn off echo/canonical mode */
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
 
  /* Apply the new settings */
  tcsetattr(stdin_fd, TCSANOW, &newt);
 
  /* Call the standard getchar() function */
  ch = getchar();
 
  /* Restore the original settings */
  tcsetattr(stdin_fd, TCSANOW, &oldt);
 
  return ch;
}
#endif

//----------------------------------------
//Prints help menu
//----------------------------------------
void print_menu(void)
{
	printf("\n---------------------------------\n");
	printf("|            Menu               |\n");
	printf("---------------------------------\n");
	printf("<i> Iniciar o teste\n");
	printf("<m> Menu\n");
	printf("<q> Sair \n\n");
}

//----------------------------------------
//imprime evento
//----------------------------------------
void print_event(char *szMsg, int port)
{

	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);
	now = localtime(&curSecs);
	printf("\n<%02d:%02d:%02d> <%d>: %s\n",now->tm_hour, now->tm_min, now->tm_sec, port,szMsg);
}

//----------------------------------------
//Call back de eventos
//----------------------------------------
#ifndef __LINUX__
void CALLBACK ReceiveEvents(void *context_data)
#else
void ReceiveEvents(void *context_data)
#endif
{
    dg_event_data_structure *EventContext;
    char data[512];
    char szDig[256];
	int nSignalQ;
	int ret=0;
    data[0] = 0;

    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);

	szDig[0] = 0;
 	
	switch (EventContext->command)
	{
			case EV_AFTERDIAL:
				sprintf(data,"(EV_AFTERDIAL) - Terminou de discar ");
			break;
			
			case EV_AFTERPICKUP:
				sprintf(data,"(EV_AFTERPICKUP) - Atendeu com sucesso");
			break;

			case EV_ANSWERED:
					sprintf(data,"(EV_ANSWERED) - Detectou Atendimento");
			break;

			case EV_BUSY:
				sprintf(data,"(EV_BUSY) - Ocupado....");
			break;

			case EV_CALLERID:
				sprintf(data,"(EV_CALLERID) - BINA");
			break;

			case EV_CALLING:
				sprintf(data,"(EV_CALLING) - Chamando...");
			break;
		
			case EV_DIALTONE:
				sprintf(data,"(EV_DIALTONE) - Tom de linha... ");
			break;

			case EV_DIGITSRECEIVED:
				sprintf(data,"(EV_DIGITSRECEIVED) - Desligado");
			break;

			case EV_ERRORDETECTED:
				sprintf(data,"(EV_ERRORDETECTED) - Erro na placa. Ret= 0x%x ", EventContext->data);
			break;

			case EV_FAX:
				sprintf(data,"(EV_FAX) - Detectou tom de FAX...");
			break;

			case EV_LINEREADY:
				sprintf(data,"(EV_LINEREADY) - Line Ready...");
			break;

			case EV_LINEOFF:
				sprintf(data,"(EV_LINEOFF) - Line OFF...");
			break;

			case EV_PLAYSTART:
				sprintf(data,"(EV_PLAYSTART) - Reproduzindo...");
			break;

			case EV_PLAYSTOP:
				sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir");
			break;

			case EV_RECORDING:
				sprintf(data,"(EV_RECORDING) - Gravando (%d) segundo(s)...", EventContext ->data );
			break;

			case EV_RECORDSTOP:
				sprintf(data,"(EV_RECORDSTOP) - Parou de gravar com sucesso");
			break;

			case EV_RINGS:
				sprintf(data,"(EV_RINGS) - Ring....");
			break;

			default:
				EventContext->command = 0xff;
		}
#ifdef DEBUG
	if (strlen(data)>0)
		print_event(data, EventContext->port);
#endif
}

int main(int argc, char* argv[])
{
	short ret;
	char ch;
	int cc,i,n;
	int nPortsCount,nCardsCount;
	int nRunningStatus = 0;
	int c=1;
	int flag=1;
	char szFile[256];
	int nEcho=0;

	printf("----------------------------------------------\n");
	printf("- Programa de Teste Placas DigiVoice   v1.58     -\n");
	printf("----------------------------------------------\n");

	//Passa para a dll o ponteiro da callback que tratara os eventos
	dg_SetEventCallback(ReceiveEvents,&event_context);

	print_menu();

	while(flag)
	{
		ch = getch();
#ifndef DG_WIN
		digivoice_sleep(10);
#endif
		switch(ch)
		{

			case 'i': //Inicia teste
			case 'I':
				printf("\nEntre com o numero de testes: ");
				fflush(stdin);
				scanf("%d",&n);

				cc=1;

				while(cc!=(n+1))
				{

					printf("\n%d - Iniciando VoicerLib...Aguarde...",cc);

					//Inicia Voicerlib
					ret = dg_StartVoicerlib(NULL);
					if (ret!=DG_EXIT_SUCCESS)
					{
						printf("\n**************************************************\n");
						printf(" Erro ao inicializar a Voicerlib. Ret = %d			                       \n",ret);		
						printf("**************************************************\n");
						break;
					}
					else	
						printf("\n%d - Voicerlib inicializada com sucesso",cc);

					//Armazena quantidade de portas 
					nPortsCount = dg_GetPortsCount();

					//Armazena quantidade de placas 
					nCardsCount = dg_GetCardsCount();

					printf("\n%d - Voicerlib inicializada com -------- %d placas ------ %d canais", cc,nCardsCount,nPortsCount);
					
					for(i=0;i<dg_GetCardsCount();i++)
						printf("\n%d - Versao do Firmware: %x ",cc,dg_GetVersion(i+1));
#ifdef DG_WIN
					Sleep(2000);
#else
					digivoice_sleep(2000);
#endif

					//Finaliza a Voicerlib
					ret = dg_ShutdownVoicerlib();
					if (ret != DG_EXIT_SUCCESS)
						printf("\n%d - Erro ao finalizar a Voicerlib\n",cc);
					else
						printf("\n%d - Voicerlib finalizada com sucesso\n",cc);

					cc++;

				}
				print_menu();

				break;

			case 'm': //Menu
			case 'M':			
				print_menu();
				break;

			case 'q': //Sair
			case 'Q':
				flag=0;
				break;

		}
	}//fim do while

	return 0;
}

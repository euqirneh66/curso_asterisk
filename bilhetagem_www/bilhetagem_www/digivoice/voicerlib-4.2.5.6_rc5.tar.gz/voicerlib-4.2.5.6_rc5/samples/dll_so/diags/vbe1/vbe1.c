//---------------------------------------------------------------------------------------------------------------------
//Digivoice Tecnologia em eletronica Ltda.
//Exemplo da placa E1
//
//configuracoes para Windoes MS VS8
//Project->Properties->C/C++->General->Aditional Include Directories->c:\Arquivos de Programas\VoicerLib4\include
//Project->Properties->Linker->General->Aditional Library Directories->c:\Arquivos de Programas\VoicerLib4\lib
//Project->Properties->Linker->Input->Aditional Dependencies->voicerlib.lib
//
//---------------------------------------------------------------------------------------------------------------------


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef DG_WIN
#include <conio.h>
#include <windows.h>
#include <io.h>
#else
#include <termios.h>
#include <unistd.h>
#endif
#include <vlibdef.h>
#ifdef DG_WIN
#define DllImport   __declspec(dllimport)
#endif
#include <voicerlib.h>

#define DEBUG 1
#define MAX_CANAIS			240			//maximo de canais do sistema
#define MAX_RINGS				6

//estados de atendimento
#define REPOUSO					1
#define ATENDEU					2
#define FALANDO					3
#define DESLIGANDO				4


//estrutura de controle dos canais
struct stCanais 
{
	int nChanState;
	int nRingsCount;
	FILE *fFala;
	char szNumero[50];
	char szNumeroA[50];
	int nFirstTime;
}Canais[MAX_CANAIS];

//variaveis globais
FILE *play_stream;
int nConta[20];			//contadores de eventos
char szTemp[255];		//armazenagem de string de caracteres temporaria
char szTemp1[255];		//armazenagem de string de caracteres temporaria
int file_format = 3;	    //ffWave,ffSig,ffWavePCM, ffGsm610
int play=0;
char szMsg[255];
int nVerbose=0;			//flag de verbose

dg_event_data_structure event_context;

#ifndef DG_WIN
int getch(void) {
  struct termios oldt, newt;
  int ch;
 
  /* We can't necessarily trust POSIX's STDIN_FILENO */
  int stdin_fd = fileno(stdin);
 
  /* Get and save the current terminal flags */
  tcgetattr(stdin_fd, &oldt);
 
  /* Copy the old settings and turn off echo/canonical mode */
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
 
  /* Apply the new settings */
  tcsetattr(stdin_fd, TCSANOW, &newt);
 
  /* Call the standard getchar() function */
  ch = getchar();
 
  /* Restore the original settings */
  tcsetattr(stdin_fd, TCSANOW, &oldt);
 
  return ch;
}
#endif

//----------------------------------------
//Prints help menu
//----------------------------------------
void print_menu(void)
{
	printf("\n---------------------------------\n");
	printf("|            Menu               |\n");
	printf("---------------------------------\n");
	printf("<c> Mudar o canal\n");
	printf("<p> Atender \n");
	printf("<d> Discar \n");
	printf("<h> Desligar\n");
	printf("<s> Configurar o sincronismo \n");
	printf("<k> Reproduzir mensagem\n");
	printf("<l> Interromper reproducao da mensagem\n");
	printf("<r> Gravar ligacao\n");
	printf("<t> Interromper gravacao\n");
	printf("<m> Menu\n");
	printf("<v> Verbose - Logs \n");
	printf("<q> Sair \n\n");
}

//----------------------------------------
//imprime evento
//----------------------------------------
void print_event(char *szMsg, int port)
{

	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);
	now = localtime(&curSecs);
	printf("<%02d:%02d:%02d> <%d>: %s\n",now->tm_hour, now->tm_min, now->tm_sec, port,szMsg);
}

//----------------------------------------
//Call back de eventos
//----------------------------------------
#ifndef __LINUX__
void CALLBACK ReceiveEvents(void *context_data)
#else
void ReceiveEvents(void *context_data)
#endif
{
    dg_event_data_structure *EventContext;
    char data[512];
    char szDig[256];
	int nSignalQ;
	int ret=0;
    data[0] = 0;

    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);

	szDig[0] = 0;
 	
	switch (EventContext->command)
	{
			case EV_AFTERDIAL:
				sprintf(data,"(EV_AFTERDIAL) - Terminou de discar ");
			break;
			
			case EV_AFTERPICKUP:
				sprintf(data,"(EV_AFTERPICKUP) - Atendeu com sucesso");
			break;

			case EV_ANSWERED:
				if (EventContext->data == AUDIO_DETECTED)
					sprintf(data,"(EV_ANSWERED) - Detectou Atendimento por Presenca de AUDIO");
				else
					if (EventContext->data == TIMEOUT_DETECTED)
						sprintf(data,"(EV_ANSWERED) - Detectou Atendimento por TIMEOUT");	        
			break;

			case EV_BUSY:
				sprintf(data,"(EV_BUSY) - Ocupado....");
					
				if (dg_IsPlaying(EventContext->port))
				{
					//Para reproducao 
					ret = dg_StopPlayFile(EventContext->port);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_BUSY) - Erro ao interromper a reproducao do arquivo. Ret %d",ret);
					else
						sprintf(data,"(EV_BUSY) - Interrompeu a reproducao do arquivo...");
				}

				if (dg_IsRecording (EventContext->port))
				{
					//Para gravacao												
					ret = dg_StopRecordFile(EventContext->port);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_BUSY) - Erro ao interromper a gravacao do arquivo. Ret %d",ret);
					else
						sprintf(data,"(EV_BUSY) - Interrompeu a gravacao do arquivo...");
				}
				break;

			case EV_CALLERID:
				//Salva o numero de quem ligou
				dg_GetCallerId(EventContext->port,Canais[EventContext->port].szNumeroA);
				sprintf(data,"(EV_CALLERID) - BINA: %s", Canais[EventContext->port].szNumeroA);
			break;

			case EV_CALLING:
				sprintf(data,"(EV_CALLING) - Chamando...");
				break;
		
			case EV_DIALTONE:
				sprintf(data,"(EV_DIALTONE) - Tom de linha... ");
			break;

			case EV_DIGITSRECEIVED:
				if (nVerbose == 1)
				{
					switch (EventContext->data)
					{
						case edOff:
							sprintf(data,"(EV_DIGITSRECEIVED) - Desligado");
							break;

						case edWaiting:
							sprintf(data,"(EV_DIGITSRECEIVED) - Em espera");
							break;

						case edMaxDigits:
							sprintf(data,"(EV_DIGITSRECEIVED) - Alcancou m�ximo de digitos");
							break;

						case edTermDigit:
							sprintf(data,"(EV_DIGITSRECEIVED) - Recebeu digito finalizador");
							break;

						case edDigitTimeOut:
							sprintf(data,"(EV_DIGITSRECEIVED) - Timeout global");
							break;

						case edInterDigitTimeOut:
							sprintf(data,"(EV_DIGITSRECEIVED) - Timeout interdigito");
							break;	
					}
				}
				break;

			case EV_E1_ALARM:
				if (nVerbose == 1)
				{
					switch (EventContext ->data)
					{
						case ALARM_RSLIP:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_RSLIP ON");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_RSLIP OFF");
							break;

						case ALARM_RAIS:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_RAIS ON");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_RAIS OFF");
							break;

						case ALARM_AISS:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_AISS ON");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_AISS OFF");
							break;

						case ALARM_AIS16S:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_AIS16S ON");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_AIS16S OFF");
							break;

						case ALARM_LOSS:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_LOSS ON");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_LOSS OFF");
							break;

						case ALARM_CRC4SYNC:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_CRC4SYNC ON");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_CRC4SYNC OFF");
							break;

						case ALARM_MFSYNC:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_MFSYNC ON");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_MFSYNC OFF");
							break;

						case ALARM_SYNC:
							if (EventContext ->data_aux == 1)
								sprintf(data,"(EV_E1_ALARM) - ALARM_SYNC ON ");
							else
								sprintf(data,"(EV_E1_ALARM) - ALARM_SYNC OFF ");
							break;
					}
				}
				break;

			case EV_E1CHANGESTATUS:
				if (nVerbose == 1)
				{
					switch (EventContext ->data)
					{
						case C_E1_IDLE:
							sprintf(data,"(EV_E1CHANGESTATUS) - Livre"); 
							break;
						case C_SEIZURE:
							sprintf(data,"(EV_E1CHANGESTATUS) - Ocupacao"); 
							break;
						case C_NUMBER_RECEIVED:
							dg_GetE1Number(EventContext -> port , szTemp);
							sprintf(data,"(EV_E1CHANGESTATUS) - Numero recebido: %s",szTemp); 
							break;
						case C_CONGESTION:
							sprintf(data,"(EV_E1CHANGESTATUS) - Congestionamento"); 
							break;
						case C_B_ENDCALL:
							sprintf(data,"(EV_E1CHANGESTATUS) - Fim da Chamada "); 
							break;
						case C_NOTCOMPLETED:
							sprintf(data,"(EV_E1CHANGESTATUS) - Nao completada"); 
							break;
						case	C_GROUP_II:
							sprintf(data,"(EV_E1CHANGESTATUS) - Categoria"); 
							break;
						case C_UNAVAILABLE:
							sprintf(data,"(EV_E1CHANGESTATUS) - Nao disponivel"); 
							break;
					}
				}
				break;

			case EV_ERRORDETECTED:
				sprintf(data,"(EV_ERRORDETECTED) - Erro na placa. Ret= 0x%x ", EventContext->data);
			break;

			case EV_FAX:
				sprintf(data,"(EV_FAX) - Detectou tom de FAX...");
			break;

			case EV_LINEREADY:
				sprintf(data,"(EV_LINEREADY) - Line Ready...");
			break;

			case EV_LINEOFF:
				sprintf(data,"(EV_LINEOFF) - Line OFF...");
			break;

			case EV_PLAYSTART:
				sprintf(data,"(EV_PLAYSTART) - Reproduzindo...");
				break;

			case EV_PLAYSTOP:

				switch (EventContext->data)
				{
					case ssStopped:
					case ssNormal:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir");
						break;
					case ssDigitReceived:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir pois recebeu digito finalizador");
						break;
					case ssAbnormal:
						sprintf(data,"(EV_PLAYSTOP) - Erro indeterminado ao interromper a reproducao");
						break;
					default:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir a mensagem");
				}
			break;

			case EV_RECORDING:
				sprintf(data,"(EV_RECORDING) - Gravando (%d) segundo(s)...", EventContext ->data );
				break;

			case EV_RECORDSTOP:
				switch (EventContext->data)
				{
					case ssNormal:
						sprintf(data,"(EV_RECORDSTOP) - Parou de gravar com sucesso");
						break;

					case ssStopped:
						sprintf(data,"(EV_RECORDSTOP) - Gravacao interrompida");
						break;

					case ssDigitReceived:
						sprintf(data,"(EV_RECORDSTOP) - Gravacao interrompida por digito");
						break;

					case ssAbnormal:
						sprintf(data,"(EV_RECORDSTOP) - Erro indeterminado ao parar gravacao");
						break;
				}		

				//Desabilita InputBuffer
				ret = dg_DisableInputBuffer(EventContext ->port);
				if(ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_RECORDSTOP) - Erro ao desabilitar InputBuffer. Ret %d", ret);
				break;

			case EV_RINGS:
				sprintf(data,"(EV_RINGS) - Ring....");
				Canais[EventContext->port].nRingsCount++;
				if(Canais[EventContext->port].nRingsCount >= MAX_RINGS)
				{
					sprintf(data,"(EV_RINGS) - Nao atendeu....");
					Canais[EventContext->port].nRingsCount = 0;
					//Desliga o canal
					ret = dg_HangUp(EventContext -> port);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_RINGS) - Erro ao desligar a porta. Ret %d", ret);
					//Atende a porta
					//ret = dg_PickUp(EventContext->port,1000);
					//if (ret != DG_EXIT_SUCCESS)
					//	sprintf(data,"(EV_RINGS) - Erro ao atender o canal. Ret %d",ret);
					//else
					//{
					//	sprintf(data,"(EV_RINGS) - Atendeu...");
					//	Canais[EventContext->port].nChanState = ATENDEU;				    
					//}
				}
				break;

			default:
				EventContext->command = 0xff;
		}
#ifdef DEBUG
	if (strlen(data)>0)
		print_event(data, EventContext->port);
#endif
}

int main(int argc, char* argv[])
{
	short ret;
	char ch;
	int cc, card, sync, temp, temp1;
	int nPortsCount,i;
	int nRunningStatus = 0;
	int c=1;
	int flag=1;

	printf("------------------------------------------------\n");
	printf("- Programa de Diagnostico interface E1 R2D MFC -\n");
	printf("------------------------------------------------\n");

	//Passa para a dll o ponteiro da callback que tratara os eventos
	dg_SetEventCallback(ReceiveEvents,&event_context);

	printf("\nIniciando VoicerLib...Aguarde...\n");

	//Inicia Voicerlib
	ret = dg_StartVoicerlib(NULL);
	if (ret!=DG_EXIT_SUCCESS)
	{
		printf("\n**************************************************\n");
		printf(" Erro ao inicializar a Voicerlib. Ret = %d			                       \n",ret);		
		printf("**************************************************\n");
		printf("\nAperte uma tecla para sair...");
		ch = getch();
		exit(0);
	}
	else	
		printf("\nVoicerlib inicializada com sucesso");

	//Armazena quantidade de portas 
	nPortsCount = dg_GetPortsCount();
	
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		//Seta formato de reproducao
		ret = dg_SetPlayFormat(cc,ffWaveULaw);
		if (ret != DG_EXIT_SUCCESS)
			printf("\n(%d)Erro ao setar o formato de reproducao. Ret %d\n", cc, ret);
		//Seta formato de gravacao
		ret = dg_SetRecordFormat(cc,ffWaveULaw);
		if (ret != DG_EXIT_SUCCESS)
			printf("\n(%d)Erro ao setar o formato de gravacao. Ret %d\n", cc, ret);
		Canais[cc].nChanState = REPOUSO;
		Canais[cc].nRingsCount=0;
		Canais[cc].nFirstTime=0;
	}

	printf("\nFormato de gravacao e reproducao: WaveULaw\n\n");

	for (cc=1;cc<=nPortsCount;cc++)  
	{
		card = dg_GetCardNumber(cc);
		//Testa interface da placa
		if(dg_GetCardInterface(card) == DG_DIGITAL_INTERFACE)
		{
			//----------------------------------------------------
			//Cria threads E1
			//----------------------------------------------------
			if ((ret=dg_CreateE1Thread(cc)) != DG_EXIT_SUCCESS)
			{	
				printf("**************************************************\n");
				printf("(%d) Erro ao criar thread E1. Ret = %d !!!! \n",cc,ret);
				printf("**************************************************\n\n");
	     		//Finaliza Voicerlib
				ret = dg_ShutdownVoicerlib();
				if (ret != DG_EXIT_SUCCESS)
					printf("\nErro ao finalizar a Voicerlib. Ret %d\n",ret);
				cc=getch();
				exit(0);
			}
			//else
				//printf("(%d) Thread E1 criada com sucesso\n",cc-1);			
		}
	}

	//----------------------------------------------------------
	// Configuracoes
	//----------------------------------------------------------
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		card = dg_GetCardNumber(cc);
		//Testa interface da placa
		if(dg_GetCardInterface(card) == DG_DIGITAL_INTERFACE)
		{
			//Categoria do Assinante
            dg_ConfigE1Thread(cc, E1CFG_GROUP_II, 1);
            //Seta o Bina
            dg_SetPortId(cc, "1121916363");
            //Numero total de digitos a receber
            dg_ConfigE1Thread(cc, E1CFG_MAXDIGITS_RX, 4);
            //Status Grupo B
            dg_ConfigE1Thread(cc, E1CFG_GROUP_B, 1);
            //Em ligacoes de entrada, pede bina apos o 2 digito
            dg_ConfigE1Thread(cc, E1CFG_SEND_ID_AFTERDIGIT, 2);
		}    
	}   

	//------------------------------------------------------------
	// Sincronismo
	//------------------------------------------------------------
	for (i=1;i<=dg_GetCardsCount();i++)  
	{
		//Testa interface da placa
		if(dg_GetCardInterface(i) == DG_DIGITAL_INTERFACE)
		{
			//Configura o sincronismo como padrao interno
            ret = dg_SetCardSyncMode(i, SYNC_INTERNAL);
            if (ret != DG_EXIT_SUCCESS)
				printf("\n(%d) Erro ao configurar o sincronismo placa. Ret %d ", i,ret);
			else
				printf("\n(%d)Sincronismo configurado com sucesso - Interno\n\n",i);
           //Seta notificacao de alarme como automatica
           dg_SetAlarmMode(i, ALARM_AUTOMATIC_NOTIFY);           
		}
	}

	for(cc=0;cc<dg_GetCardsCount();cc++)
		printf("\nVersao do Firmware: %x \n",dg_GetVersion(cc+1));

	print_menu();

	while(flag)
	{
		ch = getch();
#ifndef DG_WIN
		digivoice_sleep(10);
#endif
		switch(ch)
		{

			case 'c': //Mudar o canal 
			case 'C':			
				c++;
				if(c>dg_GetPortsCount())
					c=1;
				printf("\nTrocou o canal %d....\n" , c);
				break;

			case 'p': //Atender
			case 'P':
				//Atende o canal
				ret = dg_PickUp(c,100);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao atender o canal. Ret %d \n", c, ret);
				else
					printf("\n(%d)Atendeu o canal...\n" , c);
				break;

			case 'd': //Discar
			case 'D':
				printf("\nEntre com o numero: ");
				fflush(stdin);
				scanf("%s",szTemp);
				//Disca
				ret = dg_Dial(c,szTemp,100,dtDTMF);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao discar %s. Ret %d \n",c,szTemp,ret);
				else
					printf("\n(%d)Discando %s....\n",c,szTemp);
				break;

			case 'h': //Desligar
			case 'H':
				//Desliga o canal
				ret = dg_HangUp(c);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao desligar o canal. Ret %d \n" , c, ret);	
				else
					printf("\n(%d)Desligou o canal...\n" , c);
				break;

			case 's': //Configurar o sincronismo
			case 'S':
				//Solicitar a placa
				printf("\nDigite o numero da placa: ");
				fflush(stdin);
				scanf("%s",szTemp);
				temp1 = atoi(szTemp);
				if (temp1 <= dg_GetCardsCount())
				{
					//Solicitar o tipo de sincronismo
					printf("\n---------------------------------\n");
					printf("\n| (1)Sincronismo Externo LINE A	|");
					printf("\n| (2)Sincronismo Externo LINE B |");
					printf("\n| (3)Sincronismo Interno	|\n");
					printf("---------------------------------\n");
					printf("\nDigite o tipo de sincronismo: ");
					fflush(stdin);
					scanf("%s",szTemp1);
					temp = atoi(szTemp1);	
					switch (temp)
					{
						case 1: //Sync Line A
							sync = SYNC_LINE_A; 
							break;
						case 2: //Sync Line B
							sync = SYNC_LINE_B; 
							break;
						case 3: //Interno
							sync = SYNC_INTERNAL;
							break;
					}
					//Configura o sincronismo
					ret = dg_SetCardSyncMode(temp1,temp);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao configurar o sincronismo. Ret %d\n",temp1,ret);
					else
						printf("\n(%d)Sincronismo configurado com sucesso, opcao: %d\n",temp1,sync);
				}
				else
				{
					printf("\nNumero de placa invalido\n");
				}	
				break;

			case 'k': //Reproduzir mensagem
			case 'K':
				if (dg_IsPlaying(c) == FALSE)
				{
					//Inicia a reproducao de um arquivo atraves da placa
					ret = dg_PlayFile(c, "teste.wav", "", 0);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao inicializar a reproducao. Ret %d \n" , c, ret);
					else
						printf("\n(%d)Reproducao inicializada com sucesso!\n" , c);				
				}
				break;
				
			case 'l': //Interromper reproducao da mensagem
			case 'L':
				if(dg_IsPlaying(c))
				{
					//Interrompe a reproducao de um arquivo
					ret = dg_StopPlayFile(c);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao interromper a reproducao. Ret %d\n" , c, ret);
					else
						printf("\n(%d)Reproducao interrompida com sucesso!\n" , c);	
				}
				else
					printf("\n(%d)Nao ha reproducao em curso para interromper\n",c);

				break;

			case 'r': //Gravar ligacao
			case 'R':
				//Habilita o envio de amostras
				ret =  dg_EnableInputBuffer(c, DG_ENABLE_AGC);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao habilitar inputbuffer. Ret %d \n", c, ret);
			
		        //Grava mensagem
				ret = dg_RecordFile(c, "teste.wav","");
				if(ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao inicializar a gravacao. Ret %d \n", c, ret);
				else
					printf("\n(%d)Gravacao inicializada com sucesso!\n",c);					
				break;

			case 't': //Interromper gravacao 
			case 'T':
				if (dg_IsRecording(c))
				{
					//Interrompe a gravacao
					ret = dg_StopRecordFile(c);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao finalizar a gravacao. Ret %d\n", c, ret);	
					else
						printf("\n(%d)Gravacao finalizada com sucesso!\n",c);
				}
				else
					printf("\n(%d)Nao ha gravacoes em curso para interromper\n",c);
				break;

			case 'm': //Menu
			case 'M':			
				print_menu();
				break;

		case 'v': //Verbose - Logs
		case 'V':
			if(nVerbose == 0)
				nVerbose = 1;
			else
				nVerbose = 0;
			printf("\nVerbose - Logs = %d\n",nVerbose);
			break;

			case 'q': //Sair
			case 'Q':
				flag=0;
				break;

		}
	}//fim do while

	for (cc=1;cc<=nPortsCount;cc++) 
	{
		card = dg_GetCardNumber(cc);		
		if(dg_GetCardInterface(card) == DG_DIGITAL_INTERFACE)
			//Destroi threads E1
			if ((ret=dg_DestroyE1Thread(cc)) != DG_EXIT_SUCCESS)
				printf("\nErro ao destruir a thread E1 - %d\n!!!!",cc);
	}	

	//Finaliza a Voicerlib
	ret = dg_ShutdownVoicerlib();
	if (ret != DG_EXIT_SUCCESS)
		printf("\nErro ao finalizar a Voicerlib\n");
	return 0;
}

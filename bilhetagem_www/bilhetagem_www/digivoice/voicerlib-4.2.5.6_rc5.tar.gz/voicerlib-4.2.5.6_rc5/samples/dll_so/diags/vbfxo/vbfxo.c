//---------------------------------------------------------------------------------------------------------------------
//Digivoice Tecnologia em eletronica Ltda.
//Exemplo da placa FXO
//
//configuracoes para Windoes MS VS8
//Project->Properties->C/C++->General->Aditional Include Directories->c:\Arquivos de Programas\VoicerLib4\include
//Project->Properties->Linker->General->Aditional Library Directories->c:\Arquivos de Programas\VoicerLib4\lib
//Project->Properties->Linker->Input->Aditional Dependencies->voicerlib.lib
//
//---------------------------------------------------------------------------------------------------------------------


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef DG_WIN
#include <conio.h>
#include <windows.h>
#include <io.h>
#else
#include <termios.h>
#include <unistd.h>
#endif
#include <vlibdef.h>
#ifdef DG_WIN
#define DllImport   __declspec(dllimport)
#endif
#include <voicerlib.h>

#define DEBUG 1
#define MAX_CANAIS			240			//maximo de canais do sistema
#define MAX_RINGS				6

//estados de atendimento
#define REPOUSO					1
#define ATENDEU					2
#define FALANDO					3
#define DESLIGANDO				4


//estrutura de controle dos canais
struct stCanais 
{
	int nChanState;
	int nRingsCount;
	FILE *fFala;
	char szNumero[50];
	char szNumeroA[50];
	int nFirstTime;
}Canais[MAX_CANAIS];

//variaveis globais
FILE *play_stream;
int nConta[20];			//contadores de eventos
char szTemp[255];		//armazenagem de string de caracteres temporaria
int file_format = 3;	    //ffWave,ffSig,ffWavePCM, ffGsm610
int play=0;
char szMsg[255];
int nVerbose=0;			//flag de verbose

dg_event_data_structure event_context;

#ifndef DG_WIN
int getch(void) {
  struct termios oldt, newt;
  int ch;
 
  /* We can't necessarily trust POSIX's STDIN_FILENO */
  int stdin_fd = fileno(stdin);
 
  /* Get and save the current terminal flags */
  tcgetattr(stdin_fd, &oldt);
 
  /* Copy the old settings and turn off echo/canonical mode */
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
 
  /* Apply the new settings */
  tcsetattr(stdin_fd, TCSANOW, &newt);
 
  /* Call the standard getchar() function */
  ch = getchar();
 
  /* Restore the original settings */
  tcsetattr(stdin_fd, TCSANOW, &oldt);
 
  return ch;
}
#endif

//----------------------------------------
//Prints help menu
//----------------------------------------
void print_menu(void)
{
	printf("\n---------------------------------\n");
	printf("|            Menu               |\n");
	printf("---------------------------------\n");
	printf("<c> Mudar o canal\n");
	printf("<p> Atender \n");
	printf("<d> Discar \n");
	printf("<h> Desligar\n");
	printf("<k> Reproduzir mensagem\n");
	printf("<l> Interromper reproducao da mensagem\n");
	printf("<r> Gravar ligacao\n");
	printf("<t> Interromper gravacao\n");
	printf("<m> Menu\n");
	printf("<q> Sair \n\n");
}

//----------------------------------------
//imprime evento
//----------------------------------------
void print_event(char *szMsg, int port)
{

	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);
	now = localtime(&curSecs);
	printf("<%02d:%02d:%02d> <%d>: %s\n",now->tm_hour, now->tm_min, now->tm_sec, port,szMsg);
}

//----------------------------------------
//Call back de eventos
//----------------------------------------
#ifndef __LINUX__
void CALLBACK ReceiveEvents(void *context_data)
#else
void ReceiveEvents(void *context_data)
#endif
{
    dg_event_data_structure *EventContext;
    char data[512];
    char szDig[256];
	int nSignalQ;
	int ret=0;
    data[0] = 0;

    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);

	szDig[0] = 0;
 	
	switch (EventContext->command)
	{
			case EV_AFTERDIAL:
				sprintf(data,"(EV_AFTERDIAL) - Terminou de discar ");
				//Habilita supervisao de linha
				ret = dg_EnableCallProgress(EventContext->port,CP_ENABLE_ALL);
				if (ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_AFTERDIAL) - Erro ao habilitar supervisao de linha. Ret %d ",ret);
				else
					sprintf(data,"(EV_AFTERDIAL) - Habilitou supervisao de linha");
				//Habilita deteccao de atendimento
				ret = dg_EnableAnswerDetection(EventContext->port);
				if (ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_AFTERDIAL) - Erro ao habilitar deteccao de atendimento. Ret %d ",ret);
			break;
			
			case EV_AFTERPICKUP:
				sprintf(data,"(EV_AFTERPICKUP) - Atendeu com sucesso");
			break;

			case EV_ANSWERED:
				if (EventContext->data = AUDIO_DETECTED)
					sprintf(data,"(EV_ANSWERED) - Detectou Atendimento por Presenca de AUDIO");
				else
					if (EventContext->data = TIMEOUT_DETECTED)
						sprintf(data,"(EV_ANSWERED) - Detectou Atendimento por TIMEOUT");	

				//Habilita a Supervisao de Linha
				ret = dg_EnableCallProgress(EventContext->port, CP_ENABLE_BUSY_OR_FAX);
				if (ret != DG_EXIT_SUCCESS) 
					sprintf(data,"(EV_ANSWERED) - Erro ao habilitar a supervisao de linha. Ret %d",ret);
				//Desabilita deteccao de atendimento
				ret = dg_DisableAnswerDetection(EventContext->port);
				if (ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_ANSWERED) - Erro ao desabilitar supervisao de atendimento. Ret %d",ret);            
			break;

			case EV_BUSY:
				sprintf(data,"(EV_BUSY) - Ocupado....");
					
				if (dg_IsPlaying(EventContext->port))
				{
					//Para reproducao 
					ret = dg_StopPlayFile(EventContext->port);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_BUSY) - Erro ao interromper a reproducao do arquivo. Ret %d",ret);
					else
						sprintf(data,"(EV_BUSY) - Interrompeu a reproducao do arquivo...");
				}

				if (dg_IsRecording (EventContext->port))
				{
					//Para gravacao												
					ret = dg_StopRecordFile(EventContext->port);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_BUSY) - Erro ao interromper a gravacao do arquivo. Ret %d",ret);
					else
						sprintf(data,"(EV_BUSY) - Interrompeu a gravacao do arquivo...");
				}
				break;

			case EV_CALLERID:
				//Salva o numero de quem ligou
				dg_GetCallerId(EventContext->port,Canais[EventContext->port].szNumeroA);
				sprintf(data,"(EV_CALLERID) - BINA: %s", Canais[EventContext->port].szNumeroA);
			break;

			case EV_CALLING:
				sprintf(data,"(EV_CALLING) - Chamando...");
				break;
		
			case EV_DIALTONE:
				sprintf(data,"(EV_DIALTONE) - Tom de linha... ");
			break;

			case EV_DIGITSRECEIVED:

				switch (EventContext->data)
				{
					case edOff:
						sprintf(data,"(EV_DIGITSRECEIVED) - Desligado");
						break;

					case edWaiting:
						sprintf(data,"(EV_DIGITSRECEIVED) - Em espera");
						break;

					case edMaxDigits:
						sprintf(data,"(EV_DIGITSRECEIVED) - Alcancou m�ximo de digitos");
						break;

					case edTermDigit:
						sprintf(data,"(EV_DIGITSRECEIVED) - Recebeu digito finalizador");
						break;

					case edDigitTimeOut:
						sprintf(data,"(EV_DIGITSRECEIVED) - Timeout global");
						break;

					case edInterDigitTimeOut:
						sprintf(data,"(EV_DIGITSRECEIVED) - Timeout interdigito");
						break;	
				}
				break;

			case EV_ERRORDETECTED:
				sprintf(data,"(EV_ERRORDETECTED) - Erro na placa. Ret= 0x%x ", EventContext->data);
			break;

			case EV_FAX:
				sprintf(data,"(EV_FAX) - Detectou tom de FAX...");
			break;

			case EV_LINEREADY:
				sprintf(data,"(EV_LINEREADY) - Line Ready...");
			break;

			case EV_LINEOFF:
				sprintf(data,"(EV_LINEOFF) - Line OFF...");
			break;

			case EV_PLAYSTART:
				sprintf(data,"(EV_PLAYSTART) - Reproduzindo...");
				break;

			case EV_PLAYSTOP:

				switch (EventContext->data)
				{
					case ssStopped:
					case ssNormal:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir");
						break;
					case ssDigitReceived:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir pois recebeu digito finalizador");
						break;
					case ssAbnormal:
						sprintf(data,"(EV_PLAYSTOP) - Erro indeterminado ao interromper a reproducao");
						break;
					default:
						sprintf(data,"(EV_PLAYSTOP) - Parou de reproduzir a mensagem");
				}
				//Desliga o canal
				/*ret = dg_HangUp(EventContext->port);
				if (ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_PLAYSTOP) - Erro ao desligar a porta. Ret %d",ret);
				else
					sprintf(data,"(EV_PLAYSTOP) - Desligou a porta ");			*/
			break;

			case EV_RECORDING:
				sprintf(data,"(EV_RECORDING) - Gravando (%d) segundo(s)...", EventContext ->data );
				break;

			case EV_RECORDSTOP:
				switch (EventContext->data)
				{
					case ssNormal:
						sprintf(data,"(EV_RECORDSTOP) - Parou de gravar com sucesso");
						break;

					case ssStopped:
						sprintf(data,"(EV_RECORDSTOP) - Gravacao interrompida");
						break;

					case ssDigitReceived:
						sprintf(data,"(EV_RECORDSTOP) - Gravacao interrompida por digito");
						break;

					case ssAbnormal:
						sprintf(data,"(EV_RECORDSTOP) - Erro indeterminado ao parar gravacao");
						break;
				}		

				//Desabilita InputBuffer
				ret = dg_DisableInputBuffer(EventContext ->port);
				if(ret != DG_EXIT_SUCCESS)
					sprintf(data,"(EV_RECORDSTOP) - Erro ao desabilitar InputBuffer. Ret %d", ret);
				break;

			case EV_RINGS:
				sprintf(data,"(EV_RINGS) - Ring....");
				Canais[EventContext->port].nRingsCount++;
				if(Canais[EventContext->port].nRingsCount >= MAX_RINGS)
				{
					//Atende a porta
					ret = dg_PickUp(EventContext->port,1000);
					if (ret != DG_EXIT_SUCCESS)
						sprintf(data,"(EV_RINGS) - Erro ao atender o canal. Ret %d",ret);
					else
					{
						sprintf(data,"(EV_RINGS) - Atendeu...");
						Canais[EventContext->port].nChanState = ATENDEU;				    
					}
				}
				break;

			default:
				EventContext->command = 0xff;
		}
#ifdef DEBUG
	if (strlen(data)>0)
		print_event(data, EventContext->port);
#endif
}

int main(int argc, char* argv[])
{
	short ret;
	char ch;
	int cc;
	int nPortsCount;
	int nRunningStatus = 0;
	int c=1;
	int flag=1;

	printf("-------------------------------------------\n");
	printf("- Programa de Diagnostico interface FXO   -\n");
	printf("-------------------------------------------\n");

	//Passa para a dll o ponteiro da callback que tratara os eventos
	dg_SetEventCallback(ReceiveEvents,&event_context);

	printf("\nIniciando VoicerLib...Aguarde...\n");

	//Inicia Voicerlib
	ret = dg_StartVoicerlib(NULL);
	if (ret!=DG_EXIT_SUCCESS)
	{
		printf("\n**************************************************\n");
		printf(" Erro ao inicializar a Voicerlib. Ret = %d			                       \n",ret);		
		printf("**************************************************\n");
		printf("\nAperte uma tecla para sair...");
		ch = getch();
		exit(0);
	}
	else	
		printf("\nVoicerlib inicializada com sucesso");

	//Armazena quantidade de portas 
	nPortsCount = dg_GetPortsCount();
	
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		//Seta formato de reproducao
		ret = dg_SetPlayFormat(cc,ffWaveULaw);
		if (ret != DG_EXIT_SUCCESS)
			printf("\n(%d)Erro ao setar o formato de reproducao. Ret %d\n", cc, ret);
		//Seta formato de gravacao
		ret = dg_SetRecordFormat(cc,ffWaveULaw);
		if (ret != DG_EXIT_SUCCESS)
			printf("\n(%d)Erro ao setar o formato de gravacao. Ret %d\n", cc, ret);
		Canais[cc].nChanState = REPOUSO;
		Canais[cc].nRingsCount=0;
		Canais[cc].nFirstTime=0;
	}

	printf("\nFormato de gravacao e reproducao: WaveULaw\n\n");

	//Cria thread de supervisao de linha
	for (cc=1;cc<=nPortsCount;cc++)  
	{
		if ((ret=dg_CreateCallProgress(cc,"cp_default.cfg")) != DG_EXIT_SUCCESS)
		{
			printf("**************************************************************\n");
			printf("(%d) Erro ao criar thread de Supervisao de Linha. Ret = %d!!!\n",cc,ret);
			printf("**************************************************************\n\n");
	     	//Finaliza a VoicerLib
            dg_ShutdownVoicerlib();
			cc=getch();
			exit(0);
		}
		else
			printf("(%d) Thread de Supervisao de Linha criada com sucesso\n",cc);
	}	

	for(cc=0;cc<dg_GetCardsCount();cc++)
		printf("\n\nVersao do Firmware: %x \n",dg_GetVersion(cc+1));

	print_menu();

	while(flag)
	{
		ch = getch();
#ifndef DG_WIN
		digivoice_sleep(10);
#endif
		switch(ch)
		{

			case 'c': //Mudar o canal 
			case 'C':			
				c++;
				if(c>dg_GetPortsCount())
					c=1;
				printf("\nTrocou o canal %d....\n" , c);
				break;

			case 'p': //Atender
			case 'P':
				//Atende o canal
				ret = dg_PickUp(c,100);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao atender o canal. Ret %d \n", c, ret);
				else
				{
					printf("\n(%d)Atendeu o canal...\n" , c);
					//Habilita supervisao de linha
					ret = dg_EnableCallProgress(c,CP_ENABLE_LINETONE_OR_BUSY);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao habilitar supervisao de linha. Ret %d\n" , c, ret);
				}
				break;

			case 'd': //Discar
			case 'D':
				printf("\nEntre com o numero: ");
				fflush(stdin);
				scanf("%s",szTemp);
				//Disca
				ret = dg_Dial(c,szTemp,100,dtDTMF);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao discar %s. Ret %d \n",c,szTemp,ret);
				else
					printf("\n(%d)Discando %s....\n",c,szTemp);
				break;

			case 'h': //Desligar
			case 'H':
				//Desliga o canal
				ret = dg_HangUp(c);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao desligar o canal. Ret %d \n" , c, ret);	
				else
					printf("\n(%d)Desligou o canal...\n" , c);
				//Desabilita supervisao de linha
				ret = dg_DisableCallProgress(c);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao desabilitar supervisao de linha. Ret %d \n" , c, ret);
				break;

			case 'k': //Reproduzir mensagem
			case 'K':
				if (dg_IsPlaying(c) == FALSE)
				{
					//Inicia a reproducao de um arquivo atraves da placa
					ret = dg_PlayFile(c, "teste.wav", "", 0);
					if(ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao inicializar a reproducao. Ret %d \n" , c, ret);
					else
						printf("\n(%d)Reproducao inicializada com sucesso!\n" , c);				
				}
				break;
				

			case 'l': //Interromper reproducao da mensagem
			case 'L':
				if(dg_IsPlaying(c))
				{
					//Interrompe a reproducao de um arquivo
					ret = dg_StopPlayFile(c);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao interromper a reproducao. Ret %d \n" , c, ret);
					else
						printf("\n(%d)Reproducao interrompida com sucesso!\n" , c);	
				}
				else
					printf("\n(%d)Nao ha reproducao em curso para interromper\n",c);

				break;

			case 'r': //Gravar ligacao
			case 'R':
				//Habilita o envio de amostras
				ret =  dg_EnableInputBuffer(c, DG_ENABLE_AGC);
				if (ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao habilitar inputbuffer. Ret %d \n", c, ret);
			
		        //Grava mensagem
				ret = dg_RecordFile(c, "teste.wav","");
				if(ret != DG_EXIT_SUCCESS)
					printf("\n(%d)Erro ao inicializar a gravacao. Ret %d \n", c, ret);
				else
					printf("\n(%d)Gravacao inicializada com sucesso!\n",c);					
				break;

			case 't': //Interromper gravacao 
			case 'T':
				if (dg_IsRecording(c))
				{
					//Interrompe a gravacao
					ret = dg_StopRecordFile(c);
					if (ret != DG_EXIT_SUCCESS)
						printf("\n(%d)Erro ao finalizar a gravacao. Ret %d\n", c, ret);	
					else
						printf("\n(%d)Gravacao finalizada com sucesso!\n",c);
				}
				else
					printf("\n(%d)Nao ha gravacoes em curso para interromper\n",c);
				break;

			case 'm': //Menu
			case 'M':			
				print_menu();
				break;

			case 'q': //Sair
			case 'Q':
				flag=0;
				break;

		}
	}//fim do while

	//Finaliza a Voicerlib
	ret = dg_ShutdownVoicerlib();
	if (ret != DG_EXIT_SUCCESS)
		printf("\nErro ao finalizar a Voicerlib\n");
	return 0;
}

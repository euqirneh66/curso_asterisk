/***************************************************************************
 *   Copyright (C) 2004 by Digivoice Eletronica                            *
 *   paulo@digivoice.com.br                                                *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Library General Public License as       *
 *   published by the Free Software Foundation; either version 2 of the    *
 *   License, or (at your option) any later version.                       *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU Library General Public     *
 *   License along with this program; if not, write to the                 *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
/*  Created : 04/09/1998
******************************************************/

#include <stdlib.h>

#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#include "inifile.h"

/* Global Variableas */

    FILE         *fp_inifile;              
    char         szArqIni[SIZE_FILE];
    char szIni[MAXLINES][SIZE_LINE_INI];  //Array onde ficara' guardado as linhas do ini   
    short         bOk;            //Flag para construtor
    
    unsigned uLinhas;
    unsigned uLinhasParaGravar;


//***********************************************
//Construtor - Opens file and load into array
//***********************************************
int OpenIniFile(char *szArq)
{

  
  strcpy(szArqIni,szArq);

  //First try to open file for read
  if ( (fp_inifile=fopen(szArqIni,"r+")) == NULL)
	{
    //Cannot open then try to open for write (create)
    if ( (fp_inifile=fopen(szArqIni,"w+")) == NULL)
    {
      //Error creating file
      bOk = FALSE;
    }
  }

  uLinhas = 0;
  //Load file into array
  while (!feof(fp_inifile))
  {
    //Read line
    if (fgets(szIni[uLinhas],SIZE_LINE_INI,fp_inifile) == NULL)
      break;
      
    if (szIni[uLinhas][0]!=0 && szIni[uLinhas][0]!=0x0a && szIni[uLinhas][0]!=0x0d)
       uLinhas++;
  }
  //Save the lines count to use with write method
  uLinhasParaGravar = uLinhas;
  fclose(fp_inifile);     //close file
  bOk = TRUE;
  return bOk;
}


//*********************************************************************
// Read strings
// ** Lines starting with ; will be ignoreds
// item1=value
//
//*********************************************************************
unsigned ReadString(char *szItem,char *szValue, unsigned uTam ,char *szDefault)
{

  char szLinha[SIZE_LINE_INI];
  char szItemLido[SIZE_LINE_INI];
  int ln;
  int x;
  
  //Set null to all strings
  memset(szItemLido, 0, SIZE_LINE_INI);
  memset(szValue, 0, uTam);
    
  //Read all lines
  ln=0;
  while (ln < uLinhas)
  {
      
    //Read the line
    strcpy(szLinha,szIni[ln]);
    
    
    //verify if the first char is a ';' - remark
    if (szLinha[0] != ';')
    {
                
      //verify is this line contais the desirable item
      //Catch the item read
      int ct=0;
      while( (ct < SIZE_LINE_INI) && (szLinha[ct] != '=') )
      {
          szItemLido[ct] = szLinha[ct];   //copia item
          ct++;
      }
      szItemLido[ct] = 0;
      
      //Compare both strings
      if (!strncasecmp(szItem,szItemLido,strlen(szItemLido)) )
      {
        //It's the samer
        //Pick the value after =
        strncpy(szValue,&szLinha[ct+1],uTam);

        //Put null instead of \n
        for (x=0;x<uTam;x++)
          if (szValue[x] == '\n')
          {
            szValue[x] = 0;
            break;
          }

        szValue[uTam] = 0;


        //returns the number of bytes readed
        return strlen(szValue);
      }

    }
    ln++;
  }
  
  //Cannot found - copies the default value
  strncpy(szValue,szDefault,uTam);

  //Store new value into array
  sprintf(szIni[uLinhas],"%s=%s\n",szItem,szValue);
  uLinhas++;

  //returns 0 if doens't found anything
  return 0;


}

//*********************************************************************
// WriteString
// 1a param. - item
// 2o. param. - data to be stored
//*********************************************************************
void WriteString(char *szItem,char *szValue3)
{

  char szLinha[SIZE_LINE_INI];
  char szItemLido[SIZE_LINE_INI];

  //Move nulo para todas as strings
  memset(szItemLido, 0, SIZE_LINE_INI);

  //Percorre todas as linhas
  int ln=0;
  while (ln < uLinhas)
  {
    //Le a linha
    strcpy(szLinha,szIni[ln]);

    //verifica se o primeiro caracter nao e' <;>
    if (szLinha[0] != ';')
    {
      //Nao e' comentario, entao segue lendo
      //Verifica se a linha lida eh o item desejado
      //ignorando maiusculas e minusculas

      //Pega item lido
      int ct=0;
      while( (ct < SIZE_LINE_INI) && (szLinha[ct] != '=') )
      {
          szItemLido[ct] = szLinha[ct];   //copia item
          ct++;
      }
      szItemLido[ct] = 0;

      //Compara os dois para ver se eh igual
      if (!strncasecmp(szItem,szItemLido,strlen(szItemLido)) )
      {
        //Eh igual!
        //Pega valor apos o igual (=)
        sprintf(szIni[ln],"%s=%s\n",szItem,szValue3);
        return;
      }

    }
    ln++;   //incrementa contador de linha
  }
  //Caso nao ache grava numa nova linha do arquivo
  sprintf(szIni[ln],"%s=%s\n",szItem,szValue3);
  uLinhas++;    //Incrementa contador global de linhas

  return;
}

//*********************************************************************
// Descarrega o array no arquivo para que fique gravado
//*********************************************************************
void CloseIniFile(void)
{



  //Tenta abrir o arquivo
  if ( (fp_inifile=fopen(szArqIni,"wt")) != NULL)
  {
    for (int ln=0;ln<uLinhas;ln++)
    {
      //sprintf(szLinha,"%s\n",&szIni[ln]);
      fputs(szIni[ln],fp_inifile);
    }
    fclose(fp_inifile);

  }
}


/****************************************************************************
 *                                                                          *
 *   File: vlib_diag.c                                                      *
 *   Date: 27/02/2004                                                       * 
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                        *
 *   desenvolvimento@digivoice.com.br                                       *    
 *                                                                          *
 *   Copyright (c) 2006-2007 Digivoice Eletronica                           *
 *                                                                          *
 *   This file contains the diagnostic tool for Digivoice Cards             *
 *                                                                          *
 *   This program requires ncurses                                          *
 *                                                                          *
 *   This program is free software; you can redistribute it and/or modify   *
 *   it under the terms of the GNU General Public License as published by   *
 *   the Free Software Foundation; either version 2 of the License, or      *
 *   (at your option) any later version.                                    *
 *                                                                          *
 *   This program is distributed in the hope that it will be useful,        *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the           *
 *   GNU General Public License for more details.                           *
 *                                                                          *
 ****************************************************************************/
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ncurses.h>
#include <pthread.h>
#include <getopt.h>


#include <vlibdef.h>
#include <voicerlib.h>

#define MAX_PATH 255

#define MAX_CANAIS		600

int idle_on[MAX_CANAIS];	
int cp_on[MAX_CANAIS];	
int e1_thread_on[MAX_CANAIS];
int gsm_thread_on[MAX_CANAIS];
int gsm_hide_number[MAX_CANAIS];

WINDOW *win;
int current_channel=1;



int file_format = 0;	//ffWave,ffSig,ffWavePCM, ffGsm610

char *szFF[] = { "ffWaveULaw\0","ffSig\0","ffWavePCM\0", "ffGsm610\0", "ffWaveALaw\0" };

char szFileName[255];

char szNumberToDial[255];

short answer_state = 0;
int card_type;

dg_event_data_structure event_context;

FILE *stream;
char szSamples[320];
int stream_size;

WINDOW *win_ev;	//windows events

char win_ev_scroll[15][80];

char szTempAux[MAX_PATH];

//-------------------------------------------------------------------
// Functions to manage ncurses windows
//-------------------------------------------------------------------
WINDOW *create_newwin(int height, int width, int starty, int startx)
{
	WINDOW *local_win;

	local_win = newwin(height, width, starty, startx);
	box(local_win, 0 , 0);		/* 0, 0 gives default characters 
					 * for the vertical and horizontal
					 * lines			*/
	wrefresh(local_win);		/* Show that box 		*/

	return local_win;
}

void destroy_win(WINDOW *local_win)
{	
	/* box(local_win, ' ', ' '); : This won't produce the desired
	 * result of erasing the window. It will leave it's four corners 
	 * and so an ugly remnant of window. 
	 */
	wborder(local_win, ' ', ' ', ' ',' ',' ',' ',' ',' ');
	/* The parameters taken are 
	 * 1. win: the window on which to operate
	 * 2. ls: character to be used for the left side of the window 
	 * 3. rs: character to be used for the right side of the window 
	 * 4. ts: character to be used for the top side of the window 
	 * 5. bs: character to be used for the bottom side of the window 
	 * 6. tl: character to be used for the top left corner of the window 
	 * 7. tr: character to be used for the top right corner of the window 
	 * 8. bl: character to be used for the bottom left corner of the window 
	 * 9. br: character to be used for the bottom right corner of the window
	 */
	wrefresh(local_win);
	delwin(local_win);
}

void write_debug_vlib_diag(char *szMsg, int port)
{
	FILE    *f;
	time_t curSecs;
	struct tm *now_dbg;
	char szdbgtemp[200];
	char szFileName[200];

	curSecs = time(NULL);
	now_dbg = localtime(&curSecs);
	sprintf(szdbgtemp, "<%02d:%02d:%02d> (%d):", now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec, port);
	sprintf(szFileName, "/var/log/voicerlib/vlib_diag.log");
	f = fopen(szFileName, "a+");
	fprintf(f, "%s ", szdbgtemp);
	fprintf(f, szMsg);
	fprintf(f,"\n");
	fclose(f);
}

//---------- NCURSES screen functions -----------
void print_event(char *szMsg, int port, int endline)
{
	int i;
	struct tm *now;
	time_t curSecs;
	curSecs = time(NULL);				
	now = localtime(&curSecs);
	
	if (port < 0 || port > dg_GetPortsCount() || port > MAX_CHANNELS)
		port = 0;

	for (i = 1; i <= 14; i++)
		sprintf(win_ev_scroll[i-1], "%s", win_ev_scroll[i]);
	
	sprintf(win_ev_scroll[14], "<%02d:%02d:%02d> (%d): %s", now->tm_hour, now->tm_min, now->tm_sec, port, szMsg);
	
	//send log messages to log file
	write_debug_vlib_diag(szMsg, port);

	attron(COLOR_PAIR(2));
	wclear(win_ev);

	for (i = 0; i <= 14; i++)
	{
		wmove(win_ev, i, 0);
		if (endline)
			wprintw(win_ev, "%s\n", win_ev_scroll[i]);
		else
			wprintw(win_ev, "%s", win_ev_scroll[i]);
	}

	attroff(COLOR_PAIR(2));
	wrefresh(win_ev);
}

/* Print Main Screen */
void print_screen()
{
    /* Print Main Screen */
    attron(COLOR_PAIR(1));
    box(win, '|', '-');    
    mvprintw(0, 30, "[ DigiVoice VoicerLib Diagnostic Tool ]");
    refresh();
    attroff(COLOR_PAIR(1));
    mvprintw(1, 1, "Card(s) Count  : %d", dg_GetCardsCount());
	mvprintw(2, 1, "Current Channel: %d", current_channel);    
    attron(COLOR_PAIR(3));

    /* Print Menu */    
    mvprintw(3 , 1, "<q>Quit              <c>Clear Screen    <+>Channel     <->Channel            ");
    mvprintw(4 , 1, "<p>Pickup            <h>Hangup          <d>Dial        <a>Detection Type DTMF");
    mvprintw(5 , 1, "<g>Getdigits Sample  <f>Frequency(400)  <r>RecordFile  <s>Stop Record        ");    
    mvprintw(6 , 1, "<e>Pause Rec On/Off  <l>Play File       <k>Stop Play                         ");    
    mvprintw(7 , 1, "</>Enable E1 Thread Control             <\\>Disable E1 Thread Control        ");
    mvprintw(8 , 1, "<m>Start Ring and SetFlash              <n>Stop Ring                         ");
    mvprintw(9 , 1, "<t>Enable Callprogress                  <y>Disable Callprogress              ");        
    mvprintw(10, 1, "<w>Change Record/Play Format            <z>Enable/Disable Answer Detection   ");
    mvprintw(11, 1, "<o>Change to FXO interface type         <x>Change to FXS interface type      ");
    
    //GSM OPTIONS
    mvprintw(12, 1, "<(>Enable GSM Thread Control            <)>Disable GSM Thread Control        ");
    mvprintw(13, 1, "<i>Show/Hide My Number(GSM)             <b>Set PIN Number(GSM)               ");
    mvprintw(14, 1, "<j>Write SMS Message(GSM)               <|>Send a Generic Command(GSM)       ");    
    
    //Please, after insert an option, change the following line: win_ev = create_newwin...;
    
    attroff(COLOR_PAIR(3));
    
    /* Print Main Screen */
/*    attron(COLOR_PAIR(1));
    box(win,'|', '-');    
    mvprintw(0,30,"   Digivoice VoicerLib Diagnostic Tool   ");
    refresh();
    attroff(COLOR_PAIR(1));

    mvprintw(1,1,"Cards: %d", dg_GetCardsCount());
    attron(COLOR_PAIR(3));
*/
    /* Print Menu */
/*    mvprintw(3 ,1," <q>uit       <c>lear screen    <p>ickup                <h>angup        ");
    mvprintw(4 ,1," <+>channel   <->channel  <t>enable callprogress  <y>disable callprogress");
    mvprintw(5 ,1," <a>detection type DTMF   <f>frequency (400)      <d>dial");
	mvprintw(6 ,1," <l>play file <k>stop play");
	mvprintw(7 ,1," <r>ecordfile		<s>top record   <e> pause rec on/off <g>etdigits sample");
	mvprintw(8 ,1," <z>enable/disable answer detection     <w>change record/play format");
	mvprintw(9 ,1," </>enable e1 thread control <\\>disable e1 thread control");
	mvprintw(10,1," <m>Start Ring and SetFlash  <n>Stop Ring");	
		
    attroff(COLOR_PAIR(3));
*/        
}
//---------- end of NCURSES screen functions -----------


void GetSamplesFromCard(short port, short size, void *SampleData)
{
		switch(file_format)
		{
			case ffWaveULaw:case ffWaveALaw: case ffGsm610:
				fwrite(SampleData,sizeof(char),size,stream);			
				break;
			case ffWavePCM:
				fwrite(SampleData,sizeof(short),size,stream);		
				break;
		}

}


//------------------------------------------------------------------------------------------
// Function that will be receive events from library 
//------------------------------------------------------------------------------------------
void ReceiveEvents(void *context_data)
{

    dg_event_data_structure *EventContext;
    char data[255];
    char szDig[MAX_PATH];
    char szTemp[MAX_PATH];
    int i, j, k;
    
    data[0] = 0;
        
    /* Copy received Data */
    EventContext = ((dg_event_data_structure*)context_data);
    dg_signal_e1_thread_structure *p_e1_thread_structure;
 
		switch (EventContext->command)
		{
			case EV_AUDIO_SIGNAL:
			    sprintf(data,"Porta %d Audio=%d", EventContext->port,EventContext->data);			    
			    break;
			case EV_E1_ALARM:
				//port means E1_A ou E1_B
				switch(EventContext->data)
				{
					case ALARM_RSLIP:		//escorregamento 
						sprintf(data,"Placa %d E1-%d ALARM - RSLIP - Contador=%d", EventContext->card, EventContext->port,EventContext->data_aux);
						break;
					case ALARM_RAIS:		//alarme remoto
						sprintf(data,"Placa %d E1-%d ALARM - RAIS - Estado=%d", EventContext->card,EventContext->port,EventContext->data_aux);
						break;
					case ALARM_AISS:		//indica�o de alarme
						sprintf(data,"Placa %d E1-%d ALARM - AISS - Estado=%d", EventContext->card,EventContext->port,EventContext->data_aux);
						break;
					case ALARM_AIS16S:		//indica�o de alarme canal  16
						sprintf(data,"Placa %d E1-%d ALARM - AIS16S - Estado=%d", EventContext->card,EventContext->port,EventContext->data_aux);
						break;
					case ALARM_LOSS:		//perda de sinal
						sprintf(data,"Placa %d E1-%d ALARM - LOSS - Estado=%d", EventContext->card,EventContext->port,EventContext->data_aux);
						break;
					case ALARM_CRC4SYNC:	//crc4
						sprintf(data,"Placa %d E1-%d ALARM - RESERVED - Estado=%d", EventContext->card,EventContext->port,EventContext->data_aux);
						break;
					case ALARM_MFSYNC:		//sincronismo de multiquadro
						sprintf(data,"Placa %d E1-%d ALARM - MFSYNC - Estado=%d", EventContext->card,EventContext->port,EventContext->data_aux);
						break;
					case ALARM_SYNC:		//sincronismo de quadro
						sprintf(data,"Placa %d E1-%d ALARM - SYNC - Estado=%d", EventContext->card,EventContext->port,EventContext->data_aux);
						break;
				}
				break;       

			case EV_R2:
			    sprintf(szDig,"R2 - %x", EventContext->data);			
			    sprintf(data,szDig);
			    break;
			case EV_GROUP_B:
				p_e1_thread_structure = dg_GetE1ThreadPointer(EventContext->port);

				if (p_e1_thread_structure)
				{				
					if (EventContext->data == p_e1_thread_structure->b_free_calling)
						sprintf(data,"Group B event - Free and Calling");
					else if ( (EventContext->data == p_e1_thread_structure->b_busy      ) ||
							  (EventContext->data == p_e1_thread_structure->b_congestion) )
						sprintf(data,"Group B event - Busy or Congestion");
					else if (EventContext->data == p_e1_thread_structure->b_number_changed)				
						sprintf(data,"Group B event - Number was changed");
					else if (EventContext->data == p_e1_thread_structure->b_free_withoutbilling)
						sprintf(data,"Group B event - Free without billing");
					else if (EventContext->data == p_e1_thread_structure->b_collectcall)
						sprintf(data,"Group B event - Collect Call");
					else if (EventContext->data == p_e1_thread_structure->b_number_unknown)
						sprintf(data,"Group B event - Number unknown");
					else if (EventContext->data == p_e1_thread_structure->b_out_of_service)
						sprintf(data,"Group B event - Out of service");
				} //if (p_e1_thread_structure)
				else
					sprintf(data,"Group B event - !p_e1_thread_structure");
				
				break;
			case EV_E1CHANGESTATUS:
				//this events are related only for E1 R2 protocol
				switch (EventContext->data)
				{
					case C_ANSWERED:
						sprintf(data,"E1 Events: Answered ou B Returns");
						break;    
					case C_SEIZURE:
						//R2 protocol. wait for 4 digits
                                                sprintf(data,"E1 Events: SEIZURE");
						break;
                    case C_E1_IDLE:
                    	sprintf(data,"E1 Events: IDLE");
                        break;			    
                    case C_E1_SEIZURE_ACK:
                        sprintf(data,"E1 Events: SEIZURE ACK");
                        break;
					case C_NUMBER_RECEIVED:
						dg_GetE1Number(EventContext->port, szDig);
						sprintf(data,"E1 Events: Number received = %s", szDig);
						break;
					case C_CONGESTION:
						sprintf(data,"E1 Events: Congestion");
						break;
					case C_B_ENDCALL:
					  sprintf(data,"E1 Events: B Subscriber hangup");
						break;
					case C_NOTCOMPLETED:
						sprintf(data,"E1 Events: Call could not be completed");
						break;
					case C_UNAVAILABLE:
					  sprintf(data,"E1 Events: Channel unavailable");
						break;
				}
				break;
			case EV_CALLERID:
				dg_GetCallerId(EventContext->port,szDig);
				sprintf(data,"CallerID: %s", szDig);
				break;
			case EV_RINGS:
				sprintf(data,"EV_RINGS", EventContext->port);
				break;       
			case EV_DTMF:
				sprintf(data,"DTMF Number: %c", EventContext->data);
				break;       
			case EV_LINEREADY:				
				sprintf(data,"OFF-HOOK");
				break;
			case EV_LINEOFF:
    			sprintf(data,"ON-HOOK");
				break;
			case EV_BUSY:
				sprintf(data,"EV_BUSY");
				break;
			case EV_CALLING:
				sprintf(data,"EV_CALLING");
				break;
			case EV_DIALTONE:
				sprintf(data,"DIALTONE");
				print_event(data, EventContext->port, 1);
				
				//if e1 thread is on, send a number to dial
				if (e1_thread_on[EventContext->port])
				{
					//ask for number
					//wprintw(win_ev,"Discando para %s",szNumberToDial);
					sprintf(data, "Discando para %s", szNumberToDial);
					dg_Dial(EventContext->port,szNumberToDial,500,dtDTMF);
				}
				break;
			case EV_AFTERDIAL:
				sprintf(data, "After Dial EVENT");
				if (cp_on[EventContext->port])
				{
					dg_EnableAnswerDetection(EventContext->port);
					dg_EnableCallProgress(EventContext->port, CP_ENABLE_ALL);
				}
				break;
			case EV_AFTERFLASH:
				sprintf(data,"After Flash EVENT");
				dg_Dial(EventContext->port,"23",1000,dtDTMF);
				break;
			case EV_AFTERPICKUP:
				sprintf(data,"After PickUp EVENT");
				break;
			case EV_PLAYSTOP:
				sprintf(data,"Play Stop EVENT");
				break;
			case EV_RECORDSTART:
				sprintf(data,"Record Start EVENT");
				break;
			case EV_RECORDSTOP:
				dg_DisableInputBuffer(EventContext->port);
				sprintf(data,"Record Stop EVENT"); 
				break;
			case EV_RECORDING:
				sprintf(data,"Recording %ds...",EventContext->data); 
				break;
			case EV_ANSWERED:
				sprintf(data,"Answer Detected!"); 
				if (cp_on[EventContext->port]) {
					dg_DisableAnswerDetection(EventContext->port);
					dg_EnableCallProgress(EventContext->port, CP_ENABLE_BUSY_OR_FAX);
				}
				break;
			case EV_FAX:
			    sprintf(data,"Fax Detected!");
				break;
			case EV_DIGITSRECEIVED:
				/* retrieve digits */
				dg_ReadDigits(EventContext->port,szDig);
				switch(EventContext->data)  //status from dsp
				{
					case edMaxDigits:
						sprintf(data,"Max Digits Received - > %s",szDig);
						break;
					case edTermDigit:
						sprintf(data,"Digit termination - Digits Received - > %s",szDig);
						break;
					case edInterDigitTimeOut:
						sprintf(data,"Interdigit Timeout Received - > %s",szDig);
						break;
					case edDigitTimeOut:
						sprintf(data,"Digit Timeout Received - > %s",szDig);
						break;
					case edDigitOverMessage:
						sprintf(data,"Digit Cut-off - > %s",szDig);
						break;					
				}		
				break;
			case EV_FLASH:
				sprintf(data, "FLASH", EventContext->port);				
				break;
				
			//GSM EVENTS
			case EV_GSMTIMEOUT:
				sprintf(data, "GSM Timeout Received!");
				break;
			case EV_GSMSMSRECEIVED:
				sprintf(data, "-------------------------------");
				print_event(data, EventContext->port, 1);

				/*
				attron(COLOR_PAIR(2));
				wclear(win_ev);
				wmove(win_ev, 5, 0);
				dg_GSMGetSMS(EventContext->port, szTempAux);
				wprintw(win_ev, "SMS RECEIVED:\n", strlen(szTempAux));
				for (i = 0; i <= strlen(szTempAux) - 1; i++)//60
					if (szTempAux[i] != '\r')
						wprintw(win_ev, "%c", szTempAux[i]);
				wprintw(win_ev, "\n");				
				wrefresh(win_ev);
				attroff(COLOR_PAIR(2));
				*/

				sprintf(data, "SMS RECEIVED:");
				print_event(data, EventContext->port, 1);

				for (j = 0; j <= 254; j++)
					data[j] = '\0';
				k = 0;
				
				dg_GSMGetSMS(EventContext->port, szTempAux);
				for (i = 0; i <= strlen(szTempAux) - 1; i++)
				{
					if ((szTempAux[i] == '\r') || (szTempAux[i] == '\n'))
					{
						if (data[0]!=0) 
							print_event(data, EventContext->port, 1);
						for (j = 0; j <= 254; j++)
							data[j] = '\0';
						k = 0;
					}
					else
					{
						data[k] = szTempAux[i];
						k++;
					}
				}				
				if (data[0]!=0) 
					print_event(data, EventContext->port, 1);

				sprintf(data, "-------------------------------");
				break;
			case EV_GSMMESSAGE:
				dg_GSMGetLastCommand(EventContext->port, szTemp);
				sprintf(data, "GSM CMD: %s", szTemp);
				dg_GSMGetMessage(EventContext->port, szTemp);
				sprintf(data, "GSM Message: %s", szTemp);
				break;
			case EV_GSMSMSSENT:
				dg_GSMGetMessage(EventContext->port, szTemp);
				sprintf(data, "GSM Message Sent: %s", szTemp);
				break;
			case EV_GSMERROR:
				dg_GSMGetMessage(EventContext->port, szTemp);
				sprintf(data, "GSM ERROR received: %s", szTemp);
				break;
			case EV_GSMREADY:
				if (EventContext->data == 1)
					sprintf(data, "EV_GSMREADY received, MODULE START OK");
				else
					sprintf(data, "EV_GSMREADY received, MODULE START ERROR, do not use this port!!!");
				break;				
			//default:
			//    sprintf(data,"Unknown data from Port: %d cmd: %x Data: %x", EventContext.port,EventContext.command,EventContext.data);
		}
	if (data[0]!=0)
		print_event(data, EventContext->port, 1);
}

//----------------------------------------------------------
//Shows help messages
//----------------------------------------------------------
void show_help()
{
		printf("\nInvalid Parameters!");
		printf("\nUsage: vlib_diag -c <num_cards> -t <card_type> -p <firmware_path>");
		printf("\n       Where: num_cards - Number of installed cards     ");
		printf("\n              card_type - vbox or vppci     ");
		printf("\n              firm_path - Path to the firmware path\n");
}

//------------------------------------------------------------------------------------------
// Main Function 
//------------------------------------------------------------------------------------------
int main (int argc, char *argv[])
{
	char ch;

	char szNumber[2];
	char szTemp[255];
	char szMsg[255];
	const char* program_name;
	int next_option,ret;
	int ncards, i;
	short cc,j,paused=0;
	char szNumberToSMS[255];
	char szMessageToSMS[255];	
  
	WINDOW *wndH100;    
		
	/* Parse Command line arguments */
	/* parameters: no_cards , card_type, szFirmwarePath */ 
	const char* const short_options = "p:";
	
	const struct option long_options[] = {
		{ "path", 1, NULL, 'p'}, 		
		{ NULL, 0, NULL, 0 }
		};
		
	//const char output_filename = (const char)NULL;

	//-------------------------------------------------------------------
	// command line parser
	//-------------------------------------------------------------------
	program_name = argv[0]; /* Saves program name*/
		
	do {
		next_option = getopt_long(argc, argv, short_options, long_options, NULL);
		
		switch(next_option)
		{
		
			case 'p':		/* -p or --path */
				
				sscanf(optarg,"%s",&szTemp);				
				if (strlen(szTemp)==0)
				{
						show_help();
						exit(EXIT_FAILURE);
				}
				break;
		}
	}
	while (next_option != -1);
	//-------------------------------------------------------------------
		
	/* Start VoicerLib engine */
	if ((ret = dg_StartVoicerlib(NULL)) != EXIT_SUCCESS)
	{
			printf("\nError starting voicerlib (code %d)\n",ret);
			exit(EXIT_FAILURE);
	}
	printf("OK....\n",szTemp);
	digivoice_sleep(500);

	ncards = dg_GetCardsCount();
	
	//CONFIGURE CARDS BEHAVIOUR
	
	//sync mode for all cards
	
	for (i = 1; i <= ncards; i++) 
	{
		if (dg_GetCardInterface(i) == DG_DIGITAL_INTERFACE)
		{
			printf("Setting Sync for card %d - EXTERNAL LINE_A....\n",i);
			dg_SetCardSyncMode(i, SYNC_LINE_A);
			//dg_SetCardSyncMode(i,MASTER_INTERNAL_SYNC);
		}
	}

    //digivoice_sleep(4000);

	printf("Setting General Defaults....\n");

	//default properties for each enabled port
	for(current_channel=1; current_channel<=dg_GetPortsCount();current_channel++)
	{
		e1_thread_on[current_channel] = 0;			//e1 thread off
		gsm_thread_on[current_channel] = 0;			//gsm thread off
		gsm_hide_number[current_channel] = 0;

		//set the same id for all channels
		strcpy(szTemp,"1121916363\0");
		dg_SetPortId(current_channel,szTemp);
		//internal control variables
		idle_on[current_channel-1] = 0;
		cp_on[current_channel-1] = 0;
		e1_thread_on[current_channel-1] = 0;
		gsm_thread_on[current_channel-1] = 0;
		gsm_hide_number[current_channel-1] = 0;
	}

	current_channel=1;
	
	printf("Starting GUI....\n");	
	/* initialize ncurses stuff */
	win = initscr();
	start_color();  /* Start the color functionality */
	cbreak();       /* Line buffering disabled, Pass on
										* every thing to me         */
	keypad(stdscr, TRUE);        /* I need that nifty F1     */
	noecho();
	
	/* Initialize used colors */
	init_pair(1, COLOR_CYAN, COLOR_BLACK);        
	init_pair(2, COLOR_RED, COLOR_WHITE);            
	init_pair(3, COLOR_GREEN, COLOR_BLACK);            

	/* print initial screen */
	print_screen();
	
	/* disable getch wait */
	nodelay(win, TRUE);


	//create event window
	win_ev = create_newwin(15,78,15,1);
	wbkgd(win_ev,A_REVERSE | A_BOLD);
	scrollok(win_ev, TRUE);
	wrefresh(win_ev);
	
	for (i = 0; i <= 14; i++)
	{
		win_ev_scroll[i][0] = '\0';
	}
	
    /* Set events function callback */
    dg_SetEventCallback(ReceiveEvents,&event_context);
    


    for (j=1;j<=dg_GetCardsCount();j++)
    {
        dg_SetAlarmMode(j,ALARM_AUTOMATIC_NOTIFY);
    }



	for (i = 1; i <= ncards; i++) {
		sprintf(szTemp, "Firmware version card %d - %xh", i, dg_GetVersion(i));
		print_event(szTemp, i, 1);
	}
	
	strcpy(szFileName,"./grava%d.wav\0");

	/* Main Loop */
	while((ch = getch()) != 'q')
	{
		digivoice_sleep(10);
		
		if (ch == 'Q')
				break;

		switch(ch)
		{
				case 'w': case 'W':		//change file format
					file_format++;
					if (file_format>4)
							file_format=0;
					dg_SetPlayFormat(current_channel,file_format);
					dg_SetRecordFormat(current_channel,file_format);
					sprintf(szTemp,"Current file format is %s",szFF[file_format]);
					print_event(szTemp,current_channel, 1);
					break;
				/*case 'I' : case 'i':
						//cria
						if (idle_on[current_channel])
						{
							//desliga
							ret = dg_IdleAbort(current_channel);
							idle_on[current_channel]=0;
							print_event("Idle OFF!!!!",current_channel);
						}
						else
						{
							dg_IdleSettings(current_channel, 0,2,500, 1, 0, wtDTMF,500,20,"");
							ret = dg_IdleStart(current_channel);
							if (ret == EXIT_SUCCESS)
							{
								print_event("Idle Control Created!!!!",current_channel);
								idle_on[current_channel]=1;
							}
							else
							{
								sprintf(szMsg,"Idlr ERRO codigo = %x",ret);
								print_event(szMsg,current_channel);
							}
						}
					break;*/
				case 'g': case 'G':	    // GetDigits
					sprintf(szTemp,"Starting GetDigits waiting for 5 numbers with 5s for the first and 2s each another ones",current_channel);
					print_event(szTemp,current_channel, 1);
					dg_ClearDigits(current_channel);
					dg_GetDigits(current_channel,5,"#*",5000,2000);
					break;
				case 'l': case 'L':	    // play
					switch(file_format)
					{
						case 0:case 2:case 4:
							sprintf(szTemp,"./grava%d.wav\0",current_channel);
							break;
						case 1:
							sprintf(szTemp,"./grava%d.sig\0",current_channel);
							break;
						case 3:
							sprintf(szTemp,"./grava%d.gsm\0",current_channel);
							break;
					}
					dg_SetPlayFormat(current_channel,file_format);
					ret = dg_PlayFile(current_channel,szTemp,"*",0);
					if (ret==0)
					{
						sprintf(szMsg,"Playing %s",szTemp);
						print_event(szMsg,current_channel, 1);
					}
					else
					{
						sprintf(szMsg,"Could not open file. Error %d",ret);
						print_event(szMsg,current_channel, 1);
					}
					break;
				case 'r': case 'R':	    // record
					switch(file_format)
					{
						case 0:case 2:case 4:
							sprintf(szTemp,"./grava%d.wav\0",current_channel);
							break;
						case 1:
							sprintf(szTemp,"./grava%d.sig\0",current_channel);
							break;
						case 3:
							sprintf(szTemp,"./grava%d.gsm\0",current_channel);
							break;
					}
					dg_SetRecordFormat(current_channel,file_format);

					/*stream = fopen(szTemp,"wb");
					if(stream==NULL)
						print_event("Nao foi possivel abrir o arquivo",current_channel);
					else
 						print_event("Gravando...!",current_channel);
					dg_SetAudioInputCallback(GetSamplesFromCard);*/

					if (dg_EnableInputBuffer(current_channel, DG_DISABLE)==DG_EXIT_SUCCESS)
					{
						if (dg_RecordFile(current_channel,szTemp,"*")==0)
						{
							sprintf(szMsg,"Recording...%s",szTemp);
							print_event(szMsg,current_channel, 1);
						}
						else
							print_event("Could not open rec file",current_channel, 1); 
					}
					else
						print_event("Error creating input buffer",current_channel, 1); 

					break;
				case 's': case 'S':
					print_event("Record stopped",current_channel, 1);
					dg_StopRecordFile(current_channel);
					//if (stream)
					//	fclose(stream);

					//dg_StopRecordFile(current_channel+1);
					break;
				case 'k': case 'K':     //stop play
					print_event("Playback stopped",current_channel, 1);
					dg_StopPlayFile(current_channel);
					dg_StopPlayBuffer(current_channel);
					break;
				case 'e': case 'E':
					if (paused==0)
					{
						//paused=dg_RecordPause(current_channel,1);	//paused
                        paused=1;
                        dg_PauseInputBuffer(current_channel,paused);
						print_event("Rec Paused On",current_channel, 1);
					}
					else
					{
						//paused=dg_RecordPause(current_channel,0);	//unpaused
                        paused=0;
                        dg_PauseInputBuffer(current_channel,paused);
						print_event("Rec Paused Off",current_channel, 1);
					}
					break;
				case 'f': case 'F':
					dg_SetFrequency(1,425);
					print_event("Set frequency to 425Hz to card 1!",current_channel, 1);
					dg_Flash(current_channel, 1, 100,1000);
					break;
                case 'p': case 'P':
                        if (e1_thread_on[current_channel])
                        	wprintw(win_ev,"Porta %d - Numero a discar: ",current_channel);
						echo();
						wscanw(win_ev,"%s", &szNumberToDial);
						noecho();
						dg_PickUp(current_channel,100);
						print_event("Picked Up!",current_channel, 1);
						break;
				case 'M': case 'm':							 
					dg_SetRing(current_channel, DG_ENABLE, 1);
					print_event("Start Ring Generation Type 1", current_channel, 1);
					dg_SetFlash(current_channel, 80, 650);									
					print_event("SetFlash to 80-650(ms)", current_channel, 1);
					break;
				case 'N': case 'n':
					dg_SetRing(current_channel, DG_DISABLE, 1);
					print_event("Stop Ring Generation", current_channel, 1);					
					break;		
				case 'h': case 'H':
						dg_HangUp(current_channel);
						print_event("HangUp!",current_channel, 1);
						break;
				case 't': case 'T':
						if (cp_on[current_channel])
						{
							dg_DisableCallProgress(current_channel);
							dg_DestroyCallProgress(current_channel);
							cp_on[current_channel] = 0;
						}
						else
						{
							ret = dg_CreateCallProgress(current_channel, "cp_default.cfg");
							if (ret==DG_EXIT_SUCCESS)
							{
								ret=dg_EnableCallProgress(current_channel, CP_ENABLE_BUSY_OR_FAX);
								if (ret == DG_EXIT_SUCCESS)
										print_event("Call progress enabled!",current_channel, 1);
								else
									print_event("Error Call progress - erro %d!",ret, 1);

								cp_on[current_channel] = 1;
							}
							else
							{	
								sprintf(szTemp,"Error creating call progress - cod:%d\0",ret);
								print_event(szTemp,current_channel, 1);			
							}
						}
						//dg_GenerateMF(current_channel,GENERATE_TONE1,0);
						break;
				case 'y': case 'Y':
						dg_DisableCallProgress(current_channel);
						print_event("Call progress disabled!",current_channel, 1);
						break;
				case 'c': case 'C':
						clear();
						print_screen();
						break;
				case ',':
					current_channel-=30;
					if (current_channel < 1)
						current_channel = 1;
					mvprintw(2, 1, "Current Channel: %d    ",current_channel);
					break;
				case '.':
					current_channel+=30;
					if (current_channel > dg_GetPortsCount())
						current_channel = dg_GetPortsCount();
					mvprintw(2, 1, "Current Channel: %d    ",current_channel);
					break;

				case '-':
					if (current_channel > 1)
						current_channel--;
					mvprintw(2, 1, "Current Channel: %d    ",current_channel);
					break;
				case '+':
					if (current_channel < dg_GetPortsCount())
						current_channel++;               
					//Test E1 Calls
					mvprintw(2, 1, "Current Channel: %d    ",current_channel);
					break;
				case 'd': case 'D':
					//if (gsm_thread_on[current_channel])
					{                  	
						print_event("Port %d - Dial to: ", current_channel, 0);
						echo();
						wscanw(win_ev, "%s", &szNumberToDial);
						noecho();
						dg_Dial(current_channel, szNumberToDial, 2000, dtDTMF);
						sprintf(szTemp, "Dialing to: %s", szNumberToDial); 
						print_event(szTemp, current_channel, 1);
					}/*
					else
					{
						dg_Dial(current_channel, "26", 2000, dtDTMF);
						print_event("Dialing!", current_channel, 1);
					}*/

					break;
                case 'a': case 'A':
                        //dg_DisableFramer(1,CFG_FRAMER_E1_A);
                        //print_event("Disabling framers!",current_channel);
                        //usleep(3000*1000);
                    //    dg_EnableFramer(1,CFG_FRAMER_E1_A);
                    //    print_event("Enabling framers!",current_channel);
                    //    usleep(3000*1000);

                        print_event("Enabling DTMF Detection!",current_channel, 1);
                        dg_EnableEchoCancelation(current_channel, ECHO_HW_DSP, ECHO_TAPS_64, 1000, 3);
                        dg_SetSilenceThreshold(current_channel, -36);
                        dg_SetDetectionType(current_channel, DETECT_DTMF, DG_ENABLE);
                        break;
					case 'z': case 'Z':
						if (answer_state)
						{
							dg_DisableAnswerDetection(current_channel);
							print_event("Answer Detection Disabled!",current_channel, 1);
							answer_state = 0;
						}
						else
						{
							dg_EnableAnswerDetection(current_channel);
							print_event("Answer Detection enabled!",current_channel, 1);
							answer_state = 1;
						}
						break;								
					case '1': case '2': case '3': case '4': case '5': case '6':
					case '7': case '8': case '9': case '0': case '#': case '*':
							szNumber[0] = ch;
							szNumber[1] = 0;
							sprintf(szTemp,"Dialing: %c",ch);
							print_event(szTemp, current_channel, 1);

							if (gsm_thread_on[current_channel])
								dg_Dial(current_channel,szNumber, 1000, dtDirectMF);
							else
								dg_Dial(current_channel,szNumber, 1000, dtTone);

							break;
					case 'o': case 'O':
						if (dg_GetCardInterface(dg_GetCardNumber(current_channel)) == DG_FX_INTERFACE)
						{
							dg_SetFXCardType(current_channel, DG_FX_TYPE_FXO);
							print_event("Changing to DG_FX_TYPE_FXO!", current_channel, 1);
						}
						break;
					case 'x': case 'X':
						if (dg_GetCardInterface(dg_GetCardNumber(current_channel)) == DG_FX_INTERFACE)
						{
							dg_SetFXCardType(current_channel, DG_FX_TYPE_FXS);
							print_event("Changing to DG_FX_TYPE_FXS!", current_channel, 1);
						}
						break;
						/*//Teste de streaming de fala
						switch(file_format)
						{
							case 0:case 2:case 4:
								sprintf(szTemp,"./grava%d.wav\0",current_channel);
								break;
							case 1:
								sprintf(szTemp,"./grava%d.sig\0",current_channel);
								break;
							case 3:
								sprintf(szTemp,"./grava%d.gsm\0",current_channel);
								break;
						}
						//playbuffer
						stream = fopen(szTemp,"rb");
						if(stream==NULL)
							print_event("Nao foi possivel abrir o arquivo",current_channel);
						else
						{
								sprintf(szTemp,"Falando arquivo via streaming. Não pode ser interrompido");
								print_event(szTemp,current_channel);
								j=0;
								while((stream_size = fread(&szSamples,sizeof(char),33,stream)) )
								{
									
									if(stream_size>32)
									{
										ret = dg_PlayBuffer(current_channel,szSamples,stream_size, NULL);
										//usleep(1000*1);

										if (ret!=DG_EXIT_SUCCESS)
										{
											sprintf(szTemp,"falando arquivo - erro=%x",ret);
											print_event(szTemp,current_channel);		
											j++;
										
										}
									}
									
									
								}
						}
						if (stream)
						    fclose(stream);
						    
						sprintf(szTemp,"While %d vezes",j);
						print_event(szTemp,current_channel);						
						
						break;*/
					case '/': //create E1 handle to current_port
						//set the Port id for all channels
						if (dg_CreateE1Thread(current_channel) != DG_EXIT_SUCCESS)
							print_event("Error creating E1 Handle!!!!",current_channel, 1);
						else
						{
							strcpy(szTemp,"1121936360\0");
							dg_SetPortId(current_channel,szTemp);
							//set the same category  for all channels
							dg_ConfigE1Thread(current_channel,E1CFG_GROUP_II,1);
							//set to receive only 4 digits
							dg_ConfigE1Thread(current_channel,E1CFG_MAXDIGITS_RX,4);
							print_event("E1 Handle Created!!!!",current_channel, 1);
							e1_thread_on[current_channel]=1;
							dg_ConfigE1Thread(current_channel,E1CFG_SEND_ID_AFTERDIGIT,1);
							dg_ConfigE1Thread(current_channel,E1CFG_R2_COUNTRY, 1);//1=brazil, 2=argentine, 3=mexico - default=1
                        	dg_EnableDebug(current_channel);
						}
						break;
					case '\\': //create E1 handle to current_port
						if (dg_DestroyE1Thread(current_channel) != EXIT_SUCCESS)
							print_event("Error destroying E1 Handle!!!!",current_channel, 1);
						else
						{
							print_event("E1 Handle destroyed!!!!",current_channel, 1);
							e1_thread_on[current_channel]=0;
						}
						break;
					/*case '(':
						for (cc=1;cc<=60;cc++)
						{
							if (dg_DestroyE1Thread(cc) != EXIT_SUCCESS)
								print_event("Error destroying E1 Handle!!!!",cc);
							else
							{
								e1_thread_on[cc]=0;
							}
							
						}
						print_event("E1 Handle Destroyed!!!!",cc);
						break;*/
					/*case ')':
					    //sprintf(szTemp,"Versao %x", dg_GetVersion());
					    //print_event(szTemp, current_channel);
						for (cc=1;cc<=dg_GetPortsCount();cc++)
						{
							ret = dg_CreateE1Thread(cc);
							if (ret != EXIT_SUCCESS)
							{
							    
								sprintf(szTemp,"Error creating E1 Handle!!!! codigo %x",ret);
								print_event(szTemp,cc);
							}
							else
							{
								strcpy(szTemp,"1141952557\0");
								dg_SetPortId(cc,szTemp);
								//set the same category  for all channels
								dg_ConfigE1Thread(cc,E1CFG_GROUP_II,1);
								//set to receive only 4 digits
								dg_ConfigE1Thread(cc,E1CFG_MAXDIGITS_RX,8);
								
								e1_thread_on[cc]=1;
								dg_ConfigE1Thread(cc,E1CFG_SEND_ID_AFTERDIGIT,2);
								dg_ConfigE1Thread(cc,E1CFG_R2_COUNTRY, 1);//1=brazil, 2=argentine, 3=mexico - default=1
							}
							
						}
						print_event("E1 Handle Created!!!!",cc);
                        for (cc=1;cc<=dg_GetPortsCount();cc++)
                        {
                            ret = dg_CreateCallProgress(cc,"cp_default.cfg");
                            if (ret != EXIT_SUCCESS)
                            {

                                sprintf(szTemp,"Error creating callprogress Handle!!!! codigo %x",ret);
                                print_event(szTemp,cc);
                            }
                        }
                        print_event("CallProgress Handle Created!!!!",cc);
                        for (cc=1;cc<=dg_GetPortsCount();cc++)
                        {
                            ret = dg_EnableInputBuffer(cc,DG_DISABLE);
                            if (ret != EXIT_SUCCESS)
                            {

                                sprintf(szTemp,"Error creating inputbuffer Handle!!!! codigo %x",ret);
                                print_event(szTemp,cc);
                            }
                        }
                        print_event("inputbuffer Handle Created!!!!",cc);
					    break;*/						
					case 'v': case 'V':
						//reinicia 
						dg_ShutdownVoicerlib();
						print_event("Fechou!!!!",1, 1);
						sleep(5);
						/* Set events function callback */
						dg_SetEventCallback(ReceiveEvents,&event_context);
						if ((ret = dg_StartVoicerlib("../../../firmware")) != EXIT_SUCCESS)
						{
								printf("\nError starting voicerlib (code %d)\n",ret);
								exit(EXIT_FAILURE);
						}
						print_event("Reiniciou!!!!",1, 1);

						break;
					case '_': //alarm mode to automatic
						dg_SetAlarmMode(j,ALARM_GETSTATUS);
						
						break;
					case '~':
						print_event("Desabilita InputBuffer!",current_channel, 1);
						//dg_SetRecordGain(current_channel, -20);
						dg_DisableInputBuffer(current_channel);
						//dg_DisableInputBuffer(current_channel+60);
						if (stream)
							fclose(stream);
						break;
						
					//GSM FUNCTIONS
					case '(': //create GSM handle to current_port						
						if (dg_CreateGSMThread(current_channel) != DG_EXIT_SUCCESS)
							print_event("Error creating GSM Handle!!!!", current_channel, 1);
						else
						{
							//timeout between digits
							gsm_thread_on[current_channel]=1;
							dg_EnableGSMThread(current_channel);							
							print_event("GSM Handle Created!!!!",current_channel, 1);
							dg_EnableGSMDebug();
						}
						break;
					case ')': //create GSM handle to current_port
						if (dg_DestroyGSMThread(current_channel) != EXIT_SUCCESS)
							print_event("Error destroying GSM Handle!!!!", current_channel, 1);
						else
						{
							gsm_thread_on[current_channel]=0;
							
							print_event("GSM Handle destroyed!!!!", current_channel, 1);
						}
						break;
					case 'i': case 'I':  //Show/Hide My Number						
						if (gsm_hide_number[current_channel])
						{	
							gsm_hide_number[current_channel] = 0;
							dg_DisableGSMThread(current_channel);
							dg_ConfigGSMThread(current_channel, GSMCFG_ID_RESTRICTION, 0);
							dg_EnableGSMThread(current_channel);						
							print_event("GSM Will Show the Number(CID)!", current_channel, 1);						
						}
						else
						{
							gsm_hide_number[current_channel] = 1;
							dg_DisableGSMThread(current_channel);
							dg_ConfigGSMThread(current_channel, GSMCFG_ID_RESTRICTION, 1);
							dg_EnableGSMThread(current_channel);
							print_event("GSM Will Hide the Number(CID)!", current_channel, 1);							
						}
						break;
					case 'b': case 'B': //Set PIN Number
						print_event("Port %d - PIN Number: ", current_channel, 0);
						echo();
						wscanw(win_ev, "%s", &szNumberToSMS);
						noecho();
						dg_DisableGSMThread(current_channel);
						dg_GSMSetPinNumber(current_channel, szNumberToSMS, NULL);
						dg_EnableGSMThread(current_channel);
                       	sprintf(szTemp, "PIN Number '%s' setted", szNumberToSMS);
                       	print_event(szTemp, current_channel, 1);
						break;
					case 'j': case 'J': //Write SMS Message
						print_event("Port %d - Sent to: ", current_channel, 0);
						echo();
						wscanw(win_ev, "%s", &szNumberToSMS);
						noecho();						
						sprintf(szMessageToSMS, "SMS Test Message: Este eh um teste de envio de SMS pela placa Vb0404GSM.\r\nA nova solucao GSM da DigiVoice.\r\n");
						print_event(szMessageToSMS, current_channel, 1);
						
                       	dg_GSMSendSMS(current_channel, szNumberToSMS, szMessageToSMS);
                       	
                       	sprintf(szTemp, "Sending SMS Message to %s", szNumberToSMS);
                       	print_event(szTemp, current_channel, 1);
						break;
					case '|': //Send a Generic Command
                       	wprintw(win_ev, "Port %d - GSM Generic Command: ", current_channel);
						echo();
						wscanw(win_ev, "%s", &szTemp);
						noecho();						
					
						dg_GSMSendCommand(current_channel, szTemp);
						
						sprintf(szTemp, "Generic Command Sent: '%s'", szTemp);
						print_event(szTemp, current_channel, 1);
						break;
        }
    } /* while */

	wclear(win_ev);	
	destroy_win(win_ev);
	clear();
    endwin();
    /* Stops voicerlib engine */
    dg_ShutdownVoicerlib();

    printf("\n\n* * * Goodbye! * * *\n\n");
    
    return EXIT_SUCCESS;
}

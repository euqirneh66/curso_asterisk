/* Generic.h */

//Prototypes to generic functions - mudanca no fala

//#pragma pack(1)

//#define DEBUG_LOCKS

#ifndef __GENERIC_H__
#define __GENERIC_H__

#ifdef WIN32
	#define WCDECL __cdecl
#else
	#define WCDECL
#endif



#ifdef __LINUX__
	
	#ifndef __KERNEL__
		#include <sys/ioctl.h>		/*verificar 2.4 - estava fora do ifdef */
		#include <unistd.h>		/*verificar 2.4 */
		#include <pthread.h>
		#include <fcntl.h>
		//#include <asm/signal.h>
		#include <signal.h>
		#include <sys/stat.h>
		#include <sys/time.h>
		#include <sys/types.h>

		extern int pthread_mutexattr_settype (pthread_mutexattr_t *__attr, int __kind)
     		__THROW;
		
	#endif


#endif

#ifdef WIN32
	#include <string.h>
	#include <stdio.h>
	#include <windows.h>
	#include <process.h>
	#include <time.h>
#endif

#include "vlibdef.h"

#ifdef __LINUX__
	/* Global Variables */
	/* global timer structures */
	#define		TRUE		1
	#define		FALSE		0

	#ifndef __KERNEL__
		typedef pthread_t DIGIVOICE_THREAD;
		struct itimerval global_timer;
	  struct itimerval global_timer_old;
		struct sigaction sa_timer;
	  struct sigaction sa_timer_old;
	#endif
#else
 #ifdef WIN32
	#define MAX_LOADSTRING 100

	typedef long DIGIVOICE_THREAD;

	int TimerThread_ID;
	HINSTANCE hInstance;								// current instance
	TCHAR szTitle[MAX_LOADSTRING];					// The title bar text
	TCHAR szWindowClass[MAX_LOADSTRING];			// the main window class name
	HWND hWndTimer;
	UINT_PTR			uIDTimer;
	MSG msg;
 #endif
#endif


//critical section and mutexes
#ifdef __LINUX__
	//typedef struct {void *v; } DIGIVOICE_CRITICAL_SECTION;
	#ifndef __KERNEL__
		typedef pthread_mutex_t DIGIVOICE_CRITICAL_SECTION;
	#endif
#else
	typedef CRITICAL_SECTION DIGIVOICE_CRITICAL_SECTION;
#endif

//estrucutre used to pass address  to ioctl
typedef struct MEM_CMD {
	unsigned char card;
	unsigned int dwAddrSpace;
	unsigned int dwOffSet;
	unsigned int dwData;
} MEM_CMD;


unsigned char TXContadorGlobal[MAX_CARDS];

//functions prototypes
void write_generic_command(void *tx_command);

short InsereCmd_Tx(dg_cmd_tx *tmp);
short RetiraCmd_Rx(short card,dg_signal_from_device *rxcmd);

//---------------------------------------------------------------------------
//Critical Section Functions
//---------------------------------------------------------------------------
/*void WCDECL digivoice_initcriticalsection(DIGIVOICE_CRITICAL_SECTION *);
void WCDECL digivoice_deletecriticalsection(DIGIVOICE_CRITICAL_SECTION *);
void WCDECL digivoice_entercriticalsection(DIGIVOICE_CRITICAL_SECTION *);
void WCDECL digivoice_leavecriticalsection(DIGIVOICE_CRITICAL_SECTION *);
*/

#ifdef __LINUX__

  #ifndef __KERNEL__
	//---------------------------------------------------------------------------
	//
	//---------------------------------------------------------------------------
	static inline int WCDECL digivoice_initcriticalsection(DIGIVOICE_CRITICAL_SECTION *cs)
	{
		int res;		
		pthread_mutexattr_t attr;
		
		pthread_mutexattr_init(&attr);
		pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE_NP);
		
		res = pthread_mutex_init(cs, &attr);
		pthread_mutexattr_destroy(&attr);
		return res;
	}
	//---------------------------------------------------------------------------
	//
	//---------------------------------------------------------------------------
	static inline int WCDECL digivoice_deletecriticalsection(DIGIVOICE_CRITICAL_SECTION *cs)
	{
		return pthread_mutex_destroy(cs);
	
	}
	//---------------------------------------------------------------------------
	//
	//---------------------------------------------------------------------------
	/*static inline int WCDECL digivoice_entercriticalsection(DIGIVOICE_CRITICAL_SECTION *cs)
	{
		return pthread_mutex_lock(cs);
	}*/
	
	//---------------------------------------------------------------------------
	//
	//---------------------------------------------------------------------------
	/*static inline int WCDECL digivoice_leavecriticalsection(DIGIVOICE_CRITICAL_SECTION *cs)
	{
		return pthread_mutex_unlock(cs);
	}*/	
	
#ifdef DEBUG_LOCKS	
		#define digivoice_entercriticalsection(a, port) __ast_vlib_mutex_lock(a, __LINE__, __PRETTY_FUNCTION__, #a, port)
		static inline int WCDECL __ast_vlib_mutex_lock(DIGIVOICE_CRITICAL_SECTION *t, int lineno, const char *func, const char* mutex_name, int port)
		{
			int res;
			write_debug("digivoice_entercriticalsection(before): line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
			res = pthread_mutex_lock(t);
			write_debug("digivoice_entercriticalsection(after):  line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
			return res;
		}
#else
		static inline int WCDECL digivoice_entercriticalsection(DIGIVOICE_CRITICAL_SECTION *t, int port)
		{
			return pthread_mutex_lock(t);
		}	
#endif//#ifdef DEBUG_LOCKS	

#ifdef DEBUG_LOCKS
		#define digivoice_leavecriticalsection(a, port) __ast_vlib_mutex_unlock(a, __LINE__, __PRETTY_FUNCTION__, #a, port)
		static inline int WCDECL __ast_vlib_mutex_unlock(DIGIVOICE_CRITICAL_SECTION *t, int lineno, const char *func, const char* mutex_name, int port)
		{
			int res;
			write_debug("digivoice_leavecriticalsection(before): line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
			res = pthread_mutex_unlock(t);
			write_debug("digivoice_leavecriticalsection(after):  line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
			return res;
		}
#else
		static inline int WCDECL digivoice_leavecriticalsection(DIGIVOICE_CRITICAL_SECTION *t, int port)
		{
			return pthread_mutex_unlock(t);
		}
#endif//#ifdef DEBUG_LOCKS

	/*
	#define digivoice_entercriticalsection(a, port) __ast_vlib_mutex_lock(a, __LINE__, __PRETTY_FUNCTION__, #a, port)
	static inline int WCDECL __ast_vlib_mutex_lock(DIGIVOICE_CRITICAL_SECTION *t, int lineno, const char *func, const char* mutex_name, int port)
	{
		int res;
#ifdef DEBUG_LOCKS
			write_debug("digivoice_entercriticalsection(before): line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
#endif//#ifdef DEBUG_LOCKS
			
		res = pthread_mutex_lock(t);
		
#ifdef DEBUG_LOCKS
			write_debug("digivoice_entercriticalsection(after):  line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
#endif//#ifdef DEBUG_LOCKS
		return res;		
	}

	#define digivoice_leavecriticalsection(a, port) __ast_vlib_mutex_unlock(a, __LINE__, __PRETTY_FUNCTION__, #a, port)
	static inline int WCDECL __ast_vlib_mutex_unlock(DIGIVOICE_CRITICAL_SECTION *t, int lineno, const char *func, const char* mutex_name, int port)
	{
		int res;
#ifdef DEBUG_LOCKS
			write_debug("digivoice_leavecriticalsection(before): line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
#endif//#ifdef DEBUG_LOCKS
			
		res = pthread_mutex_unlock(t);
		
#ifdef DEBUG_LOCKS
			write_debug("digivoice_leavecriticalsection(after):  line %05d(%s), port %03d, mutex '%s'\n", lineno, func, port, mutex_name);
#endif//#ifdef DEBUG_LOCKS
		return res;		
	}
	*/
	
	#endif //not kernel
#endif

#ifdef WIN32
//---------------------------------------------------------------------------
//Critical Section Functions
//---------------------------------------------------------------------------
__forceinline void WCDECL digivoice_initcriticalsection(DIGIVOICE_CRITICAL_SECTION *cs)
{
	InitializeCriticalSection((LPCRITICAL_SECTION)cs);
}

__forceinline void WCDECL digivoice_deletecriticalsection(DIGIVOICE_CRITICAL_SECTION *cs)
{
	DeleteCriticalSection((LPCRITICAL_SECTION)cs);
}


__forceinline void WCDECL digivoice_entercriticalsection(DIGIVOICE_CRITICAL_SECTION *cs, int port)
{
	EnterCriticalSection((LPCRITICAL_SECTION)cs);
}

__forceinline void WCDECL digivoice_leavecriticalsection(DIGIVOICE_CRITICAL_SECTION *cs, int port)
{
	LeaveCriticalSection((LPCRITICAL_SECTION)cs);
}

#endif //win32

void WCDECL digivoice_sleep(unsigned int ms);
//int digivoice_beginthread(void(*func)(void*), int stack, void *data);
int WCDECL digivoice_beginthread(void *thread_id,void(*func)(void*), int stack, void *data);
void WCDECL digivoice_endthread(void);
void digivoice_cancelthread(void *thread_id);

void WCDECL digivoice_starttimer(void);
void WCDECL digivoice_stoptimer(void);
short WCDECL digivoice_configure(void);
int WCDECL digivoice_load_firmware(char *);

void digivoice_disableinterrupts(void);

u32 WCDECL digivoice_gettick(void);		//emulates GetTickCount

#ifdef __LINUX__
	void TimerProc(int signum);
#endif


#ifdef WIN32

	//local functions - specific for DLLs
	BOOL				InitInstance(HINSTANCE, int);
	//LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
	//void CALLBACK TimerProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime);
	void PlayThread( void *ThreadID );
	//void MessageQueueThread( char *ThreadID );
	void TimerProc(int signum);
#endif

#ifndef __KERNEL__

	/*DIGIVOICE_CRITICAL_SECTION mtx_insert_to_e1;
	//DIGIVOICE_CRITICAL_SECTION mtx_insert_to_control;  
	DIGIVOICE_CRITICAL_SECTION mtx_insert_to_logger;  
	DIGIVOICE_CRITICAL_SECTION mtx_insert_to_cas;  
	DIGIVOICE_CRITICAL_SECTION mtx_insert_to_cp;  
	DIGIVOICE_CRITICAL_SECTION mtx_insert_to_idle;
	
	DIGIVOICE_CRITICAL_SECTION event_mutex;
	DIGIVOICE_CRITICAL_SECTION play_mutex;
	DIGIVOICE_CRITICAL_SECTION rec_mutex;
	DIGIVOICE_CRITICAL_SECTION dial_mutex;
	DIGIVOICE_CRITICAL_SECTION cmd_mutex; */

	DIGIVOICE_CRITICAL_SECTION cmd_mutex;  //write_generic_command mutex
	DIGIVOICE_CRITICAL_SECTION event_mutex;  //RX mutex

	//DIGIVOICE_CRITICAL_SECTION handle_digits_mutex[MAX_CARDS*MAX_CHANNELS_CARD];	//mutex to avoid concurrency between threads
	//DIGIVOICE_CRITICAL_SECTION rec_stop_mutex[MAX_CARDS*MAX_CHANNELS_CARD];	//mutex to avoid concurrency between threads
	
	DIGIVOICE_CRITICAL_SECTION card_mutex[MAX_CARDS];	//mutex to avoid race conditions between threads	

	DIGIVOICE_CRITICAL_SECTION port_mutex[MAX_CARDS*MAX_CHANNELS_CARD];	//mutex to avoid race conditions between threads
#endif

#endif

/*-----------------------------------------------------------------------

	Module: DG_API.h

	Remarks: This module creates all functions that will interact with
	         Jungo Windriver(c) functions. Prototypes

------------------------------------------------------------------------*/

//#pragma pack(1)

#ifndef _DG_API_H_
#define _DG_API_H_


#ifdef WIN32
	#include "c:/lp/windriver/include/windrvr.h"
	#include "c:/lp/windriver/include/windrvr_int_thread.h"
	#include "c:/lp/windriver/include/windrvr_events.h"
	#include "c:/lp/windriver/samples/shared/pci_regs.h"
	#include "c:/lp/windriver/samples/shared/bits.h"

#endif

#ifdef __LINUX__
	#include "../src_linux/linux_api.h"
	#include <sys/types.h>
#endif

#include "../src_common/vlibdef.h"

//eeprom functions defines 
#define EE_CS								0x2000000	
#define EE_CLK								0x1000000
#define EE_DI								0x4000000
#define EE_DO								0x8000000
#define EE_ID_DIGI					0x6			//address of digivoice�s identification

#define BUFFER_WR 					0x400  //conforme no programa de boot
#define BUFFER_RD 					0x403  //conforme no programa de boot

//Esta funcao coloca pino HCS (GPIO0) em 1
void Set_HCS(VLIB_HANDLE hPlx);

//Estas funcao coloca HCS (GPIO0) em 0
void Reset_HCS(VLIB_HANDLE hPlx);

//Esta funcao coloca pino RESET (GPIO1) em 1
void Set_RESET(VLIB_HANDLE hPlx);

//Estas funcao coloca RESET (GPIO1) em 0
void Reset_RESET(VLIB_HANDLE hPlx);

//Esta funcao coloca pino RESET2(GPIO2) em 1
void Set_RESET2(VLIB_HANDLE hPlx);

//Estas funcao coloca RESET2 (GPIO2) em 0
void Reset_RESET2(VLIB_HANDLE hPlx);

//le um reg no endereco mapeado em memoria na placa
//addr eh o offset do endereco a ser lido pelo pc
u16 Placa_Read_Reg(VLIB_HANDLE hPlx, u32 dwAddr);

//Escreve em um reg no endereco mapeado em memoria na placa
//addr eh o offset do endereco a ser escrito pelo pc
void Placa_Write_Reg(VLIB_HANDLE hPlx, u32 dwAddr, u16 wData);

//le um dado na placa
u16 Placa_Read(VLIB_HANDLE hPlx, u32 dwAddr);

//escreve um dados na placa
void Placa_Write(VLIB_HANDLE hPlx, u32 dwAddr,u16 wData);

//le uma sequencia de dados na placa
void Placa_Read_N(VLIB_HANDLE hPlx, u32 dwAddr,u16 *wData, u32 dwN);

//escreve uma sequencia de dados na placa
void Placa_Write_N(VLIB_HANDLE hPlx, u32 dwAddr,u16 *wData, u32 dwN);

//Tira interrupcao do DSP
void Reset_Int_DSP(VLIB_HANDLE hPlx);

int load1(char *arquivo, VLIB_HANDLE hPlx);
int testeload1(char *arquivo, VLIB_HANDLE hPlx);

int load2(char *arquivo, VLIB_HANDLE hPlx);
int testeload2(char *arquivo, VLIB_HANDLE hPlx);

int htoi(char c);

u16 Read_EEPROM(VLIB_HANDLE hPlx,u16 wAdr);
void Write_EEPROM(VLIB_HANDLE hPlx,u16 wAdr,u16 wData);
void Ewen_EEPROM(VLIB_HANDLE hPlx);
void Ewds_EEPROM(VLIB_HANDLE hPlx);

#ifdef __LINUX__
	short WCDECL digivoice_setdgdummycardinterrupt(void);
#endif//#ifdef __LINUX__

#endif


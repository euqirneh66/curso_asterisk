/***************************************************************************
 *                                                                         *
 *   VoicerLib - Linux Version                                             *
 *                                                                         *
 *   Copyright (c) 2004, Digivoice Tecnologia em Eletr�nica Ltda           *
 *                                                                         *
 *   Module: threads.h                                                     *
 *                                                                         *
 *   Description: Threads.c include file                                   *
 *                                                                         *
 *                                                                         *
 *   Author: Paulo Garcia                                                  *
 *   paulo@digivoice.com.br                                                *
 *                                                                         *
 *                                                                         *
 *  This software is licensed under Digivoice Public License               *
 *                                                                         *
 *	Copyright (c) 2004, Digivoice Tecnologia em Eletr�nica Ltda            *
 *	All rights reserved.                                                   *
 *                                                                         *
 *	Redistribution and use in source and binary forms, with or without     *
 *	modification, are permitted provided that the following conditions     *
 *  are met:                                                               *
 *                                                                         *
 * - Redistributions of source code must retain the above copyright        *
 *   notice, this list of conditions and the following disclaimer.         *
 * - Redistributions in binary form must reproduce the above copyright     *
 *   notice, this list of conditions and the following disclaimer in the   *
 *   documentation and/or other materials provided with the distribution.  *
 * - Modifications must not alter or remove any copyright notices in       *
 *   the Software and related documents.                                   *
 * - Any modifications in the original source code or modified versions of *
 *   this library must be available under this license.                    *
 * - You may develop application programs, reusable components and other   *
 *   software items that link with the original or modified versions of    *
 *   this library and release them under the license you wish.             *
 * - Neither the name of the Digivoice Tecnologia em Eletr�nica Ltda,      *
 *   VoicerLib nor the names of its contributors may be used to endorse    *
 *   or promote products derived from this software without specific prior *
 *   written permission.                                                   *
 *                                                                         *
 *  DISCLAIMER                                                             *
 *                                                                         *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS    *
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT      *
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  *
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  *
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT       *
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  *
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  *
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT    *
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE  *
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.   *
 *                                                                         *
 ***************************************************************************/

#ifndef __THREADS_H__
#define __THREADS_H__

//#pragma pack(1)

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <string.h>
#ifdef __LINUX__
	#include <semaphore.h>
#endif


#include "voicerlib.h"
#include "generic.h"

unsigned short thread_count;



DIGIVOICE_THREAD thread_playback_id[MAX_CHANNELS];	//holds the playback thread handle
DIGIVOICE_THREAD thread_record_id[MAX_CHANNELS];	//holds the record thread handle
DIGIVOICE_THREAD thread_dial_id[MAX_CHANNELS];	//holds the record thread handle
DIGIVOICE_THREAD thread_flash_id[MAX_CHANNELS];	//holds the record thread handle
DIGIVOICE_THREAD thread_event_id[MAX_CARDS];
DIGIVOICE_THREAD thread_ccs_id[MAX_CARDS];

//ccs thread device handle
int   device_ccs[MAX_CARDS];


short	ignore_error[MAX_CARDS];

#ifdef __LINUX__
	DIGIVOICE_THREAD thread_recsignal[MAX_CHANNELS];						//rec sync thread
	DIGIVOICE_THREAD thread_playsignal[MAX_CHANNELS];						//rec sync thread
	sem_t			 recsync_sem[MAX_CHANNELS];				//semaphore structure
	sem_t			 playsync_sem[MAX_CHANNELS];			//semaphore structure
#endif



//Function declarations
void SignalsFromCard(void *unused);
void PlayThread(void *device_info);
void DialThread(void *dial_info);
void RecordThread(void *device_info);
void FlashThread(void *flash_info);
void ccs_thread(void *flash_info);

#ifdef __LINUX__
	void RecSignalThread(void *device_info);
	void PlaySignalThread(void *device_info);
#endif

#endif







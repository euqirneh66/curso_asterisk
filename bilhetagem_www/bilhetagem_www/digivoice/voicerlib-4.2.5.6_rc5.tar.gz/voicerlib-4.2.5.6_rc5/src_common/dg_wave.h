/*****************************************************************************************
*	Wave functions header
*****************************************************************************************/

/*****************************************************************************************

	FormatCode	  	PreProcessor Symbol  						Data
	------------------------------------------------------------------------------------
	0x0001 			WAVE_FORMAT_PCM 							PCM
	0x0003 			WAVE_FORMAT_IEEE_FLOAT 						IEEE float
	0x0006 			WAVE_FORMAT_ALAW 							8-bit ITU-T G.711 A-law
	0x0007 			WAVE_FORMAT_MULAW 							8-bit ITU-T G.711 �-law
	0xFFFE 			WAVE_FORMAT_EXTENSIBLE 						Determined by SubFormat

*****************************************************************************************/


#ifndef _DG_WAVE_
#define _DG_WAVE_

#include <stdio.h>
#include <stdlib.h>

#define FALSE		0
#define TRUE		1
#define WAVE42_SIZE 65

#ifdef __cplusplus
   #define EXTERN_C     extern "C"
#else
   #define EXTERN_C     extern
#endif

/*****************************************************************************************
*	Wave main header structure
*****************************************************************************************/
typedef struct wave_main_header {
	char ckID[4];
	unsigned int ckSize;
	char WaveID[4];
	char ckFmtID[4];
	unsigned int ckFmtChunkSize; //16, 18 ou 40 -> determines the type of format
	unsigned short  wFormatTag; 

} WAVE_MAIN_HEADER;

typedef struct  { 
    
    unsigned short  nChannels; 
    unsigned int nSamplesPerSec; 
    unsigned int nAvgBytesPerSec; 
    unsigned short nBlockAlign; 
} WAVE_FORMAT; 
 
typedef struct { 
    unsigned short  nChannels; 
    unsigned int nSamplesPerSec; 
    unsigned int nAvgBytesPerSec; 
    unsigned short  nBlockAlign; 
    unsigned short  wBitsPerSample; 
    unsigned short  cbSize; 
} WAVE_FORMAT_EX; 

/*****************************************************************************************
*	Extra data
*****************************************************************************************/
typedef struct { 
	unsigned short  wValidBitsPerSample;		//Number of valid bits
	unsigned int	dwChannelMask;				//Speaker position mask
	char			SubFormat[16];				//GUID, including the data format code
} WAVE_EXTRA_FORMAT;

typedef struct { 
	char chID[4];
	unsigned int ckSize;
} WAVE_FACT;

typedef struct { 
	char chID[4];
	unsigned int ckSize;
} WAVE_DATA;

/*****************************************************************************************
*	WAVE 
*****************************************************************************************/
typedef struct wgenericheader
{
 char			riff[4];		// 'RIFF'
 unsigned long	        tam_arq;	
 char			wave[4];		// 'WAVE'
								//------ fmt chunk ---------
 char			fmt[4];			// 'fmt '
 unsigned long	tamanho;	
 unsigned short formato; 		// 0-unknown, 1-PCM linear,...
 unsigned short canais;  		// 1-mono, 2-stereo
 unsigned long	freq;   		// samples/second
 unsigned long	bs;      		// bytes/second
 unsigned short bloco;			// alignment (channels * size of the sample)
 unsigned short par;			// format specific parameter
 unsigned short cb;				
 unsigned char  extradata[22];
 
								// ------ fact chunk ------
 char			fact[4];
 unsigned long	dwFactChunkSize;
 unsigned long	dwFactFileSize;
								// ------ data chunk -------
 char			data[4];		// 'data'
 unsigned long	tm;				
 }WGenericHeader;


/*****************************************************************************************
*	WAVE Format header structure
*****************************************************************************************/
typedef struct 
{
  unsigned char l[8];
  unsigned long Samples;
  unsigned int  Revision;
  unsigned int  FileType;
  unsigned int  Bits;
  unsigned long Sampling;
  unsigned int  Normalization;
  unsigned char Unused[70];
  unsigned char Message[32];
  int  MenosRevision;

}Header;	

/*****************************************************************************************
*	Header of a Wave file
*****************************************************************************************/
typedef struct  wheader
{
 char			riff[4];		// 'RIFF'
 unsigned long	tam_arq;		
 char			wave[4];		// 'WAVE'
 char			fmt[4];			// 'fmt '
 unsigned long	tamanho;		// size of 'chunk' format
 unsigned short formato; 		// 0-unknown, 1-PCM linear,...
 unsigned short canais;  		// 1-mono, 2-stereo
 unsigned long	freq;   		// samples/second
 unsigned long	bs;      		// bytes/second
 unsigned short bloco;			// alignment (channels * size of the sample)
 unsigned long	par;			// format specific parameter
 char			data[4];		// 'data'
 unsigned long	tm;				

 }WHeader;

/*****************************************************************************************
*	 Header of GSM
*****************************************************************************************/
typedef struct gsmheader
{
	char		comments[256];	
	WHeader		wavepart;
 }GSMHeader;

#ifdef __cplusplus
extern "C" {
#endif
	//functions prototypes
	unsigned int dg_wave_get_le32(unsigned char *p);
	void dg_wave_get_format_name (int format, char *szName);
	int	dg_wave_find_str(FILE *wv, char *szData);
	int dg_wave_read_header(FILE *wv, 
							WAVE_MAIN_HEADER		*waveMain,
							WAVE_FORMAT				*waveFmtPCM,
							WAVE_FORMAT_EX			*waveFmtEx,
							WAVE_EXTRA_FORMAT		*waveExtraData,
							WAVE_FACT				*waveFact,
							WAVE_DATA				*waveData);

	void cW49Gsm		(unsigned char * );
	int	 cGsmW49		(unsigned char * );


#ifdef __cplusplus
	}
#endif

#endif

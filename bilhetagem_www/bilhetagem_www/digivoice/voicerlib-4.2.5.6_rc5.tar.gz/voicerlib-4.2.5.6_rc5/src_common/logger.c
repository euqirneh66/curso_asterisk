
/***************************************************************************
 *                                                                         *
 *   VoicerLib															   *
 *                                                                         * 
 *   Copyright (c) 2004, Digivoice Tecnologia em Eletronica Ltda           *
 *                                                                         *
 *   Module: Logger Control                                                *
 *                                                                         *
 *                                                                         *
 * target_port is the main port that will receive events into application  *
 * port2 is the *another* port, making pair with target_port			   *
 *
 *   Author: Paulo Garcia                                                  *                                                
 *   paulo@digivoice.com.br                                                *
 *                                                                         
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *   
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *   
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************/

 
#define INCOMINGCALL	1
#define OUTGOINGCALL	2

#define MFF				1
#define MFT				2


#include "vlibdef.h"
#include "voicerlib.h"

#include <fcntl.h>

#ifdef __LINUX__
	#include <unistd.h>
	#include <assert.h>
	#include <stdarg.h>
#endif

//extern DIGIVOICE_CRITICAL_SECTION mtx_insert_to_logger;

#ifdef WIN32

#ifdef _DEBUG
//------------------------------------------------------------------------
// fun�o inline para escrever arquivo de log: e1-(canal).log
//------------------------------------------------------------------------
__forceinline int __cdecl write_logger(short port,const char *s, ...)
{
	FILE *pdebug;
	time_t curSecs;
	struct tm *now;
	char szTemp[200];
	char szFileName[200];
	va_list argp;
	int retval=0;

	curSecs = time(NULL);
	now = localtime(&curSecs);
	sprintf(szTemp,"<%02d:%02d:%02d>",now->tm_hour, now->tm_min, now->tm_sec);


    va_start(argp, s);
	sprintf(szFileName,"c:\\log\\log-%d.log",port);
	pdebug=fopen(szFileName,"a+");
	if (pdebug!=NULL)
	{
		fprintf(pdebug,"%s-",szTemp);
		retval = vfprintf( pdebug, s, argp);
		fprintf(pdebug,"\n");
        /* let somebody else do the work */
		fclose(pdebug);
	}
	va_end(argp);

	return retval;
}
#else
__forceinline void __cdecl write_logger(short port,const char *s, ...)
{
}

#endif//debug

#else

void write_logger(short port,char *fmt, ...)
{
	
	va_list argptr;
	int     ret;
	FILE    *f;
	time_t curSecs;
	struct tm *now_dbg;
	char szdbgtemp[200];
	char szFileName[200];	
	
	curSecs = time(NULL);				\
	now_dbg = localtime(&curSecs);	\
	sprintf(szdbgtemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);						\

	va_start(argptr, fmt);
	sprintf(szFileName,"/var/log/voicerlib/logger-%d.log",port);	
	f = fopen(szFileName, "a+");
	fprintf(f,"%s-",szdbgtemp);	
	ret = vfprintf(f,fmt,argptr);
	fprintf(f,"\n");	
	fclose(f);
	assert(ret != 0);

	va_end(argptr);
}	

#endif


//------------------------------------------------------------------------
// Thread function to signal in E1 cards
//------------------------------------------------------------------------
void Logger_Thread(void *signal_logger_info)
{
	dg_logger_thread_structure *logger;
	dg_event_data_structure 	logger_events;


	short card;
	unsigned int seizure_timeout = 0;
	short port_save = 0;	/* porta a ser salva para tratamento de inversao de R2 */

	short trata_r2 = 0;
	int rx_group_i = 0;
	int r2i = 0,mfci=0;
	int line_state=OFF;
	int r2_step=P_R2_LIVRE;
	int mfc_step=P_MFC_REPOUSO;

	char rx_group_ii = 0;			//categoria
	//char rx_grupo_i = 0;
	
	int mf_type = 0;		//1 MFF   2 MFT
	int a5 = OFF;
	int retencao = 0;
	int grupo_a=0;
	int rx_group_b=0;

#ifdef __LINUX__
	int fifo_rx;
#else
	HANDLE fifo_rx;
	u32 cbBytesRead;
#endif

	logger = (dg_logger_thread_structure *)signal_logger_info;



	write_logger(logger->target_port,"Criando thread de logger");
	

#ifdef __LINUX__ 
	fifo_rx = open(logger->szFifoToLogger,O_RDONLY);
	if (fifo_rx==0)
	{
		//nao conseguiu abrir a fifo
		write_logger(logger->target_port,"Error openning fifo....");
	}

#endif

#ifdef WIN32

	fifo_rx	= CreateFile(logger->szFifoToLogger,
						GENERIC_READ | 
						GENERIC_WRITE,
						0,						//NO SHARING
						NULL,
						OPEN_EXISTING,
						0,
						NULL);

#endif


	logger->calltype = -1;

	while(logger->thread_running)
	{
		//retirar e tratar um evento da fifo
#ifdef __LINUX__
		read(fifo_rx,&logger_events,sizeof(logger_events));
#else

		//windows
		WaitForSingleObject(logger->oOverlapLogger.hEvent,INFINITE);
		ReadFile(fifo_rx,        // handle to pipe 
				&logger_events,    // buffer to receive data 
				sizeof(logger_events),      // size of buffer 
				&cbBytesRead, // number of bytes read 
				&logger->oOverlapLogger);        // not overlapped I/O 
#endif


		write_logger(logger->target_port,"LOGGER (%d) Cmd: %x Dado: %x", logger_events.port,logger_events.command ,logger_events.data );
		//terminates thread
		if (logger_events.command == C_ENDTHREAD)
		{
			//cancel thread execution
			write_logger( logger->target_port,"Finalizing Logger thread...");
			break;
		}
		//trata R2
		switch(logger_events.command)
		{
				case C_CAS:
					//dado R2 tem q ser filtrado s�para pegar o R2
					r2i = (logger_events.data | 0x1) & 0xd;
					mfci = 0;
					break;
				case C_AUDIO:				//digits or silence
					mfci = logger_events.data;
					//determina o type de MF que chegou
					if (logger->calltype==INCOMINGCALL)
						//__________
						if (dg_GetRelativeChannelNumber(logger_events.port) <= HALF_CHANNELS)
							mf_type = MFF;
						else
							mf_type = MFT;
					else
						if (dg_GetRelativeChannelNumber(logger_events.port) <= HALF_CHANNELS) //_____
							mf_type = MFT;
						else
							mf_type = MFF;
					break;
		}
		trata_r2 = 1;
		while (trata_r2>0)
		{
			switch (r2_step)
			{
				case P_R2_LIVRE:
					switch(r2i)
					{
						case R2_SEIZURE:  //ligacao entrante
							write_logger(logger->target_port,"LOGGER (%d) P_R2_LIVRE->R2_SEIZURE",logger_events.port);
							// decide if it is an incoming call or outgoing call
							if (dg_GetRelativeChannelNumber(logger_events.port) <= HALF_CHANNELS)
							{
								logger->calltype = INCOMINGCALL;

								write_logger(logger->target_port,"LOGGER (%d) Ligacao entrante",logger_events.port);
							}
							else
							{
								//event received from port n+30, then events.port is n+30
								logger->calltype = OUTGOINGCALL;
								write_logger(logger->target_port,"LOGGER (%d) Ligacao sainte",logger_events.port);
							}
							//desabilita portas da conferencia e do mixer
							dg_ChatDisablePort(logger->chat_handle,logger->port2);
							dg_ChatDisablePort(logger->chat_handle,logger->target_port);
							dg_SetPortChatLog(logger->target_port,logger->chat_handle,0);
							dg_SetPortChatLog(logger->port2 ,logger->chat_handle,0);
							//disable agc
							//dg_DisableAgc(logger->target_port);
							//dg_DisableAgc(logger->port2);


							logger->rx_number_of_digits=0;
							logger->rx_complete_count=0;
							logger->rx_id_number_of_digits = 0;
							r2_step=P_R2_CONFIRMAOCUPACAO;

                            //the following block has been moved from the P_R2_CONFIRMAOCUPACAO to detect mf before seizure_ack
                            //AA block start

							//canal x recebeu ocupacao e em x+30 a confirmacao de ocupacao
							if (logger->calltype == OUTGOINGCALL ) /* && (dg_GetRelativeChannelNumber(logger_events.port) > HALF_CHANNELS) )*/
							{
								//event coming from port N + 30

								//enable MF detections
								//N->MFT
								dg_SetSilenceThreshold(logger->target_port,logger->silence_threshold_signaling );								
								dg_SetDetectionType(logger->target_port,DETECT_ALL_MF, DG_DISABLE);
								dg_SetDetectionType(logger->target_port,DETECT_MFT, DG_ENABLE);

								//N+30->MFF
								dg_SetSilenceThreshold(logger_events.port,logger->silence_threshold_signaling );								
								dg_SetDetectionType(logger_events.port,DETECT_ALL_MF, DG_DISABLE);
								dg_SetDetectionType(logger_events.port,DETECT_MFF, DG_ENABLE);

	
								//AA r2_step=P_R2_RECEBENDO_MFC;
								//AA logger->rx_number_of_digits = 0;
								//AA logger->rx_complete_count = 0;
								mfc_step = P_MFC_ESPERA_MF;
							}
							else
								//canal x+30 recebeu ocupacao e em x a confirmacao de ocupacao
								if (logger->calltype == INCOMINGCALL)/*&& (dg_GetRelativeChannelNumber(logger_events.port) <= HALF_CHANNELS) )*/
								{
									//enable MF detections
									//N->MFF
									dg_SetSilenceThreshold(logger_events.port,logger->silence_threshold_signaling );
									dg_SetDetectionType(logger_events.port,DETECT_ALL_MF, DG_DISABLE);
									dg_SetDetectionType(logger_events.port,DETECT_MFF, DG_ENABLE);

									//N+30->MFT
									dg_SetSilenceThreshold(logger->port2,logger->silence_threshold_signaling );
									dg_SetDetectionType(logger->port2,DETECT_ALL_MF, DG_DISABLE);
									dg_SetDetectionType(logger->port2,DETECT_MFT, DG_ENABLE);

									//AA r2_step=P_R2_RECEBENDO_MFC;
									//AA logger->rx_number_of_digits = 0;
									//AA logger->rx_complete_count = 0;
									mfc_step = P_MFC_ESPERA_MF;
								}
								else
								{
									//caso improvavel..verificar

								}
							r2i = 0;
							a5=OFF;
							rx_group_b = 0;
							rx_group_ii = 0;
                            //AA block end

							//verifica se a confirmacao ja chegou no evento anterior
							if ( (digivoice_gettick() - seizure_timeout) < 1500)
							{
								//for� passar novamente pelo P_R2_CONFIRMAOCUPACAO
								r2i = R2_SEIZURE_ACK;
								trata_r2 = 2;
								logger_events.port = port_save;	/* indica a porta anterior */
								write_logger(logger->target_port,"LOGGER (%d) SINALIZACAO INVERTIDA. CORRIGINDO",logger_events.port);
							}
							seizure_timeout = 0;
							break;
						case R2_SEIZURE_ACK:
							//receber a confirma�o qdo est�livre pode ser um sinal de R2D invertido
							//devido �concorrencia das thread
							//Neste caso ser�setado um timeout. Se logo em seguida chagar a ocupa�o
							//a thread entender�que a confirma�o tb ja chegou
							seizure_timeout = digivoice_gettick();
							port_save = logger_events.port;
							break;
						
						case 0:

						break;

						default:
                            //AA disable MF detection
   							dg_SetDetectionType(logger->port2,DETECT_ALL_MF, DG_DISABLE);
							dg_SetDetectionType(logger->target_port,DETECT_ALL_MF, DG_DISABLE);
							mfc_step = P_MFC_REPOUSO;
							r2_step = P_R2_LIVRE;
							line_state=OFF;

							write_logger(logger->target_port,"LOGGER (%d) P_R2_LIVRE->default de valor %x",logger_events.port,r2i);
							break;
					}//switch
					break;
				case P_R2_CONFIRMAOCUPACAO:
					switch(r2i)
					{
						case R2_SEIZURE_ACK:
							write_logger(logger->target_port,"LOGGER (%d) P_R2_CONFIRMAOCUPACAO->R2_SEIZURE_ACK %x",logger_events.port,r2i);
							//canal x recebeu ocupacao e em x+30 a confirmacao de ocupacao
//							if (logger->calltype == INCOMINGCALL && (dg_GetRelativeChannelNumber(logger_events.port) > HALF_CHANNELS) )
//							{
//								//event coming from port N + 30
//
//								//enable MF detections
//								dg_SetDetectionType(logger->target_port,DETECT_OFF, DG_ENABLE);
//								dg_SetDetectionType(logger->target_port,DETECT_MFF, DG_ENABLE);
//
//								dg_SetDetectionType(logger_events.port,DETECT_OFF, DG_ENABLE);
//								dg_SetDetectionType(logger_events.port,DETECT_MFT, DG_ENABLE);
//
//								r2_step=P_R2_RECEBENDO_MFC;
//								logger->rx_number_of_digits = 0;
//								logger->rx_complete_count = 0;
//								mfc_step = P_MFC_ESPERA_MF;
//							}
//							else
//								//canal x+30 recebeu ocupacao e em x a confirmacao de ocupacao
//								if (logger->calltype == OUTGOINGCALL && (dg_GetRelativeChannelNumber(logger_events.port) <= HALF_CHANNELS) )
//								{
//									//enable MF detections for outgoing calls
//									dg_SetDetectionType(logger->port2,DETECT_OFF, DG_ENABLE);
//									dg_SetDetectionType(logger->port2,DETECT_MFF, DG_ENABLE);
//
//									dg_SetDetectionType(logger_events.port,DETECT_OFF, DG_ENABLE);
//									dg_SetDetectionType(logger_events.port,DETECT_MFT, DG_ENABLE);
//									r2_step=P_R2_RECEBENDO_MFC;
//									logger->rx_number_of_digits = 0;
//									logger->rx_complete_count = 0;
//									mfc_step = P_MFC_ESPERA_MF;
//								}
//								else
//								{
//									//caso improvavel..verificar
//
//								}
//							r2i = 0;
//							a5=OFF;
//							rx_group_b = 0;
//							rx_group_ii = 0;
                            //AA
							r2_step=P_R2_RECEBENDO_MFC;
							break;

						case 0:

						break;

						default:
                            //AA disable MF detection
   							dg_SetDetectionType(logger->port2,DETECT_ALL_MF, DG_DISABLE);
							dg_SetDetectionType(logger->target_port,DETECT_ALL_MF, DG_DISABLE);
							mfc_step = P_MFC_REPOUSO;
							r2_step = P_R2_LIVRE;
							line_state=OFF;

							//nao gera evento??
							write_logger(logger->target_port,"LOGGER (%d) P_R2_CONFIRMAOCUPACAO->default %x",logger_events.port,r2i);
							break;

					}
					break;
				case P_R2_RECEBENDO_MFC: //ligacao entrante
					switch(r2i)
					{
						case R2_ANSWERED:
							write_logger(logger->target_port,"LOGGER (%d) P_R2_RECEBENDO_MFC->R2_ANSWERED",logger_events.port);
							//disable MF detection
							dg_SetDetectionType(logger->target_port , DETECT_ALL_MF, DG_DISABLE);
							dg_SetDetectionType(logger->port2 , DETECT_ALL_MF, DG_DISABLE);
							//enable mixer
							dg_SetPortChatLog(logger->target_port ,logger->chat_handle,1);
							dg_SetPortChatLog(logger->port2,logger->chat_handle,1);
							//enable ports to listen
							dg_ChatEnablePort(logger->chat_handle,logger->target_port,CHAT_LISTEN);
							dg_ChatEnablePort(logger->chat_handle,logger->port2  ,CHAT_LISTEN);
							
							dg_SetSilenceThreshold(logger->target_port,logger->silence_threshold_after_signaling );
							dg_SetSilenceThreshold(logger->port2,logger->silence_threshold_after_signaling );
							//enable agc
							//TODO : retirado paleativamente ate fazer novo AGC
							//para v4.0
							//..dg_EnableAgc(logger->target_port);
							//..dg_EnableAgc(logger->port2 );
							//raise both events
							RaiseEvents_ThreadSafe(EV_LINEREADY, 0,  0,logger->target_port ,&port_mutex[logger->target_port-1]);
							RaiseEvents_ThreadSafe(EV_LOGGEREVENT, LOGGER_LINEREADY,  0,logger->target_port ,&port_mutex[logger->target_port-1]);
							line_state=ON;
							r2_step = P_R2_LIGACAOEMCURSO;
							mfc_step = P_MFC_REPOUSO;
							break;
						case R2_IDLE:
							write_logger(logger->target_port,"LOGGER (%d) P_R2_RECEBENDO_MFC->R2_IDLE",logger_events.port);
                            //AA disable MF detection
   							dg_SetDetectionType(logger->port2,DETECT_ALL_MF, DG_DISABLE);
							dg_SetDetectionType(logger->target_port,DETECT_ALL_MF, DG_DISABLE);
							line_state=OFF;
							r2_step = P_R2_LIVRE;
							mfc_step = P_MFC_REPOUSO;
							break;
					}
					break;
				case P_R2_LIGACAOEMCURSO:
					switch(r2i)
					{
						case R2_IDLE:
							if (line_state==ON)
							{

								line_state=OFF;
								//gera evento de fim de ligacao
								r2_step = P_R2_LIVRE;

								//desabilita portas da conferencia e do mixer
								dg_ChatDisablePort(logger->chat_handle, logger->port2);
								dg_ChatDisablePort(logger->chat_handle, logger->target_port);

								dg_SetPortChatLog(logger->port2,logger->chat_handle,0);
								dg_SetPortChatLog(logger->target_port,logger->chat_handle,0);

								//dg_DisableAgc(logger->target_port);
								//dg_DisableAgc(logger->port2);

								//raise both events to app
								RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,logger->target_port ,&port_mutex[logger->target_port-1]);
								RaiseEvents_ThreadSafe(EV_LOGGEREVENT, LOGGER_LINEOFF,  0,logger->target_port,&port_mutex[logger->target_port-1]);
								write_logger(logger->target_port,"LINEOFF->P_R2_LIGACAOEMCURSO->r2_IDLE");
							}
							break;
						case R2_CLEAR_BACK:
							//GERA EVENTO PARA A APLICACAO
							RaiseEvents_ThreadSafe(EV_LOGGEREVENT, LOGGER_B_ENDCALL,  0,logger->target_port,&port_mutex[logger->target_port-1]);
							write_logger(logger->target_port,"LOGGER (%d) P_R2_LIGACAOEMCURSO->R2_CLEAR_BACK",logger_events.port);
							break;
						case R2_ANSWERED:
							//Atendimento duranta ligacao significa que B desligou para tras e depois voltou
							RaiseEvents_ThreadSafe(EV_LOGGEREVENT, LOGGER_B_RETURN,  0,logger->target_port,&port_mutex[logger->target_port-1]);
							write_logger(logger->target_port,"LOGGER (%d) P_R2_LIGACAOEMCURSO->R2_ANSWERED",logger_events.port);
							break;
					}
					r2i = 0;
					break;
			} //switch (r2_step)
			trata_r2--;
		} //fim do while

		switch (mfc_step)
		{
			case P_MFC_REPOUSO:

				break;
			case P_MFC_ESPERA_MF:

				if (mf_type == MFF)
				{
					if ((mfci>=1)&&(mfci<=15))
					{
					write_logger(logger->target_port,"LOGGER (%d) P_MFC_ESPERA_MFF->%d",logger_events.port,mfci);
						if (logger->rx_number_of_digits==0)		//first I-n
						{
							grupo_a =0;
							logger->rx_digits[logger->rx_number_of_digits++] = mfci;
							logger->rx_digits[logger->rx_number_of_digits] = 0; //finalizador de string
							//guarda numero rx - GetE1Number
							logger->rx_complete_digits[logger->rx_complete_count++] = mfci;
							logger->rx_complete_digits[logger->rx_complete_count] = 0; //finalizador de string

						}
						else
						{

							switch(grupo_a)
							{
								case 1:
									logger->rx_digits[logger->rx_number_of_digits++] = mfci;
									logger->rx_digits[logger->rx_number_of_digits] = 0; //finalizador de string
									//guarda numero rx - GetE1Number
									logger->rx_complete_digits[logger->rx_complete_count++] = mfci;
									logger->rx_complete_digits[logger->rx_complete_count] = 0; //finalizador de string

									break;
								case 3:
									rx_group_ii = mfci;
									
									break;
								case 5:
									if (a5==OFF)
									{
										//primeiro A-5
										a5 = ON;
										logger->rx_id_number_of_digits = 0;
									}
									if (mfci<11)    //fim de numero(15) ou indisponivel(12) - qquer coisa > 11 
									{
										logger->rx_id_digits[logger->rx_id_number_of_digits++] = mfci;
										logger->rx_id_digits[logger->rx_id_number_of_digits] = 0;
									}
									else
									{
										//fim de numero - gera evento
										RaiseEvents_ThreadSafe(EV_CALLERID, logger->rx_id_number_of_digits ,  0,logger->target_port,&port_mutex[logger->target_port-1]);

									}
									break;
								case 6: case 10: case 11:
								case 12: case 13: case 14:case 15:	//alimenta variavel de rx_grupo_i
									rx_group_i = mfci;
									break;
										

							}
						}
					}
				} //MFF
				else
				{
					//tratamento MFT
					if ((mfci>=1)&&(mfci<=15))
					{

					write_logger(logger->target_port,"LOGGER (%d) P_MFC_ESPERA_MFT->%d",logger_events.port,mfci);
						if (rx_group_ii > 0)
						{
							//recebeu rx_group_b
							rx_group_b=mfci;
							mfc_step = P_MFC_ESPERA_FIM_MF;
						}
						else
						{
							switch(mfci)
							{
								case 1:			//A-1
									a5=OFF;
									grupo_a = 1;
									break;
								case 2://pede primeiro digito
									a5=OFF;
									logger->rx_number_of_digits = 0;
									break;
								case 3:			//A-3
									grupo_a = 3;
									a5=OFF;
									break;
								case 4://CONGESTIONAMENTO
									mfc_step=P_MFC_FIM;


									a5=OFF;
									break;
								case 5:			//A-5
									grupo_a = 5;
									break;
								case 7:
									logger->rx_number_of_digits-=2;
									a5=OFF;
									if (logger->rx_number_of_digits<0)logger->rx_number_of_digits=0;
									grupo_a = 1;
									break;
								case 8:
									logger->rx_number_of_digits-=3;
									if (logger->rx_number_of_digits<0)logger->rx_number_of_digits=0;
									a5=OFF;
									grupo_a = 1;
									break;
								case 9:
									logger->rx_number_of_digits-=1;
									if (logger->rx_number_of_digits<0)logger->rx_number_of_digits=0;
									grupo_a = 1;
									a5=OFF;
									break;
								case 6: case 10: case 11:
								case 12: case 13: case 14:case 15:
									mfc_step=P_MFC_RECEBE_GRUPO_I;
									grupo_a = 1;
									a5=OFF;
									break;
							} //switch(mfci)
						} //else do rx_group_ii
					}
				} //MFT
				break;
			case P_MFC_ESPERA_FIM_MF:
				if (mfci>15)
				{
					if (grupo_a == 4)
					{
						//evento de congestionamento
						//mandar grupo_a
						RaiseEvents_ThreadSafe(EV_LOGGEREVENT, grupo_a ,  0,logger->target_port,&port_mutex[logger->target_port-1]);
					}
					else
					{
						//gera evento de fim MF
						//situa�o ap� a troca de sinaliza�o, mas antes do atendimento
						//.....tem q mandar o grupo_b no evento
						write_logger(logger->target_port,"LOGGER (%d) P_MFC_ESPERA_FIM_MF->EV_LOGGEREVENT-> antes de atender antes do evento",logger_events.port);
						RaiseEvents_ThreadSafe(EV_LOGGEREVENT, rx_group_b ,  0,logger->target_port,&port_mutex[logger->target_port-1]);
						write_logger(logger->target_port,"LOGGER (%d) P_MFC_ESPERA_FIM_MF->EV_LOGGEREVENT-> antes de atender depois do evento",logger_events.port);
					}
					mfc_step = P_MFC_REPOUSO;
				}
				break;
		} //switch (mfc_step)

	} //fim while(1)

	//generate events to allow stop recording
	RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,logger->target_port ,&port_mutex[logger->target_port-1]);
	RaiseEvents_ThreadSafe(EV_LOGGEREVENT, LOGGER_LINEOFF,  0,logger->target_port,&port_mutex[logger->target_port-1]);


	//destroi conferencias
	write_logger(logger->target_port,"Logger -> thread finalizada!");

	//ports_info[logger->target_port-1].card_channel = card_channel;	
	card = ports_info[logger->target_port-1].card;

	//desliga chat
	dg_ChatRemovePort(logger->chat_handle,logger->target_port);
	dg_ChatRemovePort(logger->chat_handle,logger->port2);
	dg_DestroyChatRoom(card,logger->chat_handle);

#ifdef __LINUX__
	close(ports_info[logger->target_port-1].fifo_to_logger);


	close(fifo_rx);
#else
	//destroi os eventos
	CloseHandle(logger->LoggerEvent.hEvent);
#endif
	logger->thread_running=0;
	logger->thread_id = 0;	
}



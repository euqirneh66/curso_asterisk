
/************************************************************************************
 *                                                                                  *
 *   VoicerLib - Windows/Linux Version                                              *
 *                                                                                  *
 *   Copyright (c) 2004-2015 DigiVoice Tecnologia em Eletronica Ltda                *
 *                                                                                  *
 *   Module:  Main module                                                           *
 *                                                                                  *
 *   Description: Implements exposed functions                                      *
 *                                                                                  *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                                  *
 *   This library is free software; you can redistribute it and/or                  *
 *   modify it under the terms of the GNU Lesser General Public                     *
 *   License as published by the Free Software Foundation; either                   *
 *   version 2.1 of the License, or (at your option) any later version.             *
 *                                                                                  *
 *   This library is distributed in the hope that it will be useful,                *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of                 *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU               *
 *   Lesser General Public License for more details.                                *
 *                                                                                  *
 *   You should have received a copy of the GNU Lesser General Public               *
 *   License along with this library; if not, write to the Free Software            *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *  
 *                                                                                  *
 ************************************************************************************

 Changelog
 ---------

versao 4.2.5.6_rc5 - 27/07/2015 - 06/08/2015 - Linux

        - Corrido erro de "critical section" ao receber um evento ERROR_UART_FIFO_FULL
          em um canal GSM;
        - Alteracao do padrao de timeout para discagem GSM, o timeout foi definido em
          100 segundos (90s Anatel + 10s timeout);
        - Tratamento dos dois eventos de resposta ao enviar um SMS (+CMGS e OK);



versao 4.2.5.6_rc4 - 23/07/2015 - 23/07/2015 - Linux

        - Corrigida falha na maquina de estados de envio de SMS;



versao 4.2.5.6_rc3 - 09/07/2015 - 14/07/2015 - Linux

        - Aprimorado o erro de ERROR_UART_FIFO_FULL;



versao 4.2.5.6_rc2 - 23/04/2015 - 27/05/2015 - Linux

        - Alteracao na rotina de dg_DestroyGSMThread, implementado desligamento
          do modulo GSM antes da finalizacao da respectiva thread de controle;
        - Criado tratamento de erro de FIFO cheia em placas GSM, ao recebermos
          o evento ERROR_UART_FIFO_FULL da placa geramos um EV_GSMERROR para a
          aplicacao. Neste caso a mesma deve iniciar o processo de restart do canal;
          Obs.: Para esta alteracao o firmware da placa GSM (vb02.i00) foi
                atualizado para a versão 4Ch;



versao 4.2.5.6_rc1 - 05/03/2015 - 20/03/2015 - Linux

        - Tratamento de todas as excecoes e erros possiveis na maquina de estado GSM;
        - Implementacao de temporizador na thread GSM para que seja permitido o uso
          da rotina dg_GSMClearAllSMS somente apos 30 segundos da inicializacao de um
          canal GSM;
        - Criada rotina para recuperar a qualidade da chamada de um canal GSM:
        IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetCallQuality(short port, char *szMessage);



versao 4.2.5.5 - 05/01/2015 - 23/01/2015 - Linux

        - Versao final contendo todas as implementacoes das versoes
          4.2.5.5_rc1 e 4.2.5.5_rc2;
        - Criada rotina para habilitar ou desabilitar os logs para debug GSM:
        	IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableGSMDebug(void);
        	IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableGSMDebug(void);



versao 4.2.5.5_rc2 - 01/10/2014 - 30/12/2014 - Linux

        - VoicerLib preparada para funcionamento com placas DGV_2E1F e DGV_1E1F;
        - VoicerLib preparada para funcionamento com os novos modulos mc55i-w para
          placas VB0404GSM;



versao 4.2.5.5_rc1 - 25/09/2014 - 29/09/2014 - Linux

        - Criada funcao dg_ReadIRQNumber(short wCard, char *wData), esta funcao
          permite verificar o numero da IRQ utilizada por uma determinada placa
          (somente para sistemas operacionais Linux);



versao 4.2.5.4 - 25/08/2014 - 01/09/2014 - Linux

        - Implementacoes na thread GSM, quando recebermos determinados erros do
          comando ATD geramos o evento *EV_BUSY* setando o segundo parametro
          com um codigo para cada erro, onde este erro pode ser tratado pela
          aplicacao que chamou o comando *dg_Dial(...)*.
          Abaixo temos uma tabela de relacionamento destes erros:
             | * GSM MSG * | APP CAUSE |
             | NO CARRIER  | 404       |
             | BUSY        | 486       |
             | NO DIALTONE | 503       |
        - Correcao na thread GSM ao enviar o comando para habilitar ou
          desabilitar o recebimento de segunda chamada;



versao 4.2.5.3 - 16/06/2014 - 16/06/2014 - Linux

        - Correcoes na thread GSM, quando o modulo estivesse em seu limite de
          armazenamento de SMS o mesmo gera um ERRO de leitura. Este erro
          estava sendo interpretado de forma incorreta, impossibilitando que o
          modulo recebesse novas mensagens SMS;
        - Versao final contendo todas as implementacoes da versao
          4.2.5.3_rc1;



versao 4.2.5.3_rc1 - 28/04/2014 - 28/04/2014 - Linux

        - Implementacoes para Kernel superior a 3.11.x;



versao 4.2.5.2 - 10/02/2014 - 20/02/2014 - Linux

        - Alteracao na thread GSM permitindo o envio de mensagens SMS de Classe 0,
          tambem conhecida como FlashSMS:
          dg_ConfigGSMThread(PORT, GSMCFG_FLASHSMS_ENABLE, 0/1);
        - Alteracao na thread GSM permitindo o recebimento de mensagens USSD,
          atraves do evento EV_GSMUSSDRECEIVED;
        - Novo metodo criado para recuperar a mensagem USSD recebida:
          dg_GSMGetUSSD(short port, char *szMessage);
        - Correcoes nos metodos utilizados pela thread de PlaySignalThread;
        - Consistencias na rotina de vlib_release;
        - Alterado vlibd.init para executar o stop em modo 0, 1 e 6;



versao 4.2.5.1 - 27/08/2013 - 27/08/2013 - Linux

        - Versao final contendo todas as implementacoes das versoes
          4.2.5.1_rc1 e 4.2.5.1_rc2;



versao 4.2.5.1_rc2 - 06/08/2013 - 19/08/2013 - Linux

        - Alteracoes no tamanho dos dados enviados ao HW em modo CCS;



versao 4.2.5.1_rc1 - 22/07/2013 - 22/07/2013 - Linux

        - Implementacoes para Kernel superior a 3.6.x;



versao 4.2.5.0 - 07/05/2013 - 24/05/2013 - Linux

        - Alteracoes no tamanho das FIFO's e tamanho dos DADOS utilizados em modo CCS;



versao 4.2.5.0_rc3 - 01/04/2013 - 17/04/2013 - Linux

        - Melhorias e correcoes nas rotinas de envio e recebimento de SMS;



versao 4.2.5.0_rc2 - 08/10/2012 - 09/10/2012 - Linux

        - Melhorias e correcoes nas rotinas dg_WriteCode, dg_CheckCode e dg_ReadCode;



versao 4.2.5.0_rc1 - 03/09/2012 - 11/09/2012 - Linux

        - Implementacoes para Kernel 3.x;



versao 4.2.4.0 - 10/03/2011 - 29/07/2011 - Linux

        - Implementacao de dois novos eventos gerados pela VoicerLib,
          EV_FAX_CNG e EV_FAX_CED;
        - Melhoria nas rotinas executadas no durante o dg_ShutdownVoicerlib,
          pois algumas threads poderiam ficar travadas aguardando um retorno do
          comando de read executado no driver;
        - Melhorias na maquina de estado de controle de canais GSM;
        - Remocao das rotinas do driver utilizadas por placas antigas;
        - Implementacao do novo metodo ioctl para versoes de kernel superiores
          a 2.6.36 (32 e 64 bits);



versao 4.2.3.0 - 24/03/2010 - 01/12/2010 - Linux

        - Versao final contendo todas as implementacoes desde a versao
          4.2.3.0_rc1 ate a versao 4.2.3.0_rc13;



versao 4.2.3.0_rc13 - 11/11/2010 - 19/11/2010 - Linux

        - Criado exemplo MonitorDeSinal, com este exemplo eh possivel testar a
          frequencia de uma linha telefonica, ou mesmo medir a cadencia de tom
          de ocupado, chamando etc;
        - Para melhorar a eficiencia de processamento do cancelador de eco via
          software, foi implementado no Makefile do driver alguns parametros
          para otimizacao das rotinas de cancelamento de eco;



versao 4.2.3.0_rc12 - 13/10/2010 - 15/10/2010 - Linux

        - Redefinicao dos ganhos de entrada do audio no cancelador de eco via
          software;
        - Melhorias para o cancelador de eco via hardware em placas VB0404GSM;



versao 4.2.3.0_rc11 - 28/09/2010 - 29/09/2010 - Linux

        - Problema de alocacao de cancelador de eco via software corrigido
          para Linux (problema apresentado em ambiente CentOS);



versao 4.2.3.0_rc10 - 27/09/2010 - 28/09/2010 - Linux

        - Logs no driver linux melhorados;
        - Logs na voicerlib retirados;



versao 4.2.3.0_rc9 - 02/09/2010 - 22/09/2010 - Linux

        - Alteracao da funcao dg_EnableEchoCancelation, agora podemos habilitar
          dois tipos de cancelador de echo, o cancelador via hardware (padrao)
          e o cancelador de echo via software. O define de K_ECHO deve estar
          habilitado para que um novo parametro possa ser recebido. Outra
          Alteracao para o cancelador eh que sera mantido o cancelador de echo
          antigo para placas E1, somente para as placas GSM, FX e FXO sera
          mantido o firmware mais novo onde eh possivel ter 2 filtros
          simultaneos;



versao 4.2.3.0_rc8 - 05/07/2010 - 01/09/2010 - Linux

        - Inumeras alteracoes para melhorar a performance em links ISDN;



versao 4.2.3.0_rc7 - 06/07/2010 - 07/07/2010

		- Alteracoes na funcao gsm_delayed e no timeout da placa GSM: nRunGsm = 1;
		- Nao manda como default a confirmacao de envio/recebimento de SMS;



versao 4.2.3.0_rc6 - 21/06/2010 - 23/06/2010

        - Atualizacao de firmware para todas as placas com um novo cancelador de echo:
          VBE16060PCI                (e05.i00) : Versao 0x37e,
          VBE16060PCI_R + VB6060PCIE (e06.i00) : Versao 0x37e,
          VBE13030PCI   + VB3030PCIE (e07.i00) : Versao 0x138,
          VB0408PCI     + VB0408PCIE (vb00.i00): Versao 0x28a,
          VB0404FX      + VB0404FX_R (vb01.i00): Versao 0x26c,
          VB0404GSM                  (vb02.i00): Versao 0x4a;
        - Alteracao da funcao dg_EnableEchoCancelation, foi retirado o parametro training,
          nao necessario nesta nova versao de cancelador de echo;



versao 4.2.3.0_rc5 - 14/06/2010 - 14/06/2010

        - Merge entre a versao da VoicerLib Linux e Windows;



versao 4.2.3.0_rc4 - 26/05/2010 - 14/06/2010 - Linux

        - Criado flag thread_ready para controlar se a thread GSM esta pronta
          para receber comandos;
        - Alteracao da funcao dg_EnableEchoCancelation, agora podemos passar um
          novo parametro nlp(no linear processor), este novo parametro pode
          receber os seguintes valores: 0=DESABLED, 1=MUTE, 2=CLIP ou 3=CNG(Padrao);



versao 4.2.3.0_rc3 - 05/05/2010 - 17/05/2010 - Windows

	- Alteracao na funcao: dg_SetE1CRC4Option;
	- Alteracao na funcao: Call_Progress_Thread, quando a opcao for nAnswerSensibility = 0
	  o evento de OnAnswerDetected sera gerado;
	- Correcao: Em uma ligacao que ocorre falha a proxima ligacao nao se perde mais;



versao 4.2.3.0_rc2 - 06/04/2010 - 09/04/2010

	- Merge entre a versao da VoicerLib Linux e Windows;



versao 4.2.3.0_rc1 - 24/03/2010 - 24/03/2010 - Linux

        - Upgrade da versao de firmware para placas VB0404FX (226h);
        - Alteracao dos tamanhos dos buffers utilizados pelo ISDN;



versao 4.2.2.0_rc84 - 01/04/2010 - 06/04/2010

	- Incluido tratamento de entrada/saida de chip: AT^SCKS
	- Incluida funcao dg_GSMGetSMSConfirmation 
	- Incluido evento OnGSMSMSConfirmation(EV_GSMCONFIRMATION)
	- Incluido evento OnGSMSIM que avisa quando o SIM Card foi inserido ou retirado do modulo GSM
	- Correcao na rotina de recebimento de mensagem SMS, (CMTI e CMGR) nao manda direto para o step SMS2
	  	

versao 4.2.2.0_rc83 - 16/03/2010 - 18/03/2010
	
	- Adicionada configuracoes: CPCFG_GENERICFREQ5
	- Correcao na funcao dg_CreateCallProgress, nao funcionava: TONE5, TONE6, TONE7 e TONE8
	- Alteracao e inclusao de nova configuracao no cp_default.cfg: GenericToneFreq5

versao 4.2.2.0_rc82 - 08/03/2010 - 11/03/2010

	- Alteracao no metodo EnableMailBoxDetection, incluso novo parametro silencetime de tempo de silencio
	- Correcao na funcao dg_GetAlarmStatus, antes sempre fazia um for com todas as placas
	- Melhoria na funcao HandleSilence: comentado o tempo de silencio (ports_info[port-1].silence.silence_time =2000)

versao 4.2.2.0_rc81 - 02/03/2010 - 02/03/2010

	- A constante ALARM_RESERVED foi renomeada para ALARM_CRC4SYNC

versao 4.2.2.0_rc8 - 10/02/2010 - 24/02/2010

	- Incluidos os metodos EnableMailBoxDetection e DisableMailBoxDetection.
	- Incluido o evento OnMailBoxDetected.
	- Modificacao na thread de CallProgress: Alteracao na estrutura cp->nToneType que possuia 10 posicoes
	e agora possui 15 posicoes. 
	Inclusa constantes: T_GTONE2, T_GTONE3 e T_GTONE4.
	Alteracao e inclusao de novas configuracoes no cp_default.cfg: GenericToneFreq, GenericToneFreq2, GenericToneFreq3 e
	GenericToneFreq4 todas referentes ao CP_TONE4.


versao 4.2.2.0_rc7 - 26/01/2010 - 26/01/2010

	- Correcao no driver, incluso #define VISTA para reconhecer as placas com o codigo
	novo.

versao 4.2.2.0_rc6 - 21/12/2009 - 04/01/2010

	- Inclusao das funcoes: dg_ConnectAudioChannels, dg_DisconnectAudioChannels 
	e dg_ConnectAudioCallback
	- Alteracoes e validacoes no driver em windows



versao 4.2.2.0 - 08/10/2009 - 06/01/2010 - Linux

        - Versao final contendo todas as implementacoes das versoes:
          4.2.2.0_rc1, 4.2.2.0_rc2, 4.2.2.0_rc3, 4.2.2.0_rc4, 4.2.2.0_rc5,
          4.2.2.0_rc6, 4.2.2.0_rc7 e 4.2.2.0_rc8;
        - Adicionado definicao do tipo da interface (FXS/FXO) na estrutura de
          portas (ports_info) ao chamar a funcao dg_SetFXCardType;



versao 4.2.2.0_rc8 - 02/12/2009 - 02/12/2009 - Linux

        - Upgrade da versao de firmware para placas VB0404FX (224h);



versao 4.2.2.0_rc7 - 16/11/2009 - 16/11/2009 - Linux

        - Removido criticalsection da rotina dg_InsertCPFifo;



versao 4.2.2.0_rc6 - 13/11/2009 - 13/11/2009 - Linux

        - Criacao de variavel group_i_end_of_ani para a thread R2, esta
          variavel pode assumir o valor 12 ou 15, para sinalizacao
          R2_COUNTRY_AR ou R2_COUNTRY_BR respectivamente;



versao 4.2.2.0_rc5 - 06/11/2009 - 09/11/2009 - Linux

        - Implementacao de dg_GetLibVersion tambem para Linux;
        - Novo firmware para placas VB0404GSM (0x40);
        - Aumentado tempo para leitura da quantidade de canais para placas
        VB0404GSM;



versao 4.2.2.0_rc4 - 28/10/2009 - 28/10/2009 - Linux

        - Melhorias no tratamento de timeout na thread GSM;



versao 4.2.2.0_rc3 - 23/10/2009 - 26/10/2009 - Linux

        - Upgrade da versao de firmware para placas VB0404GSM (38h);
        - Tratamento de evento "NO DIALTONE" na thread GSM;



versao 4.2.2.0_rc2 - 21/10/2009 - 21/10/2009

	- Correcao na thread e1 ao solicitar o cid apos receber todos os digitos
	  de did;


versao 4.2.2.0_rc1 - 08/10/2009 - 15/10/2009

	- Correcao na rotina dg_GSMSetPinNumber para placas GSM;
	- Correcao de possivel deadlock na rotina dg_PickUp e dg_HangUp, apenas
	  em placas GSM;



versao 4.2.1.0 - 17/08/2009 - 30/09/2009

	- dg_GetLibVersion: Esta funcao permite verificar a versao dos arquivos
	  da voicerlib ocx e dll;
	- Novo evento OnCallProgressTimeout;
	- Correcao no evento de OnCallerID que era gerado duas vezes;
	- Constante MAX_CHANNELS estava 360, aumentou para 600;
	- Versao final contendo todas as implementacoes das versoes:
	  4.2.1.0_rc1, 4.2.1.0_rc2, 4.2.1.0_rc3;



versao 4.2.1.0_rc3 - 31/08/2009 - 02/09/2009

	- Correcao na leitura dos arquivos de callprogress;
	- Incluso nova funcao GetNameID (somente para FSK);
	- Incluso tratamento de C_UART3;
	- Incluso o tipo de retorno DG_ERROR_SERIAL_FAILURE para o erro 4096;
	- Criacao da estrutura fsk_info por porta;



versao 4.2.1.0_rc2 - 21/08/2009 - 27/08/2009

	- Alteracao na thread de R2 para pertimir a solicitacao do CID apos receber
	  todos os MFs de DID;
	- Merge entre versao Windows E Linux;
	- Criada funcao dg_EnableFSKDetection;



versao 4.2.1.0_rc1 - 17/08/2009 - 17/08/2009

	- Incluso no arquivo vbgsm.c mais um estado GSM_SYSSTART;
	
	

versao 4.2.0.0_rc8 - 05/08/2009 - 05/08/2009

	- Na funcao EnableCallProgress incluso DisableCallProgress, ou seja, sempre
	  antes de habilitar a supervisao de linha, desabilito primeiro. A mesma
	  coisa com a funcao EnableSilenceDetected;
	
	

versao 4.2.0.0_rc7 - 28/07/2009 - 31/07/2009

	- Alteracao na thread de GSM, inclusa opcao de configuracao
	  GSMCFG_RETRY_TIMEOUT na funcao dg_ConfigGSMThread. Permite restartar a
	  thread com um determinado tempo;
	
	

versao 4.2.0.0_rc6 - 28/07/2009 - 28/07/2009

	- Alteracao na thread de GSM, inclusa opcao de configuracao na funcao
	  dg_ConfigGSMThread, a funcao pode ser utilizada antes da inicializacao da
	  thread GSM;
	
	

versao 4.2.0.0_rc5 - 17/07/2009 - 28/07/2009

	- Alteracao na thread de GSM, correcoes de erros e criacao de buffer de
	  recebimento;
	
	

versao 4.2.0.0_rc4 - 14/07/2009 - 17/07/2009

	- Alteracao na thread de GSM para evitar envio de comando durante o
	  recebimento de SMS com consequente travamento no modulo GSM;
	
	

versao 4.2.0.0_rc3 - 07/07/2009 - 14/07/2009

	- Upgrade das versoes de firmware (todas as placas);
	- Melhorias nas rotinas de inicializacao das placas VB0404GSM;
	- Implementacao de reset para placas VB0404GSM;
	- CCS_DATA_SIZE changed to 256 (KERNEL >= 2.6.26);



versao 4.2.0.0_rc2 - 03/04/2009 - 03/04/2009
	- Implementacao de funcao dg_WriteFXTypeCode(short Port, short Type);
	- Downgrade das versoes de firmware;



versao 4.2.0.0_rc1 - 18/01/2009 - 06/04/2009

	- Correcao de gravacao utilizando formato ffWave49;
	- Implementacoes e Adaptacoes na VoicerLib para funcionamento com a placa
	  VB0404GSM, incluimos as seguintes funcoes(para maiores informacoes de
      como utiliza-las acesse o Guia do Programador):
        dg_CreateGSMThread(short port),
        dg_DestroyGSMThread(short port),
        dg_ConfigGSMThread(short port, short command, int value),
        dg_EnableGSMThread(short port),
        dg_DisableGSMThread(short port),
        dg_GSMGetSMS(short port, char *szMessage),
        dg_GSMSendCommand(short port, char *szCommand),
        dg_GSMGetMessage(short port, char *szMessage),
        dg_GSMSetPinNumber(short port, char *szPIN, char *szNewPIN),
        dg_GSMSendSMS(short port, char *szNumber, char *szMessage),
        dg_GSMCheckSignalQuality(short port),
        dg_GSMGetSignalQuality(short port, char *szMessage),
        dg_GSMGetIndexList(short port, char *szMessage),
        dg_GSMRestartPort(short port),
        dg_GSMDeleteSMS(short port, short index),
        dg_GSMReadAndDeleteSMS(short port, short index),
        dg_GSMListSMS(short port, short status),
        dg_GSMClearAllSMS(short port),
        dg_GSMCallControl(short port, short command, short call);



versao 4.1.0.3 - 16/10/2008 - 06/01/2009

	- Versao final contendo todas as implementacoes das versoes:
	  4.1.0.3_rc1, 4.1.0.3_rc2, 4.1.0.3_rc3, 4.1.0.3_rc4 e 4.1.0.3_rc5 - Linux;



versao 4.1.0.3_rc5 - 25/11/2008 - 25/11/2008

	- Alterado tamanho do buffer de audio(WRITE_BUFFER_LINES) utilizado no
	  PlayBuffer;



versao 4.1.0.3_rc4 - 14/11/2008 - 14/11/2008

	- Alteracao na thread E1, foi adicionado deteccao de A_6 pulsado para
	  sinalizacao Argentina;
	  
	  

versao 4.1.0.3_rc3 - 12/11/2008 - 12/11/2008

	- Alteracao na thread E1, foi adicionado deteccao de fim de numero ao
	  terminar de receber o dnis;



versao 4.1.0.3_rc2 - 23/10/2008 - 31/10/2008

	- Implementacoes para uso do dahdi;
	- Correcao na funcao dg_CreateLoggerControl para linux;



versao 4.1.0.3_rc1 - 16/10/2008 - 17/10/2008

	- Alteracoes para recebimento de A_6(Argentina);



versao 4.1.0.2 - 29/08/2008 - 29/08/2008

	- Alterada macro de mutex debug;



versao 4.1.0.1 - 25/08/2008 - 28/08/2008

	- Criado nova funcao para setar na placa VB0404FX_R a impedancia
	  (apenas para interfaces do tipo FXO), a funcao tem o nome de 
	  SetFXCardImpedance e para acessa-la eh necessario passar os parametros
	  de porta e a impedancia(600 ou 900 ohms) - FirmWare ainda nao disponivel;



versao 4.1.0.0 - 16/05/2008 - 04/08/2008

	- Versao final contendo todas as implementacoes das versoes:
	  4.1.0.0_rc1, 4.1.0.0_rc2, 4.1.0.0_rc3, 4.1.0.0_rc4 e 4.1.0.0_rc5 - Linux;
	- Adicionado mutex debug;



versao 4.1.0.0_rc5 - 09/07/2008 - 11/07/2008

	- Alterado rotina de pesquisa de placas PCI e/ou PCIe;



versao 4.1.0.0_rc4 - 04/07/2008 - 07/07/2008

	- Alterado KERNEL_WRITE e memcpy_toio para gsm write;



versao 4.1.0.0_rc3 - 16/06/2008 - 19/06/2008

	- Implementado dg_ResetError ao receber C_ERROR da placa;
	- Implementado debug mais aprimorado entre o USERMODE e o KERNELMODE, 
	  dg_SetVerboseLevel(short card, short level);



versao 4.1.0.0_rc2 - 02/06/2008 - 05/06/2008

	- Implementacoes para PCIe;



versao 4.1.0.0_rc1 - 16/05/2008 - 16/05/2008

	- Resolvido problema de StartVoicerLib apos crash do asterisk;



 versao 4.0.9.9 - 27/02/2008 - 30/04/2008

	- Versao final contendo todas as implementacoes das versoes:
	  4.0.9.9_rc1, 4.0.9.9_rc2, 4.0.9.9_rc3 e 4.0.9.9_rc6 - Linux,
	  4.0.9.9_rc4 e 4.0.9.9_rc5 - Windows;
	- Alteracoes na thread de idle(idle.c), adicionado reset de variaveis ao
	  receber timeout(C_TIMEOUT), evitando assim em uma ligacao sainte a
	  deteccao de DTMF o que poderia provocar a nao deteccao de CALLERID
	  durante a proxima ligacao entrante;



 versao 4.0.9.9_rc6 - 25/04/2008 - 30/04/2008
 
 	- Implementacoes na interrupcao do driver para linux(vlibdrv.c),
 	  foi adicionado um "#define USE_DGDUMMY 1" para controlar o uso do
 	  DG_DUMMY, o DG_DUMMY tem com como funcao servir de fonte de tempo para o
 	  Asterisk, ou seja, a fonte de tempo para o Asterisk agora tambem pode ser
 	  feita por nossa interrupcao(2ms) ou atraves do ZT_DUMMY, que serviu como
 	  base para o nosso proprio desenvolvimento;



 versao 4.0.9.9_rc5 - 14/04/2008 - 18/04/2008

	- Implementacao de rotinas de conversao de audio:
	  dg_GsmToWave, dg_GsmRawToWave, dg_GsmToWave49, dg_GsmRawToWave49,
	  dg_WaveToGsm, dg_WaveToGsmRaw, dg_Wave49ToGsm, dg_Wave49ToGsmRaw;





/*************************************************************************
	MERGE, WINDOWS VERSION CHANGELOG (START)
	
 ----------
 versao 4.1.0.1 rc1 - 26/11/2008 - 02/12/2008

	- Alteracao no arquivo logger.c, voicerlib.c e voicerlib.h
	- Inclusao da funcao SetLoggerSilenceThreshold
	- Inclusao do case 0: break; na thread de logger "Logger_Thread"

 versao 4.1.0.0 - 05/09/2008 - 16/10/2008
	- Identificacao da EEPROM mudou para 0x33xx no vlibdef.h
	- Suporta os Sistemas Operacionais: XP/2000/2003/Vista/2008

 
 versao 4.1.0.0_rc6 - 26/08/2008 - 04/09/2008
	- Inclusao da placa PCIExpress no Windows Vista


 versao 4.1.0.0_rc6 - 04/08/2008 - 25/08/2008

	- Inclusao da placa PCIExpress no Windows XP
	- Atualizacao do Windriver 8.01 -> 9.21 
	- Atualizacao do Visual Studio 2003 -> 2008
	- A placa VB3030PCIE eh 0x440b e nao 0x4410
 
 versao 4.1.0.0_rc5 - 28/07/2008 - 28/07/2008

	- As funcoes dg_ReadEEPROM e dg_WriteEEPROM foram renomeadas e melhoradas
		dg_WriteEEPROM -> dg_WriteCode
		dg_ReadEEPROM  -> dg_CheckCode

 versao 4.1.0.0_rc4 - 26/06/2008 - 26/06/2008

	- Novas funcoes: dg_ReadEEPROM, dg_WriteEEPROM e dg_ReturnCodeToString

 versao 4.1.0.0_rc3 - 28/05/2008 - 02/06/2008
	
	- Adaptacao para as placas VB3030PCIE e VB6060PCIE (PCIExpress)


 versao 4.1.0.0_rc2 - 10/05/2008 - 27/05/2008
	
	- Correcoes e validacoes nas funcoes: dg_StartVoicerLib e dg_ShutDownVoicerLib
 

 versao 4.1.0.0_rc1 - 25/04/2008 - 08/05/2008

	- Incluso o tratamento do formato de audio ffWave49, gravacao e reproducao;
	- Corrigido alguns warnings;
	- Retirado o pragma;
	- Cabecalho dos formatos corrigidos;
	- SendAudioToAppPtr foi alterada, o primeiro e o segundo parametro sao somente short e int e nao
short * e int * ;
	- dg_playstruct, origin (parametro do PlayFile) agora eh definido como long e nao mais como short;



 versao 4.0.9.9 - 27/02/2008 - 18/04/2008

	- Versao final contendo todas as implementacoes das versoes:
	  4.0.9.9_rc1, 4.0.9.9_rc2 e 4.0.9.9_rc3 - Linux,
	  4.0.9.9_rc4 e 4.0.9.9_rc5 - Windows;
	- Alteracoes na thread de idle(idle.c), adicionado reset de variaveis ao
	  receber timeout(C_TIMEOUT), evitando assim em uma ligacao sainte a
	  deteccao de DTMF o que poderia provocar a nao deteccao de CALLERID
	  durante a proxima ligacao entrante;




 versao 4.0.9.9_rc5 - 14/04/2008 - 18/04/2008

	- Implementacao de rotinas de conversao de audio:
	  dg_GsmToWave, dg_GsmRawToWave, dg_GsmToWave49, dg_GsmRawToWave49,
	  dg_WaveToGsm, dg_WaveToGsmRaw, dg_Wave49ToGsm, dg_Wave49ToGsmRaw;





	MERGE, WINDOWS VERSION CHANGELOG (FINISH)

/*************************************************************************





 versao 4.0.9.9_rc4 - 03/04/2008 - 03/04/2008

	- Incluso geracao de evento EV_ANSWERED no customthd.c;



versao 4.0.9.9_rc3 - 12/03/2008 - 12/03/2008

	- Criado nova funcao para setar na placa DG_FX_INTERFACE o tipo da 
	  interface(DG_FX_TYPE_FXO/DG_FX_TYPE_FXS), a funcao tem o nome de 
	  dg_SetFXCardType e para acessa-la eh necessario passar os parametros
	  de porta e tipo da interface; 



 versao 4.0.9.9_rc2 - 07/03/2008 - 07/03/2008

	- Criado novo parametro onde eh definido se a thread e1 esta funcionando
	  como R2MFC(R2_TYPE_MFC), channelbank_fxo(R2_TYPE_CB_FXO) ou
	  channelbank_fxs(R2_TYPE_CB_FXS). Parametro E1CFG_SIGTYPE definido na
	  funcao dg_ConfigCBThread;
	  
	- Alteracao na funcao dg_GetCallerId para que a mesma retorne o CallerID
	  identificado em uma placa E1 com E1CFG_SIGTYPE R2_TYPE_CB_FXO ou
	  R2_TYPE_CB_FXS;



 versao 4.0.9.9_rc1 - 27/02/2008 - 28/02/2008

	- Alteracao na thread FlashThread(threads.c) e na funcao dg_Flash
	  (voicerlib.c), caso seja chamada a funcao dg_Flash com os parametros
	  zerados(dg_Flash(p->port, 0, 0, 0)) o flash eh cancelado;	  



 versao 4.0.9.8 - 21/02/2008 - 21/02/2008

	- Versao final liberada; 



 versao 4.0.9.8_rc2 - 09/01/2008 - 07/02/2008

	- Alteracao na rotina dg_ClearDigits para que o PlayFile da frase de conferencia nao seja 
	  interrompida por um digito qualquer; 
	- Corrigido problema de falar a frase de conferencia aleatoriamente; 
 	- Corrigido problema das opcoes de confirmação do prompt e menu; 

 versao 4.0.9.8_rc1 - 12/12/2007 - 01/02/2008

	- E1CFG_R2_COUNTRY;	

 versao 4.0.9.7 - 29/01/2008 - 29/01/2008

    - Implementacao para reset de timer no inicio da thread para channel_bank FXS;


 versao 4.0.9.6 - 13/11/2007 - 10/12/2007

	- Implementacao de thread para controle do channel bank FXS(channel_bank.c), esta thread
	  eh um "mix" entre thread E1 R2 e placas FXS, pois tem um funcionamento similar ao R2 e gera
	  eventos identicos a uma placa FXS;
	- Criacao dos seguintes metodos dg_CreateCBThread, dg_ConfigCBThread, dg_DestroyCBThread,
	  dg_EnableCBThread, dg_DisableCBThread e dg_GetCBThreadStatus;


 versao 4.0.9.5 - 23/08/2007 - 12/09/2007

	- Adicionado reset da variavel sDigitsDetected ao chamar o comando dg_Hangup;
	- Correcao nos alarmes com opcao de CCS sem CRC-4(firmware e05.i00, e06.i00, e07.i00);
	- Implementacao no arquivo threads.c que ao receber um evento de HOOK_OFF ou HOOK_ON
      seta a variavel FStatusPort para ser utilizada na funcao dg_GetPortStatus, implementacao
      somente para placas FXS;
	- Removido if que verificava se o ultimo alarm aconteceu nos ultimos 2 segundos(voicerlib.c); 


 versao 4.0.9.4 - 28/06/2007 - 09/08/2007

	- Versao de VoicerLib 4.0.9.4 liberada ao publico;
	- Adicionado ifdef para compatibilidade com kernel 2.6.22(vlibdrv.c, vlibdrv.h);
	- Adicionado reset da variavel FStatusPort ao chamar o comando dg_DialAbort e dg_Hangup;
	- Correcao nas rotinas de on/off dos leds de alarme para placas e1(firmware);
	- Alteracoes na sinalizacao r2, que ao receber os eventos de B_NUMBER_UNKNOWN, B_NUMBER_CHANGED e
	  B_OUT_OF_SERVICE, ainda continuamos em processo de chamando para poder receber a mensagem
	  de audio da operadora(e1.c);


 versao 4.0.9.4_beta2 - 19/07/2007 - 07/07/2007 - Luciano / Caio
 
	- Correcao de problema ao utilizar o PlayBuffer, pois quando a placa esta em processo de fala de buffer
	  mesmo nao existindo mais amostras de audio a mesma continua falando, sendo assim caso nao existam mais 
	  amostras de audio nos setamos os ponteros com buffers de silencio(vlibdrv.c);
	- Criado metodo dg_GetCardNumberStartError, que retorna o numero da placa que gerou o erro
	  no comando dg_StartVoicerlib, este comando so pode ser executado ao receber os seguintes retornos:
	  DG_ERROR_FIRMWARE_NOT_FOUND, DG_ERROR_FIRMWARE_IO_TIMEOUT e DG_ERROR_READING_PORTCOUNT;
 
 
 versao 4.0.9.4_beta1 - 28/06/2007 - 12/07/2007 - Luciano / Caio
 
	- Implementacoes para a sinalizacao E1/R2 ARGENTINA(vlibdef.h, e1.h);
	- Implementacoes para maquinas 64bits(vlibdrv.c, vlibdrv.h, shmem.h);
    
        
 versao 4.0.9.3 - 25/06/2007 - 25/06/2007
 
 	- Correcao nos firmwares para cancelamento de echo, caso o canal desde o inicio da ligacao possuisse audio, 
 	  o cancelador nao executava o treinamento;    
    
    
 versao 4.0.9.2 - 24/05/2007 - 06/06/2007
 
 	- Alteracoes na thread e1 para poder setar o estado do canal quando o mesmo parar de discar, 
 	  assim conseguindo monitorar pelo retorno do 'dg_GetPortStatus' se o canal r2 esta discando ou nao;

        
 versao 4.0.9.1rcm1 - 18/05/2007 - 24/05/2007
 
 	- Implementacoes para a sinalizacao E1/R2 MEXICO(e1.c e e1.h);


 versao 4.0.9.0rc2 - 16/04/2007 - xx/04/2007
 
 	- Implementacoes para no novo modelo de placa, a placa FXS;
 	

 versao 4.0.9.0rc1 - 28/03/2007 - 28/04/2007
 
 	- Primeira versao com ISDN liberada aos colaboradores; 
 	 

 versao 4.0.8.0 - 23/03/2007

    - Nova funcao dg_R2SendBackwardSignal
	- Na thread E1 o tempo de espera de seizure foi reduzido de 100ms para 20ms para se adequar s 
	  normas "telebras".
    - SetSilenceThreshold agora passa formula fTemp = (42 + value) * 0.33 - 25 e agora permite receber
	  -45dBm como parametro

    - No CreateCallProgress agora  possivel ler dos arquivos .cfg as frequencias que deverao ser 
      assumidas para deteccao de ocupado, linha, etc... Formato:

            tone1=425,0  (frequencia1, frequencia2)
            tone2=1100,0
            tone3=2100,0
            tone4=0,0
            tone5=0,0
            tone6=0,0
            tone7=0,0
            tone8=0,0
    - A funcao EnableCallProgress agora verifica se a thread de callprogress esta pronta pra receber
      comandos. Caso nao esteja, entra num timer e fica tentando a cada 100ms.... Isto corrige alguns
      problemas de callprogress relatados.

    - Alterados os firmwares versao xxxxxxxx
    - Corrigido problema na deteccao de ocupado quando se usa o CP_ENABLE_BUSY_OR_FAX
    - Colocado item finalizador no cp_default.cfg para poder detectar caso o arquivo esteja com algum
      problema de estrutura retornando DG_WARNING_OLDFILEFORMAT (0x460). Nao significa necessariamente erro
      porem alerta o usuario para verificar manualmente
    - Corrigidos problemas de finalizao das threads pois estava referenciando os indices dos arrays de maneira
      incorreta.


 versao 4.0.7.6 - RC2 - 29/01/2007

	- Criadas constantes DG_ENABLE_AGC e DG_DISABLE_AGC para utilizao no dg_EnableInputBuffer
	  para deixar os parametros mais auto-explicativos.
    - Na verso Windows, foi retirado o parametro taps do enableechocancelation para evitar recompilacoes 
	  de aplicativos desenvolvidos, por enquanto. Assume 128 TAPS para placas com 30 canais ou menos.
	- Correo nas funes PlayList/Menu pois em algumas situaes onde um PlayList era acionado dentro do 
	  evento OnMenu, era possvel que as mensagens deste PlayList no fossem reproduzidas.
    - No caso de dupla ocupao na thread E1, o sistema iniciar um timeout para evitar situaes de deadlock
      caso a operadora nao consiga reconhecer o livre. Tambem foi colocado uma pausa antes de se enviar o livre.
    - colocado no e1.c a finalizao da ligacao caso receba um livre duranteo P_R2_AGUARDA_LIVRE
    - Nova funcao *dg_GetSpansCount(short card);* que retorna o numero de spans das placas Digitais
    - Novo parametro *BusySensibility* determina quantos tons de ocupado devem ser detectados para que seja gerado 
      um evento para a aplicao. O padrao  1 e este parmetro  aplicado somente no CP_ENABLE_BUSY_OR_FAX
    - Corrigido problema no callprogress usando CP_ENABLE_BUSY_OR_FAX que, dependendo dos valores nos arquivos .cfg
      poderia nunca pegar o tom de ocupado.
    - Firmwares atualizados com correo no AGC em gravaes em formato wave e novo algoritmo de cancelamento de
	  eco com funcionalidades de pr-treinamento
    - Nesta versao o cancelamento de eco em windows assume os padroes de taps e training 
	- Nova funo *dg_DialAbort(port)* permitindo cancelar uma discagem em curso
	- HangUp agora cancela timer do evento AfterPickUp, evitando que seja chamado apos o hangup

 versao 4.0.7.5a - Windows - versao com correes no idle que nao afetam verso linux

	- No idle foi alterado para considerar lineoff no estado desligado como ring
	- No idle, ao receber um lineready ja muda o estado para evitar perder o getdigits quando receber outro 
	  em seguida (ctiserver)
    - No desligar no idle, cancela timer de AfterPickup para evitar aparecer afterpickup apos o desligamento caso 
	  o tempo deste seja muito grande.


 versao 4.0.7.5:

    - VoicerLib em Linux liberada sob licensa LGPL
    - Incluido comando para configurar o tamanho do stack das threads criadas - padrao 256Kbytes. Isso permitir
      executar a voicerlib com muitos canais (LINUX)
    - Resolvido problema de execuao no Debian Sarge com Kernel 2.6.8 quando o sistema tem muitos canais
    - Corrigido problema no Makefile do device driver para kernel 2.4.x
    - Criado e1->ring_generate_ringback para poder configurar se a thread E1 vai gerar o ringback ou nao. 
    - Inserido modo de deteco fast para o Idle pegar o bina
    - Removido duplo-hangup nas threads E1
    - Criado metodo dg_PauseInputBuffer 
    - Corrigido o problema da thread E1 gerar o RING antes do termino da sinalizao, o que podia fazer perder os 
      eventos de atendimento
    - Novos recursos para depurao da sinalizao R2D/MFC em Linux

 versao 4.0.7.4

    - Inserido modo de deteco fast para o Idle pegar o bina
    - Resolvido problema de duplo-hangup nas threads E1
	- Resolvido problema no logger, que nao estava gravando por falha na funcao EnableChat
	- Criada funo dg_PauseInputBuffer/PauseInputBuffer que permite deixar a thread de inputbuffer 
	  sempre criada, porem em pausa (DG_RELEASE,DG_PAUSE)
    - Criada funcao SetTwist com parametros (firmwares tambem foram atualizados):
		- twist1: padrao 9dB - diferena MAXIMA aceita entre as freq1 e freq2 - maior valor, *menos* rigor
		- twist2: padrao 15dB - diferena MINIMA entre freq1/2 e freq3 - maior valor, *maior* rigor
	- dg_DisableAutoFramers(void) permite desativar a funcao que habilita os framers automaticamente
	  quando se chama a funo dg_SetCardSyncMode
    - Exemplos em C (VC++ Express 2005) de Discador e CustomCas completos
	- O evento de RING agora  gerado aps o periodo de 1s na thread e1.
    - Inicializao mais rapida


 versao 4.0.7.3

    - SetPortGain agora tem opo de PLAY_GAIN
    - Correcao na ordem de inicializacao do EnableSilenceDetection para que seja possivel detectar
	  audio caso o audio seja o estado atual
    - Correcao na funcao SetRecordFormat, que faz com que na mudanca de formato os buffer 
      dentro da interrupcao sejam reiniciados.
    - Ajuste nos tempos de deteco de fax no arquivo cp_default.cfg
    - Suporte a nova placa VBE13030PCI (1 span)
	- No DisableInputBuffer  forado o fim da thread caso no esteja gravando.


 versao 4.0.7.2

    - Firmware 0x31a que verifica a existencia ou no do segundo span antes de reseta-lo
    - Rotina de Carga do firmware modificada no mtodo de re-tentativas de carga
    - Funcao Enable/DisableFramer chamada automaticamente na inicializacao/finalizacao da voicerlib
    - VoicerLib verifica se o cancelamento de eco ja esta habilitado antes de mandar de novo o comando pra placa

 versao (4.0.7.2 beta 1)
 ---------------------------------

    - Opo de debug no linux permite receber R2 e MF via arquivo - melhorar
    - dg_EnableFramer/dg_DisableFramer/dg_EnableCCSMode
    - As opes EnableFramer e DisableFramer 
    - Correo no device driver do Linux em relao ao buffer ativo a ser enviado para a placa
      o que ocasionava ruidos no udio
    - Atualizados os firmwares para as placas FXO e E1, com o algoritmo de cancelamento de eco
      melhorado, principalmente em situaes onde o ganho  muito alto.
    - Retirada mensagem de debug do device driver, que podia ocasionar degradao de performance
      o mesmo erros de travamento/kernel PANIC

 versao 4.0.7
	
	Geral
	=====

	- Descoberto e Corrigido problema no tratamento do alarme quando a placa eh de 30 canais.
	- Corrigido bloqueio dos canais 30 e 60 no caso de perda de Sinal E1 (LOSS)
	- Criada funcao R2SendGroupB que permite enviar manualmente o groupo-b da sinalizacao R2/MFC quando
	  utilizado de maneira manual
    - A funcao R2AskForGroupB foi renomeada para R2AskForGroupII e agora tem um segundo paramentro que 
	  indica se pedir o grupo B de modo compelido (default) ou pulsado (no caso de sinalizacao manual) e 
    - Corrigido problema no Logger pois nao iniciava a gravacao corretamente quando existia apenas uma placa instalada
	- Funo dg_GetVersion agora permite escolher qual placa mostrara' a versao interna do firmware
	- Corrigido ordem das constantes de uso em Conferencia (CHAT_LISTEN,etc...)
	- PlayBuffer tem novo parametro utilizado para receber informacoes de espaco livre no buffer.
    - A sinalizao na thread E1 agora  feita com o modo de deteco rapida ativada, para diminuir o tempo da 
      troca de sinalizao.
    - Documentao atualizada com captulo no Guia de Referncia sobre os cdigos de erros das funes
	- Firmwares atualizados com melhorias nos ganhos do AGC nas rotinas de gravao
	- Versoes do Firmware: 
		- Placa FXO - 202H
		- Placa E1 Full - 606H
		- Placa E1 slim - 306H 
	- Suporte a recebimento de A5 pulsado na thread de controle e1
	- O mtodo EnableSilenceDetection foi modificado para permitir a deteco de silencio mesmo que o estado inicial,
	  antes da chamada do mtodo, j fosse silencio.
    - EnableEchoCancelation permite ser utilizado por placas E1 pequenas e 60 canais
	- Modificada forma de gerao de ring na thread E1

	Windows
	=======

	- Includo no Setup da VoicerLib o .inf para as novas placas E1 com RJ45
	- Refeito o tratamento de recepo de digitos duranto o playlist, prompt e menu no activeX
	- GetVersion agora recebe placa como parametro

	Linux
	=====

	- Corrigido no driver Linux um erro no codec do GSM que fazia com que ruidos aparecessem no audio
	- Corrigido erro de compilao do exemplo vlib_diag


 versao 4.0.6 - 01/08/2006

	Geral

	- funcao SetEnableTimer consiste se interval e menor que zero
	- Retirado Mutex da chamada as funcoes callback da gravacao para evitar deadlock
	- nova funcao dg_h100_DisconnectAll - desconecta todos os canais do h100 - tudo para de funcionar com isso
	- nova funcao dg_h100_SetDefault - volta tudo ao estado inicial E1 <-> DSP
	- nova funcao dg_LocalBridgeConnect(short port1, short port2);
	- nova funcao dg_LocalBridgeDisconnect(short port1, short port2);
	- SetRecordGain agora configura um ganho especifico de gravacao, e nao mais um ganho RX geral
	- Corrigido bug na thread E1 quando fosse utilizada de modo interativo, com as funcoes dg_SetStartE1RxCount e
	  dg_SetNextE1RxCount
    - Nova funcao dg_ForceSingleSpan que forca placas E1 de 60 canais a serem placas de 30 canais, permitindo assim
	  utilizar o recurso de cancelamento de eco

	Windows

	- Revisada a instalacao dos includes para utilizacao da API em Windows
	- vlib_diag em windows modificado para procurar os headers nos diretorios padrao
	- Incluido _DESENV_ no projeto em Windows para facilitar uso em programas API em windows

	Linux

	- Novo procedimento 'make; make install' no diretorio raiz da voicerlib que compila o device driver, a biblioteca 
	  e os programas de teste
	
 versao 4.0.5 - 19/07/2006

	Geral:
	======
	- Resolvido problema de inicializacao da placa PCI0408 com 4 canais. Falha no retry....
	- A funcao GetAlarmStatus resseta os controles de alarme, permitindo a vinda de todos os 
      alarmes, ligados ou desligados.
	- Corrigido problema no firmware da novas placas slim BNC e RJ45 que fazia com que os canais
	  acima do 16 nao funcionassem

    Linux:
    ======
	- Corrigido problema de memory leak na criacao das threads. A thread no linux e criada por default
	  como nao sendo auto-detach, fazendo com que as threads fiquem como processos zubies 
	- Log de debug da voicerlib agora fica em /var/log/voicerlib/xxxxx
	- Novo programa de teste: dgr2loop para teste de discagem do R2D em Loop, em samples/dll_so/dg_utils.
	- O programa vlib_diag nao precisa mais do parÃ¢metro '-p' devido a nova localizacao do firmware
	- Novas tarefas do 'make install' da voicerlib:
		- As fifos no Linux agora sao criadas com direitos de escrita para todos - DG_FIFO_ACCESS_RIGHTS
		- Em linux o firmware deve ser lido em /var/lib/voicerlib/firmware. Se passar vazio no startvoicerlib
      	este diretorio e assumido
		- Instala headers para o diretorio /usr/include/voicerlib fazendo com que os programas
      	que usem a voicerlib nao precisem mais utilizar caminhos absolutos.
	- No device driver e feito o tratamento para permitir reiniciar o sistema em caso de seg.fault na
      aplicacao
	- Device Driver apresenta numero de versao no dmesg

 4.0.4.1 Linux

    - Reducao dos tamanhos dos buffers de memoria compartilhada
    - Correcao no PlayBuffer que impedia que se falasse g711 ou PCM


 05/07/2005 v4.0.4

	- Ao dar um StopPlayFile no ActiveX cancela a execucao do PlayList. Isso corrige um problema da lista
	  continuar em execucao apos o StopPlayFile.
    - Correcao nos metodos h100_HalfDuplexConnect.
	- O metoo h100_HalfDuplexDisconnect agora exige a passagem de dois parÃ¢metros: portsource e porttarget
	- Agora sempre sera necessario chamar o h100_EnablePort() antes de tentar conectar os canais
    - Criados metodos:
		- EnableE1Thread / DisableE1Thread e
		- GetE1ThreadStatus podendo retornar os valores:
			|_ DG_E1_THREAD_DISABLED/DG_E1_THREAD_ENABLED
	- Correcao no device driver para linux para kernel 2.6.9
	- Corrigido erro do StopPlayFile quando tem lista em execucao
	- Corrigidos exemplos em Visual Basic 6
	- Corrigido bug no device driver em Linux quando eram utilizadas mais de uma placa no micro


 16/06/2006  v4.0.3

	Geral
	=====

	- Correcao na thread de reproducao na virada do buffer para o device driver. Tambem foi colocado
	  a variavel local_rp para fazer as validacoes sempre com o mesmo valor de rp. Retirado o sleep
	  a cada interacao do loop.
    - Correcao da thread E1. O problema ocorria quando o assinante B desligava e depois retornava a
	  ligacao. A thread nao "percebia" o retorno e desligava por timeout. Agora ao retornar, a aplicacao
	  tambem recebe o evento EV_E1CHANGESTATUS -> C_ANSWERED
    - Na thread E1, quando for detectado o atendimento, tambem e gerado o evento EV_E1CHANGESTATUS -> C_ANSWERED
	  Antes so eram gerados o EV_ANSWERED e o EV_LINEREADY. Com isso o programador que faz aplicacoes exclusivas
	  para E1 tambem pode fazer todos os tratamentos no EV_E1CHANGESTATUS
    - Nova versao 0x112 
	- Firmware da placa FXO VB0408/PCI
			- Diminuicao dos ganhos no echocan
			- ajuste de ganhos do gsm
			- deteccao de pulso
    - Importante correcao na alocacao de memoria para reproducao e gravacao de arquivos 
    - Nova consistÃªncia no PlayBuffer indicando buffer cheio (DG_ERROR_PLAY_BUFFER_FULL)
	- Corrigido problema no IdleStart (erro 0x503). Este erro ocorria quando se executava um IdleAbort e logo em
	  seguida um IdleStart.

	Windows
	=======

	- Correcao no numero de tentativas da funcao MenuStart

	Linux
	=====

	- Correcao no install do MakeFile do ast_channel
	- Incluida opcao de 'make config' no device driver, para inicializacao automatica do device driver da digivoice
	- Diversas alteracoes no channel Asterisk. Ver em CHANGELOG do diretorio ast_channel

	- Corrigido problema 


 29/05/2006 versao 4.0.2

	Geral:
	=====
	- Correcao na thread de gravacao. Estava perdendo um frame (16 ou 33) a cada
	  50 recebidos.
    - CallProgress - corrigido falha na deteccao de atendimento. O timeout estava em
	  500ms e agora e configuravel pelo paramentro AnswerSensitivityTimer

    Linux
	=====
	- Suporte ao Kernel 2.6 (testado 2.6.16 e 2.6.8 (remap_fpn_range))
	- Correcoes no device driver, nas etapas de finalizacao do sistema.


 19/05/2006 versao 4.0.1

	Geral
	-----

	- Nova funcao dg_GetCardInterface que retorna o tipo da interface da placa, podendo ser:
			DG_DIGITAL_INTERFACE = 1,
			DG_FXO_INTERFACE = 2,			
			DG_UNKNOWN_INTERFACE = 99;
	- Nova funcao dg_GetPortInterface que retorna a mesma informacao acima, so que passando
	  a porta absoluta como parÃ¢metro
  
  - Criacao da funcao port2CardChannel para centralizar as contas de conversao de placa/porta/canal
  - Corrigido arquivo de configuracao cp_1232d.cfg para funcionar com o Panasonic
  - CallProgress: Incluido o parÃ¢metro AnswerSensitivityTime com padrao de 200ms. Este parÃ¢metro permite diminuir
                  a sensibilidade do atendimento aumentando o este valor

	Windows (ActiveX):
	------------------

	- Corrigido problema no Prompt que nao funcionar com a opaoo de confirmacao habilitada e se tentar repetir o prompt
	- PlayListClear saopermite apagar se nao estiver falando nada
	- VBoxConfig para placas E1 atualizado para versao 1.5.0
	- Melhorias no programa de testes *vlib_diag*:
		- Possibilidade de indicar o arquivo de configuracao do call progress
		- Alteracao interna da ordem das supervisao de linha, adequando-as  forma que o programador deverao utilizar na pratica
		- Exibicao da versoes da DLL e do ActiveX na inicializacao do programa

	Linux
	-----

	- Linux: Cleanup do codigo do device driver
	- Linux: corrigido erro na gravacao. A variavel ub_readed nao era zerada no inicio podendo causar
    segmentation faults e outros comportamentos nao previstos.
	- Linux: opcao de habilitar ou nao o cancelamento de eco no channel para Asterisk (digivoice.conf)


  TODO para 4.0.1:
  ---------------

		- Documentar melhorias do prompt, com o evento OnPrompt permitir repetir o prompt

 09/05/2006 versao 4.0.0 (build 707)

	- dg_CancelGetDigits nao apaga mais o buffer de digitos recebidos, somente cancela os timers e zera os flags de controle

 05/05/2006 versao 4.0.0 (build 706)

	- dg_EnableEchoCancelation - consiste se a placa E1 tem 60 canais, se tiver, retorna erro 
	- Channel Asterisk funcional para Asterisk 1.2.7.1

 03/05/2006 Versao 4.0.0

	- undocumented function - se passar -1 na pausa apos o pickup, nao gera o afterpickup
	- Startvoicerlib inicializa as frequencias de detecao de tom para um padrao 425,1100,2100
	- dg_StartVoicerlib agora so recebe o caminho do firmware como parametro
	- funcao de IdleXXX implementada na dll e activeX
	- Funcao Makefile completada com flash e relacionados
	- inifile.c permite ler hexa
	- funcao de canais virtuais funcionando corretamente - deve se documentado a utilizacao dos
	  canais virtuais + logger.

    mudancas beta 3
	===================

	- correcao  do tipo de funcao de tratamento dos eventos no ActiveX. Agora esta declarada corretamente como CALLBACK
	- diretorio padrao setado para voicerlib4 no caso de configpath estiver vazio ""
	- correcao nas definicoes Extern do SignalEvent
	- SetEventFunction modificada para SetEventCallback
	- Novas funcoes: dg_PlayBuffer, dg_StopPlayBuffer
	- Nova funcao dg_SetGSMMode que recebe como parametro GSM_DIGIVOICE ou GSM_RAW (padrao)
	- BUG NO MFC - IMPORTANTE: Foi detectado um bug quando se chama um metodo no ActiveX que
	  retorna VARIANT_BOOL. Apliquei um metodo descrito no artigo abaixo:
	  http://216.101.185.148/scripts/isapi.dll/article?id=2009D1F4&article=1132863&host=ms	
	  criando uma classe dummy para limpar o registrador eax antes de retornar. 
	    - Este bug fazia com que as funcoes abaixo voltassem sempre TRUE
			-> IsPlaying
			-> IsRecording
			-> DriverEnabled
    
	- algumas mudancas na thread E1:
	  -> Se estiver bloqueado e dar pickup, agora gera o Unavailable
	  -> tem um flag para evitar de gerar o evento de Unavailable 2 vezes, devido as duas 
	     sequencias de R2 que tem que mandar pra evitar locked
	  -> Quando da um hangup, gera o evento EV_LINEOFF

   mudancas beta 4
   ===============

    - funcao dg_GetPortCardType devolve o tipo de placa de determinada porta


	mudancas beta 6 e 7
    ===============

	- implementado metodo REC_DELAY e NO_DELAY no EnableInputBuffer para streaming. Com isso, qdo se
	  utiliza NO_DELAY, as amostras so enviadas de 33 em 33 amostras para gsm
	  TODO: (*) os formatos wave ainda precisam ser modificados para enviar de poucas amostras.
	  TODO: Melhorar logica de passagem de eventos no modo streaming

    mudancas beta 8
	===============

	- Corrigido erro ao tentar iniciar a lib novamente, caso de erro 2 antes
	- dg_SetRecordFormat nao permite alterar valores caso o input_buffer esteja habilitado
	- Erro no IdleSettings ao passar termdigits vazio corrigido

	beta 9
	======

	- Funcoes de Pulse desabilitados
	- AutoClearDigits agora sempre e OFF - Nao e possivel mudar mais
	- EnableAnswerDetection agora pode ser habilitado em qualquer tipo de CallProgress

	beta10
	======

	- IdleSettings com parametro nulo corrigido
	- Constantes de Framer atualizadas para:
			FRAMER_LOOP_OFF, 
			FRAMER_LOOP_REMOTE, 
			FRAMER_LOOP_LOCAL
	- Colocada consistencia de loop_type no SetFramerLoop

	beta11-12
	======

	- Corrigido erro no makecall e no prompt qdo nao passa frase inicial (NULL)
	- O MenuStart nao aceita frase inicial vazia, retornando erro 4
	- Diminuido tempo de inicializacao da VoicerLib
	- EV_RECORDSTOP no activeX e acionado diretamente da CallBack e nao mais via PostMessage
	- Correcao de GPF durante a gravacao
	- SetSilenceThreshold eh o parametro para aumentar e diminuir a sensibilidade
	- TimerProc com intervalo de 80ms para deixar os eventos mais precisos
	- Implementado detecao de silencio.
		|_ EnableSilenceDetection(porta, tempo_silencio, tempo_audio)
			tempo_silencio - em ms, informa o tempo a ser considerado silencio
			tempo_audio - em ms, tempo para se considerar audio. Deve-se utilizar zero para pegar no primeiro
			              audio. No caso de valor maior, nao utilizar nada alem de 100ms.....
		|_ DisableSilenceDetection(porta) - desabilita a deteccao de silencio
		|_ evento OnSilenceDetection(porta, state) onde: state = 0 (SILENCE_OFF) ou 1 (SILENCE_ON)

	- Constantes DG_DISABLE=0 e DG_ENABLE=1 criadas no activex - a serem utilizadas em funcoes que habilitam ou 
	  desabilitam algo, como a dg_SetDetectionType
    - Corrigido problema do PromptStart retornar BSTR no ActiveX. O correto eh SHORT.

	build 13
	========

	- novo firmware para placa de 4/8 canais resolvendo problemas da placa nao iniciar
	- correcoes diversas nas rotinas de gravacao

	beta 14
	=======

	- Idle corrigido - nao gera mais eventos AfterPickUp. A thread idle precisa ignorar tudo o que acontecer
	  depois dos procedimentos WatchTrunkAfter
    - Corrigido problema nos cabecalhos wave
	- Retirado parametro BufferType na funcao dg_EnableInputBuffer/EnableInputBuffer

    beta 15
    =======

  - Corrigido problema no ConfigCallProgress de retorno -1 para configuracoes acima do valor 10
  - Finalizacao do timer na versao LINUX
  - Atualizado firmware da placa de 4 canais - nao pode mais inicializar errado
  
  beta 16
  =======
	- Thread de callprogress agora tem um flag chamado thread_ready que indica que a thread pode receber na fifo
	- Thread de E1 com controle de enabled tambem
	- TODO: Fazer para as outras threads


  beta 20
  =======

    - Novo timer interno para Windows.
	- Metodo GetTest(Placa) para saber se o firmware resetou no caso de erro ao ler placa.
	- Corrigido problema de concorrencia entre threads na deteccao de digitos. Foram criadas 
	  critical sections para evitar o problema

  beta 21-22
  =======

    - Windriver 8.00
	- dg_EnableInputBuffer(short port, short agc_enable) onde agc_enable deve ser DG_ENABLE_AGC ou DG_DISABLE_AGC

  beta 23
  =======
	- CallerID corrigido

  beta 24
  =======
		
	- Mudanca na rotina de falar
	- dg_PlayBuffer , dg_StopPlayBuffer
	- CriticalSections na funcao SaveHeader na finalizacao das gravacoes
	- O bIsRecording eh colocado em false antes de gerar o evento OnRecordStop para a aplicacaoo, ja que
	  o arquivo ja esta fechado

  beta 25
  =======

	- Streaming em PCM Linear OK
	- Streaming GSM OK
	- Problema no CallProgress na detecï¿½o de FAX quando habilita a opï¿½o BUSY_OR_FAX corrigida.

  beta 27
  =======

	- firmware modificado para transferir o GSM tudo de uma vez e nao de 3 em 3 blocos
	- fax corrigido tambï¿½ para a opï¿½o CP_ENABLE_ALL do CallProgress

  beta 28
  =======
  
    - Foi colocado um sleep no fala de arquivo, sempre quando o ponteiro de inserï¿½o encontrar o de 
      retirada - testar no Windows

  RC 1 - Release Candidate 1
  =====
	- Firmware Placa E1 Slim atualizado
	- Corrigido problema no CallProgress de pegar "chamando" no lugar de ocupado.
	- Criado retry na carga do firmware

  RC 2
  ====

    - Aumentada as FIFOS de comando 
	- Resolvido problema de deadlock no write_generic_command

  RC 3
  ====
    - Mudanï¿½s nos mutex, tornando-os por canal
	- No ReceiveEvents do ActiveX foi retirada a chamada direta do evento para utilizar o PostMessage
	- Colocado RaiseEvents_ThreadSafe nos timers globais
	- EV_SILENCE no activeX acionado por postmessage

  RC 5
  ====

	- RaiseEvents com mutex por porta

  rc 6
  =====

    - Corrigido problema no evento OnSilenceDetected - travamento e codigo do State em caso de detecï¿½o 
	  de audio

  rc 7
  =====

	- testes - retirador criticalsection do fclose e do SaveHeader na gravacao
	- atualizado para windriver 8.01


  rc 8
  ====

	- Corrigido problema no Idle de nï¿½ atender, introduzido no RC3
	- Habilitando a interrupï¿½o somente no final do StartVoicerLib
	- Arquivo cp_default.cfg com novos comentarios explicativos

  rc 9
  ====

  - Retirado o mï¿½odo/funï¿½o SetFrequencyTime
  - Retorno do StartVoicerLib ï¿½zero (DG_EXIT_SUCCESS)
  - Corrigido problema de nï¿½ parar a gravaï¿½o caso o DisableInputBuffer fosse chamado logo em seguida
    do StopRecordFile. Agora nï¿½ hï¿½problema em fazer isso.
  - RecordPause retorna DG_EXIT_SUCCESS em caso de sucesso.
  - Novos cï¿½igos de retorno e erro - ver arquivo com DG_ERROR_xxxx para pegar as mudanï¿½s
  - Incluida rotina de detecï¿½o de pulso - EnablePulseDetection recebe sensibilidade de -42dB atï¿½+12dB (padrao 0)
  - Corrigido timeout de tom de linha no callprogress. Tb criado arquivo cp_1232d.cfg para o nosso PABX
  - Corrigido problema na propriedade do StockSigs. Nï¿½ estava adicionando a "\" no final.
  - Corrigido problema na Interface do OCX do PlayDate
  - Deteccao de Pulso funcionando

  rc 10
  =====

  - Firmware/Device driver da placa vï¿½a (R2 sem retrabalho) acertado para trabalhar com GSM sem quebra por grupo
  - Mï¿½odos PromptStart e MenuStart agora tem dois novos parï¿½etros: Usa detecao de pulso e a sensibilidade de pulso
  - Ao primeiro digito detectado por tom, a detecï¿½o de pulso ï¿½desabilitada automaticamente - valido para prompt, menu e 
    getdigits
  - Mensagens de erro modificadas para valores positivos >= 1024 (400h) para contornar o problema do delphi converter
    os tipos *enum* para TOleEnum que ï¿½um tipo long sem sinal.

  rc 11
  =====

  - retirado SetAgcIndex e ConfigureAgc
  - Retiradas propriedades DelayComma, DelayDot, DelaySemicolon do ActiveX
  - Colocados no ActiveX os metodos SetDialDelays, GetRecordFormat, GetPlayFormat , SetCustomMF, DisconnectBus

  rc 12 - Final Version build 646
  =====

  - Corrigido problemas de estalos na reproduï¿½o de arquivos wave
  - Criadas constantes DG_AUDIO_DETECTED e DG_SILENCE_DETECTED para uso com o evento OnSilenceDetected
  - Documentaï¿½o OK
  - Corrigido alguns valores de retorno que estavam trocados

	


--------------------------------------------------------------------------------------------------------
 21/10/2005 Versï¿½ 3.1.8

	- Ganho de gravacao do E1 agora varia de -40 ate +12 (SetRecordGain)
	- Incluido suporte a placa E1 com retrabalho . O kernel plugin tem a
	  rotina de interrupcoes duplicada para cada tipo de placa
	- Criada funcao dg_SetE1CRC4Option que permite habilitar ou desabilitar a 
	  funcao de CRC4 do Framer E1
	- Diminuicao das Fifos de comandos e da shared memory
	- Shutdownvoicerlib agora destroi o loggercontrol e faz outras verificacoes para evitar
	  erros de finalizacao
    - Gravacao em GSM le da placa o momento do sincronismo para otimizar os processos de leitura
	- Corrigido no firmware o clic no inicio da reprioducao do GSM
	- Corrigido problema de reproducao onde parecia que o arquivo continuava de onde parou
	- Compilado com o Windriver 7.02
	- Necessita de c:\apps\wavetools

 27/09/2005 Versao 3.1.7

	- Contantes R2_ENABLEDETECTION(0x10) R2_DISABLEDETECTION (0x20) inseridas no ActiveX em
	  substituicao R2_ENABLE e R2_DISABLE.
    - Criada funcao dg_SetAlarmMode
	- Firmware atualizado para sempre inicializar com tratamento de alarme com notificacao manual e 
	  no automatico so manda alarmes a cada 1 segundo
    - Correcao de reproducao em leiA que nao funcionava
	- Arquivos pequenos em leiA e leiMi nao eram interrompidos no final do buffer
	- Device Driver modificado para evitar conflitos de interrupcao entre placas. No IntEnable foi passado
	  a placa que gerara  interrupcoes


 21/07/2005 Versao 3.1.6

	- Corrigido problemas nas funcoes de logger acima do canal 60 - criado variaval target_port
	- Corrigido erro na propriedade DriverEnabled do ActiveX
	- Corrigido problema no firmware que causava distorcao na reproducao do GSM em canais acima do 16
	- Corrigida falha na reproducao de GSM, que eventualmente poderia causar crash no sistema
	- Inserido no termino do playback, amostras de silencio para os buffers da placa.
	- Logger -> Tratamento de desistencias - chegada de livre durante a troca de sinalizacao
	- Funcao PlayFile agora reconhece o formato do arquivo pela extensao, sobrepondo-se ao formato
	  especificado pelo SetPlayFormat
    - Corrigido problema no device driver, de nao gerar eventos de gravacao e reproducao acima do canal 256
	- EnableDetections agora conta com opcao de modo normal e modo rapido (para logger)
	- Logger agora preve situacoes da CONFIRMACAO de OCUPACAO vir antes da OCUPACAO. Este tipo de situacao
	     eÂ´  raro mas pode ocorrer devido a concorrencias entre threads, etc...
	- Novo manual completo

 17/06/2005	Versao 3.1.5

	- Acertado tratamento de alarmes no device driver
	- Correcao do dg_GetDigits. Ao estourar os timeouts nao estava sendo cancelada sua execucao
	- MakeCall - Correï¿½o do problema de sinalizar Nao Atende qdo ia para o estado Chamando e o 
	  Makecall estava na pausa apos atendimento.
    - Nova nomenclatura dos mï¿½odos da DLL usando letras maiusculas e minusculas
	- Correï¿½es na transferencia de comandos do device driver para a placa e vice-versa
	- Ultimos acertos no protocolo da thread E1
	- Diminuiï¿½o da Shared Memory do DeviceDriver de 7mb para 1.2mb
	- Corrigido problema de consistencia na funï¿½o ConfigE1Thread
	- Versï¿½ do Firmware: 348h


 27/05/2005 Versao 3.1.4

	- Se passar "" no ConfigPath, a VoicerLib assume como padrao o diretorio C:\arquivos de programas\voicerlib
	- Correï¿½o na thread de E1, que fazia gerar RINGS indefinidamente por habilitar a detecï¿½o de DTMF e por 
	  nao tratar a saida do estado P_R2_ENVIA_CONFIRMACAO
    - Correï¿½es diversas na thread E1
	- Ao receber uma alarme, inibe envio de dados para a thread E1.
	- Acertos no MakeCall, para retorno de chamando e ocupado na chegada do Grupo B
	- Criacao do comando dg_ResetError/ResetError e do evento OnErrorDetected para pegar erros da placa
	- Corrigido problemas de iniciar thread de logger acima do canal 31
	- Corrigido problemas nas funcoes de Prompt do ActiveX - ï¿½preciso apagar os digitos e habilitar DTMF 
	  explicitamente antes de chamar o PromptStart
	- Colocado includes e libs no setup para compilaï¿½o dos exemplos em C
	- Incluido ganho na entrada do GSM
	- Correcao de excecoes no timer do OCX
	- Manual atualizado

  Known bugs:

	- Existe uma situaï¿½o onde ï¿½dado o PickUp porem nao gera o AfterPickup na dll

 05/05/2005 Versao 3.1.3 build 100:

	- Funï¿½es CustomCAS
	- AutoClearDigits colocado false como default
	- Novos algoritmos para reproduï¿½o de frases consumindo bem menos CPU
	- Mudanï¿½ no tratamento de gravaï¿½o no device driver
	- GetE1Number devolve numero acumulado do protocolo
	- A threadE1, numa ligaï¿½o entrante agora gera o tom de ring e o evento de ring a cada 5 segundos

 13/07/2004 - Initial version 3.0

 ***************************************************************************/



#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include <fcntl.h>

#include "voicerlib.h"

#include "../src_common/vbgsm.h"

#ifdef __LINUX__
	#include <unistd.h>
	#include <pthread.h>
	#include <linux/version.h>
  	#include <sys/ioctl.h>
	#include <string.h>
	#include "../src_linux/linux_api.h"
	#include "inifile.h"
#else
	#include <io.h>
	#include "../src_windows/dll/win_api.h"
	#include "../src_windows/dll/ccs/ccs.h"
#endif

#include <math.h>
#include <errno.h>

#include "vlibdef.h"
#include "generic.h"
#include "shmem.h"
#include "threads.h"
#include "e1.h"
#include "logger.h"
#include "dg_api.h"

#ifdef WIN32
	extern SET_EVENT		RecEvent[MAX_CARDS*MAX_CHANNELS_CARD];
	extern SET_EVENT		PlayEvent[MAX_CARDS*MAX_CHANNELS_CARD];
	extern SET_EVENT		TimerEvent;
#endif

extern DG_RECMEM		*rm[MAX_CARDS*MAX_CHANNELS_CARD];
extern DG_PLAYBACKMEM	*pm[MAX_CARDS*MAX_CHANNELS_CARD];
#ifdef CCS_ENABLE
	extern DG_CCS_MEMORY    *ccsm;
#endif

extern const unsigned char _st_14linear2ulaw[0x4000];
//external declarations
//extern int load_firmware (int nCardType, int cards_count, char *szFirmFile, char *szFirmPath);
extern int	f_fast;
extern int	f_verbose; 

#ifdef WIN32
	extern SET_EVENT SignalEvent[MAX_CARDS];;
	extern SET_EVENT SignalCCSEvent[MAX_CARDS];;
	extern SET_EVENT PlayEvent[MAX_CARDS*MAX_CHANNELS_CARD];
	extern DG_SHAREDMEMORY *sm;
#endif

#ifdef __LINUX__
  pthread_cond_t timer_cond = PTHREAD_COND_INITIALIZER;
  pthread_mutex_t timer_mutex = PTHREAD_MUTEX_INITIALIZER;
#endif

#ifdef __LINUX__

#ifdef DEBUG
void write_debug(char *fmt, ...)
{
			va_list argptr;
			int     ret;
			FILE    *f;
			time_t curSecs;
			struct tm *now_dbg;
			char szdbgtemp1[CCS_DATA_SIZE*4];
			char szFileName[200];
            static u32 last_time = 0;

			curSecs = time(NULL);				
			now_dbg = localtime(&curSecs);	
			sprintf(szdbgtemp1,"<%02d:%02d:%02d.%03d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec,digivoice_gettick()/*-last_time*/);

            last_time = digivoice_gettick();
			va_start(argptr, fmt);
			sprintf(szFileName,"/var/log/voicerlib/messages");
			f = fopen(szFileName, "a+");
			fprintf(f,"%s-",szdbgtemp1);
			ret = vfprintf(f,fmt,argptr);
			fprintf(f,"\n");
			fflush(f);
			fclose(f);
			
			va_end(argptr);
}
#else
void write_debug(char *fmt, ...) { }
#endif
void write_verbose(char *fmt, ...)
{
			va_list argptr;
			int     ret;
			FILE    *f;
			time_t curSecs;
			struct tm *now_dbg;
			char szdbgtemp1[200];
			char szFileName[200];
            static u32 last_time = 0;

            if (SendEventsToApp!=NULL)
            {
				curSecs = time(NULL);				
				now_dbg = localtime(&curSecs);	
				sprintf(szdbgtemp1,"<%02d:%02d:%02d.%03d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec,digivoice_gettick());
	
	            last_time = digivoice_gettick();
				va_start(argptr, fmt);
				sprintf(szFileName, "/var/log/voicerlib/verbose");
				f = fopen(szFileName, "a+");
				fprintf(f,"%s-",szdbgtemp1);
				ret = vfprintf(f,fmt,argptr);
				fprintf(f,"\n");
				fflush(f);
				fclose(f);
	
				va_end(argptr);
            }
}
#endif


WHeader  hWave;  //Header do wave

short force_all_single_span=0;

short enable_framers_auto=1;

short global_card_type;

extern u8 TXContadorGlobal[MAX_CARDS];

short CPCommands[] = {	DETECT_AUDIO,     //qualquer sinal diferente de silencio e os outros tons habilitados
						DETECT_TONE1,   //enables pure 425hz detection
						DETECT_TONE2, 	//enables pure 1100hz detection (fax)
						DETECT_TONE3,   //enables pure 2100hz detection (fax)
						DETECT_TONE4, 	//enables pure user-defined tone
						DETECT_TONE5, 	
						DETECT_TONE6,
						DETECT_TONE7,
						DETECT_TONE8
};

//array para a estrutura de controle das funcoes de discagem com supervisao
//MAKECALL_PARAMS stMakeCall[MAX_CARDS*MAX_CHANNELS_CARD];

//-----------------------------------------------------------------------------------------
// Generates events to application, protected by mutex
//-----------------------------------------------------------------------------------------
void WCDECL RaiseEvents_ThreadSafe(unsigned short command, unsigned short data, unsigned short data_aux, unsigned short port,DIGIVOICE_CRITICAL_SECTION *mtx)
{
	
	dg_event_data_structure event_to_app;
	
	digivoice_entercriticalsection(mtx, port);
	//EnterCriticalSection(mtx);
	//Fire event
	event_to_app.command = command;
	event_to_app.port = port;
	event_to_app.data = data;
	event_to_app.data_aux = data_aux;
	if (SendEventsToApp!=NULL)
	{
		//write_debug("----- RaiseEvents_ThreadSafe (%d) SendEventsToApp ", port);
		SendEventsToApp((void *)&event_to_app);
	}
	digivoice_leavecriticalsection(mtx, port);
	//LeaveCriticalSection(mtx);
	//write_debug("----- RaiseEvents_ThreadSafe (%d) 4 ", port);
}


//-----------------------------------------------------------------------------------------
// Save header at finish
//-----------------------------------------------------------------------------------------
void SaveHeaderWave(short Port, FILE *f, unsigned long size, short FileFormat)
{
	GSMHeader hGSMRecord;
	WGenericHeader hWaveFact;

	//TODO: ALTERAR PARA VOLTAR ERRO
	if (f==NULL || (Port<1 && Port>dg_GetPortsCount() ))
		return;

	rewind(f);

	if (FileFormat == ffWaveULaw || FileFormat == ffWaveALaw)
	{
		hWaveFact.riff[0] = 'R';
		hWaveFact.riff[1] = 'I';
		hWaveFact.riff[2] = 'F';
		hWaveFact.riff[3] = 'F';  // 'RIFF'
		fwrite(&hWaveFact.riff,4,1,f);

		hWaveFact.tam_arq = size+38L;  
		fwrite(&hWaveFact.tam_arq,4,1,f);

		hWaveFact.wave[0] = 'W';
		hWaveFact.wave[1] = 'A';
		hWaveFact.wave[2] = 'V';
		hWaveFact.wave[3] = 'E';  // 'WAVE'
		fwrite(&hWaveFact.wave,4,1,f);

		hWaveFact.fmt[0] = 'f';
		hWaveFact.fmt[1] = 'm';
		hWaveFact.fmt[2] = 't';
		hWaveFact.fmt[3] = ' ';   // 'fmt '
		fwrite(&hWaveFact.fmt,4,1,f);

		hWaveFact.tamanho = 18L; //16L - tamanho do bloco ate o data
		fwrite(&hWaveFact.tamanho,4,1,f);

		if (FileFormat == ffWaveULaw)
			hWaveFact.formato = 7;    // 7 lei mi
		else
			hWaveFact.formato = 6;    // 6 lei A

		fwrite(&hWaveFact.formato,2,1,f);

		hWaveFact.canais = 1;     // 1-mono, 2-stereo
		fwrite(&hWaveFact.canais,2,1,f);

		hWaveFact.freq = 8000L;    // samples/sec
		fwrite(&hWaveFact.freq,4,1,f);

		hWaveFact.bs = 8000L;            // bytes/sec
		fwrite(&hWaveFact.bs,4,1,f);

		hWaveFact.bloco = 1;    // alinhamento (canais*tamanho da amostra)
		fwrite(&hWaveFact.bloco,2,1,f);

		hWaveFact.par = 8;          // parametro especifico do formato
		fwrite(&hWaveFact.par,2,1,f);

		hWaveFact.cb = 0;  
		fwrite(&hWaveFact.cb,2,1,f);

		hWaveFact.fact[0] = 'f';
		hWaveFact.fact[1] = 'a';
		hWaveFact.fact[2] = 'c';
		hWaveFact.fact[3] = 't';
		fwrite(&hWaveFact.fact,4,1,f);

 		hWaveFact.dwFactChunkSize = 4L;
		fwrite(&hWaveFact.dwFactChunkSize,4,1,f);

 		hWaveFact.dwFactFileSize = size;
		fwrite(&hWaveFact.dwFactFileSize,4,1,f);

		hWaveFact.data[0] = 'd';
		hWaveFact.data[1] = 'a';
		hWaveFact.data[2] = 't';
		hWaveFact.data[3] = 'a';  // 'data'
		fwrite(&hWaveFact.data,4,1,f);

		hWaveFact.tm = size;  // tamanho do bloco de dados em bytes
		fwrite(&hWaveFact.tm,4,1,f);
	}
	else
	{
		if (FileFormat == ffWavePCM)
		{
			//volta ao inicio do arquivo para reescrever o header com tamanho certo
			hWaveFact.riff[0] = 'R';
			hWaveFact.riff[1] = 'I';
			hWaveFact.riff[2] = 'F';
			hWaveFact.riff[3] = 'F';  // 'RIFF'
			fwrite(&hWaveFact.riff,4,1,f);

			hWaveFact.tam_arq = size+38L;
			fwrite(&hWaveFact.tam_arq,4,1,f);

			hWaveFact.wave[0] = 'W';
			hWaveFact.wave[1] = 'A';
			hWaveFact.wave[2] = 'V';
			hWaveFact.wave[3] = 'E';  // 'WAVE'
			fwrite(&hWaveFact.wave,4,1,f);

			hWaveFact.fmt[0] = 'f';
			hWaveFact.fmt[1] = 'm';
			hWaveFact.fmt[2] = 't';
			hWaveFact.fmt[3] = ' ';   // 'fmt '
			fwrite(&hWaveFact.fmt,4,1,f);

			hWaveFact.tamanho = 18L; //16L
			fwrite(&hWaveFact.tamanho,4,1,f);

			hWaveFact.formato = 1;    // wavepcm
			fwrite(&hWaveFact.formato,2,1,f);

			hWaveFact.canais = 1;     // 1-mono, 2-stereo
			fwrite(&hWaveFact.canais,2,1,f);

			hWaveFact.freq = 8000;    // amostras/segundo
			fwrite(&hWaveFact.freq,4,1,f);

			hWaveFact.bs = 16000L;            // bytes/segundo
			fwrite(&hWaveFact.bs,4,1,f);

			hWaveFact.bloco = 2;    // alinhamento (canais*tamanho da amostra)
			fwrite(&hWaveFact.bloco,2,1,f);

			hWaveFact.par = 16;          // bits/samples
			fwrite(&hWaveFact.par,2,1,f);

			hWaveFact.cb = 0;       
			fwrite(&hWaveFact.cb,2,1,f);

			hWaveFact.data[0] = 'd';
			hWaveFact.data[1] = 'a';
			hWaveFact.data[2] = 't';
			hWaveFact.data[3] = 'a';  // 'data'
			fwrite(&hWaveFact.data,4,1,f);

			hWaveFact.tm = size;  // tamanho do bloco de dados em bytes
			fwrite(&hWaveFact.tm,4,1,f);

			write_debug("gravou header PCM");
		}
		else
		{
			if (FileFormat == ffGsm610 && FGSM_Mode==GSM_DIGIVOICE)  //header only in Digivoice format
			{
				//volta ao inicio do arquivo para reescrever o header com tamanho certo
				memset(&hGSMRecord.comments,0x20,256);
				fwrite(&hGSMRecord.comments,256,1,f);

				hGSMRecord.wavepart.riff[0] = 'R';
				hGSMRecord.wavepart.riff[1] = 'I';
				hGSMRecord.wavepart.riff[2] = 'F';
				hGSMRecord.wavepart.riff[3] = 'F';  // 'RIFF'
				fwrite(&hGSMRecord.wavepart.riff,4,1,f);

				hGSMRecord.wavepart.tam_arq = (size/2)+38;  
				fwrite(&hGSMRecord.wavepart.tam_arq,4,1,f);

				hGSMRecord.wavepart.wave[0] = 'G';
				hGSMRecord.wavepart.wave[1] = 'S';
				hGSMRecord.wavepart.wave[2] = 'M';
				hGSMRecord.wavepart.wave[3] = '6';  
				fwrite(&hGSMRecord.wavepart.wave,4,1,f);

				hGSMRecord.wavepart.fmt[0] = 'f';
				hGSMRecord.wavepart.fmt[1] = 'm';
				hGSMRecord.wavepart.fmt[2] = 't';
				hGSMRecord.wavepart.fmt[3] = ' ';   // 'fmt '
				fwrite(&hGSMRecord.wavepart.fmt,4,1,f);

				hGSMRecord.wavepart.tamanho = 18L; //16L
				fwrite(&hGSMRecord.wavepart.tamanho,4,1,f);

				hGSMRecord.wavepart.formato = 1;    // 7 lei mi
				fwrite(&hGSMRecord.wavepart.formato,2,1,f);

				hGSMRecord.wavepart.canais = 1;     // 1-mono, 2-stereo
				fwrite(&hGSMRecord.wavepart.canais,2,1,f);

				hGSMRecord.wavepart.freq = 8000;    // amostras/segundo
				fwrite(&hGSMRecord.wavepart.freq,4,1,f);

				hGSMRecord.wavepart.bs = 16000;            // bytes/segundo
				fwrite(&hGSMRecord.wavepart.bs,4,1,f);

				hGSMRecord.wavepart.bloco = 2;    // alinhamento (canais*tamanho da amostra)
				fwrite(&hGSMRecord.wavepart.bloco,2,1,f);

				hGSMRecord.wavepart.par = 16;          // parametro especifico do formato
				fwrite(&hGSMRecord.wavepart.par,4,1,f);

				hGSMRecord.wavepart.data[0] = 'd';
				hGSMRecord.wavepart.data[1] = 'a';
				hGSMRecord.wavepart.data[2] = 't';
				hGSMRecord.wavepart.data[3] = 'a';  // 'data'
				fwrite(&hGSMRecord.wavepart.data,4,1,f);
				hGSMRecord.wavepart.tm = (size/2);  // tamanho do bloco de dados em bytes
				fwrite(&hGSMRecord.wavepart.tm,4,1,f);
			}
			else
			{
		      if (FileFormat == ffWave49)
		      {
    			//volta ao inicio do arquivo para reescrever o header com tamanho certo
    			hWaveFact.riff[0] = 'R';
    			hWaveFact.riff[1] = 'I';
    			hWaveFact.riff[2] = 'F';
    			hWaveFact.riff[3] = 'F';  // 'RIFF'
    			fwrite(&hWaveFact.riff,4,1,f);

    			hWaveFact.tam_arq = size + 56;
    			fwrite(&hWaveFact.tam_arq,4,1,f);

    			hWaveFact.wave[0] = 'W';
    			hWaveFact.wave[1] = 'A';
    			hWaveFact.wave[2] = 'V';
    			hWaveFact.wave[3] = 'E';  // 'WAVE'
    			fwrite(&hWaveFact.wave,4,1,f);

    			hWaveFact.fmt[0] = 'f';
    			hWaveFact.fmt[1] = 'm';
    			hWaveFact.fmt[2] = 't';
    			hWaveFact.fmt[3] = ' ';   // 'fmt '
    			fwrite(&hWaveFact.fmt,4,1,f);

    			hWaveFact.tamanho = 20L;
    			fwrite(&hWaveFact.tamanho,4,1,f);

    			hWaveFact.formato = 49;    // wave49
    			fwrite(&hWaveFact.formato,2,1,f);

    			hWaveFact.canais = 1;     // 1-mono, 2-stereo
    			fwrite(&hWaveFact.canais,2,1,f);

    			hWaveFact.freq = 8000L;    // amostras/segundo
    			fwrite(&hWaveFact.freq,4,1,f);

    			hWaveFact.bs = 1625L;            // bytes/segundo
    			fwrite(&hWaveFact.bs,4,1,f);

    			hWaveFact.bloco = 65;    // alinhamento (canais*tamanho da amostra)
    			fwrite(&hWaveFact.bloco,2,1,f);

    			hWaveFact.par = 0;          // parametro especifico do formato
    			fwrite(&hWaveFact.par,2,1,f);

				hWaveFact.cb = 2; //20971522;
				fwrite(&hWaveFact.cb,2,1,f);

				hWaveFact.extradata[0] = 0x40;
				hWaveFact.extradata[1] = 0x01;
				fwrite(&hWaveFact.extradata[0],2,1,f);

				hWaveFact.fact[0] = 'f';
				hWaveFact.fact[1] = 'a';
				hWaveFact.fact[2] = 'c';
				hWaveFact.fact[3] = 't';
				fwrite(&hWaveFact.fact,4,1,f);

				hWaveFact.dwFactChunkSize = 4L;
				fwrite(&hWaveFact.dwFactChunkSize,4,1,f);

 				hWaveFact.dwFactFileSize = size + 56; //size
				fwrite(&hWaveFact.dwFactFileSize,4,1,f);

    			hWaveFact.data[0] = 'd';
    			hWaveFact.data[1] = 'a';
    			hWaveFact.data[2] = 't';
    			hWaveFact.data[3] = 'a';  // 'data'
    			fwrite(&hWaveFact.data,4,1,f);

    			hWaveFact.tm = size;  // tamanho do bloco de dados em bytes
	       		fwrite(&hWaveFact.tm,4,1,f);

    			write_debug("gravou header Wave49");
		      }
            }
		}
	}
	//digivoice_leavecriticalsection(&port_mutex[port-1], port);

}   //writeheader

//-----------------------------------------------------------------------------------------
// Read Wave File header
//-----------------------------------------------------------------------------------------
int ReadHeaderWave(FILE *f, void *hd, short FileFormat)
{
	GSMHeader *hGSMRecord;
	WGenericHeader *hWaveFact;
 
	if (f==NULL)
		return NOT_A_VALID_FILE;
	
	rewind(f);

	if (FileFormat == ffWaveULaw || FileFormat == ffWaveALaw || FileFormat == ffWavePCM || FileFormat == ffWave49 || FileFormat == -1)
	{
       hWaveFact=(WGenericHeader *)hd;

       fread(&hWaveFact->riff,4,1,f);
       if (strncmp(hWaveFact->riff,"RIFF",4))
	   {
		  return RIFF_NOT_FOUND;
	   }

	   fread(&hWaveFact->tam_arq,4,1,f);
	   fread(&hWaveFact->wave,4,1,f);

       if (strncmp(hWaveFact->wave,"WAVE",4))
	   {
		  return WAVE_NOT_FOUND;
	   }

	   fread(&hWaveFact->fmt,4,1,f);

       if (strncmp(hWaveFact->fmt,"fmt ",4))
	   {
		  return FMT_NOT_FOUND;
	   }

 	   fread(&hWaveFact->tamanho,4,1,f); //format chunk size
       fread(&hWaveFact->formato,2,1,f); //format tag
       fread(&hWaveFact->canais,2,1,f);  //channels
       fread(&hWaveFact->freq,4,1,f);    //samples per second
       fread(&hWaveFact->bs,4,1,f);      //average bytes per second
       fread(&hWaveFact->bloco,2,1,f);   //block align

       if(hWaveFact->tamanho>14)
       {
            fread(&hWaveFact->par,2,1,f);
            fread(&hWaveFact->cb,2,1,f);

			if(hWaveFact->tamanho==16)
				hWaveFact->cb = 0;

			if(hWaveFact->cb>0)
				fread(&hWaveFact->extradata,22,1,f);
		}

		//search 'fact chunk'
		if (dg_wave_find_str(f,"fact"))
		{
			//reads information from 'fact'
			strcpy(hWaveFact->fact,"fact");
			fread(&hWaveFact->dwFactChunkSize,4,1,f);
			fread(&hWaveFact->dwFactFileSize,4,1,f);
		}
		else
			hWaveFact->fact[0] = '\0';
		
		//search 'data chunck'
		if (dg_wave_find_str(f,"data"))
		{
			//reads information from 'fact'
			strcpy(hWaveFact->data,"data");
			fread(&hWaveFact->tm ,4,1,f);	
		}
		else
			return DATA_NOT_FOUND;
	}
	else
	{
		if (FileFormat == ffGsm610 && FGSM_Mode==GSM_DIGIVOICE)  //header only in Digivoice format
		{
			hGSMRecord=(GSMHeader *)hd;
			//volta ao inicio do arquivo para reescrever o header com tamanho certo
		    fread(&hGSMRecord->comments,256,1,f);
		    fread(&hGSMRecord->wavepart.riff,4,1,f);
            if (strncmp(hGSMRecord->wavepart.riff,"RIFF",4))
				return RIFF_NOT_FOUND;

			fread(&hGSMRecord->wavepart.tam_arq,4,1,f);
			fread(&hGSMRecord->wavepart.wave,4,1,f);

            if (strncmp(hGSMRecord->wavepart.wave,"GSM6",4))
				return WAVE_NOT_FOUND;

			fread(&hGSMRecord->wavepart.fmt,4,1,f);
            if (strncmp(hGSMRecord->wavepart.fmt,"fmt ",4))
				return FMT_NOT_FOUND;

		    fread(&hGSMRecord->wavepart.tamanho,4,1,f);
		    fread(&hGSMRecord->wavepart.formato,2,1,f);
		    fread(&hGSMRecord->wavepart.canais,2,1,f);
		    fread(&hGSMRecord->wavepart.freq,4,1,f);
		    fread(&hGSMRecord->wavepart.bs,4,1,f);
		    fread(&hGSMRecord->wavepart.bloco,2,1,f);
		    fread(&hGSMRecord->wavepart.par,4,1,f);
		    fread(&hGSMRecord->wavepart.data,4,1,f);
		    fread(&hGSMRecord->wavepart.tm,4,1,f);
		}
	}
	//digivoice_leavecriticalsection(&port_mutex[port-1], port);
	return 0;
}
//-----------------------------------------------------------------
//Converts port number (1-24) to card number and channel of card
// abs_channel = absolute number of channel 1-n
// card = will receive the card number 1-n
// card_channel = will receive the card channel of 1-n
//-----------------------------------------------------------------
short port2CardChannel(short abs_channel, short *card, short *card_channel)
{

  if (!FDriverEnabled)
      return DG_ERROR_DRIVER_CLOSED;

  if (abs_channel < 1 || abs_channel > dg_GetPortsCount())
           return DG_ERROR_PORT_OUT_OF_RANGE;


	*card = ports_info[abs_channel-1].card;
	*card_channel = ports_info[abs_channel-1].card_channel;

	//if the returned card number is out of range, must return this problem
	if (*card < 1 && *card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	return DG_EXIT_SUCCESS;

}

//----------------------------------------------------------------------
// Send command to desired channel - used in PCI/1 and PCI/4
/*
  unsigned short port;
  unsigned short command;
  unsigned short ndata;
  unsigned short data[MAX_TX_DATA_LEN];
*/
//----------------------------------------------------------------------
void write_command(unsigned short port,unsigned short command, unsigned short data_count, unsigned short* wdata)
{
  int i;
  send_command tx_command;

  tx_command.command = command;    /* copy command */
  tx_command.ndata=data_count;     /* copy data count */
  tx_command.port = port;

  if ((data_count > 0) && (wdata!=NULL))              /* copy all data */  
  {
      for(i=0;i<data_count;i++)
          tx_command.data[i]=wdata[i];
  }

  //write_generic_command(&((send_command)tx_command));
  //todo
  //prever o envio deste tipo de comando para a placa E1
#ifdef __LINUX__	//tirar!!!!!

  write_generic_command(&tx_command);
#endif
	
}
//-------------------------------------------------------------------
// This function handles alarms raising events to app
// data - alarm1  - data_aux = alarm2
/*  
	ALARM_RSLIP		= 0x00000001,		//escorregamento 
    ALARM_RAIS		= 0x00000002,		//alarme remoto
    ALARM_AISS		= 0x00000004,		//indicacao de alarme
    ALARM_AIS16S	= 0x00000008,		//indicacao de alarme canal  16
    ALARM_LOSS		= 0x00000010,		//perda de sinal
    ALARM_CRC4SYNC  = 0x00000020,		//reservado
    ALARM_MFSYNC	= 0x00000040,		//sincronismo de multiquadro
    ALARM_SYNC		= 0x00000080,		//sincronismo de quadro
*/
//-------------------------------------------------------------------
void HandleAlarms(dg_event_data_structure *received)
{
	dg_event_data_structure event_to_app;
	unsigned char alarm=0;
	short i,j;
	short e1;
	short placa=-1;
	short inicio,fim,absport;
	short max_e1=2;

	
	unsigned char check[8] = {ALARM_LOSS, ALARM_AISS, ALARM_SYNC,ALARM_AIS16S,
						ALARM_MFSYNC,ALARM_RAIS,ALARM_RSLIP,ALARM_CRC4SYNC};
	
#ifdef DEBUG_LEVEL
		if (sm->Cards[received->port-1].debug_level > 4)
		{
			write_verbose("HandleAlarms: Step 1 - [card: %d]", received->port-1);
		}
#endif//#ifdef DEBUG_LEVEL	
	
	//set event to application
	event_to_app.command = EV_E1_ALARM;
	event_to_app.card = received->port-1;	//porta manda a placa

	//write_debug("(card: %d) ALARME  recebido %x - %x",event_to_app.card, received->data, received->data_aux);

#ifdef DEBUG_LEVEL
		if (sm->Cards[event_to_app.card].debug_level > 4)
		{
			write_verbose("HandleAlarms: Step 2 - received - [card %d, data %x, data_aux %x]",
					      event_to_app.card, received->data, received->data_aux);
		}
#endif//#ifdef DEBUG_LEVEL    
    
	//reject alarm if the force_single_span option is on
	if (dg_GetCardPortsCount(received->port) <= 30)
	{
	    write_debug("(card: %d) ALARME recebido e rejeitado por ser single_span",event_to_app.card);
	    max_e1=1;
	    
#ifdef DEBUG_LEVEL
			if (sm->Cards[event_to_app.card].debug_level > 4)
			{
				write_verbose("HandleAlarms: Step 2.1 - rejected - [card %d]", event_to_app.card);
			}
#endif//#ifdef DEBUG_LEVEL	    
	}
	
	//->port is alarm for E1-A and data for E1-B
	alarm = (unsigned char)received->data;
	placa = event_to_app.card;
	for (i=0;i<max_e1;i++)
	{
		if (block_event[event_to_app.card][i] > 1)
		{
			//esperando timer minimo para gerar os eventos
			if ((digivoice_gettick() - block_event[event_to_app.card][i]) > 2000)
				block_event[event_to_app.card][i] = 0;
		}

		//write_debug("(e1: %d) ALARME recebido %x",i+1,alarm);

		//se o ALARM_LOSS estiver setado, despreza todos os outros alarmes
		if (alarm & ALARM_LOSS)
			alarm = alarm & ALARM_LOSS;
		else
			if (alarm & ALARM_AISS)   
				alarm = alarm & (ALARM_AISS);
			else
				if (alarm & ALARM_SYNC)   
					alarm = alarm & (ALARM_SYNC);
				else
					if (alarm & ALARM_AIS16S)   
						alarm = alarm & (ALARM_AIS16S);
					else
						if (alarm & ALARM_MFSYNC)
							alarm = alarm & (ALARM_MFSYNC);
						else
							if (alarm & ALARM_RAIS)   
								alarm = alarm & (ALARM_RAIS);

		//write_debug("---> (%d) ALARME tratado %x",i+1,alarm);
		for (j=0;j<8;j++)
		{
			if (((alarm & check[j])!=e1_alarm[placa][i][j])  || ((alarm & check[j])==ALARM_RSLIP))   //(alarm & check[j]) && 
			{
				event_to_app.port = i+1;		//E1_A ou E1_B
				event_to_app.data = check[j];

				if (check[j]!=ALARM_RSLIP)
				{
					if (check[j]==ALARM_LOSS)
					{
						write_debug("(e1: %d) ALARME ALARM_LOSS %x",i+1,j);
						if(alarm & check[j])
						{
							event_to_app.data_aux = ON;
							//verifica se thread E1 esta ativada e bloqueia
							//so deve resetar os canais do E1 com problemas
							if (event_to_app.port==E1_A)
							{
								inicio = 1;
								fim = 30;
							}
							else
							{
								inicio = 31;
								fim = 60;
							}
							for (e1=inicio;e1<=fim;e1++)
							{
								absport = dg_GetAbsolutePortNumber(placa+1,e1);
								if (ports_info[absport-1].e1_info.thread_id>0)
								{
									dg_InsertE1Fifo(absport,C_RESET_THREAD,0);
									ports_info[absport-1].e1_info.bBlocked = 1;
									write_debug("(e1: %d) ALARME ALARM_LOSS bloqueando canal %d",i+1,absport);
								}
							}

							//if (block_event[event_to_app.card][i]==0 )
							{
								if (SendEventsToApp!=NULL)
										SendEventsToApp((void *)&event_to_app);
								
#ifdef DEBUG_LEVEL
									if (sm->Cards[placa].debug_level > 4)
									{
										write_verbose("HandleAlarms: Step 3 - SendEventsToApp - [card %d]", placa);
									}
#endif//#ifdef DEBUG_LEVEL								
							}
							block_event[event_to_app.card][i] = 1;

						}
						else
						{
							event_to_app.data_aux = OFF;
							//verifica se thread E1 esta ativada e desbloqueia
							if (event_to_app.port==E1_A)
							{
								inicio = 1;
								fim = 30;
							}
							else
							{
								inicio = 31;
								fim = 60;
							}

							for (e1=inicio;e1<=fim;e1++)
							{
								absport = dg_GetAbsolutePortNumber(placa+1,e1);
								if (ports_info[absport-1].e1_info.thread_id>0)
								{
									ports_info[absport-1].e1_info.bBlocked = 0;
								}
							}
							block_event[event_to_app.card][i] = digivoice_gettick();
							if (SendEventsToApp!=NULL)
								SendEventsToApp((void *)&event_to_app);
							
#ifdef DEBUG_LEVEL
								if (sm->Cards[placa].debug_level > 4)
								{
									write_verbose("HandleAlarms: Step 4 - SendEventsToApp - [card %d]", placa);
								}
#endif//#ifdef DEBUG_LEVEL							

						}
					}   //if ((check[j]==ALARM_LOSS) 
					else
					{
						//qualquer outro alarme != LOSS
						if(alarm & check[j])
							event_to_app.data_aux = ON;
						else
							event_to_app.data_aux = OFF;
							
						//if (block_event[event_to_app.card][i]==0 )
							if (SendEventsToApp!=NULL)
								SendEventsToApp((void *)&event_to_app);
							
#ifdef DEBUG_LEVEL
								if (sm->Cards[placa].debug_level > 4)
								{
									write_verbose("HandleAlarms: Step 5 - SendEventsToApp - [card %d]", placa);
								}
#endif//#ifdef DEBUG_LEVEL							
					}
				}
				else
				{
					//incrementa contador de slip - escorregamento
					e1_slip_cont[placa][i]++;
					event_to_app.data_aux = e1_slip_cont[placa][i];

					if (SendEventsToApp!=NULL)
							SendEventsToApp((void *)&event_to_app);
					
#ifdef DEBUG_LEVEL
						if (sm->Cards[placa].debug_level > 4)
						{
							write_verbose("HandleAlarms: Step 6 - SendEventsToApp - [card %d]", placa);
						}
#endif//#ifdef DEBUG_LEVEL					

					last_time[placa][i][j] = digivoice_gettick();

				}

	
			}
			e1_alarm[placa][i][j] = alarm & check[j];	//store value
		}
		//next e1
		alarm = (unsigned char)received->data_aux;
	}
}

//-------------------------------------------------------------------
// This functions handles silence detection
//-------------------------------------------------------------------
void HandleSilenceDetection(dg_event_data_structure *received)
{
	unsigned short port;
	unsigned short data;

	unsigned long tick;

	//local copy
	port = received->port;
	data = received->data;

	tick = digivoice_gettick();

	//todo: inicializar last_signal
	if (data == CP_SILENCE)	
	{
		SetEnableTimer(&tmr_Silence[port-1],FALSE);

		//save last audio time
		if(ports_info[port-1].silence.last_signal != CP_SILENCE)
		{
			ports_info[port-1].silence.last_time += (ports_info[port-1].silence.audio_time/FACTOR_TIMER - tmr_Silence[port-1].OldCounter);
			write_debug("HandleSilenceDetection == CP_SILENCE -> silence.last_time (%d)  OldCounter (%d)",ports_info[port-1].silence.last_time,tmr_Silence[port-1].OldCounter);
			
			if(ports_info[port-1].silence.last_time >=ports_info[port-1].silence.audio_time/FACTOR_TIMER)
			{	
				
				//raise event 
				ports_info[port-1].silence.silence_detected = 0;
				//stops timer
				SetEnableTimer(&tmr_Silence[port-1],FALSE);
				if(ports_info[port-1].mbDetec == ON)		
				{
					write_debug("HandleSilenceDetection EV_MBDETECTED -> CP_AUDIO silence.last_time (%d)  OldCounter (%d)",ports_info[port-1].silence.last_time,tmr_Silence[port-1].OldCounter);
					//Raise MailBox event
					RaiseEvents_ThreadSafe(EV_MBDETECTED,0, 0,port,&port_mutex[port-1]);
					dg_DisableMailBoxDetection(port);
					return;
				}
				else
				{
					write_debug("HandleSilenceDetection EV_SILENCE -> CP_AUDIO silence.last_time (%d)  OldCounter (%d)",ports_info[port-1].silence.last_time,tmr_Silence[port-1].OldCounter);
					//Raise Silence event and continue to monitor
					RaiseEvents_ThreadSafe(EV_SILENCE,0, 0,port,&port_mutex[port-1]);
				}

			}
		}

		ports_info[port-1].silence.last_signal = CP_SILENCE;
		tmr_Silence[port-1].Interval = ports_info[port-1].silence.silence_time  / FACTOR_TIMER;
		SetEnableTimer(&tmr_Silence[port-1],TRUE);
		//ports_info[port-1].silence.last_silence_time = tick;
		//ports_info[port-1].silence.silence_detected = 0;
	}
	else
	{
		write_debug("HandleSilenceDetection != CP_SILENCE -> tipo (%d)",data);

		if (ports_info[port-1].silence.last_signal == CP_SILENCE && ports_info[port-1].silence.silence_detected == 1)
		{
			SetEnableTimer(&tmr_Silence[port-1],FALSE);		//turn-off timer
			ports_info[port-1].silence.last_signal = CP_AUDIO;	
			if (ports_info[port-1].silence.audio_time>0)
			{
				//check if last silence was less then 800ms
				if( ((ports_info[port-1].silence.silence_time/FACTOR_TIMER - tmr_Silence[port-1].OldCounter)*FACTOR_TIMER)< 800)
				{
					ports_info[port-1].silence.last_time += (ports_info[port-1].silence.silence_time/FACTOR_TIMER - tmr_Silence[port-1].OldCounter);
					write_debug("HandleSilenceDetection CP_AUDIO -> silence.last_time (%d) OldCounter (%d)",ports_info[port-1].silence.last_time,tmr_Silence[port-1].OldCounter);
				}
				else
				{
					ports_info[port-1].silence.last_time = 0L;
					write_debug("HandleSilenceDetection Zerou-> silence.last_time (%d)  OldCounter (%d)",ports_info[port-1].silence.last_time,tmr_Silence[port-1].OldCounter);
				}
				//if(ports_info[port-1].mbDetec == ON)
				//	ports_info[port-1].silence.silence_time =2000;

				tmr_Silence[port-1].Interval = ports_info[port-1].silence.audio_time  / FACTOR_TIMER;
				SetEnableTimer(&tmr_Silence[port-1],TRUE);
			}
			else
			{
				//raise event immediatelly if audio_time is zero
				ports_info[port-1].silence.silence_detected = 0;
				//Raise Silence event
				RaiseEvents_ThreadSafe(EV_SILENCE,0, 0,port,&port_mutex[port-1]);
				/*cmd_event.command = EV_SILENCE;
				cmd_event.port = port;			
				if (SendEventsToApp!=NULL)
					SendEventsToApp((void *)&cmd_event);*/
			}
			//ports_info[port-1].silence.last_audio_time = tick;
		}
		else
		{
			//all tones will be  considered audio, do nothing here
			//SetEnableTimer(&tmr_Silence[port-1],FALSE);		//turn-off timer
			write_debug("HandleSilenceDetection != else CP_SILENCE -> silence.last_time (%d)  OldCounter (%d)",ports_info[port-1].silence.last_time,tmr_Silence[port-1].OldCounter);
		}

	}
}
//-------------------------------------------------------------------
// This functions handles digits received from card
// det_type tells if was pulse or tone
//-------------------------------------------------------------------
void HandleDigits(dg_event_data_structure *received, short det_type)
{
	dg_event_data_structure event_to_app;

	char cRec;
	char szDig[2];
	unsigned short port;

	port = received->port;

	digivoice_entercriticalsection(&port_mutex[port-1], port);
	
	//Put dtmfs into ASCII format
	cRec = (char)(received->data+0x30);

	write_debug("Handle Digits - %x received", cRec);

	//disables pulse detection at first tone digit detected
	if (det_type==C_AUDIO)
		dg_DisablePulseDetection(port);

	switch(cRec)
	{
		case 63:
			cRec = 35;
			break;
		case 62:    //se chegar > vira *
			cRec = 42;
			break;
		case 0x3a:                //eh o 0x0a somado de 0x30
		{
			cRec = 65;   //DTMF
			//Quando o WindowProc receber o Digito mantem se for
			//DTMF ou coverte para 48 ser for dtMFC
			break;
		}
		case 0x3b:
			cRec = 66;
		break;
		case 0x3c:
			cRec = 67;
		break;
		case 0x3d:
			cRec = 68;
			break;
		break;
	}
	szDig[0] = cRec;
	szDig[1] = 0;

	//Store Digits on FDigits
	ports_info[port-1].FDigits[ports_info[port-1].stDigits.NumDigRecebido] = cRec;
	ports_info[port-1].FDigits[ports_info[port-1].stDigits.NumDigRecebido+1] = '\0';

	/*write_debug("HandleDigits: Ult Rec: %c Digitos ate agora: %s - NumDigRec = %d",
						cRec, ports_info[port-1].FDigits,ports_info[port-1].stDigits.NumDigRecebido
						);*/

	//Fires OnDigitDetected Event only if it isn't running GetDigits
	//todo: voltar
	if ((WaitDigit)ports_info[port-1].nGetDigitsState != edWaiting)
	{
		//Fire event
		event_to_app.command = EV_DTMF;
		write_debug("Handle Digits - command EV_DTMF");
		event_to_app.port = port;			
		event_to_app.data = cRec;
		if (SendEventsToApp!=NULL)
			SendEventsToApp((void *)&event_to_app);
	}
	
	/* GetDigits */
	if(ports_info[port-1].nGetDigitsState == edWaiting)
	{
		//Cancel the global timeout 
		//The global timeout is valid until the first digit only
		SetEnableTimer(&tmrDigit[port-1],FALSE);
		write_debug("HandleDigits: Desabilitou timer");	
		
		//Update digit counter
		ports_info[port-1].stDigits.NumDigRecebido++;
		write_debug("HandleDigits: NumDigRecebido = %d",ports_info[port-1].stDigits.NumDigRecebido);
		
		//------------------------------------
		//GetDigits I - only for termdigits
		//------------------------------------
		if (strlen(ports_info[port-1].stDigits.TermDigits)>0)
		{
			if (ports_info[port-1].stDigits.TermDigits[0]=='@' || (strchr(ports_info[port-1].stDigits.TermDigits,cRec)!=NULL))
			{

					//turn flag off
					ports_info[port-1].nGetDigitsState = edOff;

					//timers off
					SetEnableTimer(&tmrInterDigit[port-1],FALSE);

					//drop the term digits 
					if (strlen(ports_info[port-1].FDigits) > 1)
						ports_info[port-1].FDigits[strlen(ports_info[port-1].FDigits)-1]='\0';

					//Seta flag - recebeu digito
					ports_info[port-1].nGetDigitsState = edTermDigit;

					//Raise events
					event_to_app.command = EV_DIGITSRECEIVED;
					event_to_app.port = port;
					event_to_app.data = (short)edTermDigit;
					event_to_app.data_aux = det_type;		//passa o tipo de deteccao 
					if (SendEventsToApp!=NULL)
						SendEventsToApp((void *)&event_to_app);
			}
		}
	} //strlen(stDigits)

	//------------------------------------
	//GetDigits II - only for ranges and timeouts
	//------------------------------------
	if(ports_info[port-1].nGetDigitsState==edWaiting)
	{
			if (strlen(ports_info[port-1].FDigits) >= ports_info[port-1].stDigits.MaxDigits)
			{
				//flag off
				ports_info[port-1].nGetDigitsState = edOff;

				//timers off
				SetEnableTimer(&tmrInterDigit[port-1],FALSE);
				//Raise events
				//Alcancou o numero maximo de digitos
				event_to_app.command = EV_DIGITSRECEIVED;
				event_to_app.port = port;
				event_to_app.data = (short)edMaxDigits;
				event_to_app.data_aux = det_type;		//passa o tipo de deteccao 
				if (SendEventsToApp!=NULL)
					SendEventsToApp((void *)&event_to_app);
			}
			else
			{
				//reseta timer interdigitos
				SetEnableTimer(&tmrInterDigit[port-1],FALSE);
				SetEnableTimer(&tmrInterDigit[port-1],TRUE);
				write_debug("HandleDigits: if(ports_info[port-1].nGetDigitsState==edWaiting) reset de timer");
			}
	}						

	digivoice_leavecriticalsection(&port_mutex[port-1], port);

	/* Cut-off management during playbacks */
	write_debug("Handle Digits (%d): - Play -> play=%x (0 False / 1 True)!",port,ports_info[port-1].bIsPlaying);

	if ((ports_info[port-1].bIsPlaying || thread_playback_id[port-1]) && (strlen(ports_info[port-1].FPlayEndDigits)>0))
	{
		if (ports_info[port-1].FPlayEndDigits[0]=='@' || (strchr(ports_info[port-1].FPlayEndDigits,cRec)!=NULL))
		{
			//teste
			ports_info[port-1].play_digit_cutoff = 1;	//set digit cut-off flag
			write_debug("Handle Digits(%d) ->setou cutoff = 1! ports_info[port-1].FPlayEndDigits[0]:(%c)",port,ports_info[port-1].FPlayEndDigits[0]);
		}
	}


	/* Cut-off management during record */
	if ((ports_info[port-1].bIsRecording) &&
		(strlen(ports_info[port-1].FRecEndDigits)>0))
	{ 
			if (ports_info[port-1].FRecEndDigits[0]=='@' || 
				(strchr(ports_info[port-1].FRecEndDigits,cRec)!=NULL))  //any dtmf can interrupt
			{
				dg_StopRecordFile(port);
			}
	}						

	//Idle implementation - if the thread is active, pass events to it
	if (ports_info[port-1].idle_info.thread_id>0)
	{
		//Idle thread is running, then send commands to it
		dg_InsertIdleFifo(port, event_to_app.command, event_to_app.data);
	}
	

}

//------------------------------------------------------------------------
// Sets Playback status control
//------------------------------------------------------------------------
short SetPlayStatus(short port, short status)
{
	short card,card_channel;
	//send_command sc;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	
	//sc.port = port;
	//sc.command = status;
	//used to send gsm information
	//if (ports_info[port-1].FPlayFileFormat == ffGsm610)
	//	sc.ndata = 1;
	//else
	//	sc.ndata = 0;

	if (port2CardChannel(port, &card, &card_channel)==DG_EXIT_SUCCESS)
	{
		if (pm[port-1] != NULL)
		{
			sm->Cards[card-1].playing[card_channel-1] = status;
			sm->Cards[card-1].gsm_ready[card_channel-1] = 0;

			//O ndata esta sendo utilizado como flag de formato GSM, caso seja =1
			if ((ports_info[port-1].FPlayFileFormat == ffGsm610 || ports_info[port-1].FPlayFileFormat == ffWave49) &&  
				status != PLAY_OFF && status != PLAY_ENDING  )
			{
				sm->Cards[card-1].gsm_state_play[card_channel-1] = GSM_WAIT;
			}
			else
			{
				if ((ports_info[port-1].FPlayFileFormat != ffGsm610) && (ports_info[port-1].FPlayFileFormat != ffWave49)) //nao eh gsm
					sm->Cards[card-1].gsm_state_play[card_channel-1] = GSM_OFF;
			}
		}
		
		return DG_EXIT_SUCCESS;
	}
	else
		return DG_EXIT_FAILURE;
}

//------------------------------------------------------------------------
// Get Playback status control
//------------------------------------------------------------------------
short GetPlayStatus(short port)
{
	short card,card_channel;

	//check port
	if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port2CardChannel(port, &card, &card_channel)==DG_EXIT_SUCCESS)
		return sm->Cards[card-1].playing[card_channel-1];
	else
		return PLAY_OFF;
}

//------------------------------------------------------------------------
// Sets Input Buffer status control
//------------------------------------------------------------------------
short SetInputBufferStatus(short port, short status)
{
	short card,card_channel;

	//check port
	if (port < 1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port2CardChannel(port, &card, &card_channel)==DG_EXIT_SUCCESS)
	{
		if (rm[port-1] != NULL)
		{
			if (ports_info[port-1].FRecordFileFormat == ffGsm610 || ports_info[port-1].FRecordFileFormat == ffWave49)
				sm->Cards[card-1].gsm_state_rec[card_channel-1] = GSM_WAIT;
			else
				sm->Cards[card-1].gsm_state_rec[card_channel-1] = GSM_OFF;

			sm->Cards[card-1].input_buffer[card_channel-1] = status;

			write_debug("SetInputBufferStatus: card=%x ch=%x val=%x",card,card_channel,sm->Cards[card-1].input_buffer[card_channel-1]);
		}
		return DG_EXIT_SUCCESS;
	}
	else
		return DG_EXIT_FAILURE;

}

//------------------------------------------------------------------------
// Get Input Buffer status control
//------------------------------------------------------------------------
short GetInputBufferStatus(short port)
{
	short card,card_channel;

	//check port
	if (port < 1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port2CardChannel(port, &card, &card_channel)==DG_EXIT_SUCCESS)
		return sm->Cards[card-1].input_buffer[card_channel-1];
	else
		return INPUT_BUFFER_OFF;
	}

//-------------------------------------------------------------------------
// Enable/Disable Timers
//-------------------------------------------------------------------------
unsigned short SetEnableTimer(TTimer *stimer, unsigned short Enable)
{

	stimer->Enabled = Enable;
	if (Enable)
	{
		stimer->OldCounter = 0;
		if (stimer->Interval>=0)
			stimer->Counter = stimer->Interval;
		else
			stimer->Counter = 0;

		nGlobalTimerCount++;
		//nunca pode ser zero
		if (nGlobalTimerCount==0)
			nGlobalTimerCount++;

		//stores timer identification
		stimer->TimerHandle = nGlobalTimerCount;
	}
	else
	{
		//write_debug("SetEnableTimer: Counter=%d OldCounter=%d",stimer->Counter,stimer->OldCounter);
		//Save current counter
		if(stimer->Counter>0)
			stimer->OldCounter = stimer->Counter;
		else
			stimer->OldCounter=0;

		stimer->Counter = -1;
	}
	return stimer->TimerHandle;
}


//-------------------------------------------------------------------------
// Timer handler - each 100ms
//-------------------------------------------------------------------------
#ifdef __LINUX__
void TimerProc(int signum)
#else
//void CALLBACK TimerProc(HWND hWnd, UINT uMsg, UINT idEvent, DWORD dwTime)
void TimerProc(void)
#endif
{
	int nChannelTempTimer=0;
	short nPos;
	dg_event_data_structure received;
	u32 last_time = 0L;
	u32 actual_time= 0L;

#ifdef __LINUX__	
  struct timespec   ts;
  struct timeval    tp;
  int		 rc;

  pthread_mutex_lock(&timer_mutex);
#endif

  write_debug("Starting Global Timer");
  while(timer_thread_running==1)
  {

#ifdef __LINUX__

//#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#ifdef LINUX24
	/*  Convert from timeval to timespec */
	gettimeofday(&tp, NULL);
	ts.tv_sec  = tp.tv_sec;
	ts.tv_nsec = (tp.tv_usec * 1000) + 90*1000000L;
	//wait for a while to save cpu
	rc = pthread_cond_timedwait(&timer_cond, &timer_mutex, &ts);
#else
	digivoice_sleep(90);
#endif

#endif

#ifdef WIN32
	//sleeps for 50ms
	WaitForSingleObject(TimerEvent.hEvent,90);
#endif

	//write_debug("TimerProc \n");	
	//only enters in timer routine if the elapsed time is greater than 80ms
	actual_time = digivoice_gettick();
	if (1 /*actual_time-last_time >= 80*/)
	{
		if (tmrReset.Enabled)
		{
			if (tmrReset.Counter == 0)
			{
				tempo_entre_reset = 0;
				tmrReset.Enabled = FALSE;
				SetEnableTimer(&tmrReset,FALSE);
			}
			else
				tmrReset.Counter--;
		}
		//----------------------------------------------------------------
		//Channels looping
		//----------------------------------------------------------------
		for (nChannelTempTimer=0;nChannelTempTimer<nPortsCount;nChannelTempTimer++)
		{

			nPos = nChannelTempTimer; // + (nCardTempTimer*nPortsCount);

            //-------------------------------------------------------------------
            // Handle silence detection
            //-------------------------------------------------------------------
            if (tmr_CPStart[nPos].Enabled)
            {
                if (tmr_CPStart[nPos].Counter == 0)
                {
                    tmr_CPStart[nPos].Enabled = FALSE;
                    SetEnableTimer(&tmr_CPStart[nPos],FALSE);
                    if(ports_info[nPos].cp_info.thread_ready==1)
                    {
                        write_debug("tmr_CPStart (%d): Send C_SET_CALLPROGRESS\n",nPos+1);
                        dg_InsertCPFifo(nPos+1, C_SET_CALLPROGRESS, ports_info[nPos].cp_info.cptype);
                    }
                    else
                    {
                        write_debug("tmr_CPStart (%d): Waiting for thread\n",nPos+1);
                        tmr_CPStart[nPos].Enabled = TRUE;
                        SetEnableTimer(&tmr_CPStart[nPos],TRUE);
                    }
                }
                else
                    tmr_CPStart[nPos].Counter--;

            }
			//-------------------------------------------------------------------
			// Handle silence detection
			//-------------------------------------------------------------------
			if (tmr_Silence[nPos].Enabled)
			{
				if (tmr_Silence[nPos].Counter == 0)
				{

					tmr_Silence[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_Silence[nPos],FALSE);

					if (ports_info[nPos].silence.last_signal==CP_SILENCE)
					{
						ports_info[nPos].silence.silence_detected = 1;
						received.data = 1;
					}
					else
					{
						ports_info[nPos].silence.silence_detected = 0;
						received.data = 0;
					}
					//Raise Silence event
					received.port = nPos+1;
					//deteccao de secretaria eletronica
					if(ports_info[nPos].mbDetec == ON)
					{
						RaiseEvents_ThreadSafe(EV_MBDETECTED,received.data,  0,received.port,&port_mutex[received.port-1]);
						dg_DisableMailBoxDetection(received.port);
					}
					else
						RaiseEvents_ThreadSafe(EV_SILENCE,received.data,  0,received.port,&port_mutex[received.port-1]);
					
				}
				else
					tmr_Silence[nPos].Counter--;
			}



			//-------------------------------------------------------------------
			// Handle OnCalling events under E1 thread - outgoing calls
			//-------------------------------------------------------------------
			if (tmrCallProgress[nPos].Enabled)
			{
				if (tmrCallProgress[nPos].Counter == 0)
				{

					tmrCallProgress[nPos].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[nPos],FALSE);
					//Raise OnCalling event
					received.command = EV_CALLING;
					received.port = nPos+1;			
					received.data = 0;
					RaiseEvents_ThreadSafe(EV_CALLING,received.data,  0,received.port,&port_mutex[received.port-1]);

					/*if (SendEventsToApp!=NULL)
						SendEventsToApp((void *)&received);*/
					dg_InsertE1Fifo(nPos+1,C_CALLPROGRESS,1);	//0 manda religar o timer

				}
				else
					tmrCallProgress[nPos].Counter--;
				
			}

			//----------------------------------------------------------------
			//************ Timer E1 timeouts ****************
			//----------------------------------------------------------------
			if (tmr_E1[nPos].Enabled)
			{
				if (tmr_E1[nPos].Counter == 0)
				{
					tmr_E1[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_E1[nPos],FALSE);
					//Raise ...

					//Send timeout command to E1 FIFO
					dg_InsertE1Fifo(nPos+1,C_TIMEOUT,tmr_E1[nPos].TimerHandle);
				}
				else
					tmr_E1[nPos].Counter--;
			}

			//----------------------------------------------------------------
			//************ Timer GSM timeouts ****************
			//----------------------------------------------------------------
			if (tmr_GSM[nPos].Enabled)
			{
				if (tmr_GSM[nPos].Counter == 0)
				{
					tmr_GSM[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_GSM[nPos],FALSE);
					//Raise ...

					//Send timeout command to GSM FIFO
					dg_InsertGSMFifo(nPos+1,C_TIMEOUT,tmr_GSM[nPos].TimerHandle);
				}
				else
					tmr_GSM[nPos].Counter--;
			}

			//----------------------------------------------------------------
			//************ Timer GSM Wait timeouts ****************
			//----------------------------------------------------------------
			if (tmr_GSM_Wait[nPos].Enabled)
			{
				if (tmr_GSM_Wait[nPos].Counter == 0)
				{
					tmr_GSM_Wait[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_GSM_Wait[nPos],FALSE);
					//Raise ...

					//Send timeout command to GSM FIFO
					dg_InsertGSMFifo(nPos+1,C_TIMEOUT,tmr_GSM_Wait[nPos].TimerHandle);
				}
				else
					tmr_GSM_Wait[nPos].Counter--;
			}

			//------------------------------------------------------------------------
			//************ Timer GSM Wait to enable dg_GSMClearAllSMS ****************
			//------------------------------------------------------------------------
			if (tmr_GSM_ClearAllSMS[nPos].Enabled)
			{
				if (tmr_GSM_ClearAllSMS[nPos].Counter == 0)
				{
					tmr_GSM_ClearAllSMS[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_GSM_ClearAllSMS[nPos],FALSE);
					//Raise ...

					//Send timeout command to GSM FIFO
					dg_InsertGSMFifo(nPos+1,C_TIMEOUT,tmr_GSM_ClearAllSMS[nPos].TimerHandle);
				}
				else
					tmr_GSM_ClearAllSMS[nPos].Counter--;
			}

			//----------------------------------------------------------------
			//************ Timer Callprogress timeouts ****************
			//----------------------------------------------------------------
			if (tmr_CPThread[nPos].Enabled)
			{
				if (tmr_CPThread[nPos].Counter == 0)
				{
					tmr_CPThread[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_CPThread[nPos],FALSE);
					//Raise ...

					//Send timeout command to FIFO
					dg_InsertCPFifo(nPos+1,C_TIMEOUT,tmr_CPThread[nPos].TimerHandle);
				}
				else
					tmr_CPThread[nPos].Counter--;
			}
				
			
			//----------------------------------------------------------------
			//************ Idle thread timer
			//----------------------------------------------------------------
			if (tmr_IdleThread[nPos].Enabled)
			{
				if (tmr_IdleThread[nPos].Counter == 0)
				{
					tmr_IdleThread[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_IdleThread[nPos],FALSE);
					//Raise ...

					//Send timeout command to FIFO
					dg_InsertIdleFifo(nPos+1,C_TIMEOUT,tmr_IdleThread[nPos].TimerHandle);
				}
				else
					tmr_IdleThread[nPos].Counter--;
			}

			//----------------------------------------------------------------
			//************ Timer Callprogress - for audio detections only 
			//----------------------------------------------------------------
			if (tmr_CP_AudioCtrl[nPos].Enabled)
			{
				if (tmr_CP_AudioCtrl[nPos].Counter == 0)
				{
					tmr_CP_AudioCtrl[nPos].Enabled = FALSE;
					SetEnableTimer(&tmr_CP_AudioCtrl[nPos],FALSE);
					//Raise ...

					//Send timeout command to FIFO
					dg_InsertCPFifo(nPos+1,C_TIMEOUT_AUDIO,tmr_CP_AudioCtrl[nPos].TimerHandle);
				}
				else
					tmr_CP_AudioCtrl[nPos].Counter--;
			}

			//-------------------------------------------------------------------
			// Handle ring events under E1 thread - incoming calls
			//-------------------------------------------------------------------
			if (tmrRing[nPos].Enabled)
			{
				if (tmrRing[nPos].Counter == 0)
				{

					write_debug("(%d) tmrRing - EVENTO",nPos+1);
					tmrRing[nPos].Enabled = FALSE;
					SetEnableTimer(&tmrRing[nPos],FALSE);
					
					if (ports_info[nPos].e1_info.ring_event==0)
					{
						//zero - para tom e espera + 4 segundos
						//C_RING
						dg_InsertE1Fifo(nPos+1,C_RING,0);	//0 manda desligar ring
					}
					else
					{

						write_debug("(%d) tmrRing - Enviando C_RING para thread E1",nPos+1);
						dg_InsertE1Fifo(nPos+1,C_RING,1);

						//Raise OnCalling event
						//ports_info[nPos].e1_info.ring_event = 0;
						/*received.command = EV_RINGS;
						received.port = nPos+1;			
						received.data = 0;
						RaiseEvents_ThreadSafe(EV_RINGS,received.data,  0,received.port,&port_mutex[received.port-1]);*/
						/*if (SendEventsToApp!=NULL)
							SendEventsToApp((void *)&received);*/
					}
				}
				else
					tmrRing[nPos].Counter--;
			}
						
			//----------------------------------------------------------------
			//************ Timer AfterDial ****************
			//----------------------------------------------------------------
			if (tmrAfterDial[nPos].Enabled)
			{
				if (tmrAfterDial[nPos].Counter == 0)
				{
					
					tmrAfterDial[nPos].Enabled = FALSE;
					SetEnableTimer(&tmrAfterDial[nPos],FALSE);
					//Raise OnAfterDial event
					received.command = EV_AFTERDIAL;
					received.port = nPos+1;			
					received.data = 0;
					RaiseEvents_ThreadSafe(received.command,received.data,  0,received.port,&port_mutex[received.port-1]);					
					/*if (SendEventsToApp!=NULL)
						SendEventsToApp((void *)&received);*/
				}
				else
					tmrAfterDial[nPos].Counter--;
			}
						
			//----------------------------------------------------------------
			//************ Timer AfterFlash ****************
			//----------------------------------------------------------------
			if (tmrAfterFlash[nPos].Enabled)
			{

				if (tmrAfterFlash[nPos].Counter == 0)
				{

					tmrAfterFlash[nPos].Enabled = FALSE;
					SetEnableTimer(&tmrAfterFlash[nPos],FALSE);
					//Raise OnAfterDial event
					received.command = EV_AFTERFLASH;
					received.port = nPos+1;			
					received.data = 0;
					RaiseEvents_ThreadSafe(received.command,received.data,  0,received.port,&port_mutex[received.port-1]);	
					/*if (SendEventsToApp!=NULL)
						SendEventsToApp((void *)&received);*/

				}
				else
					tmrAfterFlash[nPos].Counter--;
			}
			
			//----------------------------------------------------------------
			//************ Timer OnRecording ****************
			//----------------------------------------------------------------
			if (tmrTimeRec[nPos].Enabled)
			{
				if (tmrTimeRec[nPos].Counter == 0)
				{
					tmrTimeRec[nPos].Enabled = FALSE;
					SetEnableTimer(&tmrTimeRec[nPos],FALSE);
					//Raise OnRecording event
					if (ports_info[nPos].bRecPaused==0)
					{
						received.command = EV_RECORDING;
						received.port = nPos+1;			
						//put here the elapsed time!!!!!
						received.data = (unsigned short)ports_info[nPos].lElapsedRecTime++;;
						//dbg(received.port,"EV_RECORDING: Entra Recording %ds...",received.data);
						RaiseEvents_ThreadSafe(received.command,received.data,  0,received.port,&port_mutex[received.port-1]);	
						//dbg(received.port,"EV_RECORDING: Sai Recording %ds...",received.data);
						/*if (SendEventsToApp!=NULL)
							SendEventsToApp((void *)&received);*/
					}
					//if the program is still recording, enables the timer again
					if (ports_info[nPos].bIsRecording)
					{
						//reenable timer
						tmrTimeRec[nPos].Enabled = TRUE;
						tmrTimeRec[nPos].Interval = 900 / FACTOR_TIMER;
						SetEnableTimer(&tmrTimeRec[nPos],TRUE);
					}
					else
					{
						write_debug("(%d) tmrTimeRec: ",nPos+1);
						//Sem pausa
						ports_info[nPos].bRecPaused = FALSE;
						ports_info[nPos].bStopping = FALSE;	//desliga flag 
						//raise OnRecordStop event
/*						received.command = EV_RECORDSTOP;
						received.port = nPos+1;
						received.data = 0;
						if (SendEventsToApp!=NULL)
							SendEventsToApp((void *)&received);*/

					}
				}
				else
					tmrTimeRec[nPos].Counter--;
			}
			
			//----------------------------------------------------------------
			//************ Timer do AfterPickUp ***************
			//----------------------------------------------------------------
			if (tmrAfterPickUp[nPos].Enabled)
			{				
				if (tmrAfterPickUp[nPos].Counter == 0)
				{
					tmrAfterPickUp[nPos].Enabled = FALSE;
					SetEnableTimer(&tmrAfterPickUp[nPos],FALSE);
					received.command = EV_AFTERPICKUP;
					received.port = nPos+1;			
					received.data = 0;
					RaiseEvents_ThreadSafe(received.command,received.data,  0,received.port,&port_mutex[received.port-1]);
					/*if (SendEventsToApp!=NULL)
						SendEventsToApp((void *)&received);*/
					
				}
				else
					tmrAfterPickUp[nPos].Counter--;
			}
		
			//----------------------------------------------------------------
			//************ Timer InterDigit GetDifgits ***************
			//----------------------------------------------------------------
			if (tmrInterDigit[nPos].Enabled)
			{
				if (tmrInterDigit[nPos].Counter == 0)
				{
					SetEnableTimer(&tmrDigit[nPos],FALSE);
					SetEnableTimer(&tmrInterDigit[nPos],FALSE);
					
					received.command = EV_DIGITSRECEIVED;
					received.port = nPos+1;
					received.data = (short)edInterDigitTimeOut;
					received.data_aux = 0;		
					RaiseEvents_ThreadSafe(received.command,received.data,  0,received.port,&port_mutex[received.port-1]);
					/*if (SendEventsToApp!=NULL)
						SendEventsToApp((void *)&received);*/

					//?? dg_CancelGetDigits(nPos+1);
					ports_info[nPos].FStatusPort = spNone;
					ports_info[nPos].nGetDigitsState = edOff;
					//Idle implementation - if the thread is active, pass events to it
					if (ports_info[nPos].idle_info.thread_id>0)
					{
						//Idle thread is running, then send commands to it
						dg_InsertIdleFifo(nPos+1, received.command, received.data);
					}
				}
				else
					tmrInterDigit[nPos].Counter--;
			}
			//----------------------------------------------------------------
			//************ Timer Global GetDigits ***************
			//----------------------------------------------------------------
			if (tmrDigit[nPos].Enabled)
			{
				
				if (tmrDigit[nPos].Counter == 0)
				{
					SetEnableTimer(&tmrDigit[nPos],FALSE);
					SetEnableTimer(&tmrInterDigit[nPos],FALSE);
					
					received.command = EV_DIGITSRECEIVED;
					received.port = nPos+1;
					received.data = (short)edDigitTimeOut;
					received.data_aux = 0;		
					RaiseEvents_ThreadSafe(received.command,received.data,  0,received.port,&port_mutex[received.port-1]);
					/*if (SendEventsToApp!=NULL)
						SendEventsToApp((void *)&received);*/

					//dg_CancelGetDigits(nPos+1);
					ports_info[nPos].FStatusPort = spNone;
					ports_info[nPos].nGetDigitsState = edOff;
					//Idle implementation - if the thread is active, pass events to it
					if (ports_info[nPos].idle_info.thread_id>0)
					{
						//Idle thread is running, then send commands to it
						dg_InsertIdleFifo(nPos+1, received.command, received.data);
					}
				}
				else
					tmrDigit[nPos].Counter--;
			}						

		} // looping channels
  		//save last time
		last_time = digivoice_gettick();
	  } //if last_time
   } //end of infinite while

#ifdef __LINUX__
  pthread_mutex_unlock(&timer_mutex);
#endif
	timer_thread_running = 0;
    write_debug("TimerProc -> Thread finished.....................................");
}


//-------------------------------------------------------------------------
// Sets the config file's path+filename
//-------------------------------------------------------------------------
/*short dg_setconfigfile(char *szFileName)
{
    if (strlen(szFileName) > 0 && strlen(szFileName) < DG_MAX_PATH)
    {
        strncpy(szConfigFile, szFileName, DG_MAX_PATH);
        return DG_EXIT_SUCCESS;
    }
    else
        return EXIT_DEFAULTERROR;
} */


/*---------------------------------------------------------------------------
 Bus setup - E1 / H100 / DSP
 conn_type
		|____H100_RESET -> reset all

		|___ LOCAL_LOCAL (E1->E1, E1->DSP, DSP->DSP, DSP->E1)
				|____ param1 - source (0-63 E1) or (128-191 DSP)
			    |____ param2 - target (0-63 E1) or (128-191 DSP)
				|____ param3 - not used
				|____ param4 - not used old card / DG_ENABLE/DG_DISABLE placa VB6060PCI
		|___ LOCAL_H100   (E1->H100, DSP->H100)
				|____ param1 - *source* (0-63 E1) or (128-191 DSP)
				|____ param2 - H100 frame *target* (0-31)
				|____ param3 - H100 slot *target* (0-127)
				|____ param4 - not used old card / DG_ENABLE/DG_DISABLE placa VB6060PCI
		|___ H100_LOCAL (H100->E1, H100->DSP)
				|____ param1 - *target* (0-63 E1) or (128-191 DSP)
				|____ param2 - H100 frame *source* (0-31)
				|____ param3 - H100 slot *source* (0-127)
				|____ param4 - not used old card / DG_ENABLE/DG_DISABLE placa VB6060PCI

		//*** Estes 2 abaixo nao existem para a palca VB6060PCI ****

		|___ H100_H100_CH - bus channel to be disabled allowing connection
		                    between two H100 channels
				|____ param1 - local bus channel to be disabled (0-255)
		|___ H100_H100_SW - link two H100 channels through local bus channel
				|____ param1 - H100 frame *source* (0-31)
				|____ param2 - H100 slot *source* (0-127)
				|____ param3 - H100 frame *target* (0-31)
				|____ param4 - H100 slot *target* (0-127)

//----- IMPORTANTE!!!!!! --------
Quando conecta os barramentos, a taxa de transferencia nao esta definida
portanto e necessario da primeira vez definir esta taxa de transferencia 
usando o comando

dg_SetH100(placa, H100_STREAM_RATE, <XXXX>, <YYYY>)

 XXXX podendo ser :  
 H100_ST_0_3=0,
 H100_ST_4_7=2, 
 H100_ST_8_11=4,
 H100_ST_12_15=6,			// *** eh necessario fazer uma chamada pra cada linha definida
 //placa VB6060pci
 H100_ST_16_19=8,
 H100_ST_20_23=10,
 H100_ST_24_27=12,
 H100_ST_28_31=14

 <YYYY> podendo ser:
 H100_ST_2048,
 H100_ST_4096,
 H100_ST_8192,		<----- Usar como padrao
 H100_ST_DISABLE


 O uso normal eh com 8M:

 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_0_3 , H100_ST_8192);
 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_4_7, H100_ST_8192);
 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_8_11, H100_ST_8192);
 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_12_15, H100_ST_8192);
 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_16_19, H100_ST_8192);
 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_20_23, H100_ST_8192);
 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_24_27, H100_ST_8192);
 dg_SetH100(placa, H100_STREAM_RATE, H100_ST_28_31, H100_ST_8192);

 (*) Utiliza o parametro RX_TX no comando de conexao (CMD_CONECTA). 
 Sem o H100 o E1 esta sempre conectado no DSP. O que e possivel e conectar o 
 audio que entra (RX) e mandar para  saida (TX) de qualquer canal.
 param1=origem param2=destino
 (*) params, tem que ser de 0 a 59
---------------------------------------------------------------------------*/
short WCDECL dg_ConnectBus(unsigned short card, unsigned char conn_type, unsigned char param1,
									unsigned char param2,unsigned char param3)
{

	dg_cmd_tx tx_command_e1;

    if (!FDriverEnabled)
            return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	//check consistency based on conn_type
	switch(conn_type)
	{
		case LOCAL_LOCAL:
			/* check E1 and DSP ranges */
			if ( (/*param1 < 0 || */param1 > 191) ||
					(param1 > 63 && param1 < 128) )
					return DG_ERROR_PORT_OUT_OF_RANGE;
			if ( (param2 > 191) ||
					(param2 > 63 && param2 < 128) )
					return DG_ERROR_PORT_OUT_OF_RANGE;

			break;
		case  LOCAL_H100:
		case  H100_LOCAL:
			if ( (param1 > 187) ||    //e1 and dsp
					(param1 > 63 && param1 < 128) )
					return DG_ERROR_PORT_OUT_OF_RANGE;
			if ( param2 > 31)	//frame
				return DG_ERROR_PORT_OUT_OF_RANGE;
			if ( param3 > 127) //slot
				return DG_ERROR_PORT_OUT_OF_RANGE;
			break;
		case  H100_H100_CH:
			break;
		case  H100_H100_SW:
			if (  param1 > 31)	//frame
				return DG_ERROR_PORT_OUT_OF_RANGE;
			if (  param2 > 127) //slot
				return DG_ERROR_PORT_OUT_OF_RANGE;
			if (  param3 > 31)	//frame
				return DG_ERROR_PORT_OUT_OF_RANGE;
			break;
		case  RX_TX:
			//connect locally
			if ( (param1 > 59))
					return DG_ERROR_PORT_OUT_OF_RANGE;
			if ( (param2 > 59))
					return DG_ERROR_PORT_OUT_OF_RANGE;

			break;

		default:
			//invalid conn_type
			return DG_ERROR_INVALIDPARAM;
			break;
	}

	//send commands
	tx_command_e1.command = CMD_SETBUSCONNECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);

	//new e1 card vb6060pci needs to pass ON/OFF at param4 or param3 (only for LOCAL_LOCAL)
	//if (sm->Cards[card-1].CardType == VBE16060PCI && conn_type == LOCAL_LOCAL)
	//	param3 = param4;

	tx_command_e1.param1 = conn_type;
	tx_command_e1.param2 = param1;
	tx_command_e1.param3 = param2;
	tx_command_e1.param4 = param3;
	tx_command_e1.param5 = ON;

	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;

}
//---------------------------------------------------------------
//Disconnect resource from BUS
//---------------------------------------------------------------
short WCDECL dg_DisconnectBus(unsigned short card, unsigned char conn_type, unsigned char param1,
									unsigned char param2,unsigned char param3)
{

	dg_cmd_tx tx_command_e1;

    if (!FDriverEnabled)
            return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	//check consistency based on conn_type
	switch(conn_type)
	{
		case LOCAL_LOCAL:
			/* check E1 and DSP ranges */
			if ( (/*param1 < 0 || */param1 > 191) ||
					(param1 > 63 && param1 < 128) )
					return DG_ERROR_PORT_OUT_OF_RANGE;
			if ( (param2 > 191) ||
					(param2 > 63 && param2 < 128) )
					return DG_ERROR_PORT_OUT_OF_RANGE;

			break;
		case  LOCAL_H100:
		case  H100_LOCAL:
			if ( (param1 > 187) ||    //e1 and dsp
					(param1 > 63 && param1 < 128) )
					return DG_ERROR_PORT_OUT_OF_RANGE;
			if ( param2 > 31)	//frame
				return DG_ERROR_PORT_OUT_OF_RANGE;
			if ( param3 > 127) //slot
				return DG_ERROR_PORT_OUT_OF_RANGE;
			break;
		case  H100_H100_CH:
			break;
		case  H100_H100_SW:
			if (  param1 > 31)	//frame
				return DG_ERROR_PORT_OUT_OF_RANGE;
			if (  param2 > 127) //slot
				return DG_ERROR_PORT_OUT_OF_RANGE;
			if (  param3 > 31)	//frame
				return DG_ERROR_PORT_OUT_OF_RANGE;
			break;
		case  RX_TX:
			//disconnect locally
			break;
		default:
			//invalid conn_type
			return DG_ERROR_INVALIDPARAM;
			break;
	}

	//send commands
	tx_command_e1.command = CMD_SETBUSCONNECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);

	//new e1 card vb6060pci needs to pass ON/OFF at param4 or param3 (only for LOCAL_LOCAL)
/*	if (sm->Cards[card-1].CardType == VBE16060PCI && conn_type == LOCAL_LOCAL)
		param3 = param4;*/

	tx_command_e1.param1 = conn_type;
	tx_command_e1.param2 = param1;
	tx_command_e1.param3 = param2;
	tx_command_e1.param4 = param3;
	tx_command_e1.param5 = OFF;

	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;

}

/*-------------------------------------------------------------------------------
  Setup H100 Synchronism (CMD_H100_CFG)
  
  H100type		 param1				param2
  ============	 ============		=================
->	H100_MASTER
			|_____ H100_MS_SEL
								|_____  H100_MS_DISABLE=0
 								|_____  H100_MS_CT_A=1
 								|_____  H100_MS_CT_B=3

			|_____ H100_MS_REF
								|_____  H100_MS_NONE=0
								|_____  H100_MS_CT_NETREF1=6
								|_____  H100_MS_CT_NETREF2=7
								|_____  H100_MS_L_NETREF0=8
								|_____  H100_MS_L_NETREF1=,
								|_____  H100_MS_L_NETREF2=10

			|_____ H100_MS_REFFR
								|_____  H100_MS_8KHz=0
								|_____  H100_MS_1536MHz=1
								|_____  H100_MS_1544MHz=2
								|_____  H100_MS_2048MHz=3

->	H100_SLAVE            (param2 not used)
			|_____  H100_SL_CT_A
			|_____  H100_SL_CT_B
			|_____  H100_SL_SCBUS
			|_____  H100_SL_MVIP
			|_____  H100_SL_LOCAL0
			|_____  H100_SL_LOCAL1
 
->	H100_CT_NETREF
			|_____  H100_REF_SOURCE1
								|_____  H100_REF_NONE=0
								|_____  H100_REF_L_NETREF0=8		//canal 1
								|_____  H100_REF_L_NETREF1=9		//canal 2
								|_____  H100_REF_L_NETREF2=10		//interno
			|_____  H100_REF_SOURCE2
								|_____  H100_REF_NONE=0
								|_____  H100_REF_L_NETREF0=8
								|_____  H100_REF_L_NETREF1=9
								|_____  H100_REF_L_NETREF2=10
			|_____  H100_REF_DIV1
								|_____  H100_REF_D1
								|_____  H100_REF_D192
								|_____  H100_REF_D193
								|_____  H100_REF_D256
			|_____  H100_REF_DIV2
								|_____  H100_REF_D1
								|_____  H100_REF_D192
								|_____  H100_REF_D193
								|_____  H100_REF_D256
 
->	H100_SCBUS
			|_____ H100_SC_SEL
								|_____  H100_SC_ENABLE=1
								|_____  H100_SC_DISABLE=0
			|_____ H100_SC_FREQ
								|_____  H100_SC_2048
								|_____  H100_SC_4096
								|_____  H100_SC_8192

->	H100_MVIP90					(param2 not used)
			|_____ H100_MV_ENABLE=1
			|_____ H100_MV_DISABLE=0

->	H100_HMVIP					(param2 not used)
 			|_____ H100_HMV_ENABLE=1
 			|_____ H100_HMV_DISABLE=0

->	H100_TERMINAL				(param2 not used)
 			|_____ H100_TERM_ENABLE=1
 			|_____ H100_TERM_DISABLE=0

->	H100_STREAM_RATE			
 			|_____ H100_ST_0_3=0
								|_____  H100_ST_2048
								|_____  H100_ST_4096
								|_____  H100_ST_8192
 			|_____ H100_ST_4_7=2
								|_____  H100_ST_2048
								|_____  H100_ST_4096
								|_____  H100_ST_8192
 			|_____ H100_ST_8_11=4
								|_____  H100_ST_2048
								|_____  H100_ST_4096
								|_____  H100_ST_8192
 			|_____ H100_ST_12_15=6
								|_____  H100_ST_2048
								|_____  H100_ST_4096
								|_____  H100_ST_8192

-------------------------------------------------------------------------------*/
short WCDECL dg_SetH100(unsigned short card, unsigned char h100type,
									unsigned char param2,unsigned char param3)
{
	dg_cmd_tx tx_command_e1;

	//consistency
	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	//send commands
	tx_command_e1.command = CMD_H100_CFG;

	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);
	tx_command_e1.param1 = h100type;
	tx_command_e1.param2 = param2;
	tx_command_e1.param3 = param3;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&tx_command_e1);

	//salva informacoes para reset
	/*fReset = fopen(szResetFile,"a+t");
	fprintf(fReset,"%d %d %d %d \n",card,h100type,param2,param3);
	fclose(fReset);*/

	return DG_EXIT_SUCCESS;

}

//---------------------------------------------------------------------------
// dg_SetCardSyncMode configure card to work with a preset synch
// SyncMode values:
//		SYNC_INTERNAL
//		SYNC_LINE_A
//      SYNC_LINE_B
//		SYNC_H100_CT_A
//		SYNC_H100_CT_B:
//		SYNC_H100_SCBUS_2048:		
//		SYNC_H100_SCBUS_4096:		
//		SYNC_H100_SCBUS_8192:		
//		SYNC_H100_MVIP:
//		SYNC_H100_H_MVIP:
//		SYNC_H100_CT_NETREF:
//		SYNC_H100_CLK_LINE_B:
//		SYNC_H100_CLK_LINE_A:
//		SYNC_H100_INTERNAL:
// TODO: documentar
//---------------------------------------------------------------------------
short WCDECL dg_SetCardSyncMode(unsigned short card, unsigned short SyncMode)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	switch(SyncMode)
	{
		
		case SYNC_INTERNAL: //ou MASTER_INTERNAL_SYNC:			
			if (sm->Cards[card-1].CardType==VBE16060PCI || sm->Cards[card-1].CardType==VBE16060PCI_R || sm->Cards[card-1].CardType==VBE13030PCI ||
				sm->Cards[card-1].CardType==VB3030PCIE || sm->Cards[card-1].CardType==VB6060PCIE ||
				sm->Cards[card-1].CardType==DGV_1E1F || sm->Cards[card-1].CardType==DGV_2E1F)
			{
				//VB6060PCI
				dg_SetH100(card,H100_SYNC, SYNC_INTERNAL, 0);				
			}
			else
			{
				//indica referencia interna
				dg_SetH100(card,H100_CT_NETREF,H100_REF_SOURCE1,H100_REF_L_NETREF2);
				//seta a fonte do sinal  com referencia em 2Mega (H100_REF_DIV1)
				//e usando fator de divisao H100_REF_D256 para ficar em 8Khz
				dg_SetH100(card,H100_CT_NETREF,H100_REF_DIV1,H100_REF_D256);
				//e esse seta qual a referencia do comando acima
				dg_SetH100(card,H100_MASTER, H100_MS_REFFR,H100_MS_8KHz);
				//O master deve sincronizar se baseando numa referencia. Essa funcao
				//indica qual eh essa referencia
				dg_SetH100(card,H100_MASTER, H100_MS_REF,H100_MS_CT_NETREF1);
				//liga opcao MASTER e indica qual CTBUS gerara o clock
				dg_SetH100(card,H100_MASTER, H100_MS_SEL,H100_MS_CT_A);
				//desliga opcao slave
				dg_SetH100(card,H100_SLAVE, H100_SL_CT_A,0);
			}

			break;
		
		case SYNC_LINE_A:	//ou MASTER_SYNC_A
			if (sm->Cards[card-1].CardType==VBE16060PCI || sm->Cards[card-1].CardType==VBE16060PCI_R || sm->Cards[card-1].CardType==VBE13030PCI ||
				sm->Cards[card-1].CardType==VB3030PCIE || sm->Cards[card-1].CardType==VB6060PCIE ||
				sm->Cards[card-1].CardType==DGV_1E1F || sm->Cards[card-1].CardType==DGV_2E1F)
			{
				//VB6060PCI
				dg_SetH100(card,H100_SYNC, SYNC_LINE_A, 0);
			}
			else
			{
				//indica referencia interna
				dg_SetH100(card,H100_CT_NETREF,H100_REF_SOURCE1,H100_REF_L_NETREF0);
				//seta a fonte do sinal  com referencia em 2Mega (H100_REF_DIV1)
				//e usando fator de divisao H100_REF_D256 para ficar em 8Khz
				dg_SetH100(card,H100_CT_NETREF,H100_REF_DIV1,H100_REF_D256);
				//e esse seta qual a referencia do comando acima
				dg_SetH100(card,H100_MASTER, H100_MS_REFFR,H100_MS_8KHz);
				//O master deve sincronizar se baseando numa referencia. Essa funcao
				//indica qual eh essa referencia
				dg_SetH100(card,H100_MASTER, H100_MS_REF,H100_MS_CT_NETREF1);
				//liga opcao MASTER e indica qual CTBUS gerara o clock
				dg_SetH100(card,H100_MASTER, H100_MS_SEL,H100_MS_CT_A);
				//desliga opcao slave
				dg_SetH100(card,H100_SLAVE, H100_SL_CT_A,0);
			}
			break;
		
		case SYNC_LINE_B:	//ou MASTER_SYNC_B
			if (sm->Cards[card-1].CardType==VBE16060PCI || sm->Cards[card-1].CardType==VBE16060PCI_R || sm->Cards[card-1].CardType==VBE13030PCI ||
				sm->Cards[card-1].CardType==VB3030PCIE || sm->Cards[card-1].CardType==VB6060PCIE ||
				sm->Cards[card-1].CardType==DGV_1E1F || sm->Cards[card-1].CardType==DGV_2E1F)
			{
				//VB6060PCI
				dg_SetH100(card,H100_SYNC, SYNC_LINE_B, 0);
			}
			else
			{
				//indica referencia interna
				dg_SetH100(card,H100_CT_NETREF,H100_REF_SOURCE1,H100_REF_L_NETREF1);
				//seta a fonte do sinal  com referencia em 2Mega (H100_REF_DIV1)
				//e usando fator de divisao H100_REF_D256 para ficar em 8Khz
				dg_SetH100(card,H100_CT_NETREF,H100_REF_DIV1,H100_REF_D256);
				//e esse seta qual a referencia do comando acima
				dg_SetH100(card,H100_MASTER, H100_MS_REFFR,H100_MS_8KHz);
				//O master deve sincronizar se baseando numa referencia. Essa funcao
				//indica qual eh essa referencia
				dg_SetH100(card,H100_MASTER, H100_MS_REF,H100_MS_CT_NETREF1);
				//liga opcao MASTER e indica qual CTBUS gerara o clock
				dg_SetH100(card,H100_MASTER, H100_MS_SEL,H100_MS_CT_A);
				//desliga opcao slave
				dg_SetH100(card,H100_SLAVE, H100_SL_CT_A,0);
			}
			break;
		
		case SYNC_H100_CT_A: //ou SLAVE_MODE
			if (sm->Cards[card-1].CardType==VBE16060PCI || sm->Cards[card-1].CardType==VBE16060PCI_R || sm->Cards[card-1].CardType==VBE13030PCI ||
				sm->Cards[card-1].CardType==VB3030PCIE || sm->Cards[card-1].CardType==VB6060PCIE ||
				sm->Cards[card-1].CardType==DGV_1E1F || sm->Cards[card-1].CardType==DGV_2E1F)
			{
				//VB6060PCI
				dg_SetH100(card,H100_SYNC, SYNC_H100_CT_A, 0);
			}
			else
			{
				dg_SetH100(card,H100_CT_NETREF,H100_REF_SOURCE1,H100_REF_NONE);
				dg_SetH100(card,H100_MASTER, H100_MS_SEL,H100_MS_DISABLE);
				dg_SetH100(card,H100_SLAVE, H100_SL_CT_A,0);
			}
			break;
		case SYNC_H100_CT_B:
		case SYNC_H100_SCBUS_2048:		
		case SYNC_H100_SCBUS_4096:		
		case SYNC_H100_SCBUS_8192:		
		case SYNC_H100_MVIP:
		case SYNC_H100_H_MVIP:
		case SYNC_H100_CT_NETREF:
		case SYNC_H100_CLK_LINE_B:
		case SYNC_H100_CLK_LINE_A:
		case SYNC_H100_INTERNAL:
			if (sm->Cards[card-1].CardType==VBE16060PCI || sm->Cards[card-1].CardType==VBE16060PCI_R || sm->Cards[card-1].CardType==VBE13030PCI ||
				sm->Cards[card-1].CardType==VB3030PCIE || sm->Cards[card-1].CardType==VB6060PCIE ||
				sm->Cards[card-1].CardType==DGV_1E1F || sm->Cards[card-1].CardType==DGV_2E1F)
			{
				//VB6060PCI
				dg_SetH100(card,H100_SYNC, (u8)SyncMode, 0);
			}
			else
				return DG_ERROR_PARAM_OUTOFRANGE;

			break;
		default:
			return DG_ERROR_PARAM_OUTOFRANGE;
	}

    //Enables E1 Framers TX automatically
    if (enable_framers_auto) 
    {
        digivoice_sleep(2000);
        dg_EnableFramer(card,CFG_FRAMER_E1_A);
        if (dg_GetCardPortsCount(card)>30) 
        {
            digivoice_sleep(1000);
            dg_EnableFramer(card,CFG_FRAMER_E1_B);
        }
    }

	return DG_EXIT_SUCCESS;
}
 
//-------------------------------------------------------------------------
// Disable enabling framers automatically when dg_SetCardSyncMode is called
// This function is useful when starting voicerlib only for checking cards
// ports, etc...
//-------------------------------------------------------------------------
short WCDECL dg_DisableAutoFramers(void)
{
	if (FDriverEnabled)
       return DG_ERROR_DRIVER_ALREADY_OPEN;

	//flag to force it
	enable_framers_auto = 0;

	return DG_EXIT_SUCCESS;

}

//-------------------------------------------------------------------------
// Forces all E1 cards installed to be single span
// Must be called *before* StartVoicerLib
//-------------------------------------------------------------------------
short WCDECL dg_ForceSingleSpan(void)
{
	if (FDriverEnabled)
       return DG_ERROR_DRIVER_ALREADY_OPEN;

	//flag to force it
	force_all_single_span = 1;

	return DG_EXIT_SUCCESS;

}

//-------------------------------------------------------------------------
// Startup procedure
//-------------------------------------------------------------------------
short WCDECL dg_StartVoicerlib(char *szConfigPath)
{
	int /*ctport=0,*/ret=0;
	short nLinear=0,nMi=0,p=0,q=0,ctport=0 ;
	unsigned char s;
	short FXCardType=0;
	u16 FXReadEEprom=0;
#ifdef __LINUX__	
		int nSet_Card_DGDummy;
#endif//#ifdef __LINUX__

	if (FDriverEnabled)
       return DG_ERROR_DRIVER_ALREADY_OPEN;

	tempo_entre_reset = 0;

    nCardsCount=0;
    nPortsCount=0;
    nCardNumberStartError=0;

    DebugEnabled=0;
    GSMDebugEnabled=0;

	write_debug("---------------------------------------------------");
	write_debug("dg_startvoicerlib: Begin Initialization...");
	write_debug("---------------------------------------------------");

#ifdef WIN32
	CloseSharedMemory();
	
	if (!WD_DriverName("dgdriver"))
    {
          return (short)WD_SYSTEM_INTERNAL_ERROR;
    }


  //testa se WinDriver esta carregado
  if (!PCI_Get_WD_handle(&hWinDriver)) return DG_ERROR_MEMORY_ALLOCATION;
  WD_Close (hWinDriver);
	dgAPI_RegisterWinDriver();
#endif

	digivoice_initcriticalsection(&event_mutex);	//fifo rx mutex
	digivoice_initcriticalsection(&cmd_mutex);		//write_command mutex

	//open driver
	hWinDriver = WD_Open();
	if (hWinDriver<=0) 
		return DG_ERROR_MEMORY_ALLOCATION;     //error

#ifdef CCS_ENABLE
    fd_ccs_shm = -1;    //initializes ccs variable control with < 0 
#endif

	write_debug("dg_startvoicerlib: Creating shared memory\n");
	//cria a memoria compartilhada antes de tudo
	//para guardar as informacoes da placa
	if (CreateSharedMemory()==DG_EXIT_FAILURE)
	{
		write_debug("dg_startvoicerlib: Error allocating shared memory\n");
		return DG_ERROR_MEMORY_ALLOCATION;	
	}

	//saves cards count for 0x9030 cards
	sm->nCardsCount = (short)dgAPI_CountCards(0x10b5, 0x9030);

	//saves cards count for 0x9056 cards
	sm->nCardsCount += (short)dgAPI_CountCards(0x10b5, 0x9056);

	//store configuration path into global variable
	if (szConfigPath!=NULL)
		strcpy(szConfigurationPath, szConfigPath);
	else
		strcpy(szConfigurationPath, DG_FIRMWARE_PATH);	//assumes default path always

	/* copy to global variables */
	nCardsCount = sm->nCardsCount;

	if (nCardsCount < 0 || nCardsCount > MAX_CARDS)
	{
		write_debug("dg_startvoicerlib: ERROR_MAXCARDS");
		CloseSharedMemory();
		WD_Close (hWinDriver);
		return DG_ERROR_MAXCARDS;
	}

	//3.1.8 FCardType = (EnumCardType)card_type;

	//inicializa contador global para timers da thread E1
	nGlobalTimerCount = 1;	

	write_debug("dg_startvoicerlib: Loading firmware %s...", szConfigurationPath);
	ret = digivoice_load_firmware(szConfigurationPath);
	if (ret!=DG_EXIT_SUCCESS)
	{
		write_debug("dg_startvoicerlib: error: Cannot load firmware - trying again!");
		digivoice_sleep(100);
		//closes all windriver cards
		for(p=0;p<nCardsCount;p++)
			dgAPI_Close(hPlxHandle[p]);
		digivoice_sleep(1000);
		ret = digivoice_load_firmware(szConfigPath);

		if (ret!=DG_EXIT_SUCCESS) {
			write_debug("dg_startvoicerlib: error: Cannot load firmware! Abort");
			CloseSharedMemory();
			//closes all windriver cards
			for(p=0;p<nCardsCount;p++)
				dgAPI_Close(hPlxHandle[p]);
			WD_Close (hWinDriver);
			return ret;
		}
	}
	
	write_debug("dg_startvoicerlib: Firmware was loaded successfully! %d ports",nPortsCount);
    
	/* Calculates number of ports based on card type */
	if ((nPortsCount=digivoice_configure())==0)
	{
		write_debug("dg_startvoicerlib: digivoice_configure error");
		CloseSharedMemory();
		//closes all windriver cards
		for(p=0;p<nCardsCount;p++)
			dgAPI_Close(hPlxHandle[p]);
		WD_Close (hWinDriver);
		return DG_ERROR_READING_PORTCOUNT;
	}
	write_debug("dg_startvoicerlib: digivoice_configure OK...");

#ifdef __LINUX__
		nSet_Card_DGDummy = digivoice_setdgdummycardinterrupt();
		write_debug("dg_startvoicerlib: digivoice_setdgdummycardinterrupt on card %d OK...", nSet_Card_DGDummy);	
#endif//#ifdef __LINUX__

	if (InitializesSharedMemory()==DG_EXIT_FAILURE)
	{
		CloseSharedMemory();
		//closes all windriver cards
		for(p=0;p<nCardsCount;p++)
			dgAPI_Close(hPlxHandle[p]);
		WD_Close (hWinDriver);

		return DG_ERROR_MEMORY_ALLOCATION;
	}
	write_debug("dg_startvoicerlib: Shared memory initialized!");
    
    for (p=0;p<dg_GetCardsCount();p++)
    {
        digivoice_initcriticalsection(&card_mutex[p]);
    }

#ifdef WIN32	//------------------ Windows -----------------------
	//-------------------------- 
	// Configure Memory to kernel mode access
	BZERO (kernelPlugIn);
	//Abre o Kernel PlugIn
	kernelPlugIn.pcDriverName = "vlibe1";
	//global_card_type = sm->Cards[0].CardType;
	//kernelPlugIn.pOpenData = &global_card_type;
	kernelPlugIn.pOpenData = NULL;
	
	WD_KernelPlugInOpen(hWinDriver,&kernelPlugIn);
	if (!kernelPlugIn.hKernelPlugIn)
	{
	  MessageBox(NULL,"ERRO NO KP","AVISO",0);
	  return DG_ERROR_LOADING_DEVICEDRIVER;
	}
	write_debug("dg_startvoicerlib: kernel plugin ok!");
	//Starts thread to handle each card signals
	for (p=0;p<dg_GetCardsCount();p++)
	{
		
//		digivoice_initcriticalsection(&card_mutex[p]);

		//cria evento de notificacao kernelmode->usermode para sinais - comandos da placa
		SignalEvent[p].hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);

//		write_debug("Card %d Setting signal handle %x",p+1,SignalEvent[p].hEvent);

		SignalEvent[p].card = p+1;
		if (!SignalEvent[p].hEvent)
			return DG_ERROR_CREATING_EVENT;

		//crete CCS events per card
		SignalCCSEvent[p].hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);

//		write_debug("Card %d Setting CCS signal handle %x",p+1,SignalEvent[p].hEvent);

		SignalCCSEvent[p].card = p+1;
		if (!SignalCCSEvent[p].hEvent)
			return DG_ERROR_CREATING_EVENT;

	}

	ParamsToKernel(hWinDriver, kernelPlugIn.hKernelPlugIn);
	write_debug("dg_startvoicerlib: paramsto kernel ok!");


	//creates timer event
	TimerEvent.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
#endif

	write_debug("dg_startvoicerlib: Zerando ponteiros de conferencia 1");
	
	for (p=0;p<MAX_CARDS;p++)
		dg_ReadCmdCounter(p+1);

	//dtmf config
	FDTMFDuration = 100;
	FDTMFPause = 100;

	//memoria da placa
	write_debug("Vamos ler os canais....");
	/*
	else
		nPortsCount = ret;

	if (nPortsCount <= 0)
	{
		write_debug("dg_startvoicerlib: error: cannot found any port!");
		CloseSharedMemory();
		return EXIT_FAILURE;
	}
	*/
	write_debug("dg_startvoicerlib: Setting default values - step 1");
    
	/* default properties and values */
	FCommaDelay = 1000;
	FDotDelay = 1000;
	FSemicolonDelay = 1000;
	/* try to start the thread that reads events from card */
	//duracao da frequencia
	FForcePlay = 0; 			// force playback
	FAutoClearDigits = 0;		// clear digit buffer automatically

	//reset alarm flags
	for (p=0;p<MAX_CARDS;p++)
		for (s=0;s<2;s++)
		{
			e1_slip_cont[p][s] = 0;	//zera contador de escorregamento

			for (q=0;q<8;q++)
				e1_alarm[p][s][q] = 0;
		}
	//zera ponteiros de controle de conferencia
	for (p=0;p<MAX_CARDS;p++)
	{
		TXContadorGlobal[p]=0;
		for (s=0;s<MAX_CHATROOMS;s++)
				stConf[p][s] = NULL;
	}
	write_debug("dg_startvoicerlib: Setting default values to %d ports", nPortsCount);

	//initializes shared memories for recording
	for(ctport=1;ctport<=nPortsCount;ctport++)	//inicia de 1
	{

		write_debug("dg_startvoicerlib: Setting default values to port %d", ctport);
		//digits critical section is per channel
		//critical section per channel
		digivoice_initcriticalsection(&port_mutex[ctport-1]);
#ifdef WIN32				
		//init shared memory to rec and play functions
		if (InitRecSharedMem(ctport,hWinDriver,kernelPlugIn.hKernelPlugIn)!=DG_EXIT_SUCCESS)
			return DG_ERROR_COULD_NOT_CREATE_THREAD;

		if (InitPlaySharedMem(ctport,hWinDriver, kernelPlugIn.hKernelPlugIn)!=DG_EXIT_SUCCESS)
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
#else

		if (InitRecSharedMem(ctport,hWinDriver,0)!=DG_EXIT_SUCCESS)
			return DG_ERROR_COULD_NOT_CREATE_THREAD;

		if (InitPlaySharedMem(ctport,hWinDriver, 0)!=DG_EXIT_SUCCESS)
			return DG_ERROR_COULD_NOT_CREATE_THREAD;

#endif
	} 
#ifdef CCS_ENABLE

    //Initializes CCS memory - in the future doing this on demand
    
    /*if (InitCCSSharedMem()!=DG_EXIT_SUCCESS)
    {
        write_debug("dg_startvoicerlib: ERROR starting InicCCSSharedMem");
    }*/
    
#endif
    


	/* VoicerLib functions *must* be called after FDriverEnabled=1 */
	FDriverEnabled = 1;    /* driver enabled */

	//Default values
	for(ctport=0;ctport<nPortsCount;ctport++)
	{
		//play control variables
		ports_info[ctport].play_wp = 0;
		ports_info[ctport].play_rp = 0;
		thread_playback_id[ctport] = 0;
			
        ports_info[ctport].echocan_enabled = 0;
		ports_info[ctport].echocan_type = ECHO_HW_DSP;

		ports_info[ctport].rec_streaming_on = 0;
		ports_info[ctport].bAbortPlayBack = 0;				/* default format */
		ports_info[ctport].FPlayFileFormat = ffWaveULaw;		/* default format */
		ports_info[ctport].FRecordFileFormat = ffWaveULaw;		/* default format */
		ports_info[ctport].FThreshold = 4;								//default value to answer limiar
		ports_info[ctport].SilenceThreshold = -30;	
		//port status
		ports_info[ctport].FStatusPort = spNone;
		ports_info[ctport].bIsRecording = FALSE;
		ports_info[ctport].bIsPlaying = FALSE;
		//ensure that thread_id is invalid at beginning
		ports_info[ctport].e1_info.thread_id = 0;
		ports_info[ctport].gsm_info.thread_id = 0;
		ports_info[ctport].gsm_info.nMessageConfirmation=0;
		//fills default informations about timeouts
		//the default values can be changed with dg_config_gsm_handle function
		ports_info[ctport].gsm_info.nDigitTimeout = 45000;  //45s
		ports_info[ctport].gsm_info.nRetryTimeout = 10000;  //10s
		ports_info[ctport].gsm_info.nAnswerTimeout = 30000;  //30s	
		ports_info[ctport].gsm_info.nIDRestriction = 0;
		ports_info[ctport].gsm_info.szPinNumber[0] = '\0';
		ports_info[ctport].gsm_info.nCallWaitingEnable = 1;
		ports_info[ctport].gsm_info.nDisplayCallWaitingEnable = 1;

//		ports_info[ctport].e1_info.call_thread_id = 0;
		ports_info[ctport].e1_info.tx_id_number_of_digits = 0;
		ports_info[ctport].e1_info.category = 1;
		ports_info[ctport].fsk_info.enable = 0;			//fsk detection
		ports_info[ctport].DetCmd = 0;		//estrutura a ser passada pelo CMD_DETECTION
		ports_info[ctport].FFastDetection = NORMAL_DETECTION;	//detecao normal como padrao
		ports_info[ctport].target_port = ctport+1;	//the target port is useful in logger thread
		ports_info[ctport].nGetDigitsState = edOff;		//GetDigits State

		ports_info[ctport].h100info.h100_enabled = 0;	//h100 disabled
		//to inform the port that will receive the commands and events
		dg_SetPortId(ctport+1, "");


		//set initial timers off
		tmrAfterDial[ctport].Interval = 1000 / FACTOR_TIMER;
		SetEnableTimer(&tmrAfterDial[ctport],FALSE);
		tmrAfterPickUp[ctport].Interval = 1000 / FACTOR_TIMER;
		SetEnableTimer(&tmrAfterPickUp[ctport],FALSE);

		tmrAfterFlash[ctport].Interval = 1000 / FACTOR_TIMER;
		SetEnableTimer(&tmrAfterFlash[ctport],FALSE);

		tmrTimeRec[ctport].Interval = 900 / FACTOR_TIMER;
		SetEnableTimer(&tmrTimeRec[ctport],FALSE);

		tmrInterDigit[ctport].Interval = 900 / FACTOR_TIMER;
		SetEnableTimer(&tmrInterDigit[ctport],FALSE);

		tmrDigit[ctport].Interval = 900 / FACTOR_TIMER;
		SetEnableTimer(&tmrDigit[ctport],FALSE);

		SetEnableTimer(&tmrCallProgress[ctport],FALSE);
		SetEnableTimer(&tmr_E1[ctport],FALSE);
		SetEnableTimer(&tmr_GSM[ctport],FALSE);
		SetEnableTimer(&tmr_GSM_Wait[ctport],FALSE);
		SetEnableTimer(&tmr_GSM_ClearAllSMS[ctport],FALSE);

		SetEnableTimer(&tmrRing[ctport],FALSE);
		
		SetEnableTimer(&tmr_Silence[ctport],FALSE);
		
		//callprogress timers
		SetEnableTimer(&tmr_CPThread[ctport],FALSE);
		SetEnableTimer(&tmr_CP_AudioCtrl[ctport],FALSE);
        SetEnableTimer(&tmr_CPStart[ctport],FALSE);
        
		//idle timer
		SetEnableTimer(&tmr_IdleThread[ctport],FALSE);

        //initializes pm pointers
        pm[ctport]->wp = 0;
        pm[ctport]->rp = 0;


	} //for ctport
	write_debug("dg_startvoicerlib: Setting default values - OK");
	dg_ResetPortResource();
    
	//Starts global timer to interact with TimerProc
	digivoice_starttimer();

	//generate mulaw convertion table
	for(p=0;p<2;p++) {
		for(s=0;s<8;s++) {
			for(q=0;q<16;q++) {
				if(p==0) {
					nLinear = (short)(((33<<s) | (q<<(s+1))) -33);
					nMi = (short)(((p<<7)|(s<<4)|q));
				}
				else {
					nLinear = (short)(-1*(((33<<s)|(q<<(s+1)))-33));
					nMi = (short)(((p<<7)|(s<<4)|q));
				}
				muLaw2Lin[255^nMi] = (short)(4*nLinear);
			}
		}
	} /* ulaw table */

	write_debug("dg_startvoicerlib: Initializing critical sections");
	//Starts thread to handle each card signals
	for (p=0;p<dg_GetCardsCount();p++)
	{
		nCCSLog[p] = 0;			//disable ccs log
		ignore_error[p] = 1;
        thread_ccs_id[p] = 0;   //reset thread ccs control
        device_ccs[p] = -1;
		event_card[p] = p+1;
		write_debug("dg_startvoicerlib: Starting Signal Thread for card %d",p+1);
		
		if (digivoice_beginthread(&thread_event_id[p],SignalsFromCard,0,&event_card[p])!=0)
		{
			write_debug("dg_startvoicerlib: DG_ERROR_COULD_NOT_CREATE_THREAD");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
		}
	
		//Initializes all tone structure only with 425, 1100, 2100
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE1,425,0);
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE2,1100,0);
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE3,2100,0);

		//All extra frequencies are zero to avoid conflits
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE4,0,0);
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE5,0,0);
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE6,0,0);
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE7,0,0);
		dg_SetCardDetections(p+1,CFG_DETECT_FREQTONE8,0,0);
	}

#ifdef WIN32
	for (p=0;p<dg_GetCardsCount();p++)
		SetThreadPriority(&thread_event_id[p],THREAD_PRIORITY_ABOVE_NORMAL);
	//TODO: set priority in linux version
#else
    
	//initializes semaphores to synchronizing threads
	for(ctport=0;ctport<nPortsCount;ctport++)
	{
		sem_init(&recsync_sem[ctport],0,0);
		sem_init(&playsync_sem[ctport],0,0);
	}

	//Linux creates RecSignalThread and PlaySignalThread
	for (p=0;p<dg_GetCardsCount();p++)
	{
		if (digivoice_beginthread(&thread_recsignal[p],RecSignalThread,0,&event_card[p])!=0)
		{
			write_debug("dg_startvoicerlib: DG_ERROR_COULD_NOT_CREATE_THREAD - RecSignalThread");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
		}
		if (digivoice_beginthread(&thread_playsignal[p],PlaySignalThread,0,&event_card[p])!=0)
		{
			write_debug("dg_startvoicerlib: DG_ERROR_COULD_NOT_CREATE_THREAD - PlaySignalThread");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
		}
	}
    
#endif

	dg_SetGSMMode(GSM_RAW);	//DEFAULT TYPE

	dg_SetDtmfConfig(90,90);
	
	write_debug("dg_startvoicerlib: Enabling interrupts...");
	//habilita interrupcao
	digivoice_enableinterrupts();
	write_debug("dg_startvoicerlib: Interrupts enabled...");
	digivoice_sleep(100);

	//write_debug("dg_startvoicerlib: Setting FXO interface type...");
	for (p = 0; p < dg_GetCardsCount(); p++)
	{

		switch (dg_GetCardType(p + 1))
		{
			case VB0404FX:
				for (q = 0; q < 4; q++)
				{
					dg_SetFXCardType(dg_GetAbsolutePortNumber(p + 1, q + 1), DG_FX_TYPE_FXS);
					//ports_info[dg_GetAbsolutePortNumber(p + 1, q + 1) - 1].fx_type = DG_FX_TYPE_FXS;
				}
				break;
			case VB0404FX_R:
				FXReadEEprom = Read_EEPROM(hPlxHandle[p], 0x66);
				for (q = 0; q < 4; q++)
				{
					FXCardType = (FXReadEEprom>>(q*4))&0xf;
					dg_SetFXCardType(dg_GetAbsolutePortNumber(p + 1, q + 1), FXCardType);
					//ports_info[dg_GetAbsolutePortNumber(p + 1, q + 1) - 1].fx_type = FXCardType;
				}
				break;
		}
	}	
	
	write_debug("dg_startvoicerlib: Initialization Successfully!!");
	//write_debug("---->>> Firmware at %s filename %s",szFirmwareFile,szDeviceName);
	
	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
// Shutdown procedure
//-------------------------------------------------------------------------
short WCDECL dg_ShutdownVoicerlib(void)
{
	int my_card, ctime;
	short ctport;

#ifdef WIN32
	//finaliza debug
	if (DebugEnabled)
		dg_DisableDebug();
#endif

	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;			//ja estava fechado

	write_debug("dg_ShutdownVoicerlib: Vai finalizar voicerlib");

	//desliga callback de eventos antes de mais nada
	SendEventsToApp = NULL;

	//must cleanup all thread may be running
	//write_debug("dg_ShutdownVoicerlib: Desligando gravacoes....");
	for(ctport=0;ctport<nPortsCount;ctport++)
	{
		if (dg_IsRecording(ctport+1))
		{
			dg_StopRecordFile(ctport+1);
		}

		if (dg_IsPlaying(ctport+1))
		{
			dg_StopPlayFile(ctport+1);
#ifdef WIN32
	//gera evento para nao ficar preso na thread
			if (PlayEvent[ctport].hEvent!=NULL)
				SetEvent(PlayEvent[ctport].hEvent);
#else
			sem_post(&playsync_sem[ctport]);
#endif

		}
		
		if (ports_info[ctport].e1_info.thread_id>0)
			dg_DestroyE1Thread(ctport+1);

		if (ports_info[ctport].gsm_info.thread_id>0)
			dg_DestroyGSMThread(ctport+1);

		if (ports_info[ctport].logger_info.thread_id>0)
			dg_DestroyLoggerControl(ctport+1);

		//destroy callprogress if it is enabled
		dg_DestroyCallProgress(ctport+1);

	}
	//espera todos os canais pararem de gravar
	for(ctport=0;ctport<nPortsCount;ctport++)
	{


		ctime = 20;
		while (ports_info[ctport].bIsRecording && ctime > 0)
		{
			ctime--;
#ifdef WIN32
			SetEvent(RecEvent[ctport].hEvent);
#endif
			digivoice_sleep(10);
			write_debug("dg_ShutdownVoicerlib: Esperando acabar porta %d....",ctport+1);
		}
	}
	write_debug("dg_ShutdownVoicerlib: Gravacoes Finalizadas....");

	for(ctport=0;ctport<nPortsCount;ctport++)
	{
		ctime = 20;
		while (ports_info[ctport].logger_info.thread_id>0 && ctime > 0)
		{
			ctime--;
			//dg_InsertLoggerFifo(ctport+1,C_ENDTHREAD,0);
			dg_DestroyLoggerControl(ctport+1);
			digivoice_sleep(10);
		}
	}


	write_debug("dg_ShutdownVoicerlib: Loggers Finalizadas....");

#ifdef WIN32
	//Finalizacao das threads de Sinais
	write_debug("dg_ShutdownVoicerlib: Finalizacao das threads de Sinais....");

	for (my_card=0;my_card<dg_GetCardsCount();my_card++)
	{

		//Disable CCS threads
		if(thread_ccs_id[my_card] !=0)
		{
			SignalCCSEvent[my_card].card = -999;     //indica finalizacao das threads
			ctime = 100;
			do 
			{
				ctime--;
				SetEvent(SignalCCSEvent[my_card].hEvent);
				write_debug("Shutdown CCS placa %d evento %x - evento %x",my_card, SignalCCSEvent[my_card].hEvent, thread_ccs_id[my_card]);
				digivoice_sleep(10);
			} while(thread_ccs_id[my_card]!=0 && ctime > 0);
			
		}

        //Disables E1 Framers TX automatically
        if (enable_framers_auto) 
        {
            dg_DisableFramer(my_card+1,CFG_FRAMER_E1_A);
            if (dg_GetCardPortsCount((my_card+1))>30) 
            {
                dg_DisableFramer(my_card+1,CFG_FRAMER_E1_B);
            }
        }

		SignalEvent[my_card].card = -999;     //indica finalizacao das threads
		ctime = 100;
		do 
		{
			ctime--;
			write_debug("Shutdown placa %d vai setar evento %x",my_card, SignalEvent[my_card].hEvent);
			SetEvent(SignalEvent[my_card].hEvent);
			write_debug("Shutdown placa %d evento %x - evento %x",my_card, SignalEvent[my_card].hEvent, thread_event_id[my_card]);
			digivoice_sleep(10);
		} while(thread_event_id[my_card]!=0 && ctime > 0);
	}

#endif

    FDriverEnabled = 0;    /* driver disabled */

#ifdef __LINUX__
	for (my_card=0;my_card<dg_GetCardsCount();my_card++)
	{
		ctime = 100;
		do
		{
			ctime--;

			if (ioctl(hWinDriver, VLIB_IOCTL_END_THREADS, 0) == -1)
				write_debug("dg_ShutdownVoicerlib(%d): could not send VLIB_IOCTL_END_THREADS (rec and play threads)",my_card);
			else
				write_debug("dg_ShutdownVoicerlib(%d): trying...%d, step 1", my_card,ctime);

			digivoice_sleep(10);

			if ((thread_recsignal[my_card]==0) && (thread_playsignal[my_card]==0))
				ctime = 0;

		} while(ctime > 0);
	}

	for (my_card=0;my_card<dg_GetCardsCount();my_card++)
	{
		ctime = 100;
		do
		{
			ctime--;

			if (ioctl(hWinDriver, VLIB_IOCTL_END_THREADS, 0) == -1)
				write_debug("dg_ShutdownVoicerlib(%d): could not send VLIB_IOCTL_END_THREADS (ccs and signals threads)", my_card);
			else
				write_debug("dg_ShutdownVoicerlib(%d): trying...%d, step 2", my_card, ctime);

			digivoice_sleep(10);

			if ((thread_ccs_id[my_card]==0) && (thread_event_id[my_card]==0))
				ctime = 0;

		} while(ctime > 0);
	}

	//force thread to stop
	for (my_card=0;my_card<dg_GetCardsCount();my_card++)
	{
		if ((thread_recsignal[my_card]!=0) || (thread_playsignal[my_card]!=0))
		{
			write_debug("dg_ShutdownVoicerlib: force thread rec and play to stop");
			digivoice_cancelthread(&thread_recsignal[my_card]);
			digivoice_cancelthread(&thread_playsignal[my_card]);
		}
	}

	for (my_card=0;my_card<dg_GetCardsCount();my_card++)
	{
		if ((thread_ccs_id[my_card]!=0) || (thread_event_id[my_card]!=0))
		{
			write_debug("dg_ShutdownVoicerlib(%d): force thread ccs and signals to stop", my_card);
			digivoice_cancelthread(&thread_ccs_id[my_card]);
			digivoice_cancelthread(&thread_event_id[my_card]);
		}
	}

	//destroy semaphores
	for(ctport=0;ctport<nPortsCount;ctport++)
	{
		sem_destroy(&recsync_sem[ctport]);
		sem_destroy(&playsync_sem[ctport]);
	}
#endif

	write_debug("dg_ShutdownVoicerlib: Desabilitando Isr....");
	digivoice_disableinterrupts();
  	//stops global timer
  	
  	digivoice_stoptimer();
	digivoice_sleep(500);

  	write_debug("dg_shutdownvoicerlib: Fechando Shared de Rec e Play!");

	//closes shared memory for recording
	for(ctport=1;ctport<=nPortsCount;ctport++)
	{
		digivoice_deletecriticalsection(&port_mutex[ctport-1]);
	}

	for(ctport=1;ctport<=nPortsCount;ctport++)
	{
		ClosePlaySharedMem(ctport);
	}

	for(ctport=1;ctport<=nPortsCount;ctport++)
	{
		CloseRecSharedMem(ctport);
		
	}

#ifdef CCS_ENABLE
    if (fd_ccs_shm>-1)
        CloseCCSSharedMem();
#endif

  write_debug("dg_shutdownvoicerlib: Fechou Shared de Rec e Play!");
    
#ifdef WIN32	//------------------ Windows -----------------------
	for(my_card=0;my_card<nCardsCount;my_card++)
	{
		//dereference events into kernel
		SignalEvent[my_card].card = my_card + 1;
		BZERO (kpCall);
		kpCall.hKernelPlugIn = kernelPlugIn.hKernelPlugIn;
		kpCall.dwMessage = IOCTL_UNSETEVENT;
		kpCall.pData =  &SignalEvent[my_card].hEvent;
		WD_KernelPlugInCall(hWinDriver, &kpCall);

		//do the same for ccs events
		SignalCCSEvent[my_card].card = my_card + 1;
		BZERO (kpCall);
		kpCall.hKernelPlugIn = kernelPlugIn.hKernelPlugIn;
		kpCall.dwMessage = IOCTL_UNSETCCSEVENT;
		kpCall.pData =  &SignalCCSEvent[my_card].hEvent;
		WD_KernelPlugInCall(hWinDriver, &kpCall);


	}

	//closes all windriver cards
	for(my_card=0;my_card<nCardsCount;my_card++)
	{
		//deletes card_mutex
		digivoice_deletecriticalsection(&card_mutex[my_card]);
		dgAPI_Close(hPlxHandle[my_card]);
	}
	write_debug("dg_shutdownvoicerlib: Fechando Windriver handle!");	
  
	//closes timer event
	CloseHandle(TimerEvent.hEvent);
	//Closes Kernel PlugIn
	WD_KernelPlugInClose(hWinDriver, &kernelPlugIn);

	write_debug("dg_shutdownvoicerlib: Fechando Kernel Plugin!");
#else
	//closes all windriver cards
	for(my_card=0;my_card<nCardsCount;my_card++)
	{
		//deletes card_mutex
		digivoice_deletecriticalsection(&card_mutex[my_card]);
		dgAPI_Close(hPlxHandle[my_card]);
	}
	write_debug("dg_shutdownvoicerlib: Fechando Windriver handle!");	
#endif
	digivoice_sleep(50);
	CloseSharedMemory();
	
#ifdef WIN32
	//fecha evento
	for (my_card=0;my_card<dg_GetCardsCount();my_card++)
	{
		if (SignalEvent[my_card].hEvent)
			CloseHandle(SignalEvent[my_card].hEvent);
	}	
#endif

	//closes all windriver cards
	/* for(my_card=0;my_card<nCardsCount;my_card++)
	{
		//deletes card_mutex
		digivoice_deletecriticalsection(&card_mutex[my_card]);
		dgAPI_Close(hPlxHandle[my_card]);		
	}
	write_debug("dg_shutdownvoicerlib: Fechando Windriver handle!");	
	*/	
	digivoice_sleep(50);

	//flag to force it
	force_all_single_span = 0;

	//delete critical sections
	digivoice_deletecriticalsection(&event_mutex);
	digivoice_deletecriticalsection(&cmd_mutex);

	//close windriver/linux driver
	WD_Close(hWinDriver);

	digivoice_sleep(50);
	write_debug("dg_shutdownvoicerlib: Saindo da rotina!");
  return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Get the cards numbers configured
//-------------------------------------------------------------------------
short WCDECL dg_GetCardsCount(void)
{
    return nCardsCount;
}

//-------------------------------------------------------------------------
// Get the number of spans from each card
//-------------------------------------------------------------------------
short WCDECL dg_GetSpansCount(short card)
{
    if (card < 1 || card > nCardsCount)
        return DG_ERROR_CARD_OUT_OF_RANGE;

  	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return 0;

    if (dg_GetCardPortsCount(card)>30)
        return 2;
    else 
        return 1;

}

//-------------------------------------------------------------------------
// Get the channels configured
//-------------------------------------------------------------------------
short WCDECL dg_GetPortsCount(void)
{
    return nPortsCount;
}

//Teste do 7600
short WCDECL dg_GetTest(short card)
{
	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//Teste do 0x7600
	Placa_Write_Reg(hPlxHandle[card-1], HPIA, (u16)0x7600);
  return Placa_Read_Reg(hPlxHandle[card-1], HPID);
}

short WCDECL dg_GetCardNumberStartError(void)
{
    return nCardNumberStartError;
}

//-------------------------------------------------------------------------

//-------------------------------------------------------------------------
// Pickup Port - channel
//-------------------------------------------------------------------------
short WCDECL dg_PickUp(short port, long pause_after_pickup)
{

	short card;
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

    if (pause_after_pickup < -1 || pause_after_pickup > 60000)
            return DG_ERROR_PARAM_OUTOFRANGE;

	card = dg_GetCardNumber(port);
	if (card<0)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	switch(sm->Cards[card-1].CardType)
	{
        case VBE13060PCI:
        case VBE13030PCI:
		case VBE16060PCI:
		case VBE16060PCI_R:
		case VBE13060PCI_R:
		case VB3030PCIE:			
		case VB6060PCIE:
		case DGV_1E1F:
		case DGV_2E1F:
			//verify if thread_control is running
			if (ports_info[port-1].e1_info.thread_id > 0)
			{
				write_debug("(%d) dg_pickup: pickup no E1 ================!",port);
				//send commands through CallCtrlThread
				if (dg_InsertE1Fifo(port,CPICKUP,0)==EXIT_FAILURE)
					return DG_EXIT_FAILURE;
			}
			else
			{

				if (ports_info[port-1].cas_info.thread_id > 0)	//custom cas thread control
				{
					//send commands through CAS Thread
					if (dg_InsertCASFifo(port,CPICKUP,0)==EXIT_FAILURE)
						return DG_EXIT_FAILURE;
				}
				else
					dg_SendR2Command(port, R2_SEIZURE);		//default action
			}
			break;
		case VB0408PCI:
		case VB0408PCIE:
		case VB0404FX:
		case VB0404FX_R:			
			tx_command_e1.command = CMD_LINE;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = port-1;
			tx_command_e1.param1 = port-1;
			tx_command_e1.param2 = HOOK_OFF;	//pickup
			tx_command_e1.param3 = 0;
			tx_command_e1.param4 = 0;
			tx_command_e1.param5 = 0;
			write_generic_command(&(tx_command_e1));

			break;
        case VB0404GSM:
            //send command to card
            //gsm_pickup(port);
			if (ports_info[port-1].gsm_info.thread_id > 0) //gsm thread control
			{
				//send commands through GSM Thread
				if (dg_InsertGSMFifo(port, CPICKUP, 0)==EXIT_FAILURE)
					return DG_EXIT_FAILURE;
			}
			else
				return DG_ERROR_THREAD_NOT_RUNNING;

			break;
	}
	write_debug("dg_pickup");
	//undocumented function - passing -1 in pause_after_pickup avoids AfterPickUp event
	//only if idle is off
	if (pause_after_pickup>-1/* && ports_info[port-1].idle_info.enabled==0 */)
	{
		write_debug("(%d) dg_pickup = %d !", port , pause_after_pickup);
		//starts timer
		tmrAfterPickUp[port-1].Interval = pause_after_pickup / FACTOR_TIMER;
		SetEnableTimer(&tmrAfterPickUp[port-1],TRUE);
	}

	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Hangup Port
//-------------------------------------------------------------------------
short WCDECL dg_HangUp(short port)
{
	short card;
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	card = dg_GetCardNumber(port);

	//cancel afterpickup timer
	if (ports_info[port-1].idle_info.enabled==0)
	{
		//stops timer
		SetEnableTimer(&tmrAfterPickUp[port-1],FALSE);
	}

	ports_info[port-1].FStatusPort = spNone;
	memset(ports_info[port-1].idle_info.sDigitsDetected, '\0', DG_MAX_PATH);
	memset(ports_info[port-1].idle_info.sNameDetected, '\0', DG_MAX_PATH);

	switch(sm->Cards[card-1].CardType)
	{
		case VBE13060PCI:
        case VBE16060PCI:
        case VBE13030PCI:
		case VBE16060PCI_R:
		case VBE13060PCI_R:
		case VB3030PCIE:			
		case VB6060PCIE:
		case DGV_1E1F:
		case DGV_2E1F:
			//verify if thread_control is running
			if (ports_info[port-1].e1_info.thread_id>0)
			{
				//send commands through CallCtrlThread
				if (dg_InsertE1Fifo(port,CHANGUP,0)==EXIT_FAILURE)
					return EXIT_FAILURE;

			}
			else

				if (ports_info[port-1].cas_info.thread_id > 0)	//custom cas thread control
				{
					//send commands through CAS Thread
					if (dg_InsertCASFifo(port,CHANGUP,0)==EXIT_FAILURE)
						return EXIT_FAILURE;
				}
				else

					dg_SendR2Command(port, R2_IDLE);

			break;
		case VB0408PCI:
		case VB0408PCIE:
		case VB0404FX:
		case VB0404FX_R:			
			tx_command_e1.command = CMD_LINE;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = port-1;
			tx_command_e1.param1 = port-1;
			tx_command_e1.param2 = HOOK_ON;	//hangup
			tx_command_e1.param3 = 0;
			tx_command_e1.param4 = 0;
			tx_command_e1.param5 = 0;
			write_generic_command(&(tx_command_e1));

			break;
		case VB0404GSM:
			//send command to card
            //gsm_hangup(port);
			if (ports_info[port-1].gsm_info.thread_id > 0) //gsm thread control
			{
				//send commands through GSM Thread
				if (dg_InsertGSMFifo(port, CHANGUP, 0)==EXIT_FAILURE)
					return DG_EXIT_FAILURE;
			}
			else
				return DG_ERROR_THREAD_NOT_RUNNING;

			break;
	}
    return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Enable Call progress to port
// cptype:
// 	CP_ENABLE_ALL,					//all
//	CP_ENABLE_GENERIC_TONE,			//only generic tone
//	CP_ENABLE_LINETONE_OR_BUSY,		//line or busy - using before dial or afterflash
//	CP_ENABLE_BUSY_OR_FAX			//fax or busy - during conversation
//-------------------------------------------------------------------------
short WCDECL dg_EnableCallProgress(short port, short cptype)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//check if callprogress thread is running
	if (ports_info[port-1].cp_info.thread_ready==0)
		return DG_ERROR_THREAD_NOT_RUNNING;

    ports_info[port-1].cp_info.cptype = cptype;
    if(ports_info[port-1].cp_info.thread_ready==2)
    {
        write_debug("CALLPROGRESS WAITING FOR THREAD - value = %d\n", ports_info[port-1].cp_info.thread_ready);
        tmr_CPStart[port-1].Interval = 100  / FACTOR_TIMER;
        SetEnableTimer(&tmr_CPStart[port-1],TRUE);
        tmr_CPStart[port-1].Enabled = TRUE;
    }
    else
    {
        write_debug("CALLPROGRESS THREAD OK - value = %d\n", ports_info[port-1].cp_info.thread_ready);
        //dbg(port,"dg_EnableCallProgress - Entra");
        dg_InsertCPFifo(port, C_SET_CALLPROGRESS, cptype);
    }

	if(ports_info[port-1].cp_info.enabled == 1)
	{
		//desliga timer
		tmr_CPThread[port-1].Enabled = FALSE;
 		SetEnableTimer(&tmr_CPThread[port-1],FALSE);

		tmr_CP_AudioCtrl[port-1].Enabled = FALSE;
 		SetEnableTimer(&tmr_CP_AudioCtrl[port-1],FALSE);
	}

	ports_info[port-1].cp_info.enabled = 1;
	//save port
	ports_info[port-1].cp_info.port = port;

	//Desabilitar tudo antes de habilitar novamente
	dg_SetDetectionType(port, DETECT_ALL_TONE, DG_DISABLE);
	switch(cptype)
	{
		case CP_ENABLE_ALL:
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_FAX1]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_FAX2]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_BUSY]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_LINE]-0x21], DG_ENABLE); 
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE2]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE3]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE4]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE5]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_CALLING]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_AUDIO]-0x21], DG_ENABLE);
			break;
		case CP_ENABLE_GENERIC_TONE:
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE2]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE3]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE4]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_GTONE5]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_AUDIO]-0x21], DG_ENABLE);
			break;
		case CP_ENABLE_LINETONE_OR_BUSY:
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_BUSY]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_LINE]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_AUDIO]-0x21], DG_ENABLE);
			break;
		case CP_ENABLE_BUSY_OR_FAX:
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_FAX1]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_FAX2]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_BUSY]-0x21], DG_ENABLE);
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_LINE]-0x21], DG_ENABLE); //??
			dg_SetDetectionType(port, CPCommands[ ports_info[port-1].cp_info.nToneType[T_AUDIO]-0x21], DG_ENABLE);
			break;
		default:
			ports_info[port-1].cp_info.enabled = 0;
			return DG_ERROR_PARAM_OUTOFRANGE;
	}
	//dbg(port,"dg_EnableCallProgress - Sai");

    return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Enable Call progress to port
//-------------------------------------------------------------------------
short WCDECL dg_DisableCallProgress(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//check if callprogress thread is running
	if (ports_info[port-1].cp_info.thread_ready==0)
				return DG_ERROR_THREAD_NOT_RUNNING;


	//dbg(port,"dg_DisableCallProgress - Entra");

	//send disable information to thread
	dg_InsertCPFifo(port, C_SET_CALLPROGRESS, CP_DISABLE);

	//disable all tone detections
	dg_SetDetectionType(port, DETECT_ALL_TONE, DG_DISABLE);

	//desliga timer
	tmr_CPThread[port-1].Enabled = FALSE;
 	SetEnableTimer(&tmr_CPThread[port-1],FALSE);

	tmr_CP_AudioCtrl[port-1].Enabled = FALSE;
 	SetEnableTimer(&tmr_CP_AudioCtrl[port-1],FALSE);

    SetEnableTimer(&tmr_CPStart[port-1],FALSE);
    tmr_CPStart[port-1].Enabled = FALSE;

	
	ports_info[port-1].cp_info.enabled = 0;

	//dbg(port,"dg_DisableCallProgress - Sai");

    return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Enable Silence/Audio detection
// silence_time in ms
// audio_time in ms - dont use with more than 100ms
//-------------------------------------------------------------------------
short WCDECL dg_EnableSilenceDetection(short port, int silence_time, short audio_time)
{
	dg_event_data_structure events;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	dg_DisableSilenceDetection(port);

	ports_info[port-1].silence.silence_time = silence_time;
	ports_info[port-1].silence.audio_time = audio_time;
	ports_info[port-1].silence.last_time = 0L;

	//ports_info[port-1].silence.last_silence_time = 0L;
	//ports_info[port-1].silence.last_audio_time = 0L;

	ports_info[port-1].silence.enabled = DG_ENABLE;


	//estado inicial
	ports_info[port-1].silence.last_signal = CP_SILENCE;
	ports_info[port-1].silence.silence_detected = 1;

	//forces handling for the first time
	events.port = port;
	events.command = C_AUDIO;
	events.data = CP_SILENCE;
	HandleSilenceDetection(&events );

    //enable audio detection
    dg_SetDetectionType(port, DETECT_AUDIO, DG_ENABLE);

    return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Disable Silence/Audio detection
//-------------------------------------------------------------------------
short WCDECL dg_DisableSilenceDetection(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	ports_info[port-1].silence.enabled = DG_DISABLE;

	//disable audio detection only if callprogress is disable
	if (ports_info[port-1].cp_info.enabled==DG_DISABLE)
		dg_SetDetectionType(port, DETECT_AUDIO, DG_DISABLE); //CP_AUDIO AAP - warning
	
	//Disable timer
	SetEnableTimer(&tmr_Silence[port-1],FALSE);	
    return DG_EXIT_SUCCESS;
}


//----------------------------------------------------------------
// Habilita ocupado e 425 e fax
// Chama o EnableCallProgress ja que as funcoes foram unificadas
//----------------------------------------------------------------
/*short WCDECL dg_EnableBusyDetection(short port) 
{

    if (!FDriverEnabled || (port > dg_GetPortsCount()))
		return DG_ERROR_DRIVER_CLOSED;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;


	if (FCardType==ctVBE1)	//provisorio
		return DG_EXIT_SUCCESS;;	

    write_debug("dg_enablebusydetection: channel %d",port);
		
    if (FCardType==ctVPPCI)
    {
        
        write_command(port-1,CBUSY_ON,0,NULL);
        return DG_EXIT_SUCCESS;;
    }
    else
        return dg_EnableCallProgress(port);  //PCI eh o mesmo comando
}
*/
//----------------------------------------------------------------
// Desabilita ocupado e 425 e fax
// Chama o DisableCallProgress ja que as funcoes foram unificadas
//----------------------------------------------------------------
/*short WCDECL dg_DisableBusyDetection(short port) 
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

    if (!FDriverEnabled || (port > dg_GetPortsCount()))
		return DG_ERROR_DRIVER_CLOSED;

	if (FCardType==ctVBE1)	//provisorio
		return DG_EXIT_SUCCESS;;	

		write_debug("dg_DisableBusyDetection: channel %d",port);
	
    if (FCardType==ctVPPCI)
    {
        write_command(port-1,CBUSY_OFF,0,NULL);
        return DG_EXIT_SUCCESS;;
    }
    else
        return dg_DisableCallProgress(port);
}

*/

//-------------------------------------------------------------------------
// Register a callback function to pass cards events
//-------------------------------------------------------------------------
void dg_SetEventCallback(void *ptrFunc, void *context_data)
{
   //assert(ptrFunc!=NULL);  /* Prevents null pointer */

   SendEventsToApp = ptrFunc;
   /* Used to pass data from app */
   Events_Data = (dg_event_data_structure *)context_data;
}

//-------------------------------------------------------------------------
// Register a callback function to get audio samples to app (streaming)
//-------------------------------------------------------------------------
void WCDECL dg_SetAudioInputCallback(void *ptrFunc)
{
   assert(ptrFunc!=NULL);  /* Prevents null pointer */
   SendAudioToAppPtr = ptrFunc;
}

//-------------------------------------------------------------------------
// Register a callback function to get audio samples to app (streaming)
//-------------------------------------------------------------------------
void WCDECL dg_SetCCSCallback(void *ptrFunc)
{
   assert(ptrFunc!=NULL);  /* Prevents null pointer */
   SendCCSToAppPtr = ptrFunc;
}


//-------------------------------------------------------------------------
// Sets frequency to tone detection - default is 425hz
//-------------------------------------------------------------------------
short WCDECL dg_SetFrequency(short card, short Frequency)
{
	return dg_SetCardDetections(card, CFG_DETECT_FREQTONE1, Frequency, 0);
}

//-------------------------------------------------------------------
// Converts number strings to digits
//-------------------------------------------------------------------
unsigned short WCDECL dg_convertdigits(char Number)
{
	unsigned short wData;

	switch(Number)
	{
			case 'A': case 'a':
					wData = 10;
					break;
			case 'B': case 'b':
					wData = 11;
					break;
			case 'C': case 'c':
					wData = 12;
					break;
			case 'D': case 'd':
					wData = 13;
					break;
			case '*':
					wData = 14;
					break;
			case '#':
					wData = 15;
					break;
			case '0': case '1': case '2': case '3': case '4': case '5':
			case '6': case '7': case '8': case '9':
					wData = (unsigned short)(Number - 0x30);
					break;
			default:
				wData = 0;
	}

	return wData;
}
//-----------------------------------------------------------------
// Dial to a number
//-----------------------------------------------------------------
short WCDECL dg_DialAbort(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	ports_info[port-1].FStatusPort = spNone;

	ports_info[port-1].dial_abort = 1;
			
	return DG_EXIT_SUCCESS;

}

//-----------------------------------------------------------------
// Dial to a number
// allow to pass upto 28 digits but sends 14 each time
// *** the AfterDial Pause is not used when E1Control is enabled
//-----------------------------------------------------------------
short WCDECL dg_Dial(short port, char *Number, long pause_after_dial, short dialtype)
{
	unsigned short i;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//Pausa fora do range
	if (pause_after_dial < 0 || pause_after_dial > 60000)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//Estado da porta
	ports_info[port-1].FStatusPort = spDialing;

	//E1	
	//if DialType is dtDirectMF, DialThread will be started *always*
	if (ports_info[port-1].e1_info.thread_id>0 && (dialtype != dtDirectMF))
	{
		//pass all digits to e1 thread control
		for (i=0;i<strlen(Number);i++)
		{
			//insert into control fifo
			dg_InsertE1Fifo(port,CDISCA_TOM,dg_convertdigits(Number[i]));
		} //for
	}
	else
	if (ports_info[port-1].gsm_info.thread_id>0 && (dialtype != dtDirectMF))
	{
			//copy digits to Dial to gsm structure
			strncpy(ports_info[port-1].gsm_info.tx_digits,Number,25);
			//insert into control fifo
			dg_InsertGSMFifo(port,CDISCA_TOM,0);
	}
	else
	{
		//this routine starts a thread to do all job directly to the card
		ports_info[port-1].dial_info.port = port;
		strcpy(ports_info[port-1].dial_info.szNumber,Number);  //pass pointer
		ports_info[port-1].dial_info.pause_after_dial = pause_after_dial;
		ports_info[port-1].dial_info.dialtype = dtDTMF;	//forced
	
		if (digivoice_beginthread(&thread_dial_id[port-1],DialThread,0,&ports_info[port-1].dial_info)!=0)
		{
			ports_info[port-1].FStatusPort = spNone;
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
		}
#ifdef WIN32
		SetThreadPriority(&thread_dial_id[port-1],THREAD_PRIORITY_BELOW_NORMAL);
#endif

	}	
	/* send commands and data to cards */ 
  
	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
//sets delays symbols for dialer
//------------------------------------------------------------
short WCDECL dg_SetDialDelays(unsigned short CommaDelay, unsigned short DotDelay, unsigned short SemicolonDelay) 
{
    
    FCommaDelay = CommaDelay;
    FDotDelay = DotDelay; 
    FSemicolonDelay = SemicolonDelay;
    return DG_EXIT_SUCCESS;
}


//------------------------------------------------------------
// Sets detection type per channel for digits
// DetectionType can be:
// dtDTMF
// dtMFP (=DETECT_MFF)
//------------------------------------------------------------
/*short WCDECL dg_SetDetectionType(short port, short DetectionType)
{
	

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	switch(DetectionType)
	{
		case dtDTMF:
			dg_SetDetectionType(port,DETECT_DTMF,DG_ENABLE);
			break;
		case dtMFP:
			dg_SetDetectionType(port,DETECT_MFF,DG_ENABLE);
			break;
	}

	return DG_EXIT_SUCCESS;
}
*/

//---------------------------------------------------
// Sets record gain  -  -40 to +12
// Default gain is 4
// IMPLEMENTAR o CMD_GAIN_PGA nas novas placas VoicerBox PCI/48
// Nas placas analogicas antigas, o ganho de gravacao esta limitado de 1 a 10
//---------------------------------------------------
short WCDECL dg_SetRecordGain(short port, short gain) 
{

	//check driver enabled
	if (!dg_DriverEnabled())
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//Na placa E1, o ganho de gravacao sera feito em cima do ganho
	//no RX da funcao SetPortGain
	if (gain < -40) 
		gain = -40;

	if (gain > 12) 
		gain = 12;

	return dg_SetPortGain(port,REC_GAIN,gain);

}

short WCDECL dg_StopPlayFileWithoutEvent(short port)
{
	ports_info[port-1].play_digit_cutoff = 1; /* simulating digit detected */
	ports_info[port-1].bAvoidEvent = 1;

	write_debug("dg_StopPlayFileWithoutEvent: channel %d",port);
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// stops playback
//-------------------------------------------------------------------------
short WCDECL dg_StopPlayFile(short port)
{
//	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;


	//if isn't playing, return
	if (!ports_info[port-1].bIsPlaying)
	{
		return DG_ERROR_NOT_PLAYING;
	}
	write_debug("dg_StopPlayFile: channel %d",port);
	ports_info[port-1].bAbortPlayBack = TRUE;

	
	/* send command to stop */ /*
#ifdef WIN32
	//gera evento para nao ficar preso na thread
	if (PlayEvent[port-1].hEvent!=NULL)
		SetEvent(PlayEvent[port-1].hEvent);
#else
	sem_post(&playsync_sem[port-1]);
#endif*/
/*
	SetPlayStatus(port,PLAY_OFF);
	//set commands
	tx_command_e1.command = CMD_PLAY;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port-1;
	tx_command_e1.param1 = port-1;
	tx_command_e1.param2 = E1_PLAY_OFF;
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&(tx_command_e1));
	
	SetPlayStatus(port,PLAY_OFF);
*/
	return DG_EXIT_SUCCESS;
}

//---------------------------------------------------------------------------------
//
//---------------------------------------------------------------------------------
short WCDECL dg_PlayFile(short port, char *FileName, char *TermDigits, long Origin)
{
	FILE *f;
	short rm_size,local_rp=-1;
	short local_port = port;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (!FileName)
		return DG_ERROR_PLAY_INVALID_FILENAME;

	//check if file exists
	if ((f=fopen(FileName,"rb"))==NULL)
		return DG_ERROR_PLAY_OPENFILE;
	else
		fclose(f);

	//copies data to file structure
	digivoice_entercriticalsection(&port_mutex[port-1], port);

	if (Origin!=-1 && Origin!=0)
		Origin=0;	//force to start from beginning

	local_rp = ports_info[port-1].play_rp;

	//check if there is room to put another file in queue
    if (local_rp > ports_info[port-1].play_wp)
        rm_size = (local_rp - ports_info[port-1].play_wp);
    else
        rm_size = (DG_MAX_PLAY_QUEUE-ports_info[port-1].play_wp)+local_rp;

	if (rm_size>0)
	{
		ports_info[port-1].play_info[ ports_info[port-1].play_wp ].port = port;
		strlcpy(ports_info[port-1].play_info[ ports_info[port-1].play_wp ].filename,FileName,DG_MAX_PATH);

		if (TermDigits == NULL || TermDigits[0] == 0) //estava (TermDigits == "")
		{
			ports_info[port-1].play_info[ ports_info[port-1].play_wp ].term_digits[0] = '\0';
			write_debug("dg_PlayFile - Zerou o TermDigits que veio vazio no dg_playfile",port);
		}
		else
		{
			strlcpy(ports_info[port-1].play_info[ ports_info[port-1].play_wp ].term_digits ,TermDigits,DG_MAX_PATH);
			write_debug("dg_PlayFile - Nao zerou o TermDigits pois veio com conteudo: (%s) no dg_playfile",TermDigits);
		}

		ports_info[port-1].play_info[ ports_info[port-1].play_wp ].detected_digit = 0;
		ports_info[port-1].play_info[ ports_info[port-1].play_wp ].origin = Origin;
		ports_info[port-1].play_info[ ports_info[port-1].play_wp ].return_code = DG_EXIT_SUCCESS;
		ports_info[port-1].play_wp++;

		//rotate
		if (ports_info[port-1].play_wp>=(DG_MAX_PLAY_QUEUE))
			ports_info[port-1].play_wp=0;

		write_debug("dg_PlayFile (%d): Inserting new file %s ",port,FileName);

	}
	else
	{
		digivoice_leavecriticalsection(&port_mutex[port-1], port);
		return DG_ERROR_PLAY_BUFFER_FULL;
	}

	//check if the thread is running
	if (thread_playback_id[port-1]==0)      //todo: verificar warning
	{
		//start worker thread
		write_debug("dg_PlayFile (%d): Criando Thread");
		ports_info[port-1].bAbortPlayBack = FALSE;
		//ports_info[port-1].play_digit_cutoff = FALSE;
		if (digivoice_beginthread(&thread_playback_id[port-1],PlayThread,0,local_port)!=0)
		{
			digivoice_leavecriticalsection(&port_mutex[port-1], port);
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
		}
	}
	digivoice_leavecriticalsection(&port_mutex[port-1], port);
/*	else
	{
#ifdef WIN32
		//gera evento para nao ficar preso na thread
		write_debug("dg_PlayFile (%d): Sending event thread");
		if (PlayEvent[port-1].hEvent!=NULL)
			SetEvent(PlayEvent[port-1].hEvent);
#else
		sem_post(&playsync_sem[port-1]);
#endif
	}*/


	return DG_EXIT_SUCCESS;
}


//-------------------------------------------------------------------------
// 0 - Inicio OK
// -1 - Arquivo Inexistente
// 2 - Ja esta falando
// remaining_lines devolve o numero de linhas
//-------------------------------------------------------------------------
short WCDECL dg_PlayBuffer(short port, void *Samples, short samples_size, int *remaining_size)
{
	short j=0;
	char char_tx[(WRITE_BUFFER_LINES)*SAMPLES_SIZE_GSM];
	short *tmp16;
	char *tmp8;
	dg_cmd_tx tx_command_e1;
	short local_rp;
	int rm_size=0;
	unsigned char cSource[65];
	unsigned char cTarget[66];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > nPortsCount)
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (dg_IsPlaying(port))
		return DG_ERROR_ALREADY_PLAYING;

	if (samples_size > (WRITE_BUFFER_LINES)*SAMPLES_SIZE_GSM)
		return DG_ERROR_PARAM_OUTOFRANGE;

    if (samples_size>0)
    {
    	if (ports_info[port-1].play_streaming_on==0)
    	{
    		//write_debug("dg_PlayBuffer (%d): reset pointers - size %d - format=%x ",port, samples_size,
			//			ports_info[port-1].FPlayFileFormat);
    		pm[port-1]->play_mode = PLAY_BUFFER;
    		pm[port-1]->wp = 0;
    		pm[port-1]->rp = 0;
    		SetPlayStatus(port,PLAY_START);
    	}

    	//Insert into FIFO to send to device driver
    	switch (ports_info[port-1].FPlayFileFormat)
    	{
    		case ffGsm610:
    			tmp8 = (char *)Samples;
    			for (j=0; j< (samples_size/SAMPLES_SIZE_GSM); j++)
    			{
    				local_rp = pm[port-1]->rp;

    				if (local_rp > pm[port-1]->wp)
    				{

    					if (pm[port-1]->wp==(local_rp-10))
    					{
    						write_debug("dg_PlayBuffer (%d): (DG_ERROR_PLAY_BUFFER_FUL)ERRO FULL 1 wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    						return DG_ERROR_PLAY_BUFFER_FULL;
    					}
    				}
    				else
    					if (pm[port-1]->wp > local_rp)
    					{
    						if (((WRITE_BUFFER_LINES)-pm[port-1]->wp)+local_rp == 10)
    						{
    							write_debug("dg_PlayBuffer (%d): (DG_ERROR_PLAY_BUFFER_FULL)ERRO FULL 2 wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    							return DG_ERROR_PLAY_BUFFER_FULL;
    						}
    					}

    				memcpy(&pm[port-1]->data[pm[port-1]->wp],tmp8 + (j*SAMPLES_SIZE_GSM),SAMPLES_SIZE_GSM);
    				pm[port-1]->wp++;

    				write_debug("dg_PlayBuffer (%d): wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    				if (pm[port-1]->wp>=(WRITE_BUFFER_LINES))
    				{
    					//write_debug("dg_PlayBuffer (%d): VIROU BUFFER wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    					pm[port-1]->wp = 0;
    				}


    			}
    			break;

     		case ffWave49:
    			tmp8 = (char *)Samples;
    			for (j=0; j< (samples_size/65); j++)
    			{
    				local_rp = pm[port-1]->rp;

    				if (local_rp > pm[port-1]->wp)
    				{

    					if (pm[port-1]->wp==(local_rp-10))
    					{
    						write_debug("dg_PlayBuffer (%d): (DG_ERROR_PLAY_BUFFER_FUL)ERRO FULL 1 wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    						return DG_ERROR_PLAY_BUFFER_FULL;
    					}
    				}
    				else
    					if (pm[port-1]->wp > local_rp)
    					{
    						if (((WRITE_BUFFER_LINES)-pm[port-1]->wp)+local_rp == 10)
    						{
    							write_debug("dg_PlayBuffer (%d): (DG_ERROR_PLAY_BUFFER_FULL)ERRO FULL 2 wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    							return DG_ERROR_PLAY_BUFFER_FULL;
    						}
    					}

                    memcpy(cSource, tmp8 + (j*65),65);  //copy one wave49 frame

                    dg_GsmDecode49(cSource,cTarget);    //transcode from wave49 to gsm

                    //insert the first 33 bytes into FIFO
    				memcpy(&pm[port-1]->data[pm[port-1]->wp],cTarget,SAMPLES_SIZE_GSM);
    				pm[port-1]->wp++;

    				//write_debug("dg_PlayBuffer (%d): wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    				if (pm[port-1]->wp>=(WRITE_BUFFER_LINES))
    				{
    					//write_debug("dg_PlayBuffer (%d): VIROU BUFFER wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    					pm[port-1]->wp = 0;
    				}

                    //insert the last 33 bytes into FIFO
    				memcpy(&pm[port-1]->data[pm[port-1]->wp],&cTarget[33],SAMPLES_SIZE_GSM);
    				pm[port-1]->wp++;

    				//write_debug("dg_PlayBuffer (%d): wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    				if (pm[port-1]->wp>=(WRITE_BUFFER_LINES))
    				{
    					//write_debug("dg_PlayBuffer (%d): VIROU BUFFER wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    					pm[port-1]->wp = 0;
    				}

    			}
      			break;

    		case ffWaveALaw:
    		case ffWaveULaw:
    			//send 16 samples
    			tmp8 = (char *)Samples;
    			for (j=0; j< (samples_size/SAMPLES_SIZE); j++)
    			{
    				local_rp = pm[port-1]->rp;
    				if (local_rp > pm[port-1]->wp)
    				{
    					if (pm[port-1]->wp==(local_rp-10))
    					{
    						return DG_ERROR_PLAY_BUFFER_FULL;
    					}
    				}
    				else
    					if (pm[port-1]->wp > local_rp)
    					{
    						if (((WRITE_BUFFER_LINES)-pm[port-1]->wp)+local_rp == 10)
    						{
    							return DG_ERROR_PLAY_BUFFER_FULL;
    						}
    					}

    				memcpy(&pm[port-1]->data[pm[port-1]->wp],tmp8 + (j*SAMPLES_SIZE),SAMPLES_SIZE);

    				pm[port-1]->wp++;

    				if (pm[port-1]->wp>=(WRITE_BUFFER_LINES))
    				{
    					pm[port-1]->wp = 0;
    				}
    			}
			//write_debug("dg_PlayBuffer g711 (%d): wp=%d rp=%d - samples=%d",port,pm[port-1]->wp,local_rp, samples_size);
    			break;
    		case ffWavePCM:
    			tmp16 = (short *)Samples;
    			for (j=0;j<samples_size;j++)
    			{
    				char_tx[j] = _st_14linear2ulaw[ 0x2000- ( (*tmp16)>>2 ) ];
    				tmp16++;
    			}
    			//insert into play fifo 16 samples per line
    			for (j=0; j< (samples_size/SAMPLES_SIZE); j++)
    			{
    				local_rp = pm[port-1]->rp;
    				if (local_rp > pm[port-1]->wp)
    				{
    					if (pm[port-1]->wp==(local_rp-10))
    					{
    						return DG_ERROR_PLAY_BUFFER_FULL;
    					}
    				}
    				else
    					if (pm[port-1]->wp > local_rp)
    					{
    						if (((WRITE_BUFFER_LINES)-pm[port-1]->wp)+local_rp == 10)
    						{
    							return DG_ERROR_PLAY_BUFFER_FULL;
    						}
    					}

    				memcpy(&pm[port-1]->data[pm[port-1]->wp],char_tx+(j*SAMPLES_SIZE),SAMPLES_SIZE);
    				pm[port-1]->wp++;
    				if (pm[port-1]->wp>=(WRITE_BUFFER_LINES))
    				{
    					pm[port-1]->wp = 0;
    				}
    			}
    			break;

    	}

        if (ports_info[port-1].play_streaming_on<2)
        	ports_info[port-1].play_streaming_on++;

    	if (ports_info[port-1].play_streaming_on==2)
    	{
    		SetPlayStatus(port,PLAY_ON);

    		//set commands
    		tx_command_e1.command = CMD_PLAY;
    		tx_command_e1.port_or_card = ASSUME_PORT;
    		tx_command_e1.port = port-1;
    		tx_command_e1.param1 = (unsigned char)port-1;
    		switch (ports_info[port-1].FPlayFileFormat)
    		{
    			case ffWaveALaw:
    				tx_command_e1.param2 = E1_PLAY_A;
    				break;
    			case ffWaveULaw: case ffSig: case ffWavePCM:
    				tx_command_e1.param2 = E1_PLAY_U;
    				break;
    			case ffGsm610: case ffWave49:                                
    				tx_command_e1.param2 = E1_PLAY_GSM;
    				break;
    		}
    		tx_command_e1.param3 = 0;
    		tx_command_e1.param4 = 0;
    		tx_command_e1.param5 = 0;
    		write_generic_command(&tx_command_e1);
    		//set flag to avoid starting playing again
    		ports_info[port-1].play_streaming_on=3;
    		//write_debug("dg_PlayBuffer (%d): play_streaming_on - wp=%d rp=%d",port, pm[port-1]->wp,pm[port-1]->rp);		
    
    	}   	
    } //samples_size>0
    else
        local_rp = pm[port-1]->rp;


    if (remaining_size!=NULL) 
    {

        if (local_rp > pm[port-1]->wp)
            rm_size = (local_rp - pm[port-1]->wp);
        else
            rm_size = (WRITE_BUFFER_LINES-pm[port-1]->wp)+local_rp;

        if ((ports_info[port-1].FPlayFileFormat)==ffGsm610)
            rm_size = rm_size * SAMPLES_SIZE_GSM;
        else
            rm_size = rm_size * SAMPLES_SIZE;

        //write_debug("dg_PlayBuffer (%d): remaining calc wp=%d rp=%d - samples=%d rm_size=%d",port,pm[port-1]->wp,local_rp, 
        //                samples_size, rm_size);

        *(int *)remaining_size = rm_size;
    }


	return DG_EXIT_SUCCESS;

}//----- fala buffer

//-------------------------------------------------------------------------
// stops playback from Buffer
//-------------------------------------------------------------------------
short WCDECL dg_StopPlayBuffer(short port)
{
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//if isn't playing, return
	if (ports_info[port-1].bIsPlaying)
		return DG_ERROR_ALREADY_PLAYING;	

	SetPlayStatus(port,PLAY_OFF);

	//set commands
	tx_command_e1.command = CMD_PLAY;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port-1;
	tx_command_e1.param1 = (unsigned char)port-1;
	tx_command_e1.param2 = E1_PLAY_OFF;
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&(tx_command_e1));

    pm[port-1]->wp = 0;
    pm[port-1]->rp = 0;

	ports_info[port-1].play_streaming_on=0;
	write_debug("dg_StopPlayBuffer (%d): end\n", port);		
	return DG_EXIT_SUCCESS;

}

//-------------------------------------------------------------------------
// Pause inputbuffer changing status
// only if inputbuffer is ON
//-------------------------------------------------------------------------
short WCDECL dg_PauseInputBuffer(short port, short paused)
{
    short card, card_channel;

    //check driver enabled
    if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

    //check port
    if (port < 1 || port > dg_GetPortsCount())
        return DG_ERROR_PORT_OUT_OF_RANGE;

	port2CardChannel(port, &card, &card_channel);

    //check if thread is running
    if (sm->Cards[card-1].input_buffer[card_channel-1]==INPUT_BUFFER_ON || 
        sm->Cards[card-1].input_buffer[card_channel-1]==INPUT_BUFFER_WAIT)
    {
        if (paused)
            SetInputBufferStatus(port,INPUT_BUFFER_WAIT);
        else
            SetInputBufferStatus(port,INPUT_BUFFER_ON);   

    }
    return DG_EXIT_SUCCESS;
}


//-------------------------------------------------------------------------
// Enabled streaming to application
// agc_enable can receive:
// DG_ENABLE_AGC=1
// DG_DISABLE_AGC=0
//-------------------------------------------------------------------------
short WCDECL dg_EnableInputBuffer(short port, short agc_enable)
{

	short card, card_channel;
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//agc enables
	if (agc_enable!=DG_ENABLE && agc_enable!=DG_DISABLE)
		return DG_ERROR_PARAM_OUTOFRANGE;

	port2CardChannel(port, &card, &card_channel);

	write_debug("dg_EnableInputBuffer (%d)- Entra card=%d ch=%d", port,card,card_channel );
	if (sm->Cards[card-1].input_buffer[card_channel-1]==INPUT_BUFFER_OFF)	//check if it is already enable
	{
		ports_info[port-1].port_recthread = port;
		ports_info[port-1].input_buffer_agc = agc_enable; //save this information

		/* try to create thread */
		if (digivoice_beginthread(&thread_record_id[port-1],InputBufferThread,0,&ports_info[port-1].port_recthread)!=0)
		{
			write_debug("dg_EnableInputBuffer (%d)- erro ao criar thread", port);
			ports_info[port-1].bIsRecording = FALSE;	//unlock access
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
		}		

		//SetInputBufferStatus(port,INPUT_BUFFER_INITIAL);

		//send command
		tx_command_e1.port_or_card = ASSUME_PORT;
		tx_command_e1.command = CMD_REC;
		tx_command_e1.port = port-1;
		tx_command_e1.param1 = (unsigned char)port-1;
		switch(ports_info[port-1].FRecordFileFormat)
		{
			case ffWaveALaw:
				tx_command_e1.param2 = E1_REC_A;
				break;
			case ffWaveULaw: case ffSig: case ffWavePCM:
				tx_command_e1.param2 = E1_REC_U;
				break;
			case ffGsm610: case ffWave49:                                
				tx_command_e1.param2 = E1_REC_GSM;
				break;
		}
		tx_command_e1.param3 = (unsigned char)agc_enable;
		tx_command_e1.param4 = 0;
		tx_command_e1.param5 = 0;
		write_generic_command(&(tx_command_e1));


		write_debug("dg_EnableInputBuffer (%d)- sai", port);
		return DG_EXIT_SUCCESS;
	}
	else
	{
		write_debug("dg_EnableInputBuffer (%d)- ja ta rodando!!!!!!!!!", port);
		return DG_ERROR_THREAD_ALREADY_RUNNING;
	}
}
//-------------------------------------------------------------------------
// Disables streaming to application
//-------------------------------------------------------------------------
short WCDECL dg_DisableInputBuffer(short port)
{
	dg_cmd_tx tx_command_e1;
	short card, card_channel;

	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
  if (port < 1 || port > dg_GetPortsCount())
  	return DG_ERROR_PORT_OUT_OF_RANGE;

	port2CardChannel(port, &card, &card_channel);

	write_debug("dg_DisablingInputBuffer: Entrou na rotina - channel %d card %d/%d----------",port,card,card_channel);

#ifdef WIN32
	SetEvent(RecEvent[port-1].hEvent);
#else
    sem_post(&recsync_sem[port-1]);
#endif
	if (sm->Cards[card-1].input_buffer[card_channel-1]!=INPUT_BUFFER_OFF)	//check if its running
	{
        //release pause
        dg_PauseInputBuffer(port, DG_RELEASE);

		write_debug("dg_DisablingInputBuffer: Entrou na rotina 2 channel %d card %d/%d----------",port,card,card_channel);

        if (ports_info[port-1].bIsRecording)
            SetInputBufferStatus(port,INPUT_BUFFER_ENDING);
        else
            SetInputBufferStatus(port,INPUT_BUFFER_OFF);

#ifdef WIN32
        SetEvent(RecEvent[port-1].hEvent);
#else
        sem_post(&recsync_sem[port-1]);
#endif

		//send command to E1 card
		tx_command_e1.port_or_card = ASSUME_PORT;
		tx_command_e1.command = CMD_REC;
		tx_command_e1.port = port-1;
		tx_command_e1.param1 = (unsigned char)port-1;
		tx_command_e1.param2 = E1_REC_OFF;
		tx_command_e1.param3 = 0;
		tx_command_e1.param4 = 0;
		tx_command_e1.param5 = 0;
		write_generic_command(&tx_command_e1);
	}
	write_debug("dg_DisablingInputBuffer: Saindo da rotina - channel %d ----------",port);	
	//dbg(port,"dg_DisableInputBuffer - sai");
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Start record for the specified file
// 0 -OK
// 1 - Failed to open file
// 2 - Already is recording
// 3 - Driver Disabled
//-------------------------------------------------------------------------
short WCDECL dg_RecordFile(short port, char *FileName, char *TermDigits) 
{
	short ret=0;
	dg_event_data_structure received;
	short card, card_channel;

	//check driver enabled
 	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;
	
	//Get card and card_channel
	port2CardChannel(port, &card, &card_channel);

	//it is necessary the input buffer is enabled to allow recording
	//if (sm->Cards[card-1].input_buffer[card_channel-1]==INPUT_BUFFER_OFF)
	/*if (ports_info[port-1].rec_streaming_on==0)
	{
		write_debug("dg_RecordFile: port %d Input buffer nao estiver habilitado!!!",port);
		return DG_ERROR_THREAD_NOT_RUNNING;
	}*/

	//nao liga se estiver parando
	if (ports_info[port-1].bStopping == TRUE)
	{
		write_debug("dg_RecordFile: port %d - previous thread still running!!!",port);
		return DG_ERROR_REC_STOPPING;
	}

	if (strlen(FileName)==0)
		return DG_ERROR_REC_OPENFILE;

	write_debug("--------------------------------------");
	write_debug("dg_RecordFile: port %d",port);
	write_debug("dg_recordfile: FileName %s ",FileName);              
	write_debug("dg_recordfile: TermDigits %s",TermDigits);              
	write_debug("--------------------------------------");

	if (!ports_info[port-1].bIsRecording)
	{
		
		//dbg(port, "dg_RecordFile: starting 2");		
		if((ports_info[port-1].fRec = fopen(FileName, "w+b")) == NULL)
		{
			//failed to open file
			ports_info[port-1].bIsRecording = FALSE;	//unlock access
			ret = DG_ERROR_REC_OPENFILE;
		}
		else
		{
			//Inicia gravacao
			if (ports_info[port-1].FRecordFileFormat == (short)ffSig)
			{
				hWave.riff[0] = 'R';
				hWave.riff[1] = 'I';
				hWave.riff[2] = 'F';
				hWave.riff[3] = 'F';
				hWave.tam_arq = 0+38;
				hWave.wave[0] = 'S';
				hWave.wave[1] = 'I';
				hWave.wave[2] = 'G';
				hWave.wave[3] = ' ';
				hWave.fmt[0] = 'f';
				hWave.fmt[1] = 'm';
				hWave.fmt[2] = 't';
				hWave.fmt[3] = ' ';
				hWave.tamanho = 18;    //18
				hWave.formato = 7;   //7  milaw
				hWave.canais = 1;    //1-mono - 2 - stereo
				hWave.freq = 8000;   //samples per second
				hWave.bs = 8000;     //bytes per second
				hWave.bloco = 1;
				hWave.par = 8;
				hWave.data[0] = 'd';
				hWave.data[1] = 'a';
				hWave.data[2] = 't';
				hWave.data[3] = 'a';           //total de 48 elementos
				hWave.tm = 0;
				fwrite(&hWave,WHEADER_SIZE,1,ports_info[port-1].fRec);
			}
			else
			{
				if (ports_info[port-1].FRecordFileFormat == (short)ffGsm610 && FGSM_Mode==GSM_DIGIVOICE)
				{
					//GSMHeader	gh;
					SaveHeaderWave(1,ports_info[port-1].fRec,1,ffGsm610); 
					//fwrite(&gh,GSM_HEADER_SIZE,1,ports_info[port-1].fRec);
				}
				else
				{
					//wave header 
					//the information will be updated after record
					if (ports_info[port-1].FRecordFileFormat == (short)ffWavePCM ||
						ports_info[port-1].FRecordFileFormat == (short)ffWaveULaw ||
						ports_info[port-1].FRecordFileFormat == (short)ffWaveALaw ||
						ports_info[port-1].FRecordFileFormat == (short)ffWave49)
					{
						//WGenericHeader hd;
						SaveHeaderWave(1,ports_info[port-1].fRec,1,ports_info[port-1].FRecordFileFormat); 
					}
				}

			}
			//reset file size
			ports_info[port-1].lRecFileSize = 0L;

			ports_info[port-1].bIsRecording = TRUE;	//lock access

			if (FAutoClearDigits)
			{
				//Limpa propriedade global - buffer de digitos
				ports_info[port-1].FDigits[0] = '\0';
			}

			//copy cut-off digits
			strcpy(ports_info[port-1].FRecEndDigits,TermDigits);

			sm->Cards[card-1].recording_stop[card_channel-1] = 0;
			//reset record time
			ports_info[port-1].lElapsedRecTime = 1L;

			ports_info[port-1].port_recthread = port;

			ports_info[port-1].bIsRecording = TRUE;
			ports_info[port-1].bRecPaused = FALSE;
			ports_info[port-1].bStopping = FALSE;

			//enable elapsed timer
			tmrTimeRec[port-1].Enabled = FALSE;
			tmrTimeRec[port-1].Interval = 1000 / FACTOR_TIMER;
			SetEnableTimer(&tmrTimeRec[port-1],TRUE);

			//dbg(port, "dg_RecordFile: starting 3");
			//raise event
			received.command = EV_RECORDSTART;
			received.port = port;
			received.data = 0;
			RaiseEvents_ThreadSafe(received.command,received.data,0,received.port,&port_mutex[received.port-1]);
			//dbg(port, "dg_RecordFile: starting 4");
		/*	if (SendEventsToApp!=NULL)
			{
				SendEventsToApp((void *)&received);
			}*/
			ret = DG_EXIT_SUCCESS;
		}
	} //if GRAVA_OFF
	else
	{
		//dbg(port, "dg_RecordFile: sai Isrecording");
		write_debug("dg_RecordFile: port %d - IsRecording true",port);
		ret = DG_ERROR_REC_ALREADY_RECORDING;
	}


	return ret;
}

//------------------------------------------------------------------------------------
// Pause record process
// return
// 1 - paused on
// 0 - pause off
//------------------------------------------------------------------------------------
short WCDECL dg_RecordPause(short port, short paused)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
	if (port < 1 || port > dg_GetPortsCount())
  	return DG_ERROR_PORT_OUT_OF_RANGE;

	//se nao estiver gravando, cai fora
	if (!ports_info[port-1].bIsRecording)
	{
		return DG_ERROR_REC_NOT_RECORDING;
	}

	//Muda estado de pausa
	ports_info[port-1].bRecPaused = paused;

	return DG_EXIT_SUCCESS;

}

//-------------------------------------------------------------------------
// Stops file record
//-------------------------------------------------------------------------
short WCDECL dg_StopRecordFile(short port)
{
	short card, card_channel;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//Get card and card_channel
	port2CardChannel(port, &card, &card_channel);

	if (sm->Cards[card-1].input_buffer[card_channel-1]==INPUT_BUFFER_OFF)	//check if its running
		return DG_ERROR_THREAD_NOT_RUNNING;

	if (ports_info[port-1].bStopping == TRUE)
		return DG_EXIT_SUCCESS;

	//se nao estiver gravando, cai fora
	if (!ports_info[port-1].bIsRecording)
	{
		return DG_EXIT_SUCCESS;
	}

	//set flag to avoid reentrance

	digivoice_entercriticalsection(&port_mutex[port-1], port);
	ports_info[port-1].bStopping = TRUE;
	digivoice_leavecriticalsection(&port_mutex[port-1], port);


#ifdef WIN32
	//nao seta o evento pq eh na pauleira que a thread roda
	//if (RecEvent[port-1].hEvent)
	//	SetEvent(RecEvent[port-1].hEvent);
#endif
/************
	sm->Cards[card].recording_stop[card_channel] = 1;
	//wake-up thread
	if (RecEvent[port-1].hEvent)
		SetEvent(RecEvent[port-1].hEvent);
*************/
	write_debug("-------- Fim dg_StopRecordFile: channel %d ----------",port);
	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------
// Sets the default gsm format, with or without header
// Default value = GSM_DIGIVOICE
//-----------------------------------------------------------------
short WCDECL dg_SetGSMMode(short mode)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	if (mode < GSM_DIGIVOICE || mode > GSM_RAW)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	FGSM_Mode = mode;

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------
// sets play format ffWaveULaw,ffSig,ffWavePCM,ffGsm610,ffWaveALaw, ffWave49)
//----------------------------------------------------------------
short WCDECL dg_SetPlayFormat(short port, enum EnumFileFormat file_format)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	/*if (FCardType == ctVBE1 && (file_format==ffWavePCM || file_format==ffSig) )
		return EXIT_FAILURE;*/
	
	ports_info[port-1].FPlayFileFormat = (short)file_format;
	pm[port-1]->format = (u8)file_format;
	
	write_debug("SetPlayFormat: Mudou formato para %x", (short)file_format);

	return DG_EXIT_SUCCESS;
}
//-----------------------------------------------------------------
// get play format (ffSig, ffWaveULaw, ffWavePCM, ffGsm610
//----------------------------------------------------------------
short WCDECL dg_GetPlayFormat(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	return ports_info[port-1].FPlayFileFormat;
}
//-----------------------------------------------------------------
// sets record format (ffSig, ffWaveULaw, ffWavePCM, ffGsm610
//----------------------------------------------------------------
short WCDECL dg_GetRecordFormat(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	return ports_info[port-1].FRecordFileFormat;
}

//-----------------------------------------------------------------
// sets record format (ffSig, ffWaveULaw, ffWavePCM, ffGsm610, 4)
//----------------------------------------------------------------
short WCDECL dg_SetRecordFormat(short port, enum EnumFileFormat file_format)
{
	short card, card_channel;
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
  if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	port2CardChannel(port, &card, &card_channel);

	if (sm->Cards[card-1].input_buffer[card_channel-1]==INPUT_BUFFER_OFF)	//check if it is already enable
	{
		ports_info[port-1].FRecordFileFormat = (short)file_format;
		return DG_EXIT_SUCCESS;
	}
	else
	{
		//allow change record format with the thread running only if it's not recording to a file
		if (!dg_IsRecording(port))
		{
			//Change format on the fly
			//first turn off
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.command = CMD_REC;
			tx_command_e1.port = port-1;
			tx_command_e1.param1 = (unsigned char)port-1;
			tx_command_e1.param2 = E1_REC_OFF;
			write_generic_command(&(tx_command_e1));
			
			
			
			write_debug("----> mudando gravacao para %x",(short)file_format);
			//send command
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.command = CMD_REC;
			tx_command_e1.port = port-1;
			tx_command_e1.param1 = (unsigned char)port-1;
			
			
			switch((short)file_format)
			{
				case ffWaveALaw:
					tx_command_e1.param2 = E1_REC_A;
					break;
				case ffWaveULaw: case ffSig: case ffWavePCM:
					tx_command_e1.param2 = E1_REC_U;
					break;
				case ffGsm610: case ffWave49:                               
					tx_command_e1.param2 = E1_REC_GSM;
					break;
			}
			tx_command_e1.param3 = (unsigned char)ports_info[port-1].input_buffer_agc;
			tx_command_e1.param4 = 0;
			tx_command_e1.param5 = 0;
			
			//digivoice_entercriticalsection(&port_mutex[port-1], port);//removed on 4.1.0.0
			//{
			write_generic_command(&(tx_command_e1));
			ports_info[port-1].FRecordFileFormat = (short)file_format;
			
			if (ports_info[port-1].FRecordFileFormat == ffGsm610 || ports_info[port-1].FRecordFileFormat == ffWave49)    
				sm->Cards[card-1].gsm_state_rec[card_channel-1] = GSM_WAIT;
			else
				sm->Cards[card-1].gsm_state_rec[card_channel-1] = GSM_OFF;

            /* force restarting buffers into device driver*/
            sm->Cards[card-1].input_buffer[card_channel-1] = INPUT_BUFFER_INITIAL;
			//}
			//digivoice_leavecriticalsection(&port_mutex[port-1], port);
            
			return DG_EXIT_SUCCESS;
		}	
		else
			return DG_ERROR_REC_ALREADY_RECORDING;
	}
}

//-----------------------------------------------------------------
// perform a flash with msec interval 
// ** flash_count in digital cards are always 1
//----------------------------------------------------------------
short WCDECL dg_Flash(short port, short flash_count, long msec, long pauseafterflash) 
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//Pausa fora do range
	if (pauseafterflash < 0 || pauseafterflash > 60000)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (flash_count < 0 || flash_count > 10	) //!!
		return DG_ERROR_PORT_OUT_OF_RANGE;


	if (ports_info[port-1].cas_info.thread_id > 0)	//custom cas thread control
	{
		//send commands through CAS Thread
		//if msec or pauseafterflash is zero, assume internal configuration read from
		//configuration file
		if (msec>0)
			ports_info[port-1].cas_info.flash1_delay = msec;
		if (pauseafterflash>0)
			ports_info[port-1].cas_info.flash2_delay = pauseafterflash;

		if (dg_InsertCASFifo(port,CFLASH,0)==EXIT_FAILURE)
			return DG_EXIT_FAILURE;
	}
	else
	{
		//starts the flash thread
		ports_info[port-1].flash_info.port = port;
		ports_info[port-1].flash_info.pause_after_flash = pauseafterflash; 
		ports_info[port-1].flash_info.flash_count = flash_count;
		ports_info[port-1].flash_info.flash_time = msec;

		if (msec > 0)
		{
			if (digivoice_beginthread(&thread_flash_id[port-1],FlashThread,0,&ports_info[port-1].flash_info)!=0)
			{
				ports_info[port-1].FStatusPort = spNone;
				return DG_ERROR_COULD_NOT_CREATE_THREAD;
			}			
#ifdef WIN32
			SetThreadPriority(thread_flash_id[port-1],THREAD_PRIORITY_BELOW_NORMAL);
#endif

			if (ports_info[port-1].e1_info.sigtype == R2_TYPE_CB_FXO)
				if (dg_InsertE1Fifo(port,CFLASH,0)==EXIT_FAILURE)
					return EXIT_FAILURE;				
		}
		else
			write_debug("dg_Flash> Port %d, flash time %d", port, ports_info[port-1].flash_info.flash_time);		
	} //else

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------------
// Enable answer detection passing the answer sensibility too
//----------------------------------------------------------------------
short WCDECL dg_EnableAnswerDetection(short port) 
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//enables answer flag of callprogress thread
	//the thread was already created
	if (ports_info[port-1].cp_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;
	

	ports_info[port-1].cp_info.answer_enabled = 1;


	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------------
// disable answer detection
//----------------------------------------------------------------------
short WCDECL dg_DisableAnswerDetection(short port) 
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].cp_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	ports_info[port-1].cp_info.answer_enabled = 0;

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------------
// set value to answer sensibility. Needs to call enablecallprogress to
// take efect
//----------------------------------------------------------------------
/*short WCDECL dg_SetAnswerSensitivity(short factor) 
{
	//range	
	if (factor < 1 || factor > 10)
		factor = 6;

	FAnswerFactor = factor;
	
	write_debug("dg_SetAnswerSensitivity: value: %d",factor);

	return DG_EXIT_SUCCESS;
}*/
//----------------------------------------------------------------------
// set value to answer limiar. Needs to call enablecallprogress to
// take efect
//----------------------------------------------------------------------
/*short WCDECL dg_SetAnswerThreshold(short port, short threshold) 
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;


	if (threshold < 1) 
		threshold = 1;

	if (threshold > 30) 
		threshold = 30;

	write_debug("dg_SetAnswerThreshold: port: %d - value: %d",port,threshold);		

	//atribui a variavel global	
	ports_info[port-1].FThreshold = threshold;
	
	return DG_EXIT_SUCCESS;
}*/



//----------------------------------------------------------------------
// Enables dsp pulse detection
// sensibility - -42dB to +12dB
//----------------------------------------------------------------------
short WCDECL dg_EnablePulseDetection(short port, short sensibility) 
{

	dg_cmd_tx tx_command_e1;
	double fTemp;
	unsigned short value;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (sensibility < -42 || sensibility > 12)
		return DG_ERROR_PARAM_OUTOFRANGE;

	fTemp = 0.5 + 16384 * pow(10,(sensibility/20.0));
	value = (unsigned short)fTemp;

	if (value>=65535) value=65535;

	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.command = CMD_PULSE;
	tx_command_e1.port = port-1;
	tx_command_e1.param1 = (unsigned char)port-1;
	tx_command_e1.param2 = (unsigned char)(value >> 8);
	tx_command_e1.param3 = (unsigned char)(value & 0xff);
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------------
// disables dsp pulse detection 
//----------------------------------------------------------------------
short WCDECL dg_DisablePulseDetection(short port) 
{

	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//para desabilitar envia tudo zerado
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.command = CMD_PULSE;
	tx_command_e1.port = port-1;
	tx_command_e1.param1 = (unsigned char)port-1;
	tx_command_e1.param2 = 0;
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
//Atribui a duracao do DTMF
// Sempre manda a duracao e a Pausa juntos
//------------------------------------------------------------
short WCDECL dg_SetDtmfConfig(long duration, long pause)
{
	
	if (!FDriverEnabled)  
		return DG_ERROR_DRIVER_CLOSED;

	//range verification
  if ( (duration < 0L) || (duration > 60000L))
			return DG_ERROR_PARAM_OUTOFRANGE;
			
  if ( (pause < 0L) || (pause > 60000L))
			return DG_ERROR_PARAM_OUTOFRANGE;
		
	FDTMFDuration = duration;
	FDTMFPause = pause;

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------
// Set auxiliar frequenci to detect fax or another custom freq
//-----------------------------------------------------------------
short WCDECL dg_SetFaxFrequencies(short first, short second)
{
	float nPoints = 205.0;
	int j;	
	float samples = 8000.0;

	if (first <0 || first > 10000)
		return DG_ERROR_PARAM_OUTOFRANGE;
		
	if (second <0 || second > 10000)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//E1 - Call setcarddetections function
	for (j=1;j<dg_GetCardsCount();j++)
	{
		dg_SetCardDetections(j, CFG_DETECT_FREQTONE2, first,0);
		dg_SetCardDetections(j, CFG_DETECT_FREQTONE3, second,0);
	}
	return DG_EXIT_SUCCESS;
}


//--------------------------------------------------------
//Retorna o status de playback
//--------------------------------------------------------
short WCDECL dg_IsPlaying(short port) 
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > nPortsCount)
            return DG_ERROR_PORT_OUT_OF_RANGE;

	return ports_info[port-1].bIsPlaying;
}

//--------------------------------------------------------
//Retorna o status de gravacao
//--------------------------------------------------------
short WCDECL dg_IsRecording(short port) 
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	return ports_info[port-1].bIsRecording;
}

//------------------------------------------------------------------
// Erase Digit Buffer - Needs to be called directly if AutoClearDigits
// is off
//------------------------------------------------------------------
short WCDECL dg_ClearDigits(short port) 
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	write_debug("dg_ClearDigits: channel: %d",port);
	memset(&ports_info[port-1].FDigits[0],'\0',DG_MAX_PATH);
	ports_info[port-1].stDigits.NumDigRecebido = 0;
    ports_info[port-1].play_digit_cutoff = FALSE;
	ports_info[port-1].FPlayEndDigits[0] = '\0';
	ports_info[port-1].play_digit_cutoff = 0;
	
	write_debug("dg_ClearDigits - play_digit_cutoff = FALSE  e  play_digit_cutoff = 0");
	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------------------
// Cancel GetDigits procedure
//------------------------------------------------------------------------
short WCDECL dg_CancelGetDigits(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	SetEnableTimer(&tmrDigit[port-1],FALSE);
	SetEnableTimer(&tmrInterDigit[port-1],FALSE);
	ports_info[port-1].FStatusPort = spNone;
	ports_info[port-1].nGetDigitsState = edOff;

	//Clean global property
	//v4.0.1 - nï¿½ apaga mais o buffer de digitos
	//memset(ports_info[port-1].FDigits,'\0',DG_MAX_PATH);
	//memset(ports_info[port-1].stDigits.RecDigitos,'\0',DG_MAX_PATH);
	//ports_info[port-1].stDigits.NumDigRecebido = 0;

	return DG_EXIT_SUCCESS;

}
//-------------------------------------------------------------------------
// GetDigits - Enable Digits to be received
// ==============================================
// MaxDigits - Numero maximo de digitos
// TermDigits - Digito terminador - "" se nao houver, "@" qualquer um
// DigitsTimeOut - Timeout total em milissegundos
// InterDigitsTimeOut - Timeout entre digitos - milissegundos
//-------------------------------------------------------------------------
short WCDECL dg_GetDigits(short port, short maxdigits, 
								   char *termdigits, long digitstimeout, 
								   long interdigitstimeout) 
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;


	digivoice_entercriticalsection(&port_mutex[port-1], port);

	//Copia dados para variaveis globais
	ports_info[port-1].stDigits.MaxDigits = maxdigits;
	strncpy(ports_info[port-1].stDigits.TermDigits,termdigits,DG_MAX_PATH);
	ports_info[port-1].stDigits.DigitsTimeOut = digitstimeout;
	ports_info[port-1].stDigits.InterDigitsTimeOut = interdigitstimeout;

	
	if (FAutoClearDigits)   //AutoClear ?
	{
		//Clean global property
		memset(ports_info[port-1].FDigits,'\0',DG_MAX_PATH);
		memset(ports_info[port-1].stDigits.RecDigitos,'\0',DG_MAX_PATH);
		ports_info[port-1].stDigits.NumDigRecebido = 0;
	}
	else
		ports_info[port-1].stDigits.NumDigRecebido = (unsigned char)strlen(ports_info[port-1].FDigits);

	if (ports_info[port-1].stDigits.NumDigRecebido>1)
		ports_info[port-1].stDigits.NumDigRecebido = (unsigned char)strlen(ports_info[port-1].FDigits);


	//Enable global timeout
	tmrDigit[port-1].Interval = digitstimeout / FACTOR_TIMER;
	SetEnableTimer(&tmrDigit[port-1],TRUE);
	
	//Interdigito sets the value but is off until the first dtmf
	tmrInterDigit[port-1].Interval = interdigitstimeout / FACTOR_TIMER;
	if (ports_info[port-1].stDigits.NumDigRecebido == 0)
		SetEnableTimer(&tmrInterDigit[port-1],FALSE);
	else
		SetEnableTimer(&tmrInterDigit[port-1],TRUE);
	
	//To suply GetPortStatus method
	ports_info[port-1].FStatusPort = spWaitingDigits;

	//Seta estado para espera
	ports_info[port-1].nGetDigitsState = edWaiting;
	
	write_debug("dg_digits: channel: %d - max: %d - term: %s - timeout: %ld - interdigit: %ld",port,maxdigits,termdigits,
																																										digitstimeout,interdigitstimeout);
	//enable dtmf detection
//	dg_SetDetectionType(port,DETECT_DTMF);

	digivoice_leavecriticalsection(&port_mutex[port-1], port);
	
	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// Return the content of digits buffer
//------------------------------------------------------------
short WCDECL dg_ReadDigits(short port, char *szDigits) 
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	write_debug("dg_ReadDigits: channel: %d - value: %s",port,ports_info[port-1].FDigits);
	
	strncpy(szDigits,ports_info[port-1].FDigits,DG_MAX_PATH);

	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// Return the content of status flag
//------------------------------------------------------------
short WCDECL dg_GetPortStatus(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

	//verifica se a thread e1 esta habilitada e pega o estado de la
	if (ports_info[port-1].e1_info.thread_id>0)
	{
		if (ports_info[port-1].FStatusPort != spDialing)
			if (ports_info[port-1].e1_info.bAtendido)
				ports_info[port-1].FStatusPort = spOffHook;
			else
				ports_info[port-1].FStatusPort = spNone;
	}

	return ports_info[port-1].FStatusPort;
}

//---------------------------------------------------------------
// Returns the driver status 1 - enabled 0 - disabled
//---------------------------------------------------------------
short WCDECL dg_DriverEnabled(void)
{
    return FDriverEnabled;
}

//---------------------------------------------------------------
// Set digits gain based on CMD_DIAL_CFG commands
// command:
// DIAL_CFG_GAINDTMF	-\
// DIAL_CFG_GAINMFT      |___ -3dBm ate -42 dBm  
// DIAL_CFG_GAINMFF      |
// DIAL_CFG_GAINMF      _/
// DIAL_CFG_GAINTONE1  -\___ +3.17 ate -42 dBm
// DIAL_CFG_GAINTONE2  -/
//
// As duas frequencias que compoe o MF serao setadas ao mesmo 
// tempo. No caso de DIAL_CFG_GAINDTMF teremos freq1-1 e freq2+1 dBm)
//---------------------------------------------------------------
short WCDECL dg_SetDigitGain(short card, short command, float gain_value)
{
	double fcalc;
	unsigned short value1, value2;
	int dtmf_soma = 0;
	float gain_value1,gain_value2;
	
	dg_cmd_tx tx_command_e1;
	
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//check command values
	if (command < DIAL_CFG_GAINDTMF || command > DIAL_CFG_GAINTONE2)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//gain value range
	if (command <= DIAL_CFG_GAINMF)
	{
		if (gain_value < -42 || gain_value > -3)
			return DG_ERROR_PARAM_OUTOFRANGE;
	}
	else
	{
		if (gain_value < -42 || gain_value > 3.17)
			return DG_ERROR_PARAM_OUTOFRANGE;
	}
				
	//seta frequencia de DTMF com diferenca de 2dBm entre cada uma
	if (command == DIAL_CFG_GAINDTMF)
	{
		gain_value1 = gain_value -1;
		gain_value2 = gain_value +1;
	}
	else
	{
		//nos outros casos, usar a mesma frequencia
		gain_value1 = gain_value;
		gain_value2 = gain_value;
	}

	//calculates gain (+3.17dBm to -40 dBm)
	fcalc = 0.5 + 2840 * pow(10,gain_value1 / 20.0);
	value1 = (short)fcalc;
	//...
	fcalc = 0.5 + 2840 * pow(10,gain_value2 / 20.0);
	value2 = (short)fcalc;
		
	//send commands
	tx_command_e1.command = CMD_DIAL_CFG;
	//set values for 1st frequency
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);
	tx_command_e1.param1 = (unsigned char)command; 
	tx_command_e1.param2 = (unsigned char)FREQ1;		
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = (unsigned char)(value1 >> 8);		//byte more significant
	tx_command_e1.param5 = (unsigned char)(value1 & 0xff);
	write_generic_command(&tx_command_e1);

	//set values for 2nd frequency
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);
	tx_command_e1.param1 = (unsigned char)command; 
	tx_command_e1.param2 = (unsigned char)FREQ2;		
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = (unsigned char)(value2 >> 8);		//byte more significant
	tx_command_e1.param5 = (unsigned char)(value2 & 0xff);
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
		
}
//---------------------------------------------------------------
// Set digits frequency based on CMD_DISCA_CFG commands
// frequency value between 200Hz and 3500Hz
//---------------------------------------------------------------
short WCDECL dg_SetDigitFrequency(short card, short command, short freqindex, char cDigit, int frequency_value)
{
	double fcalc;
	unsigned char nDigitValue;
	unsigned short value;
	dg_cmd_tx tx_command_e1;
	
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//card number
	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//consistencies
	if (frequency_value < 200 || frequency_value > 3500)
		return DG_ERROR_PARAM_OUTOFRANGE ;
		
	//frequency index
	if (freqindex < FREQ1 || freqindex > NONE)
		return DG_ERROR_PARAM_OUTOFRANGE ;

	//Digit consistency - 0 to 15 - 10=*, 11=#, 12=A, 13=B, 14=C, 15=D
	if (cDigit >= '0' && cDigit <= '9')
		nDigitValue = cDigit - 0x30;
	else
	{
		switch(cDigit)
		{
			case '*':
				nDigitValue = 10;
				break;
			case '#':
				nDigitValue = 11;
				break;
			case 'A': case 'a': 
				nDigitValue = 12;
				break;
		
			case 'B': case 'b': 
				nDigitValue = 13;
				break;
			
			case 'C': case 'c': 
				nDigitValue = 14;
				break;
			
			case 'D': case 'd': 
				nDigitValue = 15;
				break;
			default:
				nDigitValue = 0;
				break;
		}
	}
	
	fcalc = 0.5 + frequency_value * 4096;
	value = (unsigned short)fcalc;

	tx_command_e1.command = CMD_DIAL_CFG;
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)card; //(card-1) * nPortsCount;
	tx_command_e1.param1 = (unsigned char)command;
	tx_command_e1.param2 = (unsigned char)freqindex;			
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = (unsigned char)(value >> 8);		//byte more significant
	tx_command_e1.param5 = (unsigned char)(value & 0xff);

	
	write_generic_command(&tx_command_e1);

	
	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// This functions set the flag to use fast or normal
// detection
// enable: DG_ENABLE /DG_DISABLE
//-----------------------------------------------------------
short WCDECL dg_SetFastDetection(short port, short enable)
{
	if (enable != DG_ENABLE && enable != DG_DISABLE)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	ports_info[port-1].FFastDetection = enable;

	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// This routine enables various detections under E1 card
// DETECTA_OFF -> Disable Detection
// e.g.: DETECTA_DTMF | DETECTA_TOM1 | DETECTA_AUDIO
// --> DTMF, MFF MFT and MF are mutually exclusives
// DETECT_ALL_MF - disable all MFs but not Tones
// DETECT_ALL_TONE - disable all TONES but not MFs
//------------------------------------------------------------
short WCDECL dg_SetDetectionType(short port, short command, short enable )
{

	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	if (enable != DG_ENABLE && enable != DG_DISABLE)
			return DG_ERROR_PARAM_OUTOFRANGE;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	

	//check for command options.
	if (command != DETECT_OFF && command != DETECT_DTMF && command != DETECT_MFT && command != DETECT_MFF && 
		command != DETECT_MF && command !=  DETECT_TONE1 && command != DETECT_TONE2 && command != DETECT_TONE3 && 
		command != DETECT_TONE4 && command != DETECT_TONE5 && command != DETECT_TONE6 && command != DETECT_TONE7 && 
		command != DETECT_TONE8 && command != DETECT_ALL_MF && command != DETECT_ALL_TONE && command != DETECT_AUDIO)
			return DG_ERROR_PORT_OUT_OF_RANGE;

	

	if (command != DETECT_ALL_MF && command != DETECT_ALL_TONE)
	{
		if (enable)
			ports_info[port-1].DetCmd |= command;
		else
			ports_info[port-1].DetCmd &= ~command;
	}
	else
	{
		//DETECT_ALL_TONE and DETECT_ALL_MF are presets to allow disabling for all tone or mf detections at once
		if (command == DETECT_ALL_MF)
		{
			if (enable)
			{
				//enable
				ports_info[port-1].DetCmd |= DETECT_DTMF;
				ports_info[port-1].DetCmd |= DETECT_MFT;
				ports_info[port-1].DetCmd |= DETECT_MFF;
				ports_info[port-1].DetCmd |= DETECT_MF;
			}
			else
			{
				//disable
				ports_info[port-1].DetCmd &= ~DETECT_DTMF;
				ports_info[port-1].DetCmd &= ~DETECT_MFT;
				ports_info[port-1].DetCmd &= ~DETECT_MFF;
				ports_info[port-1].DetCmd &= ~DETECT_MF;
			}
		}
		else
			if (command == DETECT_ALL_TONE)
			{
				if (enable)
				{
					ports_info[port-1].DetCmd |= (DETECT_TONE1 | DETECT_TONE2 | DETECT_TONE3 | DETECT_TONE4 | DETECT_TONE5 | DETECT_TONE6 | DETECT_TONE7 | DETECT_TONE8 | DETECT_AUDIO);
				}
				else
				{
					//disable
					ports_info[port-1].DetCmd &= ~(DETECT_TONE1 | DETECT_TONE2 | DETECT_TONE3 | DETECT_TONE4 | DETECT_TONE5 | DETECT_TONE6 | DETECT_TONE7 | DETECT_TONE8 | DETECT_AUDIO);
				}
			}
	}
	//desliga tudo se for DETECT_OFF - evitar usar
	if (command==DETECT_OFF)	
		ports_info[port-1].DetCmd = 0;

//	write_debug("(%d) Habilitando detecoes cmd:%x valor:%04x",port, command, ports_info[port-1].DetCmd);

	//send commands
	tx_command_e1.command = CMD_DETECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port-1;
	tx_command_e1.param1 = (unsigned char)port-1;
	//must send hi,lo format
	tx_command_e1.param2 = (char)(ports_info[port-1].DetCmd >> 8);
	tx_command_e1.param3 = (char)(ports_info[port-1].DetCmd & 0xff);
	tx_command_e1.param4 = (char)ports_info[port-1].FFastDetection;

	write_generic_command(&tx_command_e1);
	
	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// dg_genericdial
// generates tones of <type>
// <Type> can be 	GENERATE_OFF,GENERATE_DTMF,	GENERATE_MFT,
//					GENERATE_MFF,GENERATE_MF,GENERATE_TONE1,
//					GENERATE_TONE2
//----------------------------------------------
short WCDECL dg_GenerateMF(short port, short type, char cDig)
{
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//consistency
	if (cDig < 0 || cDig > 15)
		return DG_ERROR_PARAM_OUTOFRANGE;
		
	if (type < 0 || type > 6)
		return DG_ERROR_PARAM_OUTOFRANGE;
		
	tx_command_e1.command = CMD_DIAL;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = (unsigned char)type;
	tx_command_e1.param3 = cDig /*- 0x30*/;
	//dummy
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;


	write_generic_command(&tx_command_e1);

#ifdef  __LINUX__
    if (DebugEnabled)
        dg_write_tx_msg(&tx_command_e1);
#endif

    if (type) {
        //write_debug("<<<<< (%d) GenerateMF -type=%d dig=%c",port, type, cDig+0x30);
        write_debug("<<mf %d                                                                      %c",port,cDig+0x30);
    }
    //else
      //  write_debug("<<<<< (%d) GenerateMF - OFF",port);
    

	return DG_EXIT_SUCCESS;
}

//---------------------------------------------------------------------------
// Sets silience threslhod to new cards
// The value (in dBm) has 3dB resolution. E.g. 0,-1 and -2 is converted to 0
//---------------------------------------------------------------------------
short WCDECL dg_SetSilenceThreshold(short port, short value)
{
	double fTemp;
	unsigned short nTemp;
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (value < -42 || value > 0)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//Save new value
	ports_info[port-1].SilenceThreshold = value;

	fTemp = (42 + value) * 0.33 - 25;	//silence threshold

	nTemp = (short)fTemp;

	write_debug("(%d) dg_SetSilenceThreshold - value=%d fvalue=%d",port, value, nTemp);

	//send commands
	tx_command_e1.command = CMD_DETECTION_CFG;
	//set values
	tx_command_e1.port = port - 1;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.param1 = CFG_DETECT_SILENCE;
	tx_command_e1.param2 = (unsigned char)port - 1;
	tx_command_e1.param3 = 0;   //not used
	tx_command_e1.param4 = (unsigned char)(nTemp >> 8);		//byte more significant
	tx_command_e1.param5 = (unsigned char)(nTemp & 0xff);

	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// Sets detection type for TONES
// type		 = CFG_DETECT_FREQMF
// freqindex = FREQ1 or FREQ2
// digit     = 0-15
// value     = 90Hz - 2840Hz
//------------------------------------------------------------
short WCDECL dg_SetCustomMF(short card, short freqindex, short digit, float value)
{
	double fTemp;
	unsigned short nTemp;
	dg_cmd_tx tx_command_e1;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//frequency value consistency
	if (value < 90 || value > 2840)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//digit consistency
	if (digit < 0 || digit  > 15)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//frequency index
	if (freqindex < FREQ1 || freqindex > NONE)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	fTemp = 0.032 * value - 1.5;	//tone frequencies

	nTemp = (unsigned short)fTemp;

	//send commands
	tx_command_e1.command = CMD_DETECTION_CFG;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)card; //(card-1) * nPortsCount;
	tx_command_e1.param1 = CFG_DETECT_FREQMF;
	tx_command_e1.param2 = (unsigned char)freqindex;
	tx_command_e1.param3 = (unsigned char)digit;
	tx_command_e1.param4 = (unsigned char)(nTemp >> 8);		//byte more significant
	tx_command_e1.param5 = (unsigned char)(nTemp & 0xff);

	write_generic_command(&tx_command_e1);
		
	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------
// Resincroniza seriais
//------------------------------------------------------
short WCDECL dg_ReSync(short card)
{


	dg_cmd_tx tx_command_e1;
	short e1;
	short h100type=0,p2=0,p3=0;

	//TESTE TESTE TESTE
	return DG_EXIT_SUCCESS;

	//RaiseEvents_ThreadSafe(EV_ERRORDETECTED, ERROR_CARD_RESET, e1,&mtx_insert_to_e1);
	if (tempo_entre_reset)
		return DG_EXIT_SUCCESS;

	tempo_entre_reset=1;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//check card number
	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	tmrReset.Interval = 300000 / FACTOR_TIMER;  //5 minutos
	tmrReset.Enabled = TRUE;
	SetEnableTimer(&tmrReset,TRUE);



	for (e1=1;e1<dg_GetPortsCount();e1++)
	{
		if (ports_info[e1-1].e1_info.thread_id>0)
		{
			dg_InsertE1Fifo(e1,C_RESET_THREAD,0);
//			ports_info[e1-1].e1_info.bBlocked = 1;
		}
	}

	//send commands
	tx_command_e1.command = CMD_RESYNC;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)card; 
	tx_command_e1.param1 = 0;
	tx_command_e1.param2 = 0;
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	
	write_generic_command(&tx_command_e1);

	digivoice_sleep(4000);

	//RaiseEvents_ThreadSafe(EV_ERRORDETECTED, ERROR_CARD_RESET, e1,&mtx_insert_to_e1);

	//le arquivos de reset para refazer sincronismo
	//LeReset();

	//salva informacoes para reset
//	fReset = fopen(szResetFile,"rt");
/*	
	while(!feof(fReset))
	{
		fgets(str,200,fReset);

		sscanf(str,"%d %d %d %d",&cd,&h100type,&p2,&p3);

		/*fscanf(fReset,"%d",&cd);
		fscanf(fReset,"%d",&h100type);
		fscanf(fReset,"%d",&p2);
		fscanf(fReset,"%d",&p3);
		//TODO: consistency
		
		//send commands
		tx_command_e1.command = CMD_H100_CFG;

		//set values
		tx_command_e1.port_or_card = ASSUME_CARD;
		tx_command_e1.port = (char)(cd);
		tx_command_e1.param1 = h100type;
		tx_command_e1.param2 = p2;
		tx_command_e1.param3 = p3;
		tx_command_e1.param4 = 0;
		tx_command_e1.param5 = 0;
		write_generic_command(&tx_command_e1);

	}
	fclose(fReset); */

	for (e1=1;e1<dg_GetPortsCount();e1++)
	{
		if (ports_info[e1-1].e1_info.thread_id>0)
		{
			dg_SendR2Command(e1,R2_ENABLEDETECTION);
			dg_InsertE1Fifo(e1,C_RESET_THREAD,0);
		}
	}
	digivoice_sleep(1500);

	return DG_EXIT_SUCCESS;
}
//------------------------------------------------------------
// Reset <framer> frame for E1 cards
// card - 1 to n
// framer - CFG_FRAMER_E1_A	(1) CFG_FRAMER_E1_B	(2)
//------------------------------------------------------------
short WCDECL dg_ResetFramer(short card, short framer)
{

	dg_cmd_tx tx_command_e1;

    if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

    //check flag type
    if (framer < 1 || framer > 2)
        return DG_ERROR_PARAM_OUTOFRANGE;

    //check card number
    if (card < 1 || card > nCardsCount)
        return DG_ERROR_CARD_OUT_OF_RANGE;


    //first disables alarms
    dg_SetAlarmMode(card, ALARM_MANUAL_NOTIFY);

    digivoice_sleep(200);

    //send commands
    tx_command_e1.command = CMD_RESYNC;
    //set values
    tx_command_e1.port_or_card = ASSUME_CARD;
    tx_command_e1.port = (char)card; 
    tx_command_e1.param1 = (unsigned char)framer;
    tx_command_e1.param2 = 0;
    tx_command_e1.param3 = 0;
    tx_command_e1.param4 = 0;
    tx_command_e1.param5 = 0;

    write_generic_command(&tx_command_e1);

    digivoice_sleep(1000);

    //alarms must be enabled by application

    return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// Send CMD_ERROR do card 
// Params:
// DONTSEND_ERROR - Reseta sem mandar codigo de erro
// SEND_ERRORCODE - Reseta e envia evento C_ERROR
//------------------------------------------------------------
short WCDECL dg_ResetError(short card, short flag)
{

	dg_cmd_tx tx_command_e1;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//check flag type
	if (flag < 0 || flag > 1)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//check card number
	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//send commands
	tx_command_e1.command = CMD_ERROR;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)card; 
	tx_command_e1.param1 = (unsigned char)flag;
	tx_command_e1.param2 = 0;
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// Set Verbose Level between 0 and 5 
//------------------------------------------------------------
short WCDECL dg_SetVerboseLevel(short card, short level)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;	
	
	if (level < 0 || level > 5)
		return DG_ERROR_PARAM_OUTOFRANGE;
	
#ifdef DEBUG_LEVEL
		sm->Cards[card-1].debug_level = level;
#else
		return DG_FEATURE_NOT_SUPPORTED;
#endif//#ifdef DEBUG_LEVEL
	
	return DG_EXIT_SUCCESS;	
}

//------------------------------------------------------------
// Sets detection type for TONES only
// card = card to set
// type = CFG_DETECT_FREQTONE1, CFG_DETECT_FREQTONE2
//        CFG_DETECT_FREQTONE3, CFG_DETECT_FREQTONE4 
//        CFG_DETECT_FREQTONE5, CFG_DETECT_FREQTONE6
//        CFG_DETECT_FREQTONE7, CFG_DETECT_FREQTONE8
//------------------------------------------------------------
short WCDECL dg_SetCardDetections(short card, short type, float value1, float value2)
{
	double fTemp;
	unsigned short nTemp;
	short i;
	dg_cmd_tx tx_command_e1;
	float value;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;
	
	if (type == CFG_DETECT_SILENCE || type == CFG_DETECT_FREQMF)
			return DG_ERROR_PARAM_OUTOFRANGE;

	value = value1;
	for (i=0;i<2;i++)
	{
		if (value>0) 
		{
			fTemp = 0.032 * value - 1.5;	//tone frequencies
			nTemp = (unsigned short)fTemp;
		}
		else
			nTemp = 0;
		//send commands
		tx_command_e1.command = CMD_DETECTION_CFG;
		//set values
		tx_command_e1.port_or_card = ASSUME_CARD;
		tx_command_e1.port = (char)card; //(card-1) * nPortsCount;
		tx_command_e1.param1 = (unsigned char)type;
		tx_command_e1.param2 = (char)i;
		tx_command_e1.param3 = 0;
		tx_command_e1.param4 = (unsigned char)(nTemp >> 8);		//byte more significant
		tx_command_e1.param5 = (unsigned char)(nTemp & 0xff);
		write_generic_command(&tx_command_e1);
		value = value2;
	}

	return DG_EXIT_SUCCESS;
}
//------------------------------------------------------------
// ASk to card to send C_ALARM status
// Return values will be send as an event (C_ALARM)
//------------------------------------------------------------
short WCDECL dg_GetAlarmStatus(short card)
{
	dg_cmd_tx tx_command_e1;
	int i,j,cards;
	
#ifdef DEBUG_LEVEL
		if (sm->Cards[card-1].debug_level > 0)
		{
			write_verbose("dg_GetAlarmStatus: Step 1 - [card %d]", card);
		}
#endif//#ifdef DEBUG_LEVEL	
	
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	if (dg_GetCardInterface(card) != DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;	

	//reset alarm status
        //for (cards=0;cards<dg_GetCardsCount();cards++)
		for (i=0;i<2;i++)
		{
			block_event[card-1][i]=0;
			for (j=0;j<8;j++)
			{
				if (j==0 && e1_alarm[card-1][i][j])	//loss
				{
					e1_alarm[card-1][i][j] = 0;
				}
				else
					if (j!=6)
						e1_alarm[card-1][i][j] = 0xff; //each card has 2 E1 - 8 alarms
			}
		}
	
#ifdef DEBUG_LEVEL	
		if (sm->Cards[card-1].debug_level > 0)
		{
			write_verbose("dg_GetAlarmStatus: Step 2 - Before set parameters - [card %d]", card);
		}
#endif//#ifdef DEBUG_LEVEL	
		
	//send commands
	tx_command_e1.command = CMD_ALARM;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)card;   //(card-1) * nPortsCount;
	tx_command_e1.param1 = ALARM_GETSTATUS;
	write_generic_command(&tx_command_e1);

#ifdef DEBUG_LEVEL
		if (sm->Cards[card-1].debug_level > 0)
		{
			write_verbose("dg_GetAlarmStatus: Step 3 - After set parameters - [command %x, port_or_card %x, port %d, param1 %x]",
						  tx_command_e1.command, tx_command_e1.port_or_card,
				          tx_command_e1.port, tx_command_e1.param1);
		}
#endif//#ifdef DEBUG_LEVEL	
	
	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// Ask to card to send C_ALARM status
// Return values will be send as an event (C_ALARM)
//------------------------------------------------------------
short WCDECL dg_SetAlarmMode(short card, short mode)
{
	dg_cmd_tx tx_command_e1;
	
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	if (mode != ALARM_MANUAL_NOTIFY && mode != ALARM_AUTOMATIC_NOTIFY)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//send commands
	tx_command_e1.command = CMD_ALARM;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)card;   //(card-1) * nPortsCount;
	tx_command_e1.param1 = (unsigned char)mode;

	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}

//------------------------------------------------------------
// Enables/Disables framer loop for testing and monitoring
// purposes
// Device-> E1 card - 1=E1_A and 2=E1_B
// loop_type -> LOOP_OFF, LOOP_REMOTE, LOOP_LOCAL
//------------------------------------------------------------
short WCDECL dg_SetFramerLoop(short card, short device, short loop_type)
{
	dg_cmd_tx tx_command_e1;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	if (device!= E1_A && device!= E1_B)
		return DG_ERROR_PARAM_OUTOFRANGE;


	if (loop_type < FRAMER_LOOP_OFF || loop_type > FRAMER_LOOP_LOCAL)
		return DG_ERROR_PARAM_OUTOFRANGE;


	//send commands
	tx_command_e1.command = CMD_LOOP;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)card; //(card-1) * nPortsCount;
	tx_command_e1.param1 = (unsigned char)device;
	tx_command_e1.param2 = (unsigned char)loop_type;

	write_generic_command(&tx_command_e1);


	return DG_EXIT_SUCCESS;

}

//------------------------------------------------------------
// Add audio from <port_mixed> with <port> and send the
// result <port>
// port - 1-60
// chat_room - 0-29 (30 desliga)
//------------------------------------------------------------
short WCDECL dg_SetPortChatLog(short port , long handle, short enable)
{
	dg_cmd_tx tx_command_e1;
	short room=0,card=0,found=0;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;


	if (!enable)
	{
		room = 30;	//passing 30 will turn off.
		found = 1;
	}
	else
	{
		//localiza sala pelo handle
		for (card=0;card<dg_GetCardsCount();card++)
		{
			for (room=0;room<MAX_CHATROOMS;room++)
			{
				if (stConf[card][room]!=NULL)
					if (stConf[card][room]->RoomHandle == handle)
					{
						found=1;
						break;
					}
			}
			if (found)	//forca sair do loop
				break;
		}
	}

	if (found)
	{
		//send commands
		tx_command_e1.command = CMD_MIXER;
		//set values
		tx_command_e1.port_or_card = ASSUME_PORT;
		tx_command_e1.port = port -1;
		tx_command_e1.param1 = (unsigned char)port -1;
		tx_command_e1.param2 = (unsigned char)room;

		write_generic_command(&tx_command_e1);


		return DG_EXIT_SUCCESS;
	}
	else
		return DG_EXIT_FAILURE;

}
//------------------------------------------------------------
// Sets gain to I/O signals.
// rx_tx - > 	RX_GAIN,TX_GAIN, REC_GAIN , PLAY_GAIN

//------------------------------------------------------------
short WCDECL dg_SetPortGain(short port, short rx_tx,  short value)
{
	dg_cmd_tx tx_command_e1;
	double fTemp;
	unsigned short nTemp;

	//check driver enabled
	if (!dg_DriverEnabled())
         return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (rx_tx < 0 || rx_tx > 3)
		return DG_ERROR_PARAM_OUTOFRANGE;

	if (value < -40 || value > 12)
		return DG_ERROR_PARAM_OUTOFRANGE;


	fTemp = 0.5 + 16384 * pow(10,(value/20.0));
	nTemp = (unsigned short)fTemp;

	if (nTemp>=65535) nTemp=65535;

	//send commands
	tx_command_e1.command = CMD_GAIN;
	//set values
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = (unsigned char)rx_tx;
	tx_command_e1.param3 = (unsigned char)(nTemp >> 8);		//byte more significant
	tx_command_e1.param4 = (unsigned char)(nTemp & 0xff);

	write_generic_command(&tx_command_e1);


	return DG_EXIT_SUCCESS;

}



//----------------------------------------------------------------
// This method create a custom thread to interact with specific CAS
// extensions
// ConfigFile can be NULL but dg_ConfigCustomCAS must be used
//----------------------------------------------------------------
short WCDECL dg_CreateCustomCAS(short port, char *ConfigFile)
{
	FILE *f;
	char szFile[DG_MAX_PATH];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].cas_info.thread_id>0)
				return DG_ERROR_THREAD_ALREADY_RUNNING;
#ifdef WIN32
	sprintf(szFile,"%s\\%s",szConfigurationPath,ConfigFile);
#else
	sprintf(szFile,"%s/%s",szConfigurationPath,ConfigFile);
#endif

	if (ConfigFile!=NULL)
	{
		//check if file exists
		f=fopen(szFile,"rt");
		if (f==NULL)
			return DG_ERROR_CONFIGFILE_NOT_FOUND;
		fclose(f);
	}

#ifdef __LINUX__
	//create fifo to cas
	sprintf(ports_info[port-1].cas_info.szFifoToCAS,"%s/dg_rxcas_%d",DG_FIFO_PATH,port-1);
	mkfifo(ports_info[port-1].cas_info.szFifoToCAS,O_RDWR | DG_FIFO_ACCESS_RIGHTS );
	//tries to open fifo
	ports_info[port-1].fifo_to_cas = open(ports_info[port-1].cas_info.szFifoToCAS,O_RDWR/*O_WRONLY*/);
	if (ports_info[port-1].fifo_to_cas < 1)
    		return DG_ERROR_FIFO_UNAVAILABLE;
#endif

#ifdef WIN32

	//TODO - Precisa consistencia

	//uses pipe to communicate
	//create fifo to cas
	sprintf(ports_info[port-1].cas_info.szFifoToCAS,"\\\\.\\pipe\\dgcas_%d",port-1);

	//cria evento de notificacao para a thread
	ports_info[port-1].cas_info.CASEvent.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (!ports_info[port-1].cas_info.CASEvent.hEvent)
		return DG_ERROR_COULD_NOT_CREATE_THREAD;

	ports_info[port-1].cas_info.oOverlapCAS.hEvent = ports_info[port-1].cas_info.CASEvent.hEvent;

	//create PIPE
	ports_info[port-1].fifo_to_cas = CreateNamedPipe(ports_info[port-1].cas_info.szFifoToCAS,
													PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
													PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
													PIPE_UNLIMITED_INSTANCES,
													1024,
													1024,
													NMPWAIT_USE_DEFAULT_WAIT,
													NULL);


	ConnectNamedPipe(ports_info[port-1].fifo_to_cas, &ports_info[port-1].cas_info.oOverlapCAS);
#endif

	//set default values
	//these values are from AVAYA DEFINITY Line-side station configuration
	if (ConfigFile!=NULL)
	{
		//make this portable!!!!!!!!!!!!!!
		ports_info[port-1].cas_info.port = port;
		ports_info[port-1].cas_info.ring_signal = GetPrivateProfileInt("CustomCas","Ring",0x1,szFile);
		ports_info[port-1].cas_info.caller_hangup_signal = GetPrivateProfileInt("CustomCas","CallerHangup",0xd,szFile);
		ports_info[port-1].cas_info.idle_signal = GetPrivateProfileInt("CustomCas","Idle",0x5,szFile); //0x5;
		ports_info[port-1].cas_info.answer_cmd = GetPrivateProfileInt("CustomCas","Answer",0xd,szFile); //0xd;
		ports_info[port-1].cas_info.pickup_cmd = GetPrivateProfileInt("CustomCas","PickUp",0xd,szFile); //0xd;
		ports_info[port-1].cas_info.drop_delay_before = GetPrivateProfileInt("CustomCas","DropDelay",100,szFile); //700;
		ports_info[port-1].cas_info.drop_cmd = GetPrivateProfileInt("CustomCas","Drop",0x5,szFile); //0x5;
		ports_info[port-1].cas_info.flash1_cmd = GetPrivateProfileInt("CustomCas","Flash1",0x5,szFile); //0x5;
		ports_info[port-1].cas_info.flash1_delay = GetPrivateProfileInt("CustomCas","Flash1Delay",100,szFile); //300;
		ports_info[port-1].cas_info.flash2_cmd = GetPrivateProfileInt("CustomCas","Flash2",0xd,szFile); //0xd;
		ports_info[port-1].cas_info.flash2_delay = GetPrivateProfileInt("CustomCas","Flash2Delay",100,szFile); //700;
	}
	//Create cas control thread
	if (digivoice_beginthread(&ports_info[port-1].cas_info.thread_id,CustomCAS_Thread,0,
				&ports_info[port-1].cas_info)!=0)
	{
			write_debug("dg_create_cas_control: ERROR_THREAD");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
	}
	//get port status
	dg_SendR2Command(port,ports_info[port-1].cas_info.drop_cmd);
	dg_SendR2Command(port,R2_ENABLEDETECTION);	//habilita



	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// Destroy created custom CAS control
//----------------------------------------------------------------
short WCDECL dg_DestroyCustomCAS(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].cas_info.thread_id>0)
	{

		dg_SendR2Command(port,R2_DISABLEDETECTION);

		//Send to threads informations to close
		dg_InsertCASFifo(port,C_ENDTHREAD,0);

		//destroi conferencias
		//port2CardChannel(MAX_CHANNELS_CARD, port-1,  &card , &card_channel);


	}
	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// Configure custom CAS - This function can be used instead of
// passing ConfigFile in dg_CreateCustomCAS
//	CASCFG_RING,
//	CASCFG_CALLER_HANGUP,
//	CASCFG_IDLE,
//	CASCFG_ANSWER,
//	CASCFG_PICKUP,
//	CASCFG_DROP_DELAY_BEFORE,
//	CASCFG_DROP,
//	CASCFG_FLASH1_CMD,
//	CASCFG_FLASH1_DELAY,
//	CASCFG_FLASH1_CMD,
//	CASCFG_FLASH2_DELAY
//----------------------------------------------------------------
short WCDECL dg_ConfigCustomCAS(short port, short command, short value)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//verificar constantes
	if (command <0 || command > 10)
		return DG_ERROR_PARAM_OUTOFRANGE ;

	//the thread was already created
	if (ports_info[port-1].cas_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	switch(command)
	{
		case CASCFG_RING:
			ports_info[port-1].cas_info.ring_signal = value;
			break;
		case CASCFG_CALLER_HANGUP:
			ports_info[port-1].cas_info.caller_hangup_signal = value;
			break;
		case CASCFG_IDLE:
			ports_info[port-1].cas_info.idle_signal = value;
			break;
		case CASCFG_ANSWER:
			ports_info[port-1].cas_info.answer_cmd = value;
			break;
		case CASCFG_PICKUP:
			ports_info[port-1].cas_info.pickup_cmd = value;
			break;
		case CASCFG_DROP_DELAY_BEFORE:
			ports_info[port-1].cas_info.drop_delay_before = value;
			break;
		case CASCFG_DROP:
			ports_info[port-1].cas_info.drop_cmd = value;
			break;
		case CASCFG_FLASH1_CMD:
			ports_info[port-1].cas_info.flash1_cmd = value;
			break;
		case CASCFG_FLASH1_DELAY:
			ports_info[port-1].cas_info.flash1_delay = value;
			break;
		case CASCFG_FLASH2_CMD:
			ports_info[port-1].cas_info.flash2_cmd = value;
			break;
		case CASCFG_FLASH2_DELAY:
			ports_info[port-1].cas_info.flash2_delay = value;
			break;
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------
// Send commands directly to CAS fifo
//-------------------------------------------------------------------
short WCDECL dg_InsertCASFifo(unsigned short port,unsigned  short command, unsigned short data)
{
	dg_event_data_structure trans;
#ifdef WIN32
	u32 cbWritten;
#endif

  //Send to threads informations to close
	trans.command = command;
	trans.port = port;
	trans.data = data;
	if (ports_info[port-1].fifo_to_cas>0)
	{
		digivoice_entercriticalsection(&port_mutex[port-1], port);
#ifdef __LINUX__
		write(ports_info[port-1].fifo_to_cas,&trans,sizeof(trans));
#else
		WriteFile(  ports_info[port-1].fifo_to_cas,        // handle to pipe
					&trans,      // buffer to write from
					sizeof(trans), // number of bytes to write
					&cbWritten,   // number of bytes written
					&ports_info[port-1].cas_info.oOverlapCAS);        // not overlapped I/O

#endif
		digivoice_leavecriticalsection(&port_mutex[port-1], port);
	}
	else
		return EXIT_FAILURE;

	return DG_EXIT_SUCCESS;
}


//---

//----------------------------------------------------------------
// Set values to Idle Function thread
//----------------------------------------------------------------
short WCDECL dg_IdleSettings(short port, u8 AutoPickUp, short RingCount, short PauseAfterPickUp,
					  u8 WatchTrunkBefore, u8 WatchTrunkAfter,short Format,
					  short TimeOut, short Max, char *TermDigits)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//check parameters ranges
	if (AutoPickUp != 0 && AutoPickUp != 1) return DG_ERROR_PARAM_OUTOFRANGE ;
	if (WatchTrunkBefore != 0 && WatchTrunkBefore != 1) return DG_ERROR_PARAM_OUTOFRANGE ;
	if (WatchTrunkAfter != 0 && WatchTrunkAfter != 1) return DG_ERROR_PARAM_OUTOFRANGE ;
	if (Format != wtMFP && Format != wtDTMF && Format != wtCustom) return DG_ERROR_PARAM_OUTOFRANGE ;
	if (Max == 0)
		Max = 999;

	ports_info[port-1].idle_info.bAutoPickUp = AutoPickUp;
	ports_info[port-1].idle_info.nRingsToAnswer = RingCount;				//toques para atendimento
	ports_info[port-1].idle_info.nPauseAfterPickUp = PauseAfterPickUp;			//pausa apos o atendimento

	ports_info[port-1].idle_info.bWatchTrunkBefore = WatchTrunkBefore;			//monitora tronco antes do atendimento
	ports_info[port-1].idle_info.bWatchTrunkAfter = WatchTrunkAfter;			//monitora tronco depois do atendimento

	ports_info[port-1].idle_info.nFormat = Format;					//dtmf, mfp, custom
	ports_info[port-1].idle_info.TimeOut = TimeOut;					//Timeout ring
	ports_info[port-1].idle_info.nStringMaxSize = Max;				//Tamanho maximo da string

	if (strlen(TermDigits)>0)
		strncpy(ports_info[port-1].idle_info.sTermDigit, TermDigits, DG_MAX_PATH);	//digitos terminadores
	else
		ports_info[port-1].idle_info.sTermDigit[0]=0;

	return DG_EXIT_SUCCESS;

}
//----------------------------------------------------------------
// Create IdleXXXX functions thread
//----------------------------------------------------------------
short WCDECL dg_IdleStart(short port )
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].idle_info.thread_id>0 && ports_info[port-1].idle_info.closing==0)
				return DG_ERROR_THREAD_ALREADY_RUNNING;

#ifdef __LINUX__
	//create fifo to cas
	sprintf(ports_info[port-1].idle_info.szFifoToIdle,"%s/dg_rxidle_%d",DG_FIFO_PATH,port-1);
	mkfifo(ports_info[port-1].idle_info.szFifoToIdle,O_RDWR | DG_FIFO_ACCESS_RIGHTS);
	//tries to open fifo
	ports_info[port-1].fifo_to_idle = open(ports_info[port-1].idle_info.szFifoToIdle,O_RDWR/*O_WRONLY*/);
	if (ports_info[port-1].fifo_to_idle < 1)
		return DG_ERROR_FIFO_UNAVAILABLE;
#endif

#ifdef WIN32

	//TODO - Precisa consistencia

	//uses pipe to communicate
	//create fifo to cas
	sprintf(ports_info[port-1].idle_info.szFifoToIdle,"\\\\.\\pipe\\dgidle_%d",port-1);

	//cria evento de notificacao para a thread
	ports_info[port-1].idle_info.IdleEvent.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (!ports_info[port-1].idle_info.IdleEvent.hEvent)
		return DG_ERROR_COULD_NOT_CREATE_THREAD;

	ports_info[port-1].idle_info.oOverlapIdle.hEvent = ports_info[port-1].idle_info.IdleEvent.hEvent;

	//create PIPE
	ports_info[port-1].fifo_to_idle = CreateNamedPipe(ports_info[port-1].idle_info.szFifoToIdle,
													PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
													PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
													PIPE_UNLIMITED_INSTANCES,
													1024,
													1024,
													NMPWAIT_USE_DEFAULT_WAIT,
													NULL);


	ConnectNamedPipe(ports_info[port-1].fifo_to_idle, &ports_info[port-1].idle_info.oOverlapIdle);
#endif

	//Create cas control thread
	ports_info[port-1].idle_info.port = port;
	ports_info[port-1].idle_info.closing = 0;
	if (digivoice_beginthread(&ports_info[port-1].idle_info.thread_id,Idle_Thread,0,
				&ports_info[port-1].idle_info)!=0)
	{
			write_debug("IdleStart: ERROR_THREAD");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
	}

	ports_info[port-1].idle_info.enabled = 1;
	//enable DTMF or MFP

	//teste

	switch(ports_info[port-1].idle_info.nFormat)
	{
		case dtMFP:
			dg_SetDetectionType(port,DETECT_MFF,DG_ENABLE);	//MFF - eh o mesmo MFP
			break;
		default:
			dg_SetFastDetection(port,DG_ENABLE);
			dg_SetDetectionType(port,DETECT_DTMF,DG_ENABLE);
			break;
	}

	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// Destroy Idle thread
//----------------------------------------------------------------
short WCDECL dg_IdleAbort(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].idle_info.thread_id>0)
	{
		//Send to threads informations to close
		dg_InsertIdleFifo(port,C_ENDTHREAD,0);
		ports_info[port-1].idle_info.closing = 1;
		//destroi conferencias
		//port2CardChannel(MAX_CHANNELS_CARD, port-1,  &card , &card_channel);
	}

	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------
// Send commands directly to Idle fifo
//-------------------------------------------------------------------
short WCDECL dg_InsertIdleFifo(unsigned short port,unsigned  short command, unsigned short data)
{
	dg_event_data_structure trans;
#ifdef WIN32
	u32 cbWritten;
#endif

  //Send to threads informations to close
	trans.command = command;
	trans.port = port;
	trans.data = data;
	if (ports_info[port-1].fifo_to_idle>0)
	{
		digivoice_entercriticalsection(&port_mutex[port-1], port);
#ifdef __LINUX__
		write(ports_info[port-1].fifo_to_idle,&trans,sizeof(trans));
#else
		WriteFile(  ports_info[port-1].fifo_to_idle,        // handle to pipe
					&trans,      // buffer to write from
					sizeof(trans), // number of bytes to write
					&cbWritten,   // number of bytes written
					&ports_info[port-1].idle_info.oOverlapIdle);        // not overlapped I/O

#endif
		digivoice_leavecriticalsection(&port_mutex[port-1], port);
	}
	else
		return EXIT_FAILURE;

	return DG_EXIT_SUCCESS;
}

//---


//----------------------------------------------------------------
// This method create a thread to control callprogress
// Must call EnableCallProgress to start the efective monitoring
// ConfigFile can be NULL but dg_ConfigCustomCAS must be used
//----------------------------------------------------------------
short WCDECL dg_CreateCallProgress(short port, char *ConfigFile)
{
#ifdef __LINUX__
	short ret;
#endif
    short i;
    char szTemp[DG_MAX_PATH];
    char szValue[DG_MAX_PATH];
	FILE *f;
    int f1,f2;

	char szFile[DG_MAX_PATH];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].cp_info.thread_id>0)
			return DG_ERROR_THREAD_ALREADY_RUNNING;

	ports_info[port-1].cp_info.thread_ready = 0;

    write_debug("dg_CreateCallProgress for port %d", port);
	//path of configuration file
#ifdef WIN32
	sprintf(szFile,"%s\\%s",szConfigurationPath,ConfigFile);
#else
	sprintf(szFile,"%s/%s",szConfigurationPath,ConfigFile);
#endif

	if (ConfigFile!=NULL && strlen(ConfigFile)!=0)
	{
		//check if file exists
		f=fopen(szFile,"rt");
		if (f==NULL)
		{
			write_debug("CreateCallProgress (%d): Could not find %s", port, szFile);
			return DG_ERROR_CONFIGFILE_NOT_FOUND;
		}
		fclose(f);
	}

#ifdef __LINUX__
	//create fifo to cas
	sprintf(ports_info[port-1].cp_info.szFifoToCP,"%s/dg_rxcp_%d",DG_FIFO_PATH,port-1);
	ret = mkfifo(ports_info[port-1].cp_info.szFifoToCP,O_RDWR | DG_FIFO_ACCESS_RIGHTS);
	/*if (ret!=0)
	{
		write_debug("CreateCallProgress (%d): Error creating FIFO - code = $d",port, errno);
		return DG_ERROR_FIFO_UNAVAILABLE;
	}*/

	//tries to open fifo
	ports_info[port-1].fifo_to_cp = open(ports_info[port-1].cp_info.szFifoToCP,O_RDWR);
	if (ports_info[port-1].fifo_to_cp < 1)
			return DG_ERROR_FIFO_UNAVAILABLE;

    write_debug("CreateCallProgress (%d): Create fifo_to_cp = %d",port, ports_info[port-1].fifo_to_cp);

#endif

#ifdef WIN32

	//TODO - Precisa consistencia

	//uses pipe to communicate
	//create fifo to cas
	sprintf(ports_info[port-1].cp_info.szFifoToCP,"\\\\.\\pipe\\dgcp_%d",port-1);

	//cria evento de notificacao para a thread
	ports_info[port-1].cp_info.CPEvent.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (!ports_info[port-1].cp_info.CPEvent.hEvent)
		return DG_ERROR_COULD_NOT_CREATE_THREAD;

	ports_info[port-1].cp_info.oOverlapCP.hEvent = ports_info[port-1].cp_info.CPEvent.hEvent;

	//create PIPE
	ports_info[port-1].fifo_to_cp = CreateNamedPipe(ports_info[port-1].cp_info.szFifoToCP,
													PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
													PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
													PIPE_UNLIMITED_INSTANCES,
													1024,
													1024,
													NMPWAIT_USE_DEFAULT_WAIT,
													NULL);


	ConnectNamedPipe(ports_info[port-1].fifo_to_cp, &ports_info[port-1].cp_info.oOverlapCP);
#endif

	//default -> answer detection disabled
	ports_info[port-1].cp_info.answer_enabled = 0;



    write_debug("dg_CreateCallProgress for port %d - reading configuration file", port);
	if (ConfigFile!=NULL)
	{
		write_debug("dg_CreateCallProgress for port %d - ConfigFile!=NULL**********", port);
		ports_info[port-1].cp_info.port = port;

		ports_info[port-1].cp_info.nAnswerSensitivity = GetPrivateProfileInt("CallProgress","AnswerSensitivity",1,szFile);
		ports_info[port-1].cp_info.nAnswerSensitivityTime = GetPrivateProfileInt("CallProgress","AnswerSensitivityTime",10,szFile);
		ports_info[port-1].cp_info.nGenericToneTimeout = GetPrivateProfileInt("CallProgress","GenericToneTimeout",15000,szFile);		//ms
		ports_info[port-1].cp_info.nGenericToneTime = GetPrivateProfileInt("CallProgress","GenericToneTime",500,szFile); 			//ms
		ports_info[port-1].cp_info.nLineToneTimeout = GetPrivateProfileInt("CallProgress","LineToneTimeout",15000,szFile);			//ms
		ports_info[port-1].cp_info.nLineToneTime = GetPrivateProfileInt("CallProgress","LineToneTime",1500,szFile);			//ms must be greater than ulBusyMaxTime
		ports_info[port-1].cp_info.nFaxToneTimeout = GetPrivateProfileInt("CallProgress","FaxToneTimeout",15000,szFile);			//ms
		ports_info[port-1].cp_info.nFaxToneTime = GetPrivateProfileInt("CallProgress","FaxToneTime",1500,szFile);			//ms must be greater than ulBusyMaxTime
		ports_info[port-1].cp_info.nCallProgressTimeout = GetPrivateProfileInt("CallProgress","CallProgressTimeout",15000,szFile);		//ms
		ports_info[port-1].cp_info.ulBusyMinTime = GetPrivateProfileInt("CallProgress","BusyMinTime",100,szFile); 			//ms
		ports_info[port-1].cp_info.ulBusyMaxTime = GetPrivateProfileInt("CallProgress","BusyMaxTime",600,szFile); 			//ms
        ports_info[port-1].cp_info.nBusySensibility = GetPrivateProfileInt("CallProgress","BusySensibility",1,szFile);
		ports_info[port-1].cp_info.ulCallingMinToneTime = GetPrivateProfileInt("CallProgress","CallingMinToneTime",700,szFile); 		//ms should be greater than ulBusyMaxTime
		ports_info[port-1].cp_info.ulCallingMaxToneTime = GetPrivateProfileInt("CallProgress","CallingMaxToneTime",2500,szFile); 		//ms
		ports_info[port-1].cp_info.ulCallingMinSilTime = GetPrivateProfileInt("CallProgress","CallingMinSilTime",700,szFile); 		//ms
		ports_info[port-1].cp_info.ulCallingMaxSilTime = GetPrivateProfileInt("CallProgress","CallingMaxSilTime",5000,szFile); 		//ms
		ports_info[port-1].cp_info.ulToneInterruptionMinTime = GetPrivateProfileInt("CallProgress","ToneInterruptionMinTime",20,szFile);		//ms
		ports_info[port-1].cp_info.ulToneInterruptionMaxTime = GetPrivateProfileInt("CallProgress","ToneInterruptionMaxTime",350,szFile);      //ms
		ports_info[port-1].cp_info.ulLineToneMinTime = GetPrivateProfileInt("CallProgress","LineToneMinTime",100,szFile); 			//ms
		ports_info[port-1].cp_info.ulLineToneMaxTime = GetPrivateProfileInt("CallProgress","LineToneMaxTime",2500,szFile);			//ms

		//le valores padrao para as frequencias a serem utilizadas
		ports_info[port-1].cp_info.nToneType[T_GTONE] = GetPrivateProfileInt("CallProgress","GenericToneFreq",CP_TONE4,szFile);
		ports_info[port-1].cp_info.nToneType[T_GTONE2] = GetPrivateProfileInt("CallProgress","GenericToneFreq2",CP_TONE5,szFile);
		ports_info[port-1].cp_info.nToneType[T_GTONE3] = GetPrivateProfileInt("CallProgress","GenericToneFreq3",CP_TONE6,szFile);
		ports_info[port-1].cp_info.nToneType[T_GTONE4] = GetPrivateProfileInt("CallProgress","GenericToneFreq4",CP_TONE7,szFile);
		ports_info[port-1].cp_info.nToneType[T_GTONE5] = GetPrivateProfileInt("CallProgress","GenericToneFreq5",CP_TONE8,szFile);
		ports_info[port-1].cp_info.nToneType[T_AUDIO] = GetPrivateProfileInt("CallProgress","Audio", CP_AUDIO ,szFile);
		ports_info[port-1].cp_info.nToneType[T_LINE] = GetPrivateProfileInt("CallProgress","LineToneFreq", CP_TONE1,szFile);
		ports_info[port-1].cp_info.nToneType[T_CALLING] = GetPrivateProfileInt("CallProgress","CallingToneFreq",CP_TONE1 ,szFile);
		ports_info[port-1].cp_info.nToneType[T_BUSY] = GetPrivateProfileInt("CallProgress","BusyToneFreq",CP_TONE1 ,szFile);
		ports_info[port-1].cp_info.nToneType[T_FAX1] = GetPrivateProfileInt("CallProgress","Fax1ToneFreq", CP_TONE2,szFile);
		ports_info[port-1].cp_info.nToneType[T_FAX2] = GetPrivateProfileInt("CallProgress","Fax2ToneFreq",CP_TONE3 ,szFile);
		ports_info[port-1].cp_info.nToneType[T_SILENCE] = GetPrivateProfileInt("CallProgress","Silence",CP_SILENCE ,szFile);

        //---------------------------
        // Read frequencies from cfg
        //---------------------------
        for (i=1;i<=8;i++) {		
            sprintf(szTemp,"tone%d",i);
            if (GetPrivateProfileString("CallProgress",szTemp,"X",szValue,DG_MAX_PATH,szFile))
            {
                //NOTE: to avoid problems with outdated cfg file, when the function returns "X" the frequency will
                //      assume the startvoicerlib default				

                if (strncmp(szValue,"X",1)) {
                    //must parse both frequencies
                    //todo: avoid to call the same function to the same card since callprogress is port based
					
                    sscanf(szValue,"%d,%d",&f1,&f2);
                    dg_SetCardDetections(dg_GetCardNumber(port) , (i+CFG_DETECT_FREQMF) , (float)f1,(float)f2);
                    write_debug("CreateCallProgress (%d): Applying frequencies %dHz and %dHz", port, f1,f2);
                }

            }
        }


        //test if there is the string end at the end of the file
        if (GetPrivateProfileInt("CallProgress","end",999,szFile)!=1)
            return DG_WARNING_OLDFILEFORMAT;



	}	

    //Create callprogress control thread
    ports_info[port-1].cp_info.thread_ready = 2; //started but not ready
    if (digivoice_beginthread(&ports_info[port-1].cp_info.thread_id,Call_Progress_Thread,0,
                &ports_info[port-1].cp_info)!=0)
    {
            ports_info[port-1].cp_info.thread_ready = 0;
            write_debug("dg_create_cp_control: ERROR_THREAD");
            return DG_ERROR_COULD_NOT_CREATE_THREAD;
    }


	write_debug("CreateCallProgress (%d): CallProgress Created", port);
	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// Destroy Call progress thread
//----------------------------------------------------------------
short WCDECL dg_DestroyCallProgress(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].cp_info.thread_id>0)
	{

		//Send to threads informations to close
		dg_InsertCPFifo(port,C_ENDTHREAD,0);

		//destroi conferencias
		//port2CardChannel(MAX_CHANNELS_CARD, port-1,  &card , &card_channel);

		write_debug("(%d) DestroyCallProgress",port);

	}
	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------------
// Configure CallProgress Thread - This function can be used instead of
// passing ConfigFile in dg_CreateCustomCAS
//	CPCFG_ANSWER_SENSITIVITY
//  CPCFG_ANSWER_SENSITIVITY_TIME
//	CPCFG_GENERICTONETIMEOUT ,
//	CPCFG_GENERICTONETIME ,
//	CPCFG_LINETONETIMEOUT ,
//	CPCFG_LINETONETIME ,
//	CPCFG_FAXTONETIMEOUT ,
//	CPCFG_NFAXTONETIME ,
//	CPCFG_CALLPROGRESSTIMEOUT ,
//	CPCFG_BUSYMINTIME ,
//	CPCFG_BUSYMAXTIME ,
//	CPCFG_CALLINGMINTONETIME ,
//	CPCFG_CALLINGMAXTONETIME ,
//	CPCFG_CALLINGMINSILTIME ,
//	CPCFG_CALLINGMAXSILTIME ,
//	CPCFG_TONEINTERRUPTIONMINTIME ,
//	CPCFG_TONEINTERRUPTIONMAXTIME ,
//	CPCFG_LINETONEMINTIME ,
//	CPCFG_LINETONEMAXTIME
//	CPCFG_LINEFREQ,				//---- FREQUENCIES
//	CPCFG_CALLINGFREQ,
//	CPCFG_BUSYFREQ,
//	CPCFG_GENERICFREQ,
//	CPCFG_GENERICFREQ2,
//	CPCFG_GENERICFREQ3,
//	CPCFG_GENERICFREQ4,
//	CPCFG_GENERICFREQ5,
//	CPCFG_SILENCE,
//	CPCFG_AUDIO
//  CPCFG_BUSYSENSIBILITY
//----------------------------------------------------------------
short WCDECL dg_ConfigCallProgress(short port, short command, int value)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//verificar constantes
	if (command <0 || command > CPCFG_MAX)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//check if the thread was already created
	if (ports_info[port-1].cp_info.thread_id<1)
				return DG_ERROR_THREAD_NOT_RUNNING;

	switch(command)
	{
		case CPCFG_ANSWER_SENSITIVITY:					//sensibilidade de atendimento
			ports_info[port-1].cp_info.nAnswerSensitivity = value;
			break;
		case CPCFG_ANSWER_SENSITIVITY_TIME:					//tempo minimo para sensibilidade de atendimento
			ports_info[port-1].cp_info.nAnswerSensitivityTime = value;
		case CPCFG_GENERICTONETIMEOUT:
			ports_info[port-1].cp_info.nGenericToneTimeout = value;
			break;
		case CPCFG_GENERICTONETIME:
			ports_info[port-1].cp_info.nGenericToneTime = value;
			break;
		case CPCFG_LINETONETIMEOUT:
			ports_info[port-1].cp_info.nLineToneTimeout = value;
			break;
		case CPCFG_LINETONETIME:
			ports_info[port-1].cp_info.nLineToneTime = value; //ms must be greater than ulBusyMaxTime
			break;
		case CPCFG_FAXTONETIMEOUT:
			ports_info[port-1].cp_info.nFaxToneTimeout = value;
			break;
		case CPCFG_FAXTONETIME:	//ms must be greater than ulBusyMaxTime
			ports_info[port-1].cp_info.nFaxToneTime = value;
			break;
		case CPCFG_CALLPROGRESSTIMEOUT:
			ports_info[port-1].cp_info.nCallProgressTimeout = value;
			break;
		case CPCFG_BUSYMINTIME:
			ports_info[port-1].cp_info.ulBusyMinTime = value;
			break;
		case CPCFG_BUSYMAXTIME:
			ports_info[port-1].cp_info.ulBusyMaxTime = value;
			break;
        case CPCFG_BUSYSENSIBILITY:
            ports_info[port-1].cp_info.nBusySensibility = value;
            break;
		case CPCFG_CALLINGMINTONETIME:	//ms should be greater than ulBusyMaxTime
			ports_info[port-1].cp_info.ulCallingMinToneTime = value;
			break;
		case CPCFG_CALLINGMAXTONETIME:
			ports_info[port-1].cp_info.ulCallingMaxToneTime = value;
			break;
		case CPCFG_CALLINGMINSILTIME:
			ports_info[port-1].cp_info.ulCallingMinSilTime = value;
			break;
		case CPCFG_CALLINGMAXSILTIME:
			ports_info[port-1].cp_info.ulCallingMaxSilTime = value;
			break;
		case CPCFG_TONEINTERRUPTIONMINTIME:
			ports_info[port-1].cp_info.ulToneInterruptionMinTime = value;
			break;
		case CPCFG_TONEINTERRUPTIONMAXTIME:
			ports_info[port-1].cp_info.ulToneInterruptionMaxTime = value;
			break;
		case CPCFG_LINETONEMINTIME:
			ports_info[port-1].cp_info.ulLineToneMinTime = value;
			break;
		case CPCFG_LINETONEMAXTIME:
			ports_info[port-1].cp_info.ulLineToneMaxTime = value;
			break;
		//configuracoes de frequencia dos tons
		case CPCFG_LINEFREQ:
			ports_info[port-1].cp_info.nToneType[T_LINE] = value;
			break;
		case CPCFG_CALLINGFREQ:
			ports_info[port-1].cp_info.nToneType[T_CALLING] = value;
			break;
		case CPCFG_BUSYFREQ:
			ports_info[port-1].cp_info.nToneType[T_BUSY] = value;
			break;
		case CPCFG_GENERICFREQ:
			ports_info[port-1].cp_info.nToneType[T_GTONE] = value;
			break;
		case CPCFG_GENERICFREQ2:
			ports_info[port-1].cp_info.nToneType[T_GTONE2] = value;
			break;
		case CPCFG_GENERICFREQ3:
			ports_info[port-1].cp_info.nToneType[T_GTONE3] = value;
			break;
		case CPCFG_GENERICFREQ4:
			ports_info[port-1].cp_info.nToneType[T_GTONE4] = value;
			break;
		case CPCFG_GENERICFREQ5:
			ports_info[port-1].cp_info.nToneType[T_GTONE5] = value;
			break;
		case CPCFG_SILENCE:
			ports_info[port-1].cp_info.nToneType[T_SILENCE] = value;
			break;
		case CPCFG_AUDIO:
			ports_info[port-1].cp_info.nToneType[T_AUDIO] = value;
			break;
		case CPCFG_FAX1:
			ports_info[port-1].cp_info.nToneType[T_FAX1] = value;
			break;
		case CPCFG_FAX2:
			ports_info[port-1].cp_info.nToneType[T_FAX2] = value;
			break;
		default:
			return DG_ERROR_PARAM_OUTOFRANGE;
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------
// Send commands directly to CallProgress fifo
//-------------------------------------------------------------------
short WCDECL dg_InsertCPFifo(unsigned short port,unsigned  short command, unsigned short data)
{
	dg_event_data_structure trans;
#ifdef WIN32
	u32 cbWritten;
#endif

  //Send to threads informations to close
	trans.command = command;
	trans.port = port;
	trans.data = data;
	if (ports_info[port-1].fifo_to_cp>0)
	{
		//digivoice_entercriticalsection(&port_mutex[port-1], port);
#ifdef __LINUX__
		write(ports_info[port-1].fifo_to_cp,&trans,sizeof(trans));
#else
		WriteFile(  ports_info[port-1].fifo_to_cp,        // handle to pipe
					&trans,      // buffer to write from
					sizeof(trans), // number of bytes to write
					&cbWritten,   // number of bytes written
					&ports_info[port-1].cp_info.oOverlapCP);        // not overlapped I/O

#endif
		//digivoice_leavecriticalsection(&port_mutex[port-1], port);
	}
	else
		return EXIT_FAILURE;

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// This method create logger thread control using E1 protocol
// type:
// 1 - LOGGER_RD2MF
//----------------------------------------------------------------
short WCDECL dg_CreateLoggerControl(short port, short type)
{
	short card, card_channel;
	short relative_ch;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;


	port2CardChannel(port, &card, &card_channel);

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this function is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	if (card_channel < 1 || (card_channel > HALF_CHANNELS))
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].logger_info.thread_id>0)
				return DG_ERROR_THREAD_ALREADY_RUNNING;

#ifdef __LINUX__
	//create fifo to logger
	sprintf(ports_info[port-1].logger_info.szFifoToLogger,"%s/dg_rxlog_%d",DG_FIFO_PATH,port-1);
	mkfifo(ports_info[port-1].logger_info.szFifoToLogger,O_RDWR | DG_FIFO_ACCESS_RIGHTS);
	write_debug("e1 - create - abrindo %s",ports_info[port-1].logger_info.szFifoToLogger);
	//tries to open fifo
	ports_info[port-1].fifo_to_logger = open(ports_info[port-1].logger_info.szFifoToLogger,O_RDWR/*O_WRONLY*/);
	if (ports_info[port-1].fifo_to_logger < 1)
		return DG_ERROR_FIFO_UNAVAILABLE;

#endif

#ifdef WIN32

	//TODO - Precisa consistencia

	//uses pipe to communicate
	//create fifo to logger
	sprintf(ports_info[port-1].logger_info.szFifoToLogger,"\\\\.\\pipe\\dglog_%d",port-1);

	//cria evento de notificacao para a thread
	ports_info[port-1].logger_info.LoggerEvent.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (!ports_info[port-1].logger_info.LoggerEvent.hEvent)
		return DG_ERROR_COULD_NOT_CREATE_THREAD;

	ports_info[port-1].logger_info.oOverlapLogger.hEvent = ports_info[port-1].logger_info.LoggerEvent.hEvent;

	//create PIPE
	ports_info[port-1].fifo_to_logger = CreateNamedPipe(ports_info[port-1].logger_info.szFifoToLogger,
													PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
													PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
													PIPE_UNLIMITED_INSTANCES,
													1024,
													1024,
													NMPWAIT_USE_DEFAULT_WAIT,
													NULL);


	if (ports_info[port-1].fifo_to_logger == INVALID_HANDLE_VALUE)
		return DG_ERROR_COULD_NOT_CREATE_THREAD;

	ConnectNamedPipe(ports_info[port-1].fifo_to_logger, &ports_info[port-1].logger_info.oOverlapLogger);

#endif

	//set default values
	ports_info[port-1].logger_info.target_port = port;

	//o port2 deveria ser obtido
	relative_ch = dg_GetRelativeChannelNumber(port);
	ports_info[port-1].logger_info.port2 = dg_GetAbsolutePortNumber( card, relative_ch + HALF_CHANNELS);	//port 2 is always the second E1

	//set reverse lookup of target port
	ports_info[port-1].target_port = port;
	ports_info[ports_info[port-1].logger_info.port2-1].target_port = port;

	//Create logger control thread
	ports_info[port-1].logger_info.thread_running = 1;	//flag to execute the thread
	if (digivoice_beginthread(&ports_info[port-1].logger_info.thread_id,Logger_Thread,0,&ports_info[port-1].logger_info)!=0)
	{
			write_debug("dg_CreateLoggerControl: ERROR_THREAD");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
	}
	//get port status
	dg_SendR2Command(ports_info[port-1].logger_info.target_port,R2_ENABLEDETECTION);	//habilita
	dg_SendR2Command(ports_info[port-1].logger_info.port2  ,R2_ENABLEDETECTION);	//habilita
	ports_info[port-1].logger_info.silence_threshold_signaling = -24;
	ports_info[port-1].logger_info.silence_threshold_after_signaling = -24;

	ports_info[ports_info[port-1].logger_info.port2-1].logger_info.silence_threshold_signaling = -24;
	ports_info[ports_info[port-1].logger_info.port2-1].logger_info.silence_threshold_after_signaling = -24;

	ports_info[port-1].logger_info.chat_handle = dg_CreateChatRoom(card,2);

	//checar valor da conferencia
	if (ports_info[port-1].logger_info.chat_handle > 0)
	{
		//insert ports into conference resource
		dg_ChatAddPort(ports_info[port-1].logger_info.chat_handle,ports_info[port-1].logger_info.target_port);
		dg_ChatAddPort(ports_info[port-1].logger_info.chat_handle,ports_info[port-1].logger_info.port2);
	}
	write_debug("Logger criado para canal %d - handle %x", port, ports_info[port-1].logger_info.chat_handle);

	//enables fast detection
	dg_SetFastDetection(port,DG_ENABLE);
	dg_SetFastDetection(ports_info[port-1].logger_info.port2,DG_ENABLE);

	//flag
	ports_info[port-1].logger_info.enabled = 1;

	return DG_EXIT_SUCCESS;

}

//----------------------------------------------------------------
// This method destroys logger thread control using E1 protocol
//----------------------------------------------------------------
short WCDECL dg_DestroyLoggerControl(short port)
{
	short card,card_channel;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;
	card = dg_GetCardNumber(port);
	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this function is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;


	//check port
	card_channel = dg_GetRelativeChannelNumber(port);
    if (card_channel < 1 || (card_channel > HALF_CHANNELS))
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].logger_info.enabled)
	{
		//Send to threads informations to close
		dg_InsertLoggerFifo(port,C_ENDTHREAD,0);

		//flag
		ports_info[port-1].logger_info.enabled = 0;

		dg_SetDetectionType(ports_info[port-1].logger_info.target_port , DETECT_ALL_MF, DG_DISABLE);
		dg_SetDetectionType(ports_info[port-1].logger_info.port2 , DETECT_ALL_MF, DG_DISABLE);

		//enable r2 detecttion
		dg_SendR2Command(port,R2_DISABLEDETECTION);
		dg_SendR2Command(ports_info[port-1].logger_info.port2,R2_DISABLEDETECTION);

		//destroi conferencias
		ports_info[port-1].logger_info.thread_running = 0;	//force thread finalization
		//Disables fast detection
		dg_SetFastDetection(port,DG_DISABLE);
		dg_SetFastDetection(ports_info[port-1].logger_info.port2, DG_DISABLE);

		//unset reverse lookup of target port
		ports_info[ports_info[port-1].logger_info.port2-1].target_port = ports_info[port-1].logger_info.port2;
	}

	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// Get calltype INCOMINGCALL = 1 ou OUTGOINGCALL = 2
//----------------------------------------------------------------
short WCDECL dg_GetLoggerCallType(short port)
{
	short card_channel;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
	card_channel = dg_GetRelativeChannelNumber(port);
    if (card_channel < 1 || (card_channel > HALF_CHANNELS))
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].logger_info.thread_id >0)
		return ports_info[port-1].logger_info.calltype;

	if (ports_info[port-1].logger_ccs_info.thread_id >0)
		return ports_info[port-1].logger_ccs_info.calltype;
	else
		return -1;
}

short WCDECL dg_SetLoggerSilenceThreshold(short port, short silence)
{
	short card_channel;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
	card_channel = dg_GetRelativeChannelNumber(port);
    if (card_channel < 1 || (card_channel > HALF_CHANNELS))
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].logger_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	if ((silence > 12) || (silence < -42))
		return DG_ERROR_INVALIDPARAM;

	ports_info[port-1].logger_info.silence_threshold_signaling = silence;
	ports_info[ports_info[port-1].logger_info.port2-1].logger_info.silence_threshold_signaling = silence;

	return DG_EXIT_SUCCESS;

}

#ifdef WIN32
//----------------------------------------------------------------
// This method create logger thread for CCS using E1 ISDN PRI
// type:
//----------------------------------------------------------------
short WCDECL dg_CreateLoggerCCS(short port, short Type)
{
	short card, card_channel;
	short relative_ch;
	short num_spans,spn;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;


	port2CardChannel(port, &card, &card_channel);

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this function is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	if (card_channel < 1 || (card_channel > HALF_CHANNELS))
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].logger_ccs_info.thread_id>0)
				return DG_ERROR_THREAD_ALREADY_RUNNING;

	//this section initialises ccs and is here for compatibility with R2 logger thread
	//because the following commands should be called one time for each span

	/* check which type of framer will be used */
	if (dg_GetCardPortsCount(card)>30)
		num_spans = 2;
	else
		num_spans = 1;

	for (spn=0; spn < num_spans; spn++) 
	{                    	
			//set ccs callback - doesn't matter call several times
		    write_debug("\nEnabling CCSMode for card %d -> span %d.\n",card,spn+1);
    		dg_SetCCSCallback(dg_CCS_Handler);
    		dg_EnableCCSMode(card,spn+1);                         
	}
	//save ccs log
	nCCSLog[card-1] = Type;

//	//TODO - Precisa consistencia
//
//	//uses pipe to communicate
//	//create fifo to logger
//	sprintf(ports_info[port-1].logger_ccs_info.szFifoToLoggerCCS,"\\\\.\\pipe\\dglogccs_%d",port-1);
//
//	//cria evento de notificacao para a thread
//	ports_info[port-1].logger_ccs_info.LoggerCCSEvent.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
//	if (!ports_info[port-1].logger_ccs_info.LoggerCCSEvent.hEvent)
//		return DG_ERROR_COULD_NOT_CREATE_THREAD;
//
//	ports_info[port-1].logger_ccs_info.oOverlapLoggerCCS.hEvent = ports_info[port-1].logger_ccs_info.LoggerCCSEvent.hEvent;
//
//	//create PIPE
//	ports_info[port-1].fifo_to_loggerCCS = CreateNamedPipe(ports_info[port-1].logger_ccs_info.szFifoToLoggerCCS,
//													PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
//													PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
//													PIPE_UNLIMITED_INSTANCES,
//													1024,
//													1024,
//													NMPWAIT_USE_DEFAULT_WAIT,
//													NULL);
//
//
//	if (ports_info[port-1].fifo_to_loggerCCS == INVALID_HANDLE_VALUE)
//		return DG_ERROR_COULD_NOT_CREATE_THREAD;
//
//	ConnectNamedPipe(ports_info[port-1].fifo_to_loggerCCS, &ports_info[port-1].logger_ccs_info.oOverlapLoggerCCS);
//
//
	//set default values
	ports_info[port-1].logger_ccs_info.target_port = port;

	ports_info[port-1].logger_ccs_info.status = 0;
	ports_info[port-1].logger_ccs_info.call_reference = -1;

	//o port2 deveria ser obtido
	relative_ch = dg_GetRelativeChannelNumber(port);
	ports_info[port-1].logger_ccs_info.port2 = dg_GetAbsolutePortNumber( card, relative_ch + HALF_CHANNELS);	//port 2 is always the second E1

	//set reverse lookup of target port
	ports_info[port-1].target_port = port;
	ports_info[ports_info[port-1].logger_ccs_info.port2-1].target_port = port;

	//Create logger control thread
	ports_info[port-1].logger_ccs_info.thread_running = 1;	//flag to execute the thread
//	if (digivoice_beginthread(&ports_info[port-1].logger_ccs_info.thread_id,Logger_CCS_Thread,0,&ports_info[port-1].logger_ccs_info)!=0)
//	{
//			write_debug("dg_CreateLoggerCCS: ERROR_THREAD");
//			return DG_ERROR_COULD_NOT_CREATE_THREAD;
//	}


	ports_info[port-1].logger_ccs_info.chat_handle = dg_CreateChatRoom(card,2);

	//checar valor da conferencia
	if (ports_info[port-1].logger_ccs_info.chat_handle > 0)
	{
		//insert ports into conference resource
		dg_ChatAddPort(ports_info[port-1].logger_ccs_info.chat_handle,ports_info[port-1].logger_ccs_info.target_port);
		dg_ChatAddPort(ports_info[port-1].logger_ccs_info.chat_handle,ports_info[port-1].logger_ccs_info.port2);
	}
	write_debug("LoggerCCS criado para canal %d - handle %x", port, ports_info[port-1].logger_ccs_info.chat_handle);

	//flag
	ports_info[port-1].logger_ccs_info.enabled = 1;
	ports_info[port-1].logger_ccs_info.thread_id = 1;
	return DG_EXIT_SUCCESS;

}

//----------------------------------------------------------------
// This method destroys logger thread control using E1 protocol
//----------------------------------------------------------------
short WCDECL dg_DestroyLoggerCCS(short port)
{
	short card,card_channel;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	card = dg_GetCardNumber(port);

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this function is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;


	//check port
	card_channel = dg_GetRelativeChannelNumber(port);
    if (card_channel < 1 || (card_channel > HALF_CHANNELS))
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].logger_ccs_info.enabled)
	{
		ports_info[port-1].logger_ccs_info.thread_id = 0;
		//Send to threads informations to close
//		dg_InsertLoggerCCSFifo(port,C_ENDTHREAD,0);

		//flag
		ports_info[port-1].logger_ccs_info.enabled = 0;

		//destroi conferencias
		ports_info[port-1].logger_ccs_info.thread_running = 0;	//force thread finalization

		//unset reverse lookup of target port
		ports_info[ports_info[port-1].logger_ccs_info.port2-1].target_port = ports_info[port-1].logger_ccs_info.port2;
	}

	return DG_EXIT_SUCCESS;
}
#endif

//----------------------------------------------------------------
// This functions creates the threads that manage all E1 ports
// protocol (r2)
//----------------------------------------------------------------
short WCDECL dg_CreateE1Thread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].e1_info.thread_id>0)
				return DG_ERROR_THREAD_ALREADY_RUNNING;

	//this functions is avaiable only for E1 cards
	if ((dg_GetPortCardType(port) != VBE13060PCI) && (dg_GetPortCardType(port) != VBE13030PCI) && 
		(dg_GetPortCardType(port) != VBE13060PCI_R) && (dg_GetPortCardType(port) != VBE16060PCI) &&
		(dg_GetPortCardType(port) != VBE16060PCI_R) &&
		(dg_GetPortCardType(port) != VB3030PCIE) && (dg_GetPortCardType(port) != VB6060PCIE) &&
		(dg_GetPortCardType(port) != DGV_1E1F) && (dg_GetPortCardType(port) != DGV_2E1F))
		return DG_FEATURE_NOT_SUPPORTED;

	write_debug("dg_CreateE1Thread: Starting configuration - port %d", port);
#ifdef __LINUX__
	//create fifo to e1
	sprintf(ports_info[port-1].e1_info.szFifoToE1,"%s/dg_rxe1_%d",DG_FIFO_PATH,port-1);
	//unlink(ports_info[port-1].e1_info.szFifoToE1);

	mkfifo(ports_info[port-1].e1_info.szFifoToE1, O_RDWR | DG_FIFO_ACCESS_RIGHTS);
	write_debug("dg_CreateE1Thread: FIFO CREATED - port %d", port);
	//tries to open fifo
	ports_info[port-1].fifo_to_e1 = open(ports_info[port-1].e1_info.szFifoToE1,O_RDWR/*O_WRONLY*/);
	if (ports_info[port-1].fifo_to_e1<1)
		return DG_ERROR_FIFO_UNAVAILABLE;

	write_debug("e1 - create - abrindo %s handle - %x",ports_info[port-1].e1_info.szFifoToE1,ports_info[port-1].fifo_to_e1 );
#endif

#ifdef WIN32

	//TODO - Precisa consistencia

	//uses pipe to communicate
	//create fifo to e1
	sprintf(ports_info[port-1].e1_info.szFifoToE1,"\\\\.\\pipe\\dg_rxe1_%d",port-1);

	//cria evento de notificacao kernelmode->usermode para sinais - comandos da placa
	ports_info[port-1].e1_info.E1Event.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (!ports_info[port-1].e1_info.E1Event.hEvent)
		return DG_ERROR_COULD_NOT_CREATE_THREAD;

	ports_info[port-1].e1_info.oOverlapE1.hEvent = ports_info[port-1].e1_info.E1Event.hEvent;

	//create PIPE
	ports_info[port-1].fifo_to_e1 = CreateNamedPipe(ports_info[port-1].e1_info.szFifoToE1,
													PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
													PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
													PIPE_UNLIMITED_INSTANCES,
													1024,
													1024,
													NMPWAIT_USE_DEFAULT_WAIT,
													NULL);


	ConnectNamedPipe(ports_info[port-1].fifo_to_e1, &ports_info[port-1].e1_info.oOverlapE1);

#endif

	ports_info[port-1].e1_info.port = port;
	//fills default informations about timeouts
	//the default values can be changed with dg_config_e1_handle function
	ports_info[port-1].e1_info.bBlocked = 0;			//desbloqueado
	ports_info[port-1].e1_info.timeout_ocupacao = 7000;  //7s
	ports_info[port-1].e1_info.timeout_retencao = 90000;     // 90s -
	ports_info[port-1].e1_info.timeout_atendimento = 75000;  // 75s - 75000
	ports_info[port-1].e1_info.timeout_bloqueio_on = 1000;  // 1s - 1000
	ports_info[port-1].e1_info.timeout_bloqueio_off = 2000; // 2s - 2000
	ports_info[port-1].e1_info.timeout_mft = 30000;          // 30s - 30000 TESTE em 70000
	ports_info[port-1].e1_info.timeout_mff = 30000;          // 30s - 30000 TESTE em 70000
	ports_info[port-1].e1_info.category = 1;					//categoria padrao
	ports_info[port-1].e1_info.rx_total_of_digits = 0;			//nao pega nada automaticamente
	ports_info[port-1].e1_info.send_id_digit_pos = 0;
	ports_info[port-1].e1_info.group_b_id = 1;
	ports_info[port-1].e1_info.silence_threshold_signaling = -30;
	ports_info[port-1].e1_info.silence_threshold_after_signaling = -24;
	ports_info[port-1].e1_info.ring_generate_ringback = 1;			//generates ringback automatically
	ports_info[port-1].e1_info.r2_country = R2_COUNTRY_BR;             //default brazil
	ports_info[port-1].e1_info.sigtype = R2_TYPE_MFC;                  //default MFC

	//turn timer off
	SetEnableTimer(&tmr_E1[port-1],FALSE);
	SetEnableTimer(&tmrCallProgress[port-1],FALSE);
	ports_info[port-1].e1_info.enabled = 0;
	write_debug("dg_CreateE1Thread: Creating thread - port %d", port);
	//Create E1-R2 protocol thread
	if (digivoice_beginthread(&ports_info[port-1].e1_info.thread_id,Signal_E1_Thread,0,&ports_info[port-1].e1_info)!=0)
	{
			write_debug("dg_CreateE1Thread: ERROR_THREAD");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
	}

#ifdef WIN32
	SetThreadPriority(ports_info[port-1].e1_info.thread_id,THREAD_PRIORITY_NORMAL);
#else
	//TODO: Prioridade de thread em Linux
#endif
	//get port status
	dg_SendR2Command(port,R2_ENABLEDETECTION);	//habilita
	//dg_SendR2Command(port, R2_BLOCKED);		//envia bloqueio
	write_debug("dg_CreateE1Thread: Created succesfully - port %d", port);

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------------
// This routine configures E1 Handle data:
// SILENCE_THRESHOLD_AFTER
//----------------------------------------------------------------------
short WCDECL dg_ConfigE1Thread(short port, short command, int value)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if ((dg_GetPortCardType(port) != VBE13060PCI) && (dg_GetPortCardType(port) != VBE13030PCI) && 
		(dg_GetPortCardType(port) != VBE13060PCI_R) && (dg_GetPortCardType(port) != VBE16060PCI)&&
		(dg_GetPortCardType(port) != VBE16060PCI_R) &&
		(dg_GetPortCardType(port) != VB3030PCIE) && (dg_GetPortCardType(port) != VB6060PCIE) &&
		(dg_GetPortCardType(port) != DGV_1E1F) && (dg_GetPortCardType(port) != DGV_2E1F))
		return DG_FEATURE_NOT_SUPPORTED;

	//verificar constantes
	if (command < E1CFG_SEIZURE_TIMEOUT || command > E1CFG_MAX)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	switch(command)
	{
		case E1CFG_GROUP_II:
			ports_info[port-1].e1_info.category = (char)value;
			break;
		case E1CFG_SEIZURE_TIMEOUT:		//7000ms
			ports_info[port-1].e1_info.timeout_ocupacao = value;
			break;
		case E1CFG_RETENTION_TIMEOUT:	//90000ms
			ports_info[port-1].e1_info.timeout_retencao = value;
			break;
		case E1CFG_ANSWER_TIMEOUT:		//75000ms
			ports_info[port-1].e1_info.timeout_atendimento = value;
			break;
		case E1CFG_BLOCKING_ON:			//1000ms
			ports_info[port-1].e1_info.timeout_bloqueio_on =  value;
			break;
		case E1CFG_BLOCKING_OFF:		//2000ms
			ports_info[port-1].e1_info.timeout_bloqueio_off = value;
			break;
		case E1CFG_MFT_TIMEOUT:			//30000ms
			ports_info[port-1].e1_info.timeout_mft = value;
			break;
		case E1CFG_MFF_TIMEOUT:			//30000ms
			ports_info[port-1].e1_info.timeout_mff = value;
			break;
		case E1CFG_MAXDIGITS_RX:		//padrao zero para tratamento manual dos eventos da thread
			ports_info[port-1].e1_info.rx_total_of_digits = (char)value;
			break;
		case E1CFG_SEND_ID_AFTERDIGIT:	//apos o digito x, envia identificacao
			ports_info[port-1].e1_info.send_id_digit_pos = (char)value;
			break;
		case E1CFG_GROUP_B:
			ports_info[port-1].e1_info.group_b_id = (char)value;
			break;
		case SILENCE_THRESHOLD:		//padrao -36
			ports_info[port-1].e1_info.silence_threshold_signaling = value;
			break;
		case SILENCE_THRESHOLD_AFTER:	//padrao -24
			ports_info[port-1].e1_info.silence_threshold_after_signaling = value;
			break;
		case E1CFG_GENERATE_RINGBACK:	//0 - without ringback - 1 - with ringback (default)
			ports_info[port-1].e1_info.ring_generate_ringback = value;
			break;
		case E1CFG_R2_COUNTRY://br(brazil), ar(argentine), mx(mexico) - default = br
			if (value < 1 || value > 3)
				return DG_ERROR_PARAM_OUTOFRANGE;
			else
				ports_info[port-1].e1_info.r2_country = value;
			break;
		case E1CFG_SIGTYPE://R2_TYPE_MFC = 1, R2_TYPE_CB_FXO = 2, R2_TYPE_CB_FXS = 3 - default = MFC
			if (value < 1 || value > 3)
				return DG_ERROR_PARAM_OUTOFRANGE;
			else
				ports_info[port-1].e1_info.sigtype = value;
			break;
		default:
			return DG_ERROR_PARAM_OUTOFRANGE;
	}
	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// This functions destroy E1 handle for a desired port
//----------------------------------------------------------------
short WCDECL dg_DestroyE1Thread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if ((dg_GetPortCardType(port) != VBE13060PCI) && (dg_GetPortCardType(port) != VBE13030PCI) && 
		(dg_GetPortCardType(port) != VBE13060PCI_R) && (dg_GetPortCardType(port) != VBE16060PCI) &&
		(dg_GetPortCardType(port) != VBE16060PCI_R) &&
		(dg_GetPortCardType(port) != VB3030PCIE) && (dg_GetPortCardType(port) != VB6060PCIE) &&
		(dg_GetPortCardType(port) != DGV_1E1F) && (dg_GetPortCardType(port) != DGV_2E1F))
		return DG_FEATURE_NOT_SUPPORTED;


	if (ports_info[port-1].e1_info.thread_id>0)
	{

		dg_SendR2Command(port,R2_BLOCKED);		//bloqueia

		dg_SendR2Command(port,R2_DISABLEDETECTION);

		ports_info[port-1].e1_info.bBlocked=0;	//allow to send C_ENDTHREAD command

		//Send to threads informations to close
		//dg_insert_callctrl_fifo(port,C_ENDTHREAD,0);
		dg_InsertE1Fifo(port,C_ENDTHREAD,0);


		//turn timer off
		SetEnableTimer(&tmr_E1[port-1],FALSE);
		SetEnableTimer(&tmrCallProgress[port-1],FALSE);


	}
	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// This functions enabled and reset E1 thread
//----------------------------------------------------------------
short WCDECL dg_EnableE1Thread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	if (ports_info[port-1].e1_info.enabled==0)
	{
		ports_info[port-1].e1_info.enabled = 1;
		dg_InsertE1Fifo(port,C_RESET_THREAD,0);
	}
	return DG_EXIT_SUCCESS;

}
//----------------------------------------------------------------
// This functions disable E1 thread
//----------------------------------------------------------------
short WCDECL dg_DisableE1Thread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	if (ports_info[port-1].e1_info.enabled)
	{
		dg_InsertE1Fifo(port,C_RESET_THREAD,0);
		ports_info[port-1].e1_info.enabled = 0;
	}
	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// This functions returns the E1 state
// DG_E1_THREAD_ENABLED 1
// DG_E1_THREAD_DISABLED 0
//----------------------------------------------------------------
short WCDECL dg_GetE1ThreadStatus(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	return ports_info[port-1].e1_info.enabled;

}

dg_signal_e1_thread_structure *WCDECL dg_GetE1ThreadPointer(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return NULL;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return NULL;

	return &ports_info[port-1].e1_info;

}

//--------------------------------------------------------------------
// This functions creates the threads that manage all GSM card's ports
//--------------------------------------------------------------------
short WCDECL dg_CreateGSMThread(short port)
{
    short nFor;

	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].gsm_info.thread_id>0)
		return DG_ERROR_THREAD_ALREADY_RUNNING;

	//this functions is avaiable only for GSM cards
	if (dg_GetPortCardType(port) != VB0404GSM)
		return DG_FEATURE_NOT_SUPPORTED;

	write_debug("dg_CreateGSMThread: Starting configuration - port %d", port);
	
#ifdef __LINUX__
		//create fifo to gsm
		sprintf(ports_info[port-1].gsm_info.szFifoToGSM,"%s/dg_rxgsm_%d",DG_FIFO_PATH,port-1);
	
		mkfifo(ports_info[port-1].gsm_info.szFifoToGSM, O_RDWR | DG_FIFO_ACCESS_RIGHTS);
		write_debug("dg_CreateGSMThread: FIFO CREATED - port %d", port);
	
		//tries to open fifo
		ports_info[port-1].fifo_to_gsm = open(ports_info[port-1].gsm_info.szFifoToGSM,O_RDWR/*O_WRONLY*/);
		if (ports_info[port-1].fifo_to_gsm<1)
			return DG_ERROR_FIFO_UNAVAILABLE;
	
		write_debug("gsm - create - abrindo %s handle - %x",ports_info[port-1].gsm_info.szFifoToGSM,ports_info[port-1].fifo_to_gsm );
#else
		//TODO - Precisa consistencia
	
		//uses pipe to communicate
		//create fifo to gsm
		sprintf(ports_info[port-1].gsm_info.szFifoToGSM,"\\\\.\\pipe\\dg_rxgsm_%d",port-1);
	
		//cria evento de notificacao kernelmode->usermode para sinais - comandos da placa
		ports_info[port-1].gsm_info.GSMEvent.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
		if (!ports_info[port-1].gsm_info.GSMEvent.hEvent)
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
	
		ports_info[port-1].gsm_info.oOverlapGSM.hEvent = ports_info[port-1].gsm_info.GSMEvent.hEvent;
	
		//create PIPE
		ports_info[port-1].fifo_to_gsm = CreateNamedPipe(ports_info[port-1].gsm_info.szFifoToGSM,
														PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
														PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
														PIPE_UNLIMITED_INSTANCES,
														1024,
														1024,
														NMPWAIT_USE_DEFAULT_WAIT,
														NULL);
	
	
		ConnectNamedPipe(ports_info[port-1].fifo_to_gsm, &ports_info[port-1].gsm_info.oOverlapGSM);
#endif

	ports_info[port-1].gsm_info.port = port;
	ports_info[port-1].gsm_info.ClearAllSMS_Enabled = 0;
	ports_info[port-1].gsm_info.ClearAllSMS_Timeout_Id = -1;
	
	//turn timer off
	SetEnableTimer(&tmr_GSM[port-1],FALSE);
	SetEnableTimer(&tmr_GSM_Wait[port-1],FALSE);
	SetEnableTimer(&tmr_GSM_ClearAllSMS[port-1],FALSE);
	SetEnableTimer(&tmrCallProgress[port-1],FALSE);

	ports_info[port-1].gsm_info.enabled = 0;
    ports_info[port-1].gsm_info.thread_ready = 0;

	write_debug("dg_CreateGSMThread: Creating thread - port %d", port);

	//Create gsm protocol thread
	if (digivoice_beginthread(&ports_info[port-1].gsm_info.thread_id,Signal_GSM_Thread,0,&ports_info[port-1].gsm_info)!=0)
	{
			write_debug("dg_CreateGSMThread: ERROR_THREAD");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
	}

#ifdef WIN32
		SetThreadPriority(ports_info[port-1].gsm_info.thread_id,THREAD_PRIORITY_NORMAL);
#else
		//TODO: Prioridade de thread em Linux
#endif

        for (nFor = 1; nFor <= 50; nFor++)
        {
                if (ports_info[port-1].gsm_info.thread_ready == 0)
                {
                        write_debug("dg_CreateGSMThread: Waiting for gsm thread (step %d)... - port %d", nFor, port);
                        digivoice_sleep(50);
                }
                else
                        break;
        }

        if (ports_info[port-1].gsm_info.thread_ready == 0)
        {
                write_debug("dg_CreateGSMThread: GSM Thread not ready - port %d", port);
                return DG_ERROR_THREAD_NOT_RUNNING;
        }

	write_debug("dg_CreateGSMThread: Created succesfully - port %d", port);

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------------
// This routine configures GSM Handle data:
//----------------------------------------------------------------------
short WCDECL dg_ConfigGSMThread(short port, short command, int value)
{
	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

	//this functions is avaiable only for GSM cards
	if (dg_GetPortCardType(port) != VB0404GSM)
		return DG_FEATURE_NOT_SUPPORTED;


	if (command < GSMCFG_DIGIT_TIMEOUT || command > GSMCFG_MAX)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	//if (ports_info[port-1].gsm_info.thread_id==0)
	//	return DG_ERROR_THREAD_NOT_RUNNING;
	
	switch(command)
	{
		case GSMCFG_DIGIT_TIMEOUT:		//5000ms
			ports_info[port-1].gsm_info.nDigitTimeout = value;
			break;

		case GSMCFG_ID_RESTRICTION:		//0
			ports_info[port-1].gsm_info.nIDRestriction = value;
			break;

		case GSMCFG_USSD_ENABLE:		//0
			ports_info[port-1].gsm_info.nUSSDEnable = value;
			break;

		case GSMCFG_CALL_WAITING_ENABLE:		//0
			ports_info[port-1].gsm_info.nCallWaitingEnable = value;
			break;

		case GSMCFG_DISPLAY_CALL_WAITING_ENABLE:		//0
			ports_info[port-1].gsm_info.nDisplayCallWaitingEnable = value;
			break;
		
		case GSMCFG_RETRY_TIMEOUT: //10000 ms
			ports_info[port-1].gsm_info.nRetryTimeout = value;
			break;	

		case GSMCFG_ANSWER_TIMEOUT: //30000 ms
			ports_info[port-1].gsm_info.nAnswerTimeout = value;
			break;

		case GSMCFG_MESSAGE_CONFIRMATION:
			ports_info[port-1].gsm_info.nMessageConfirmation = value;  //0 disable, 1 - enable
			break;

		case GSMCFG_FLASHSMS_ENABLE:
			ports_info[port-1].gsm_info.nFlashSMS = value;  //0 disable, 1 - enable
			break;

		default:
			return DG_ERROR_PARAM_OUTOFRANGE;
	}
	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// This functions destroy GSM handle for a desired port
//----------------------------------------------------------------
short WCDECL dg_DestroyGSMThread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//this functions is avaiable only for GSM cards
	if (dg_GetPortCardType(port) != VB0404GSM)
		return DG_FEATURE_NOT_SUPPORTED;


	if (ports_info[port-1].gsm_info.thread_id>0)
	{
		//dg_HangUp(port);//removed on 4.2.2.0_rc3		

		ports_info[port-1].gsm_info.bBlocked=0;	//allow to send C_ENDTHREAD command
		ports_info[port-1].gsm_info.ClearAllSMS_Enabled = 0;
		ports_info[port-1].gsm_info.ClearAllSMS_Timeout_Id = -1;

		//Send to threads informations to close
		dg_InsertGSMFifo(port,C_ENDTHREAD,0);

		//turn timer off
		SetEnableTimer(&tmr_GSM[port-1],FALSE);
		SetEnableTimer(&tmr_GSM_Wait[port-1],FALSE);
		SetEnableTimer(&tmr_GSM_ClearAllSMS[port-1],FALSE);
		SetEnableTimer(&tmrCallProgress[port-1],FALSE);
		write_debug("dg_DestroyGSMThread: Destroy process started - port %d", port);
	}
	else
		write_debug("dg_DestroyGSMThread: Error in Thread ID - port %d", port);

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// This functions enabled and reset GSM thread
//----------------------------------------------------------------
short WCDECL dg_EnableGSMThread(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id==0)
		return DG_ERROR_THREAD_NOT_RUNNING;
	
	if (ports_info[port-1].gsm_info.enabled==0)
	{
		ports_info[port-1].gsm_info.enabled = 1;
		ports_info[port-1].gsm_info.ClearAllSMS_Enabled = 0;
		ports_info[port-1].gsm_info.ClearAllSMS_Timeout_Id = -1;
		dg_InsertGSMFifo(port, C_RESET_THREAD, 0);
		write_debug("dg_EnableGSMThread: Enabled succesfully - port %d", port);
	}
	return DG_EXIT_SUCCESS;
}	

//----------------------------------------------------------------
// This functions disable GSM thread
//----------------------------------------------------------------
short WCDECL dg_DisableGSMThread(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id==0)
		return DG_ERROR_THREAD_NOT_RUNNING;

	if (ports_info[port-1].gsm_info.enabled)
	{
		dg_InsertGSMFifo(port, C_RESET_THREAD, 0);
		ports_info[port-1].gsm_info.enabled = 0;
		ports_info[port-1].gsm_info.ClearAllSMS_Enabled = 0;
		ports_info[port-1].gsm_info.ClearAllSMS_Timeout_Id = -1;
		write_debug("dg_DisableGSMThread: Disabled succesfully - port %d", port);		
	}
	return DG_EXIT_SUCCESS;
}

short WCDECL dg_send_command(short card, short param1,short param2,short param3,short param4,short param5,short param6)
{
	dg_cmd_tx tx_command_e1;

	//send commands
	tx_command_e1.command = (unsigned char)param1;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = card;
	tx_command_e1.param1 = (unsigned char)param2;
	tx_command_e1.param2 = (unsigned char)param3;
	tx_command_e1.param3 = (unsigned char)param4;
	tx_command_e1.param4 = (unsigned char)param5;
	tx_command_e1.param5 = (unsigned char)param6;


	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------
// Send R2 command
//----------------------------------------------------
short WCDECL dg_SendR2Command(short port, int r2)
{
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	tx_command_e1.command = CMD_R2;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = port - 1;
	tx_command_e1.param2 = r2;
	write_generic_command(&tx_command_e1);

	//write_debug("<<<<< vlib: (%d) dg_SendR2Command: %x",port,r2);
    if (r2<0x10) {
        write_debug("<<r2 %d                                                                  %x",port,r2);
    }
#ifdef  __LINUX__
    if (DebugEnabled)
        dg_write_tx_msg(&tx_command_e1);
#endif
	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------------
// This function send the C_ASK_FOR_ID
// this function help to user do not call insert_e1_fifo directly
//----------------------------------------------------------------------
short WCDECL dg_R2AskForId(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//thread is running?
	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;


	return dg_InsertE1Fifo(port,C_ASK_FOR_ID,0);
}
//--------------------------------------------------------------------
// C_PREP_RX_GRUPO_II - Preparacao para receber grupo II (categoria)
// this function help to user do not call insert_e1_fifo directly
//--------------------------------------------------------------------
short WCDECL dg_R2AskForGroupII(short port, short type)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//type - 0 - compelido
	//type - 1 - pulsado
	if (type!=0 && type!=1)
		return DG_ERROR_PARAM_OUTOFRANGE;

	//thread is running?
	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	return dg_InsertE1Fifo(port,C_PREP_RX_GRUPO_II,type);
}

//-----------------------------------------------------------------------
//	groupb_type options:
/* 	B_FREE_CALLING = 1,
	B_BUSY,
	B_NUMBER_CHANGED,
	B_CONGESTION,
	B_FREE_WITHOUTBILLING,
	B_COLLECTCALL,
	B_NUMBER_UNKNOWN,
	B_OUT_OF_SERVICE*/
//-----------------------------------------------------------------------
short WCDECL dg_R2SendGroupB(short port, short groupb_type)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//thread is running?
	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	if (groupb_type<0 || groupb_type>ports_info[port-1].e1_info.b_out_of_service)
		return DG_ERROR_PARAM_OUTOFRANGE;

	return dg_InsertE1Fifo(port,C_SEND_GROUP_B, groupb_type);
}
//-----------------------------------------------------------------------
// Send custom backward signal
//-----------------------------------------------------------------------
short WCDECL dg_R2SendBackwardSignal(short port, short signal)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//thread is running?
	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	if (signal<0 || signal>9)
		return DG_ERROR_PARAM_OUTOFRANGE;

	return dg_InsertE1Fifo(port,C_SEND_BACKWARD_SIGNAL, signal);
}


//-------------------------------------------------------------------
// Send commands directly to E1 fifo
//-------------------------------------------------------------------
short WCDECL dg_InsertE1Fifo(unsigned short port,unsigned  short command, unsigned short data)
{
	dg_event_data_structure trans;
#ifdef WIN32
	u32 cbWritten;
#endif

  //Send to threads informations to close
	trans.command = command;
	trans.port = port;
	trans.data = data;
/*	write_debug("InsertE1Fifo 1 (%d) - fifoe1=%x blocked=%d enabled=%d", trans.port,ports_info[port-1].fifo_to_e1,
			ports_info[port-1].e1_info.bBlocked,
			ports_info[port-1].e1_info.enabled);	*/
	if (ports_info[port-1].fifo_to_e1>0 && ports_info[port-1].e1_info.bBlocked==0 &&
				ports_info[port-1].e1_info.enabled)
	{

#ifdef __LINUX__
		write(ports_info[port-1].fifo_to_e1,&trans,sizeof(trans));
#else
		//
		WriteFile(  ports_info[port-1].fifo_to_e1,        // handle to pipe
					&trans,      // buffer to write from
					sizeof(trans), // number of bytes to write
					&cbWritten,   // number of bytes written

					&ports_info[port-1].e1_info.oOverlapE1);        // not overlapped I/O

#endif

	}
	else
	{
		if (ports_info[port-1].e1_info.bBlocked)
			return DG_EXIT_SUCCESS;
		else
			return DG_EXIT_FAILURE;
	}
	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------------------
// Send commands directly to GSM fifo
//-------------------------------------------------------------------
short WCDECL dg_InsertGSMFifo(unsigned short port,unsigned  short command, unsigned short data)
{
	dg_event_data_structure trans;
#ifdef WIN32
	u32 cbWritten;
#endif

  //Send to threads informations to close
	trans.command = command;
	trans.port = port;
	trans.data = data;
	/*write_debug("InsertGSMFifo 1 (%d) - fifoe1=%x blocked=%d enabled=%d", trans.port,ports_info[port-1].fifo_to_gsm,
			ports_info[port-1].gsm_info.bBlocked,
			ports_info[port-1].gsm_info.enabled);	*/
	if (ports_info[port-1].fifo_to_gsm>0 && ports_info[port-1].gsm_info.bBlocked==0 &&
				ports_info[port-1].gsm_info.enabled)
	{

#ifdef __LINUX__
		write(ports_info[port-1].fifo_to_gsm,&trans,sizeof(trans));
#else

			//write_debug("InsertGSMFifo Before (%d) - fifoe1=%x blocked=%d enabled=%d", trans.port,ports_info[port-1].fifo_to_gsm,ports_info[port-1].gsm_info.bBlocked,ports_info[port-1].gsm_info.enabled);	
			if(WriteFile(ports_info[port-1].fifo_to_gsm,        // handle to pipe
			 			 &trans,      // buffer to write from
						 sizeof(trans), // number of bytes to write
						 &cbWritten,   // number of bytes written
						 &ports_info[port-1].gsm_info.oOverlapGSM)==FALSE) // not overlapped I/O
			{
				cbWritten=GetLastError();
				write_debug("InsertGSMFifo Retornou ERROR (%d) - fifoe1=%x blocked=%d enabled=%d bytes escritos %d", trans.port,ports_info[port-1].fifo_to_gsm,ports_info[port-1].gsm_info.bBlocked,ports_info[port-1].gsm_info.enabled,cbWritten);	
			}
			//else
			//write_debug("InsertGSMFifo After (%d) - fifoe1=%x blocked=%d enabled=%d bytes escritos %d", trans.port,ports_info[port-1].fifo_to_gsm,ports_info[port-1].gsm_info.bBlocked,ports_info[port-1].gsm_info.enabled,cbWritten);	

#endif

	}
	else
	{
		if (ports_info[port-1].gsm_info.bBlocked)
			return DG_EXIT_SUCCESS;
		else
			return DG_EXIT_FAILURE;
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------
// Send commands directly to Logger fifo
//-------------------------------------------------------------------
short WCDECL dg_InsertLoggerFifo(unsigned short port,unsigned  short command, unsigned short data)
{
	dg_event_data_structure trans;
	short target_ch;

#ifdef WIN32
	u32 cbWritten;
#endif


  //Send to threads informations to close
	trans.command = command;

	target_ch = ports_info[port-1].target_port;

	trans.port = port;			
	trans.data = data;
	if (ports_info[target_ch-1].logger_info.enabled)
	{
		digivoice_entercriticalsection(&port_mutex[port-1], port);
#ifdef __LINUX__
		write(ports_info[target_ch-1].fifo_to_logger,&trans,sizeof(trans));
#else
		//write_debug("E1Event: Vai inserir cmd: %x  data: %x",trans.command, trans.data);
		WriteFile(  ports_info[target_ch-1].fifo_to_logger,        // handle to pipe 
					&trans,      // buffer to write from 
					sizeof(trans), // number of bytes to write 
					&cbWritten,   // number of bytes written
					&ports_info[target_ch-1].logger_info.oOverlapLogger);        // not overlapped I/O
#endif
		digivoice_leavecriticalsection(&port_mutex[port-1], port);
		//write_debug("Logger (%d) - Enviando dado = %x", target_ch,trans.data);
	}
	else
		return EXIT_FAILURE;


	return DG_EXIT_SUCCESS;
}

#ifdef WIN32
//-------------------------------------------------------------------
// Send commands directly to Logger CCS fifo
//-------------------------------------------------------------------
short WCDECL dg_InsertLoggerCCSFifo(short port,unsigned  short command, unsigned short data)
{
	dg_event_data_structure trans;
	short target_ch;

	u32 cbWritten;


  //Send to threads informations to close
	trans.command = command;

	target_ch = ports_info[port-1].target_port;

	trans.port = port;			
	trans.data = data;
	if (ports_info[target_ch-1].logger_ccs_info.enabled)
	{
		digivoice_entercriticalsection(&port_mutex[port-1], port);

		//write_debug("CCSEvent: Vai inserir cmd: %x  data: %x",trans.command, trans.data);
		WriteFile(  ports_info[target_ch-1].fifo_to_loggerCCS,        // handle to pipe 
					&trans,      // buffer to write from 
					sizeof(trans), // number of bytes to write 
					&cbWritten,   // number of bytes written
					&ports_info[target_ch-1].logger_ccs_info.oOverlapLoggerCCS);        // not overlapped I/O
		digivoice_leavecriticalsection(&port_mutex[port-1], port);
		//write_debug("Logger CCS(%d) - Enviando dado = %x", target_ch,trans.data);
	}
	else
		return EXIT_FAILURE;


	return DG_EXIT_SUCCESS;
}
#endif


//------------------------------------------------------------
// Receives Caller ID stored into E1 structure
//------------------------------------------------------------
short WCDECL dg_GetCallerId(short port, char *szCallerID)
{
	int i;
	char cRec;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if ((ports_info[port-1].e1_info.thread_id > 0) && (ports_info[port-1].e1_info.sigtype == R2_TYPE_MFC)) //tratamento de thread e1
	{
		for (i=0;i<ports_info[port-1].e1_info.rx_id_number_of_digits;i++)
		{
			cRec = ports_info[port-1].e1_info.rx_id_digits[i] + 0x30;
			switch(cRec)
			{
				case 63:
					cRec = 35;
					break;
				case 62:    //se chegar > vira *
					cRec = 42;
					break;
				case 0x3a:                //eh o 0x0a somado de 0x30
					cRec = 48;   //DTMF
					break;
				case 0x3b:
					cRec = 66;
					break;
				case 0x3c:
					cRec = 67;
					break;
				case 0x3d:
					cRec = 68;
					break;
			}
			szCallerID[i] = cRec;
		}
		szCallerID[i]=0;
	}
	else
		if (ports_info[port-1].logger_info.thread_id > 0) //tratamento durante o logger
		{
			for (i=0;i<ports_info[port-1].logger_info.rx_id_number_of_digits;i++)
			{
				cRec = ports_info[port-1].logger_info.rx_id_digits[i] + 0x30;
				switch(cRec)
				{
					case 63:
						cRec = 35;
						break;
					case 62:    //se chegar > vira *
						cRec = 42;
						break;
					case 0x3a:                //eh o 0x0a somado de 0x30
						cRec = 48;   //DTMF
						break;
					case 0x3b:
						cRec = 66;
						break;
					case 0x3c:
						cRec = 67;
						break;
					case 0x3d:
						cRec = 68;
						break;
				}
				szCallerID[i] = cRec;
			}
			szCallerID[i]=0;
			write_debug("vlib: Lendo CALLERID %s",szCallerID);
		}
		else
		if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
		{
			for (i=0;i<ports_info[port-1].gsm_info.rx_id_number_of_digits;i++)
			{
				szCallerID[i] = ports_info[port-1].gsm_info.rx_id_digits[i];
			}
			szCallerID[i]=0;
		}
		else
		if (ports_info[port-1].logger_ccs_info.thread_id > 0) //tratamento durante o loggerCCS
		{
			for (i=0;i<ports_info[port-1].logger_ccs_info.rx_id_number_of_digits;i++)
			{
				cRec = ports_info[port-1].logger_ccs_info.rx_id_digits[i];
				switch(cRec)
				{
					case 63:
						cRec = 35;
						break;
					case 62:    //se chegar > vira *
						cRec = 42;
						break;
					case 0x3a:                //eh o 0x0a somado de 0x30
						cRec = 48;   //DTMF
						break;
					case 0x3b:
						cRec = 66;
						break;
					case 0x3c:
						cRec = 67;
						break;
					case 0x3d:
						cRec = 68;
						break;
				}
				szCallerID[i] = cRec;
			}
			szCallerID[i]=0;
			write_debug("vlib: Lendo CALLERID %s",szCallerID);
		}
		else
		{
			//default handling
			
			strlcpy(szCallerID, ports_info[port-1].idle_info.sDigitsDetected, DG_MAX_PATH);
			write_debug("vlib: Lendo CALLERID %s do original %s",szCallerID, ports_info[port-1].idle_info.sDigitsDetected);
		}
	return DG_EXIT_SUCCESS;
}


//------------------------------------------------------------
// Receives Name ID stored into E1 structure
//------------------------------------------------------------
short WCDECL dg_GetNameId(short port, char *szNameID)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;


	//default handling	
	strlcpy(szNameID, ports_info[port-1].idle_info.sNameDetected, DG_MAX_PATH);
	write_debug("vlib: Lendo NAMEID %s do original %s",szNameID, ports_info[port-1].idle_info.sNameDetected);

	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get GSM Module Recived Message
//-------------------------------------------------------
short WCDECL dg_GSMGetMessage(short port, char *szMessage)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
			strlcpy(szMessage, ports_info[port-1].gsm_info.szGSMMessage, 255);
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get GSM SMS Index List
//-------------------------------------------------------
short WCDECL dg_GSMGetIndexList(short port, char *szMessage)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
			strlcpy(szMessage, ports_info[port-1].gsm_info.szIndexList, 255);
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get GSM Module Received SMS 
//-------------------------------------------------------
short WCDECL dg_GSMGetSMS(short port, char *szMessage)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		strlcpy(szMessage, ports_info[port-1].gsm_info.szRxSMS, 255);

		write_debug("vlib: Reading dg_GSMGetSMS on port %d: %s", port, szMessage);
		ports_info[port-1].gsm_info.szRxSMS[0] = '\0';
	}
	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------
// Get GSM SMS Memory usage 
//-------------------------------------------------------
short WCDECL dg_GSMGetMemory(short port, char *szMessage)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		strlcpy(szMessage, ports_info[port-1].gsm_info.szMemory, 20);

		write_debug("vlib: Reading dg_GSMMemory on port %d: %s", port, szMessage);
		ports_info[port-1].gsm_info.szMemory[0] = '\0';
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get GSM SMS Sent message confirmation string 
//-------------------------------------------------------
short WCDECL dg_GSMGetSMSConfirmation(short port, char *szMessage)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		strlcpy(szMessage, ports_info[port-1].gsm_info.szSMSConfirmation,255);
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get GSM USSD received message string
//-------------------------------------------------------
short WCDECL dg_GSMGetUSSD(short port, char *szMessage)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		strlcpy(szMessage, ports_info[port-1].gsm_info.szUSSDMessage,255);
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Send a generic command to GSM Modules
//-------------------------------------------------------
short WCDECL dg_GSMSendCommand(short port, char *szCommand)
{
	char szTemp[255];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		sprintf(szTemp,"%s\r\n",szCommand);
		gsm_puts_delayed(port, szTemp);
	}
	return DG_EXIT_SUCCESS;
}

//-----------------------------------
// Set GSM PIN Number
//-----------------------------------
short WCDECL dg_GSMSetPinNumber(short port, char *szPIN, char *szNewPIN)
{
	char szTemp[255];

	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;


	strlcpy(ports_info[port-1].gsm_info.szPinNumber, szPIN, 255);

	if(szNewPIN != NULL)
		strlcpy(ports_info[port-1].gsm_info.szNewPinNumber, szNewPIN, 255);

	if (ports_info[port-1].gsm_info.thread_id > 0) //gsm thread enabled
	{
		if(szNewPIN != NULL)
		{
			//strlcpy(ports_info[port-1].gsm_info.szNewPinNumber, szNewPIN, 255);
			sprintf(szTemp,"AT+CPIN=%s,%s\r\n",ports_info[port-1].gsm_info.szPinNumber,ports_info[port-1].gsm_info.szNewPinNumber);
		}
		else
		{
			ports_info[port-1].gsm_info.szNewPinNumber[0] = '\0';
			sprintf(szTemp,"AT+CPIN=%s\r\n",ports_info[port-1].gsm_info.szPinNumber);
		}
		if (ports_info[port-1].gsm_info.thread_id > 0) 
		{
			gsm_puts_delayed(port, szTemp);
		}
	}
	return DG_EXIT_SUCCESS;
}

//-----------------------------------
// Send GSM SMS Message
//-----------------------------------
short WCDECL dg_GSMSendSMS(short port, char *szNumber, char *szMessage)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//check message size limit
	if( strlen(szMessage) > 160)
		return DG_ERROR_PARAM_OUTOFRANGE;

	strlcpy( ports_info[port-1].gsm_info.szDestNumber,szNumber, 50);//copy destination number
	strlcpy( ports_info[port-1].gsm_info.szTxSMS,szMessage, 256);//copy SMS Text
	
	//gsm_send_sms(port);
	dg_InsertGSMFifo(port,C_SENDSMS,0);


	return DG_EXIT_SUCCESS;
}

//-----------------------------------
// Check Signal Quality
//-----------------------------------
short WCDECL dg_GSMCheckSignalQuality(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	gsm_puts_delayed(port, "AT+CSQ\r\n");
	
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get Signal Quality
//-------------------------------------------------------
short WCDECL dg_GSMGetSignalQuality(short port, char *szMessage)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		strlcpy(szMessage, ports_info[port-1].gsm_info.szSQ, 255);
		ports_info[port-1].gsm_info.szSQ[0] = '\0';
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get Call Quality (Based on BER)
//-------------------------------------------------------
short WCDECL dg_GSMGetCallQuality(short port, char *szMessage)
{
	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
	if (port < 1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		strlcpy(szMessage, ports_info[port-1].gsm_info.szCQ, 255);
		ports_info[port-1].gsm_info.szCQ[0] = '\0';
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Reset GSM Restart Port
//-------------------------------------------------------
short WCDECL dg_GSMRestartPort(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		//disable GSM Thread
		dg_DisableGSMThread(port);

		//reenable GSM Thread
		dg_EnableGSMThread(port);

	}
	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------
// Delete GSM SMS by index
//-------------------------------------------------------
short WCDECL dg_GSMDeleteSMS(short port, short index)
{
	char szTemp[256];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		sprintf(szTemp,"AT+CMGD=%d\r\n",index);
		gsm_puts_delayed(port, szTemp);
	}
	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------
//	Clear All SMS Message
//-------------------------------------------------------
short WCDECL dg_GSMClearAllSMS(short port, short flagClear)
{
	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
	if (port < 1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.ClearAllSMS_Enabled == 0)
		return DG_ERROR_RESOURCE_UNAVAILABLE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{	
		ports_info[port-1].gsm_info.flagClear = flagClear;
		gsm_puts_delayed(port,"AT+CPMS=\"MT\",\"MT\",\"MT\"\r\n");
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
//	Control Call hold and multiparty calls
//-------------------------------------------------------
short WCDECL dg_GSMCallControl(short port, short command, short call)
{	
	char szTemp[256];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		if (call>=1 && call<=7)
		{	
			if((command == GSM_TERMINATE_AND_ACCEPT)|| (command == GSM_PUT_ON_HOLD)) 
			{
				sprintf(szTemp,"AT+CHLD=%d%d\r\n",command,call);
				gsm_puts_delayed(port,szTemp);
			}
			else
				return DG_ERROR_PARAM_OUTOFRANGE;
		}
		else
		{
			if (call == 0)
			{
				sprintf(szTemp,"AT+CHLD=%d\r\n",command);
				gsm_puts_delayed(port,szTemp);
			}
			else
				return DG_ERROR_PARAM_OUTOFRANGE;
		}
	}

	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------
// Read and Delete GSM SMS by index
//-------------------------------------------------------
short WCDECL dg_GSMReadAndDeleteSMS(short port, short index)
{
	char szTemp[256];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		sprintf(ports_info[port-1].gsm_info.szIndex,"%d",index);
		sprintf(szTemp,"AT+CMGR=%d\r\n",index);
		gsm_puts_delayed(port, szTemp);
	}
	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------
// List GSM SMS 
//-------------------------------------------------------
short WCDECL dg_GSMListSMS(short port, short status)
{
	char szTemp[256];

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
		switch(status)
		{
			case REC_UNREAD:
				sprintf(szTemp,"AT+CMGL=REC_UNREAD\r\n");
			break;
			
			case REC_READ:
				sprintf(szTemp,"AT+CMGL=REC_READ\r\n");
			break;
			
			case STO_UNSENT:
				sprintf(szTemp,"AT+CMGL=STO_UNSENT\r\n");
			break;

			case STO_SENT:
				sprintf(szTemp,"AT+CMGL=STO_SENT\r\n");
			break;

			case ALL:
				sprintf(szTemp,"AT+CMGL=ALL\r\n");
			break;
		}
		gsm_puts_delayed(port, szTemp);
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Get last command
//-------------------------------------------------------
short WCDECL dg_GSMGetLastCommand(short port, char *szCommand)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].gsm_info.thread_id > 0) //tratamento de thread gsm
	{
			strlcpy(szCommand, ports_info[port-1].gsm_info.szLastCommand, 255);
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Enable GSM Thread Debug
//-------------------------------------------------------
short WCDECL dg_EnableGSMDebug(void)
{
    GSMDebugEnabled = 1;

    write_debug("dg_EnableGSMDebug: Enabling GSM Debug...");

    return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------
// Disable GSM Thread Debug
//-------------------------------------------------------
short WCDECL dg_DisableGSMDebug(void)
{
    GSMDebugEnabled = 0;

    write_debug("dg_DisableGSMDebug: Disabling GSM Debug...");

    return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------
// Sets port identification, used to send it through E1 protocol
//-------------------------------------------------------------------
short WCDECL dg_SetPortId(short port, char *szID)
{
	unsigned int i;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//pass all digits to e1 thread control
	for (i=0;i<strlen(szID);i++)
	{
		if (szID[i]=='\0')
				break;
	
		if (i<25)
			ports_info[port-1].e1_info.tx_id_digits[i] = (char)dg_convertdigits(szID[i]);

	}
	ports_info[port-1].e1_info.tx_id_number_of_digits = i;

	return DG_EXIT_SUCCESS;

}
//-------------------------------------------------------------------
// get number received during E1 R2 protocol
//-------------------------------------------------------------------
short WCDECL dg_GetE1Number(short port, char *szNumber)
{
	int i;
	char cRec;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;
	if (ports_info[port-1].e1_info.thread_id > 0)	//tratamento de thread e1
	{
		for (i=0;i<ports_info[port-1].e1_info.rx_complete_count;i++)
		{
			cRec = ports_info[port-1].e1_info.rx_complete_digits[i] + 0x30;

			switch(cRec)
			{
				case 63:
					cRec = 35;
					break;
				case 62:    //se chegar > vira *
					cRec = 42;
					break;
				case 0x3a:                //eh o 0x0a somado de 0x30
					cRec = 48;   //DTMF
					break;
				case 0x3b:
					cRec = 66;
					break;
				case 0x3c:
					cRec = 67;
					break;
				case 0x3d:
					cRec = 68;
					break;
			}
			szNumber[i] = cRec;
		}
		szNumber[i]=0;
	}
	else
		//tratamento durante o logger
		if (ports_info[port-1].logger_info.thread_id > 0)
		{
			for (i=0;i<ports_info[port-1].logger_info.rx_number_of_digits;i++)
			{
				cRec = ports_info[port-1].logger_info.rx_digits[i] + 0x30;

				switch(cRec)
				{
					case 63:
						cRec = 35;
						break;
					case 62:    //se chegar > vira *
						cRec = 42;
						break;
					case 0x3a:                //eh o 0x0a somado de 0x30
						cRec = 48;   //DTMF
						break;
					case 0x3b:
						cRec = 66;
						break;
					case 0x3c:
						cRec = 67;
						break;
					case 0x3d:
						cRec = 68;
						break;
				}

				szNumber[i] = cRec;
			}
			szNumber[i]=0;
		}
		else
		//tratamento durante o logger
		if (ports_info[port-1].logger_ccs_info.thread_id > 0)
		{
			for (i=0;i<ports_info[port-1].logger_ccs_info.rx_number_of_digits;i++)
			{
				cRec = ports_info[port-1].logger_ccs_info.rx_digits[i];

				switch(cRec)
				{
					case 63:
						cRec = 35;
						break;
					case 62:    //se chegar > vira *
						cRec = 42;
						break;
					case 0x3a:                //eh o 0x0a somado de 0x30
						cRec = 48;   //DTMF
						break;
					case 0x3b:
						cRec = 66;
						break;
					case 0x3c:
						cRec = 67;
						break;
					case 0x3d:
						cRec = 68;
						break;
				}

				szNumber[i] = cRec;
			}
			szNumber[i]=0;
		}					
		else
			return DG_ERROR_THREAD_NOT_RUNNING;
	return DG_EXIT_SUCCESS;
}
//-------------------------------------------------------------------
// set number of digits that e1 thread will be waiting for
//-------------------------------------------------------------------
short WCDECL dg_SetStartE1RxCount(short port, short count)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (count < 0 || count > 30)
		return DG_ERROR_PARAM_OUTOFRANGE;

	ports_info[port-1].e1_info.rx_number_of_digits = (char)count;

	return DG_EXIT_SUCCESS;

}
//-------------------------------------------------------------------
// set number of digits that e1 thread will be waiting for
//-------------------------------------------------------------------
short WCDECL dg_SetNextE1RxCount(short port, short count)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (count < 0 || count > 30)
		return DG_ERROR_PARAM_OUTOFRANGE;

	if (ports_info[port-1].e1_info.thread_id>0)
	{

		ports_info[port-1].e1_info.rx_number_of_digits = (char)count;
		//insere na fifo
		dg_InsertE1Fifo(port,C_WAITFORDIGITS,0);
		return DG_EXIT_SUCCESS;
	}
	else
		return DG_ERROR_THREAD_NOT_RUNNING;
	
}

short WCDECL dg_GetVersion(short card)
{
	dg_cmd_tx tx_command_e1;
	short ret = 0;
	
	if (dg_GetCardType(card) == DGV_2E1F || dg_GetCardType(card) == DGV_1E1F)
	{
	    if (!FDriverEnabled)
            return DG_ERROR_DRIVER_CLOSED;

		if (card < 1 && card > nCardsCount)
			return DG_ERROR_CARD_OUT_OF_RANGE;

		tx_command_e1.command = CMD_INFO;
		tx_command_e1.port_or_card = ASSUME_CARD;
		tx_command_e1.port = card;
		tx_command_e1.param1 = INFO_VERSION;
		tx_command_e1.param2 = 0;
		tx_command_e1.param3 = 0;
		write_generic_command(&tx_command_e1);

		ret = DG_EXIT_SUCCESS;
	}
	else
	{
		if (!FDriverEnabled)
			return 0;

		if (card < 1 || card > dg_GetCardsCount())
			return 0;

#ifdef __LINUX__
		if (!hWinDriver) {
			write_debug("dg_GetVersion: failed to open %s", VLIB_DEVICE);
			return DG_EXIT_FAILURE;
		}
		/* XXX cards are always card-1 in the kernel */
		ret = ioctl(hWinDriver, VPPCI_IOCTL_VERSION, card-1);
		if (ret == -1) {
			write_debug("dg_GetVersion: could not retrive driver version");
			return -1;
		}
#endif

#ifdef WIN32
		BZERO (kpCall);
		kpCall.hKernelPlugIn = kernelPlugIn.hKernelPlugIn;
		kpCall.dwMessage = VPPCI_IOCTL_VERSION;
		kpCall.pData = card-1;
		WD_KernelPlugInCall(hWinDriver, &kpCall);
		ret = (short)kpCall.dwResult;
#endif
	}
	return ret;
}

short WCDECL dg_GetLECInfo(short card)
{
	dg_cmd_tx tx_command_e1;

	if (dg_GetCardType(card) == DGV_2E1F || dg_GetCardType(card) == DGV_1E1F)
	{
	    if (!FDriverEnabled)
            return DG_ERROR_DRIVER_CLOSED;

		if (card < 1 && card > nCardsCount)
			return DG_ERROR_CARD_OUT_OF_RANGE;

		tx_command_e1.command = CMD_INFO;
		tx_command_e1.port_or_card = ASSUME_CARD;
		tx_command_e1.port = card;
		tx_command_e1.param1 = INFO_LECCOUNT;
		tx_command_e1.param2 = 0;
		tx_command_e1.param3 = 0;
		write_generic_command(&tx_command_e1);

		return DG_EXIT_SUCCESS;
	}
	else
	{
		return DG_ERROR_RESOURCE_UNAVAILABLE;
	}
}

//------------------------------------------------------------------------
// Get number of channels from specific card
//------------------------------------------------------------------------
short WCDECL dg_GetCardPortsCount(short card)
{

	short ret; 
	ret=0;

	//return 0 - isnt error code
	if (!FDriverEnabled)
        return 0;

	if (card < 1 || card > nCardsCount)
		return 0;

	return sm->Cards[card-1].numchannels;

}
//------------------------------------------------------------------------------------------
// Cria conferencia
// Retorna o Handle, que eh o ponteiro 
//------------------------------------------------------------------------------------------
long WCDECL dg_CreateChatRoom(short card, short maxports)
{

	int x,j;

	if (!FDriverEnabled)
        return 0;

	if (card < 1 || card > nCardsCount)
		return 0;

	//percorre vetor para ver se tem algum livre
	for (x=0; x<MAX_CHATROOMS; x++)
	{
		if (stConf[card-1][x]==NULL)
		{
			//livre
			stConf[card-1][x] = malloc(sizeof(dg_chatstructure));
			stConf[card-1][x]->RoomHandle = (long)stConf[card-1][x];
			stConf[card-1][x]->MaxPorts = maxports;
			stConf[card-1][x]->PortsCount = 0;
			for (j=0;j<MAX_CHANNELS_CARD;j++)
				stConf[card-1][x]->PortState[j] = FREE;

			return (long)stConf[card-1][x];
		}
	}
	
	return 0;

}

//------------------------------------------------------------------------------------------
// Cria conferencia
// Retorna o Handle, que eh o ponteiro 
//------------------------------------------------------------------------------------------
short WCDECL dg_DestroyChatRoom(short card, unsigned int Handle)
{
	int x;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//procura recurso pelo card/handle
	for (x=0; x<MAX_CHATROOMS; x++)
		if ((long)(stConf[card-1][x]) == Handle)
		{
			//achou
			free((void *)Handle);
			stConf[card-1][x] = NULL;
			return DG_EXIT_SUCCESS;
		}

	return DG_ERROR_RESOURCE_UNAVAILABLE;
}
//------------------------------------------------------------------------------------------
// Adiciona porta na sala
//------------------------------------------------------------------------------------------
short WCDECL dg_ChatAddPort(long Handle, short Port)
{
	int card,room;
	int found=0;
	short relative_ch=0;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//get relative port value
	relative_ch = dg_GetRelativeChannelNumber(Port);


	//localiza sala pelo handle
	for (card=0;card<dg_GetCardsCount();card++)
	{
		for (room=0;room<MAX_CHATROOMS;room++)
		{
			if (stConf[card][room]!=NULL)
				if (stConf[card][room]->RoomHandle == Handle)
				{	
					found=1;
					break;
				}
		}
		if (found)	//forca sair do loop
			break;
	}
	if (found)
	{
		//room full?
		if (stConf[card][room]->PortsCount >= stConf[card][room]->MaxPorts)
			return DG_ERROR_RESOURCE_FULL;

		//TODO: channel already allocated?

		//allocate
		stConf[card][room]->PortState[relative_ch-1] = ALLOCATED;
		stConf[card][room]->PortsCount++;

		//in this stage the port is only allocated into voicerlib context
		//to tell the card to connect audio, you must to call dg_ChatEnablePort


		return DG_EXIT_SUCCESS;
	}
	
	return DG_ERROR_RESOURCE_UNAVAILABLE;

}
//------------------------------------------------------------------------------------------
// Remove porta da sala
//------------------------------------------------------------------------------------------
short WCDECL dg_ChatRemovePort(long Handle, short Port)
{
	int found=0;
	int card,room;
	short relative_ch=0;


	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//get relative port value
	relative_ch = dg_GetRelativeChannelNumber(Port);


	//localiza sala pelo handle
	for (card=0;card<dg_GetCardsCount();card++)
	{
		for (room=0;room<MAX_CHATROOMS;room++)
		{
			if (stConf[card][room]!=NULL)
				if (stConf[card][room]->RoomHandle == Handle)
				{	
					found=1;
					break;
				}
		}
		if (found)	//forca sair do loop
			break;

	}
	if (found)
	{

		if (stConf[card][room]->PortState[relative_ch-1] != FREE)
		{
			//disable for ensure
			dg_ChatDisablePort(Handle,Port);

			stConf[card][room]->PortState[relative_ch-1] = FREE;
			stConf[card][room]->PortsCount--;
			return DG_EXIT_SUCCESS;
		}
	}

	return DG_ERROR_RESOURCE_UNAVAILABLE;


}
//------------------------------------------------------------------------------------------
// Habilita porta na sala
// Direction - CHAT_TALK - CHAT_LISTEN - CHAT_TALK_LISTEN
//------------------------------------------------------------------------------------------
short WCDECL dg_ChatEnablePort(long Handle, short Port, short Direction)
{

	dg_cmd_tx tx_command_e1;
	int found=0;
	int card,room;
	short relative_ch=0;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (Direction < CHAT_LISTEN || Direction > CHAT_TALK_LISTEN)
		return DG_ERROR_PARAM_OUTOFRANGE;


	//get relative port value
	relative_ch = dg_GetRelativeChannelNumber(Port);
	

	//localiza sala pelo handle
	for (card=0;card<dg_GetCardsCount();card++)
	{
		for (room=0;room<MAX_CHATROOMS;room++)
		{
			if (stConf[card][room]!=NULL)
				if (stConf[card][room]->RoomHandle == Handle)
				{	
					found=1;
					break;
				}
		}
		if (found)	//forca sair do loop
			break;

	}
	if (found)
	{
		if (stConf[card][room]->PortState[relative_ch-1] != FREE)
		{
			//allocate
			stConf[card][room]->PortState[relative_ch-1] = ALLOCATED;

			//call CMD_CONFERENCE
			tx_command_e1.command = CMD_CONFERENCE;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = Port - 1;
			tx_command_e1.param1 = (unsigned char)Port - 1;
			tx_command_e1.param2 = (unsigned char)room;
			tx_command_e1.param3 = (unsigned char)Direction;
			write_generic_command(&tx_command_e1);

			//turn on dtmf filter command
			tx_command_e1.command = CMD_FILTER;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = Port - 1;
			tx_command_e1.param1 = (unsigned char)Port - 1;
			tx_command_e1.param2 = 1;	//on
			write_generic_command(&tx_command_e1);

			return DG_EXIT_SUCCESS;
		}
	}

	return DG_ERROR_RESOURCE_UNAVAILABLE;


}
//------------------------------------------------------------------------------------------
// Desabilita porta na sala
//------------------------------------------------------------------------------------------
short WCDECL dg_ChatDisablePort(long Handle, short Port)
{
	dg_cmd_tx tx_command_e1;
	int found=0;
	int card,room;
	short relative_ch=0;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//get relative port value
	relative_ch = dg_GetRelativeChannelNumber(Port);


	//localiza sala pelo handle
	for (card=0;card<dg_GetCardsCount();card++)
	{
		for (room=0;room<MAX_CHATROOMS;room++)
		{
			if (stConf[card][room]!=NULL)
				if (stConf[card][room]->RoomHandle == Handle)
				{	
					found=1;
					break;
				}
		}
		if (found)	//forca sair do loop
			break;

	}
	if (found)
	{
		if (stConf[card][room]->PortState[relative_ch-1] != FREE)
		{
			//allocate
			stConf[card][room]->PortState[relative_ch-1] = ALLOCATED;

			//turn off dtmf filter command
			tx_command_e1.command = CMD_FILTER;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = Port - 1;
			tx_command_e1.param1 = (unsigned char)Port - 1;
			tx_command_e1.param2 = 0;	//off
			write_generic_command(&tx_command_e1);


			//call CMD_CONFERENCE
			tx_command_e1.command = CMD_CONFERENCE;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = Port - 1;
			tx_command_e1.param1 = (unsigned char)Port - 1;
			tx_command_e1.param2 = 30;			//30 = remove from chat room
			write_generic_command(&tx_command_e1);

			return DG_EXIT_SUCCESS;
		}
	}
	
	return DG_ERROR_RESOURCE_UNAVAILABLE;

}

//-------------------------------------------------------
// Get PCI bus info
//-------------------------------------------------------
unsigned int WCDECL dg_GetCardBus(short card)
{
	if (!FDriverEnabled)
        return 0;

	if (card < 1 && card > nCardsCount)
		return 0;

    
#ifdef WIN32
	return hPlxHandle[card-1]->pciSlot.dwBus;
#else
	return DG_EXIT_SUCCESS;
#endif
}

//-------------------------------------------------------
// Get PCI slot info
//-------------------------------------------------------
unsigned int WCDECL dg_GetCardSlot(short card)
{
	if (!FDriverEnabled)
        return 0;

	if (card < 1 && card > nCardsCount)
		return 0;

#ifdef WIN32
	return hPlxHandle[card-1]->pciSlot.dwSlot;
#else
	return DG_EXIT_SUCCESS;
#endif
}

//---------------------------------------------------------------
// devolve a placa a partir do canal absoluto
//---------------------------------------------------------------
short WCDECL dg_GetCardNumber(short absoluteport)
{
	if (!FDriverEnabled)
        return 0;

	if (absoluteport < 1 || absoluteport > dg_GetPortsCount())
		return 0;

	return ports_info[absoluteport-1].card;
}
//---------------------------------------------------------------
// devolve o canal relativo a partir do canal absoluto
//---------------------------------------------------------------
short WCDECL dg_GetRelativeChannelNumber(short absoluteport)
{
	//returns port 1 because we cannot return a positive number like errors code - delphi problem
	if (!FDriverEnabled)
        return 0;

	if (absoluteport <1 || absoluteport > dg_GetPortsCount())
		return 0;

	return ports_info[absoluteport-1].card_channel;
}
//---------------------------------------------------------------
// devolve o canal absoluto a partir de placa e canal
// forces 1 to avoid overflows in application
//---------------------------------------------------------------
short WCDECL dg_GetAbsolutePortNumber(short card, short relativeport)
{
	if (!FDriverEnabled)
        return 0;

	//check range
	if (card < 1 || card > nCardsCount)
		return 0;

	//check card port range
	if (relativeport < 1 || relativeport > sm->Cards[card-1].numchannels)
		return 0;

	return reverse_ports[card-1][relativeport-1];

}
//----------------------------------------------------------------
// Return de card type based on port parameter
//----------------------------------------------------------------
short WCDECL dg_GetPortCardType(short port)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	return dg_GetCardType(ports_info[port-1].card);
}

//---------------------------------------------------------------
// returns the card type
//---------------------------------------------------------------
short WCDECL dg_GetCardType(short card)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//check range
	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;
	
	return sm->Cards[card-1].CardType;

}
//---------------------------------------------------------------
// returns the card interface type passing port as parameter
// possible return values:
//   DG_DIGITAL_INTERFACE
//   DG_FXO_INTERFACE
//   DG_FXS_INTERFACE
//   DG_UNKNOWN_INTERFACE
//---------------------------------------------------------------

short WCDECL dg_GetPortInterface(short port)
{
	short card, ret;

	card = dg_GetCardNumber(port);
	ret = dg_GetCardInterface(card);
	if (ret == DG_FX_INTERFACE)
	{
		if (ports_info[port-1].fx_type == DG_FX_TYPE_FXS)
			ret = DG_FXS_INTERFACE;
		else
			if (ports_info[port-1].fx_type == DG_FX_TYPE_FXO || ports_info[port-1].fx_type == DG_FX_TYPE_FXO2)
				ret = DG_FXO_INTERFACE;
			else
				ret = DG_UNKNOWN_INTERFACE;
	}
	return ret;	
}
//---------------------------------------------------------------
// returns the card interface type
// possible return values:
//   DG_DIGITAL_INTERFACE
//   DG_FXO_INTERFACE
//   DG_FX_INTERFACE
//---------------------------------------------------------------
short WCDECL dg_GetCardInterface(short card)
{
	short card_type;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//check range
	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	card_type = dg_GetCardType(card);
	switch(card_type)
	{
		case VBE13060PCI:
		case VBE13060PCI_R:
        case VBE16060PCI:
        case VBE13030PCI:
		case VBE16060PCI_R:
		case VB3030PCIE:
		case VB6060PCIE:
		case VB1200PCIE:
		case DGV_1E1F:
		case DGV_2E1F:
			return DG_DIGITAL_INTERFACE;	
		case VB0408PCI:
		case VB0408PCIE:
			return DG_FXO_INTERFACE;
		case VB0404FX:
		case VB0404FX_R:			
			return DG_FX_INTERFACE;
		case VB0404GSM:
			return DG_GSM_INTERFACE;
		default:
			return DG_UNKNOWN_INTERFACE;
	}
}

//---------------------------------------------------------------
// Defines an abs_port to a card/channel
//---------------------------------------------------------------
short WCDECL dg_DefinePortResource(short port, short card, short card_channel)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//check range
	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;
	
	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;
	
	//check card port range
	/*if (port < 1 || port > sm->Cards[card-1].numchannels)
		return DG_ERROR_PORT_OUT_OF_RANGE;*/

	//set new values
	ports_info[port-1].card_channel = card_channel;	
	ports_info[port-1].card = card;

	reverse_ports[card-1][card_channel-1] = port;
	//kernel information
	sm->Cards[card-1].abs_port[ports_info[port-1].card_channel-1] = port;

	return DG_EXIT_SUCCESS;

}
//---------------------------------------------------------------
// Restores Original configuration based on cardtypes and 
// slot/bus order
//---------------------------------------------------------------
short WCDECL dg_ResetPortResource(void)
{
 	int ports;
	u16 my_card, ct;
	u16 nGlobalPort = 1;

	ports = 0;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//analyze each card to assign ports.
	//similar to digivoice_configure code
	for(my_card=0; my_card <sm->nCardsCount; my_card++)
	{
		//fill ports_info structure with default values
		for (ct = nGlobalPort; ct < (nGlobalPort+sm->Cards[my_card].numchannels); ct++)
		{
			ports_info[ct-1].card = my_card + 1;
			ports_info[ct-1].card_channel = (ct - nGlobalPort) + 1;
			//reverse search - based on card/card_channel retrieves the abs number
			reverse_ports[my_card][ports_info[ct-1].card_channel - 1] = ct;
			sm->Cards[my_card].abs_port[ports_info[ct-1].card_channel-1] = ct;
			//target port
			ports_info[ct-1].target_port = ct;

			write_debug("digivoice_configure: port:%d card:%d ch:%d",ct,my_card,(ct - nGlobalPort) + 1);
		}
		//save last port
		nGlobalPort = ct;

	} //for my_card

	return DG_EXIT_SUCCESS;
}


//----------------------------------------------------------------
// Habilta AGC
//----------------------------------------------------------------
short WCDECL dg_EnableAgc(short port)
{
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//
	tx_command_e1.command = CMD_AGC;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = 1;	//On
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;

}


//----------------------------------------------------------------
// Desabilta AGC
//----------------------------------------------------------------
short WCDECL dg_DisableAgc(short port)
{
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//dbg(port,"dg_DisableAgc - Entra");
	//
	tx_command_e1.command = CMD_AGC;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = 0;	//OFF
	write_generic_command(&tx_command_e1);

	//dbg(port,"dg_DisableAgc - Sai");

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// Enable echo cancelation
// port - port to enable
// type - defines the echo cancelation type (ECHO_HW_DSP or ECHO_SW_LEC) (optional if K_ECHO defined)
// taps - number of taps used
// training - ms to wait to start training - use 0 to not use it (only for DIGITAL cards)
// nlp - 0 = Disabled (only for non DIGITAL cards)
//       1 = Enable with MUTE method
//       2 = Enable with CLIP method
//       3 = Enable with CNG (Confort noise generator) method (Default)
//----------------------------------------------------------------
#ifdef K_ECHO
	short WCDECL dg_EnableEchoCancelation(short port, short type, short taps, short training, short nlp)
	{
		short card_channel;
#else//#ifdef K_ECHO
	short WCDECL dg_EnableEchoCancelation(short port, short taps, short training, short nlp)
	{
#endif//#ifdef K_ECHO
	dg_cmd_tx tx_command_e1;
    short card;

	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

	//check taps passed
#ifdef K_ECHO
		if (taps < ECHO_TAPS_16 || taps > ECHO_TAPS_1024)
			return DG_ERROR_PARAM_OUTOFRANGE;
#else//#ifdef K_ECHO
		if (dg_GetPortCardType(port) == DGV_2E1F || dg_GetPortCardType(port) == DGV_1E1F)
		{
			if (taps < ECHO_TAPS_16 || taps > ECHO_TAPS_1024)
				return DG_ERROR_PARAM_OUTOFRANGE;
		}
		else
			if (taps < ECHO_TAPS_16 || taps > ECHO_TAPS_512)
				return DG_ERROR_PARAM_OUTOFRANGE;
#endif//#ifdef K_ECHO

    card = dg_GetCardNumber(port);

#ifdef K_ECHO
		ports_info[port-1].echocan_type=type;

		if (type == ECHO_SW_LEC)
		{
		    if (ports_info[port-1].echocan_enabled==0)
		    {
		    	card_channel = dg_GetRelativeChannelNumber(port);

		    	sm->Cards[card-1].ec[card_channel-1] = (taps<<4)+1;//taps(1-6) + enable(1)

		    	write_debug("dg_EnableEchoCancelation: Setting echo by software to %d(%x) - card %d, card_channel %d", taps, sm->Cards[card-1].ec[card_channel-1], card, card_channel);

				ports_info[port-1].echocan_enabled=1;

				return DG_EXIT_SUCCESS;
		    }
		    else
		    	return DG_EXIT_SUCCESS;
		}
		else
			if (type == ECHO_HW_DSP)
				write_debug("dg_EnableEchoCancelation: Setting echo by hardware to %d - port %d", taps, port);
			else
				return DG_ERROR_PARAM_OUTOFRANGE;
#endif//#ifdef K_ECHO

	if ((dg_GetPortCardType(port) == VBE13060PCI) || (dg_GetPortCardType(port) == VBE13060PCI_R))
	{
		//E1 cards full-model with 60 channels does not support echo cancelation
		if (sm->Cards[card-1].numchannels>30)
			return DG_FEATURE_NOT_SUPPORTED;
	}

    if (ports_info[port-1].echocan_enabled==0)
    {
    	write_debug("dg_EnableEchoCancelation: Setting echo by hardware to %d - port %d", taps, port);

		tx_command_e1.command = CMD_ECHO;
		tx_command_e1.port_or_card = ASSUME_PORT;
		tx_command_e1.port = port - 1;
		tx_command_e1.param1 = (unsigned char)port - 1;
		tx_command_e1.param2 = ECHO_ALLOC;	//On
		tx_command_e1.param3 = (unsigned char)taps;	//On
		write_generic_command(&tx_command_e1);

		if (dg_GetPortCardType(port) == DGV_2E1F || dg_GetPortCardType(port) == DGV_1E1F)
		{
			//write_debug("dg_EnableEchoCancelation: port_or_card: %d, port: %d, param1: %d, param2: %d, param3: %d", tx_command_e1.port_or_card, tx_command_e1.port, tx_command_e1.param1, tx_command_e1.param2, tx_command_e1.param3);
		}
		else
		{
			/* check if it'll training*/
			if (dg_GetCardInterface(card) == DG_DIGITAL_INTERFACE)
				if (training>0 && training<4000)
				{
					tx_command_e1.command = CMD_ECHO;
					tx_command_e1.port_or_card = ASSUME_PORT;
					tx_command_e1.port = port - 1;
					tx_command_e1.param1 = (unsigned char)port - 1;
					tx_command_e1.param2 = ECHO_TRAINING;	//On
					tx_command_e1.param3 = (unsigned char)(training >> 8);	//On
					tx_command_e1.param4 = (unsigned char)(training & 0xff);	//On
					write_generic_command(&tx_command_e1);
				}
				else
					return DG_ERROR_PARAM_OUTOFRANGE;

			tx_command_e1.command = CMD_ECHO;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = port - 1;
			tx_command_e1.param1 = (unsigned char)port - 1;
			tx_command_e1.param2 = ECHO_ADAPT;	//On
			tx_command_e1.param3 = 1;	//On
			write_generic_command(&tx_command_e1);
		}

		ports_info[port-1].echocan_enabled=1;
    }

    if (dg_GetCardInterface(card) != DG_DIGITAL_INTERFACE)
		if (ports_info[port-1].echocan_enabled)
			if ((nlp >= 0) && (nlp <= 3))
			{
				tx_command_e1.command = CMD_ECHO;
				tx_command_e1.port_or_card = ASSUME_PORT;
				tx_command_e1.port = port - 1;
				tx_command_e1.param1 = (unsigned char)port - 1;
				tx_command_e1.param2 = ECHO_NLP;
				tx_command_e1.param3 = (unsigned char)nlp;
				write_generic_command(&tx_command_e1);

				write_debug("dg_EnableEchoCancelation: Setting NLP to %d - port %d", nlp, port);
			}
			else
				return DG_ERROR_PARAM_OUTOFRANGE;

    return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// Habilita/Desabilita a adaptao dos coeficientes do cancelamento de eco
//----------------------------------------------------------------
//short WCDECL dg_SetEchoCancelationAdapt(short port, short adapt);Before DGV_2E1F/DGV_1E1F
short WCDECL dg_SetEchoCancelationAdapt(short port, short subcommand, short param1, short param2)
{
    dg_cmd_tx tx_command_e1;
    short card;
    double dTemp;
    int nTemp;

    //check driver enabled
    if (!FDriverEnabled)
    	return DG_ERROR_DRIVER_CLOSED;

    //check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

    if (dg_GetPortCardType(port) == DGV_2E1F || dg_GetPortCardType(port) == DGV_1E1F)
    {
		tx_command_e1.param4 = 0;							//default value

    	switch (subcommand)
    	{
    		case ECHO_FREE:									//not used
    			return DG_ERROR_PARAM_OUTOFRANGE;
			case ECHO_ALLOC_DEFAULT:
			case ECHO_ALLOC:
				if (param1 < 1 || param1 > 6)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//TAPS
				break;
			case ECHO_ADAPT:
			case ECHO_RESET:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECHO_TRAINING:								//not used
				return DG_ERROR_PARAM_OUTOFRANGE;
			case ECHO_NLP:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECO_NLP_MODE:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Zarlink NLP (Advanced) or Default NLP - (1/0)
				break;
			case ECO_NOISEINJ:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECO_TONEDETECT:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECO_G165:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECO_NB:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECO_OFFSET:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECO_MUTE:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				if (param2 < 0 || param2 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				tx_command_e1.param4 = param2;				//Rin/Rout or Sin/Sout - (1/0)
				break;
			case ECO_MU_PROF_FD:
			case ECO_MU_PROF_NS:
				tx_command_e1.param3 = param1;				//0 - 65535
				break;
			case ECO_MU_PROF_SSC:
			case ECO_SUPDEC:
			case ECO_SLOW:
				if (param1 < 0 || param1 > 7)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//0 - 7
				break;
			case ECO_INSTABDETECT:
				if (param1 < 0 || param1 > 1)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Enable/Disable - (1/0)
				break;
			case ECO_DTDT:
			case ECO_NLPTHR:
				if (param1 < -90 || param1 > 0)
					return DG_ERROR_PARAM_OUTOFRANGE;

				if (param1 == 0)
				{
					tx_command_e1.param3 = 0x7f;
					tx_command_e1.param4 = 0xff;
					break;
				}

				dTemp = (param1/20);
				dTemp = (32768 * pow(10,dTemp));
				nTemp = (int)floor(dTemp);
				tx_command_e1.param3 = (nTemp >> 8)&&0xff;	//NLPTHR - (-90dB/0dB)
				tx_command_e1.param4 = (nTemp)&&0xff;
				break;
			case ECO_MU:
				tx_command_e1.param3 = param1;				//Adaptation step size (MU1) - (0x00/0xff)
				tx_command_e1.param4 = param2;				//Adaptation step size (MU2) - (0x00/0xff)
				break;
			case ECO_GAIN:
				switch (param1)
				{
					case SIN:
					case SOUT:
					case RIN:
					case ROUT:
						break;
					default:
						return DG_ERROR_PARAM_OUTOFRANGE;
				}

				if (param2 < 0 || param2 > 7)
					return DG_ERROR_PARAM_OUTOFRANGE;

				tx_command_e1.param3 = param1;				//Chip port (SIN, SOUT, RIN and ROUT)
				tx_command_e1.param4 = param2;				//Gain (-12dB to +9dB - step 3dB)
				break;
			case ECO_REG_READ:
				tx_command_e1.param3 = param1;				//Register
				break;
			case ECO_REG_WRITE:
				tx_command_e1.param3 = param1;				//Register
				tx_command_e1.param4 = param2;				//Data
				break;
			case ECO_RST_DEFAULT:
				break;
    	} //switch (subcommand)

		if (ports_info[port-1].echocan_enabled)
		{
			tx_command_e1.command = CMD_ECHO;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = port - 1;
			tx_command_e1.param1 = (unsigned char)port - 1;
			tx_command_e1.param2 = subcommand;
			write_generic_command(&tx_command_e1);
		}
		else
			return DG_FEATURE_NOT_SUPPORTED;
    }
    else
    {
		if ((dg_GetPortCardType(port) == VBE13060PCI) || (dg_GetPortCardType(port) == VBE13060PCI_R))
		{
			card = dg_GetCardNumber(port);
			//E1 cards full-model with 60 channels does not support echo cancelation
			if (sm->Cards[card-1].numchannels>30)
				return DG_FEATURE_NOT_SUPPORTED;
		}

		if (ports_info[port-1].echocan_enabled)
		{
			tx_command_e1.command = CMD_ECHO;
			tx_command_e1.port_or_card = ASSUME_PORT;
			tx_command_e1.port = port - 1;
			tx_command_e1.param1 = (unsigned char)port - 1;
			tx_command_e1.param2 = ECHO_ADAPT;
			tx_command_e1.param3 = (unsigned char)subcommand;	//On/Off
			write_generic_command(&tx_command_e1);
		}

		switch (subcommand)
		{
			case 3:
				if (ports_info[port-1].echocan_enabled)
				{
					tx_command_e1.command = CMD_ECHO;
					tx_command_e1.port_or_card = ASSUME_PORT;
					tx_command_e1.port = port - 1;
					tx_command_e1.param1 = (unsigned char)port - 1;
					tx_command_e1.param2 = ECHO_TRAINING;	//On
					tx_command_e1.param3 = 100 >> 8;	//On
					tx_command_e1.param4 = 100 & 0xff;	//On
					write_generic_command(&tx_command_e1);

					tx_command_e1.command = CMD_ECHO;
					tx_command_e1.port_or_card = ASSUME_PORT;
					tx_command_e1.port = port - 1;
					tx_command_e1.param1 = (unsigned char)port - 1;
					tx_command_e1.param2 = ECHO_ADAPT;
					tx_command_e1.param3 = (unsigned char)subcommand;	//On/Off
					write_generic_command(&tx_command_e1);
				}
				break;
			case 4:
				if (ports_info[port-1].echocan_enabled)
				{
					tx_command_e1.command = CMD_ECHO;
					tx_command_e1.port_or_card = ASSUME_PORT;
					tx_command_e1.port = port - 1;
					tx_command_e1.param1 = (unsigned char)port - 1;
					tx_command_e1.param2 = ECHO_TRAINING;	//On
					tx_command_e1.param3 = 100 >> 8;	//On
					tx_command_e1.param4 = 100 & 0xff;	//On
					write_generic_command(&tx_command_e1);
				}
				break;
		}
    }

    return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// Desabilita Cancelamento de Echo
//----------------------------------------------------------------
short WCDECL dg_DisableEchoCancelation(short port)
{
	dg_cmd_tx tx_command_e1;

#ifdef K_ECHO
		short card;
		short card_channel;
#endif//#ifdef K_ECHO

	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

#ifdef K_ECHO
		if (ports_info[port-1].echocan_type == ECHO_SW_LEC)
		{
		    if (ports_info[port-1].echocan_enabled)
		    {
		    	card = dg_GetCardNumber(port);
		    	card_channel = dg_GetRelativeChannelNumber(port);

		        if ((sm->Cards[card-1].ec[card_channel-1]&0xf) == 2)
		        {
		            sm->Cards[card-1].ec[card_channel-1] = (sm->Cards[card-1].ec[card_channel-1]&0xf0)+3;
		    		write_debug("dg_DisableEchoCancelation: Disabling echo by software - card %d, card_channel %d", card, card_channel);
		    	}
		    	else
		    		write_debug("dg_DisableEchoCancelation: Echo by software is not running on card %d, card_channel %d", card, card_channel);

				ports_info[port-1].echocan_enabled=0;

				return DG_EXIT_SUCCESS;
		    }
		    else
		    	return DG_EXIT_SUCCESS;
		}
		else
			if (ports_info[port-1].echocan_type == ECHO_HW_DSP)
				write_debug("dg_DisableEchoCancelation: Disabling echo by hardware - port %d", port);
			else
				return DG_ERROR_PARAM_OUTOFRANGE;
#endif//#ifdef K_ECHO

	tx_command_e1.command = CMD_ECHO;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = ECHO_FREE;	//Off
	write_generic_command(&tx_command_e1);

    ports_info[port-1].echocan_enabled=0;


	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// Habilta Filtro de DTMF/425
// Nao pode ser utilizado com GSM!!!1
//----------------------------------------------------------------
short WCDECL dg_EnableDTMFFilter(short port)
{
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;
	//
	tx_command_e1.command = CMD_FILTER;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = 1;//On
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;

}
//----------------------------------------------------------------
// Desabilta AGC
//----------------------------------------------------------------
short WCDECL dg_DisableDTMFFilter(short port)
{
	dg_cmd_tx tx_command_e1;

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;
	//
	tx_command_e1.command = CMD_FILTER;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = 0;	//OFF
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// Read CMD Counter
// and reset all
// card - 1 a n
//----------------------------------------------------------------
short WCDECL dg_ReadCmdCounter(short card)
{

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 || card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

#ifdef __LINUX__

	//TODO: Implementar leitura de comandos em linux
	return DG_EXIT_SUCCESS;

#else
	BZERO (kpCall);
	kpCall.hKernelPlugIn = kernelPlugIn.hKernelPlugIn;
	kpCall.dwMessage = VPPCI_IOCTL_CMDCOUNTER;
	kpCall.pData = (void *)(card);
	WD_KernelPlugInCall(hWinDriver, &kpCall);	
	return (short)kpCall.dwResult;
#endif
}

//-------------------------------------------------------------------
// H100 - Local bridge connect two ports audio without h100
// port1 and port2 must be in the same board
//-------------------------------------------------------------------
short WCDECL dg_LocalBridgeConnect(short port1, short port2)
{
	dg_cmd_tx tx_command_e1;
	short card;

	//check if port1 and port2 must be in the same board
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (dg_GetCardNumber(port1)!=dg_GetCardNumber(port2))
		return DG_ERROR_PORT_OUT_OF_RANGE;

	card = dg_GetCardNumber(port1);

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	//change port1 and port2 to relative number to card
	port1 = dg_GetRelativeChannelNumber(port1);
	port2 = dg_GetRelativeChannelNumber(port2);

	tx_command_e1.command = CMD_SETBUSCONNECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);

	tx_command_e1.param1 = RX_TX;
	tx_command_e1.param2 = (unsigned char)port1-1;
	tx_command_e1.param3 = (unsigned char)port2-1;
	tx_command_e1.param4 = ON;
	tx_command_e1.param5 = ON;
	write_generic_command(&tx_command_e1);

	//change port1 and port2 to relative number to card
	tx_command_e1.command = CMD_SETBUSCONNECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);

	tx_command_e1.param1 = RX_TX;
	tx_command_e1.param2 = (unsigned char)port2-1;
	tx_command_e1.param3 = (unsigned char)port1-1;
	tx_command_e1.param4 = ON;
	tx_command_e1.param5 = ON;
	write_generic_command(&tx_command_e1);


	return DG_EXIT_SUCCESS;


}
//-------------------------------------------------------------------
// H100 - Local bridge connect two ports audio without h100
// port1 and port2 must be in the same board
//-------------------------------------------------------------------
short WCDECL dg_LocalBridgeDisconnect(short port1, short port2)
{

	dg_cmd_tx tx_command_e1;
	short card;

	//check if port1 and port2 must be in the same board
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (dg_GetCardNumber(port1)!=dg_GetCardNumber(port2))
		return DG_ERROR_PORT_OUT_OF_RANGE;

	card = dg_GetCardNumber(port1);

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;

	//change port1 and port2 to relative number to card
	port1 = dg_GetRelativeChannelNumber(port1);
	port2 = dg_GetRelativeChannelNumber(port2);

	tx_command_e1.command = CMD_SETBUSCONNECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);

	tx_command_e1.param1 = RX_TX;
	tx_command_e1.param2 = (unsigned char)port1-1;
	tx_command_e1.param3 = (unsigned char)port2-1;
	tx_command_e1.param4 = OFF;
	tx_command_e1.param5 = OFF;
	write_generic_command(&tx_command_e1);

	tx_command_e1.param2 = (unsigned char)port2-1;
	tx_command_e1.param3 = (unsigned char)port1-1;

	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;

}
//-------------------------------------------------------------------
// H100 - Reset to default E1 -> DSP connection
//-------------------------------------------------------------------
short WCDECL dg_h100_SetDefault(short card)
{

	dg_cmd_tx tx_command_e1;

    if (!FDriverEnabled)
            return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;


	tx_command_e1.command = CMD_SETBUSCONNECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);

	tx_command_e1.param1 = H100_DEFAULT;
	tx_command_e1.param2 = 0;
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = ON;

	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;

}

//-------------------------------------------------------------------
// H100 - Disconnect all ports from H100
//-------------------------------------------------------------------
short WCDECL dg_h100_DisconnectAll(short card)
{
	dg_cmd_tx tx_command_e1;

    if (!FDriverEnabled)
            return DG_ERROR_DRIVER_CLOSED;

	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
		return DG_FEATURE_NOT_SUPPORTED;


	tx_command_e1.command = CMD_SETBUSCONNECTION;
	//set values
	tx_command_e1.port_or_card = ASSUME_CARD;
	tx_command_e1.port = (char)(card);

	tx_command_e1.param1 = H100_RESET;
	tx_command_e1.param2 = 0;
	tx_command_e1.param3 = 0;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = ON;

	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------
// H100 - Alloc position to port into H100
//-------------------------------------------------------------------
short WCDECL dg_h100_AllocPort(short port)
{
	short temp_port;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	ports_info[port-1].h100info.ChPos = ((port * 2) - 1) + 2047;
	ports_info[port-1].h100info.DSPPos = (port * 2) + 2047;

	ports_info[port-1].h100info.ChFrame = (int)(ports_info[port-1].h100info.ChPos / 128);
	ports_info[port-1].h100info.DSPFrame = (int)(ports_info[port-1].h100info.DSPPos / 128);

	ports_info[port-1].h100info.ChSlot = ports_info[port-1].h100info.ChPos % 128;
	ports_info[port-1].h100info.DSPSlot = ports_info[port-1].h100info.DSPPos % 128;

	temp_port = dg_GetRelativeChannelNumber(port);

	if (temp_port >=1 && temp_port <= 15)
		ports_info[port-1].h100info.PortRelativeE1 = (unsigned char)temp_port;
	else
		if (temp_port >=16 && temp_port <= 30)
			ports_info[port-1].h100info.PortRelativeE1 = temp_port + 1;
		else
			if (temp_port >=31 && temp_port <= 45)
				ports_info[port-1].h100info.PortRelativeE1 = temp_port + 2;
			else
				if (temp_port >=46 && temp_port <= 60)
				ports_info[port-1].h100info.PortRelativeE1 = temp_port + 3;

	//A partir da 4.0.4 o PortRelativeDSP deve ser configurado do canal 128 ate o 167, sequencial
	//portanto, e simplesmente a porta + 127
	ports_info[port-1].h100info.PortRelativeDSP = temp_port + 127;

	ports_info[port-1].h100info.CardRelative = (unsigned char)dg_GetCardNumber(port);
	
	return DG_EXIT_SUCCESS;

}
//-------------------------------------------------------------------
// H100 - enable port into H100
//-------------------------------------------------------------------
short WCDECL dg_h100_EnablePort(short port)
{
	short ret = DG_EXIT_SUCCESS;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//call function to fill port structure
	dg_h100_AllocPort(port);


	//desconectar LOCAL_LOCAL
	ret = dg_DisconnectBus(ports_info[port-1].h100info.CardRelative,
							LOCAL_LOCAL,
							ports_info[port-1].h100info.PortRelativeE1, 
							ports_info[port-1].h100info.PortRelativeDSP, 
							0);

	ret = dg_DisconnectBus(ports_info[port-1].h100info.CardRelative,
							LOCAL_LOCAL,
							ports_info[port-1].h100info.PortRelativeDSP, 
							ports_info[port-1].h100info.PortRelativeE1, 
							0);


	//conecta E1 no H100
	ret = dg_ConnectBus(ports_info[port-1].h100info.CardRelative, 
						LOCAL_H100, 
						ports_info[port-1].h100info.PortRelativeE1, 
						ports_info[port-1].h100info.ChFrame, 
						ports_info[port-1].h100info.ChSlot);
	//conecta DSP no H100
    ret = dg_ConnectBus(ports_info[port-1].h100info.CardRelative, 
						LOCAL_H100, 
						ports_info[port-1].h100info.PortRelativeDSP , 
						ports_info[port-1].h100info.DSPFrame, 
						ports_info[port-1].h100info.DSPSlot);


	//Essas duas proximas funcoes o Frame/SLot e a origem e 
	//PortRelativeXX e o destino ja que e no sentido H100_LOCAL

	//Ligacao do DSPFrame/DSPSlot no PortRelativeE1 (H100_LOCAL)
	ret = dg_ConnectBus(ports_info[port-1].h100info.CardRelative, 
						H100_LOCAL, 
						ports_info[port-1].h100info.PortRelativeE1 , 
						ports_info[port-1].h100info.DSPFrame, 
						ports_info[port-1].h100info.DSPSlot);

	//Ligacao do ChFrame/ChSlot no PortRelativeDSP (H100_LOCAL)
	ret = dg_ConnectBus(ports_info[port-1].h100info.CardRelative, 
						H100_LOCAL, 
						ports_info[port-1].h100info.PortRelativeDSP, 
						ports_info[port-1].h100info.ChFrame, 
						ports_info[port-1].h100info.ChSlot);

	//set port as enabled h100
	ports_info[port-1].h100info.h100_enabled = 1;

	return ret;
}

//-------------------------------------------------------------------
// H100 - Devolve primeira porta livre
//-------------------------------------------------------------------
short WCDECL dg_h100_GetFreePortByRange(short port_start, short port_end)
{
	short i;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;


	if (port_start > port_end)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port_start <1 || port_end > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//TODO: Implentar metodos de desconexao DisconnectBus

    for (i=port_start;i<=port_end;i++)
	{
      if (dg_GetPortStatus(i) == spNone)
	  {
        return i;
	  }
	}

	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// H100 -Conecta duas portas half duplex
//----------------------------------------------------------------
short WCDECL dg_h100_HalfDuplexConnect(short port_source, short port_target)
{
	short ret;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;


	if (!ports_info[port_source-1].h100info.h100_enabled || !ports_info[port_target-1].h100info.h100_enabled)
		return DG_ERROR_RESOURCE_UNAVAILABLE;


	//ret = dg_h100_AllocPort(port_source);
    //ret = dg_h100_AllocPort(port_target);

	//desconectar H100_LOCAL do port_target, ou seja, desconectar DSP do E1 
    ret = dg_DisconnectBus(ports_info[port_target-1].h100info.CardRelative,
						H100_LOCAL, 
						ports_info[port_target-1].h100info.PortRelativeE1,
						ports_info[port_target-1].h100info.DSPFrame, 
						ports_info[port_target-1].h100info.DSPSlot);


	//conectar H100_LOCAL do E1 (ChSlot) source para o E1 (CHSlot) target
    ret = dg_ConnectBus(ports_info[port_target-1].h100info.CardRelative,
						H100_LOCAL, 
						ports_info[port_target-1].h100info.PortRelativeE1,
						ports_info[port_source-1].h100info.ChFrame, 
						ports_info[port_source-1].h100info.ChSlot);

	return port_source;
}
//----------------------------------------------------------------
// H100 -Conecta duas portas full duplex
//----------------------------------------------------------------
short WCDECL dg_h100_FullDuplexConnect(short port1, short port2)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (!ports_info[port1-1].h100info.h100_enabled || !ports_info[port2-1].h100info.h100_enabled)
		return DG_ERROR_RESOURCE_UNAVAILABLE;

    dg_h100_HalfDuplexConnect(port1, port2);
    return dg_h100_HalfDuplexConnect(port2, port1);

}
//----------------------------------------------------------------
// H100 - Desconecta duas portas half duplex
//----------------------------------------------------------------
short WCDECL dg_h100_HalfDuplexDisconnect(short port_source, short port_target)
{
	short ret;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	//desconectar H100_LOCAL do E1 (ChSlot) source do E1 (CHSlot) target
    ret = dg_DisconnectBus(ports_info[port_target-1].h100info.CardRelative,
						H100_LOCAL, 
						ports_info[port_target-1].h100info.PortRelativeE1,
						ports_info[port_source-1].h100info.ChFrame, 
						ports_info[port_source-1].h100info.ChSlot);


	//conectar H100_LOCAL do port_target, ou seja, conectar DSP no E1 
    ret = dg_ConnectBus(ports_info[port_target-1].h100info.CardRelative,
						H100_LOCAL, 
						ports_info[port_target-1].h100info.PortRelativeE1,
						ports_info[port_target-1].h100info.DSPFrame, 
						ports_info[port_target-1].h100info.DSPSlot);


	return ret;

}
//----------------------------------------------------------------
// H100 - Desconecta duas portas full duplex
//----------------------------------------------------------------
short WCDECL dg_h100_FullDuplexDisconnect(short port1, short port2)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	dg_h100_HalfDuplexDisconnect(port1,port2);

	return dg_h100_HalfDuplexDisconnect(port2,port1);

}

//----------------------------------------------------------------
// habilita/desabilita opcao do crc4
//----------------------------------------------------------------
short WCDECL dg_SetE1CRC4Option(short card, short e1, short enable)
{
	if (card < 1 && card > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

	if (e1 != CFG_FRAMER_E1_A && e1 != CFG_FRAMER_E1_B)
		return DG_ERROR_PARAM_OUTOFRANGE;
	
	switch(enable){
		case 0:
			write_debug("dg_SetE1CRC4Option ->CFG_FRAMER_CRC4_OFF");
			return dg_send_command(card,CMD_FRAMER,CFG_FRAMER_WRITE,e1,CFG_FRAMER_CRC4_PAGE,
										CFG_FRAMER_CRC4_ADDR,CFG_FRAMER_CRC4_OFF);
		break;

		case 1 :
			write_debug("dg_SetE1CRC4Option ->CFG_FRAMER_CRC4_ON");
			return dg_send_command(card,CMD_FRAMER,CFG_FRAMER_WRITE,e1,CFG_FRAMER_CRC4_PAGE,
										CFG_FRAMER_CRC4_ADDR,CFG_FRAMER_CRC4_ON);
		break;

		case 2 :
			write_debug("dg_SetE1CRC4Option ->CFG_FRAMER_AIS_ON");
			return dg_send_command(card,CMD_FRAMER,CFG_FRAMER_WRITE,e1,CFG_FRAMER_CRC4_PAGE,
										CFG_FRAMER_CRC4_ADDR,CFG_FRAMER_AIS_ON);
		break;

		case 3 :
			write_debug("dg_SetE1CRC4Option ->CFG_FRAMER_CRC4_AIS_ON");
			return dg_send_command(card,CMD_FRAMER,CFG_FRAMER_WRITE,e1,CFG_FRAMER_CRC4_PAGE,
										CFG_FRAMER_CRC4_ADDR,CFG_FRAMER_CRC4_AIS_ON);
		break;

	}


	/*if (enable)
		return dg_send_command(card,CMD_FRAMER,CFG_FRAMER_WRITE,e1,CFG_FRAMER_CRC4_PAGE,
										CFG_FRAMER_CRC4_ADDR,CFG_FRAMER_CRC4_ON);
	else
		return dg_send_command(card,CMD_FRAMER,CFG_FRAMER_WRITE,e1,CFG_FRAMER_CRC4_PAGE,
										CFG_FRAMER_CRC4_ADDR,CFG_FRAMER_CRC4_OFF);
	*/ 
}


#ifdef CCS_ENABLE

//----------------------------------------------------------------
// Enables CCS Framer control to use with ISDN protocol
// *** You must restart Voicerlib to restore R2 mode 
//----------------------------------------------------------------
short WCDECL dg_EnableCCSMode(short card, short framer)
{

    short ret = DG_EXIT_SUCCESS;

    if (card < 1 && card > nCardsCount)
        return DG_ERROR_CARD_OUT_OF_RANGE;

    if (framer != CFG_FRAMER_E1_A && framer != CFG_FRAMER_E1_B)
        return DG_ERROR_PARAM_OUTOFRANGE;

    //check if it's 1 span board and trying to set framer B
    if (sm->Cards[card-1].numchannels==30 && framer == CFG_FRAMER_E1_B)
            return DG_FEATURE_NOT_SUPPORTED;

    if (sm->Cards[card-1].ccs_enabled[framer-1])
           return DG_ERROR_THREAD_ALREADY_RUNNING;

    //allocates CCS shared memory if its not allocated yet
    //if the shared memory was allocated before, returns DG_EXIT_SUCCESS
    ret = InitCCSSharedMem();
    if (ret!=DG_EXIT_SUCCESS)
        return ret;


    write_debug("(card: %d) enabing CMD_CCS in framer %d", card, framer);
	if( sm->Cards[card-1].ccs_enabled[framer-1] == 0)
	{
		if (dg_send_command(card,CMD_CCS,framer,DG_ENABLE,0,0,0)==DG_EXIT_SUCCESS)
		{
	        
			//ccs signalling buffer
	        write_debug("(card: %d) enabing CMD_CCS in framer %d step 1", card, framer);
			ccsm->Cards[card-1].Fifo_CCS_Rx[framer-1].wp = 0;
			ccsm->Cards[card-1].Fifo_CCS_Rx[framer-1].rp = 0;
			ccsm->Cards[card-1].Fifo_CCS_Rx[framer-1].partial = 0;
			//
			ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp = 0;
			ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].rp = 0;
			ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].partial = 0;

			ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].last_buffer = CCS_BUF1;

	        write_debug("(card: %d) enabing CMD_CCS in framer %d step 2", card, framer);

			sm->Cards[card-1].ccs_enabled[framer-1] = 1;
		
			//todo:
			// 
			//start thread of the card
			if (thread_ccs_id[card-1]<=0)
			{
				if (digivoice_beginthread(&thread_ccs_id[card-1],ccs_thread,0,&event_card[card-1])!=0)
				{
					write_debug("ccs thread: DG_ERROR_COULD_NOT_CREATE_THREAD");
					return DG_ERROR_COULD_NOT_CREATE_THREAD;
				}
			}
			else {
				write_debug("(card: %d)ccs thread: Already created for framer %d.", card, framer);
			}

	        write_debug("(card: %d) enabing CMD_CCS in framer %d step 3", card, framer);
			return DG_EXIT_SUCCESS;
		}
		else
		{
			write_debug("(card: %d) enabing CMD_CCS FAILURE in framer %d step 4", card, framer);
			return DG_EXIT_FAILURE;
		}
	}
    return ret;    
}

//------------------------------------------------------------------------------
// Similar to playbuffer, this functions put ccs data frame into D-channel
//------------------------------------------------------------------------------
short WCDECL dg_SendCCSBuffer(short card, short framer, void *ccs_data, short ccs_size, int *remaining_size)
{
    //char ccs_tx[CCS_DATA_SIZE+1];
    short local_rp;

    char szTemp[100];
    char szLinha[CCS_DATA_SIZE*4];
    short temp;

    char *p_data;


  	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

    if (!sm->Cards[card-1].ccs_enabled[framer-1])
        return DG_ERROR_RESOURCE_UNAVAILABLE;

    if (ccs_size > CCS_DATA_SIZE)
        return DG_ERROR_PARAM_OUTOFRANGE;

    //insert data into FIFO
    local_rp = ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].rp;

    if (ccs_size>0)
    {
        //adding 2 bytes to fit CRC
 //..       ccs_size += 2;

        // check space availability
        if (local_rp > ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp)
        {
            if (ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp==(local_rp-2))
            {
                return DG_ERROR_PLAY_BUFFER_FULL;
            }
        }
        else
            if (ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp > local_rp)
            {
                if (((CCS_LINES)- ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp )+local_rp == 2)
                {
                    return DG_ERROR_PLAY_BUFFER_FULL;
                }
            }

        write_debug(">TX CCS Card %d Frame %d - rp=%d wp=%d", card, framer, local_rp, ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp);

        //send frame_data - 
        p_data = (char *)ccs_data;
        memcpy(&ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].data[ ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp ],   
                 p_data  ,ccs_size);

        szTemp[0]=0;
        szLinha[0]=0;
        for (temp=0;temp<ccs_size;temp++)
        {
            sprintf(szTemp,"%02x ",ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].data[ ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp ][temp]&0xff);
            strcat(szLinha,szTemp);
        }
        write_debug(">TX CCS Card %d Frame %d Size: %d Data: %s", card, framer,ccs_size,szLinha);

        //send frame size
        ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].frame_size[ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp] = ccs_size;

        //inc pointer
        ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp++;
        if (ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp>=CCS_LINES) 
        {
            ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp = 0;
        }
    }

    // function to retrieve free buffer space
    if (remaining_size!=NULL) 
    {
        if (local_rp > ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp)
            *(int *)remaining_size = (local_rp - ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp);
        else
            *(int *)remaining_size = (CCS_LINES-ccsm->Cards[card-1].Fifo_CCS_Tx[framer-1].wp)+local_rp;

    }

    return DG_EXIT_SUCCESS;
}
#endif

//------------------------------------------------------------------------------
// Enable Selected Frame
// Call after synchronization process
//------------------------------------------------------------------------------
short WCDECL dg_EnableFramer(short card, short framer)
{
    if (card < 1 && card > nCardsCount)
        return DG_ERROR_CARD_OUT_OF_RANGE;

    //dont send error
    if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
        return DG_EXIT_SUCCESS;

    if (framer != CFG_FRAMER_E1_A && framer != CFG_FRAMER_E1_B)
        return DG_ERROR_PARAM_OUTOFRANGE;

    /* check if it's 1 span board and trying to set framer B */
    if (sm->Cards[card-1].numchannels==30 && framer == CFG_FRAMER_E1_B)
            return DG_FEATURE_NOT_SUPPORTED;

    return dg_send_command(card,CMD_LIU,3,framer,DG_ENABLE,0,0);
}

//------------------------------------------------------------------------------
// Disable Selected Frame
// Call after synchronization process
//------------------------------------------------------------------------------
short WCDECL dg_DisableFramer(short card, short framer)
{
    if (card < 1 && card > nCardsCount)
        return DG_ERROR_CARD_OUT_OF_RANGE;

    //dont send error
    if (dg_GetCardInterface(card)!=DG_DIGITAL_INTERFACE)
        return DG_EXIT_SUCCESS;

    if (framer != CFG_FRAMER_E1_A && framer != CFG_FRAMER_E1_B)
        return DG_ERROR_PARAM_OUTOFRANGE;


    /* check if it's 1 span board and trying to set framer B */
    if (sm->Cards[card-1].numchannels==30 && framer == CFG_FRAMER_E1_B)
            return DG_FEATURE_NOT_SUPPORTED;

    return dg_send_command(card,CMD_LIU,3,framer,DG_DISABLE,0,0);

}

//-----------------------------------------------------------------------------------------------
// SetTwist configures frequencies "discriminators" in dB
// twist1 - difference between freq1 and freq2 (DTMF pair) - less means more strict - default 9dB
// twist2 - difference between freq1/freq2 and freq3 - less means more relaxed - default 15dB
// values of twists can be 0,3,6,9,12,.....24,27 and so on
//-----------------------------------------------------------------------------------------------
short WCDECL dg_SetTwist(short port, short twist1, short twist2)
{
	dg_cmd_tx tx_command_e1;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//ranges
	if (twist1 < 0 || twist1> 42)
		return DG_ERROR_PARAM_OUTOFRANGE;

	if (twist2 < 0 || twist2> 42)
		return DG_ERROR_PARAM_OUTOFRANGE;


	tx_command_e1.command = CMD_TWIST;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = port - 1;
	tx_command_e1.param1 = (unsigned char)port - 1;
	tx_command_e1.param2 = (unsigned char)(twist1/3);
	tx_command_e1.param3 = (unsigned char)(twist2/3);
	write_generic_command(&tx_command_e1);

	return DG_EXIT_SUCCESS;


}

//-----------------------------------------------------------------------------------------------
// SetRing  : Configures ringtype and start/stop ring generation(fxs cards)
// enable   - (0) stop ring / (1) start ring
// ringtype - not used yet
//-----------------------------------------------------------------------------------------------
short WCDECL dg_SetRing(short Port, short Enable, short RingType)
{
	dg_cmd_tx tx_command_e1;
	
	//check driver enabled
	if (!FDriverEnabled)
    	return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (Port < 1 || Port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

	if (Enable != DG_ENABLE && Enable != DG_DISABLE)
		return DG_ERROR_PARAM_OUTOFRANGE;

    if (RingType < 1 || RingType > 3)
		return DG_ERROR_PARAM_OUTOFRANGE;

	tx_command_e1.command = CMD_LINE;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = Port-1;
	tx_command_e1.param1 = (unsigned char)Port-1;
	
	if (Enable)
		tx_command_e1.param2 = RING_START;
	else	
		tx_command_e1.param2 = RING_STOP;
		
	tx_command_e1.param3 = (unsigned char)RingType;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&(tx_command_e1));

	return DG_EXIT_SUCCESS;	
}	

//-----------------------------------------------------------------------------------------------
// SetFlash  : Configures the flash time(fxs cards)
// flashtime - time of flash(ms)
//-----------------------------------------------------------------------------------------------
short WCDECL dg_SetFlash(short Port, short FlashMinTime, short FlashMaxTime)
{
	dg_cmd_tx tx_command_e1;
	
	//check driver enabled
	if (!FDriverEnabled)
    	return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (Port < 1 || Port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

    if (FlashMinTime < 50 || FlashMinTime > 4000)
		return DG_ERROR_PARAM_OUTOFRANGE;

    if (FlashMaxTime < 50 || FlashMaxTime > 4000)
		return DG_ERROR_PARAM_OUTOFRANGE;
		
	if (FlashMinTime > FlashMaxTime) 
		return DG_ERROR_INVALIDPARAM;

	tx_command_e1.command = CMD_LINE;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = Port-1;
	tx_command_e1.param1 = (unsigned char)Port-1;
	tx_command_e1.param2 = FLASH_MIN;	
	tx_command_e1.param3 = (char)(FlashMinTime >> 8);
	tx_command_e1.param4 = (char)(FlashMinTime & 0xff);
	tx_command_e1.param5 = 0;
	write_generic_command(&(tx_command_e1));
	
	tx_command_e1.command = CMD_LINE;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = Port-1;
	tx_command_e1.param1 = (unsigned char)Port-1;	
	tx_command_e1.param2 = FLASH_MAX;	
	tx_command_e1.param3 = (char)(FlashMaxTime >> 8);
	tx_command_e1.param4 = (char)(FlashMaxTime & 0xff);
	tx_command_e1.param5 = 0;
	write_generic_command(&(tx_command_e1));

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// This functions creates the threads that manage all ChannelBank FXS ports
// protocol (r2)
//----------------------------------------------------------------
short WCDECL dg_CreateCBThread(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].e1_info.thread_id>0)
				return DG_ERROR_THREAD_ALREADY_RUNNING;

	//this functions is avaiable only for E1 cards
	if ((dg_GetPortCardType(port) != VBE13060PCI) && (dg_GetPortCardType(port) != VBE13030PCI) && 
		(dg_GetPortCardType(port) != VBE13060PCI_R) && (dg_GetPortCardType(port) != VBE16060PCI) &&
		(dg_GetPortCardType(port) != VBE16060PCI_R) && 
		(dg_GetPortCardType(port) != VB3030PCIE) && (dg_GetPortCardType(port) != VB6060PCIE) &&
		(dg_GetPortCardType(port) != DGV_1E1F) && (dg_GetPortCardType(port) != DGV_2E1F))
		return DG_FEATURE_NOT_SUPPORTED;

	write_debug("dg_CreateCBThread: Starting configuration - port %d", port);
#ifdef __LINUX__
	//create fifo to e1
	sprintf(ports_info[port-1].e1_info.szFifoToE1,"%s/dg_rxe1_%d",DG_FIFO_PATH,port-1);
	//unlink(ports_info[port-1].e1_info.szFifoToE1);

	mkfifo(ports_info[port-1].e1_info.szFifoToE1, O_RDWR | DG_FIFO_ACCESS_RIGHTS);
	write_debug("dg_CreateCBThread: FIFO CREATED - port %d", port);
	//tries to open fifo
	ports_info[port-1].fifo_to_e1 = open(ports_info[port-1].e1_info.szFifoToE1,O_RDWR/*O_WRONLY*/);
	if (ports_info[port-1].fifo_to_e1<1)
		return DG_ERROR_FIFO_UNAVAILABLE;

	write_debug("CB - create - abrindo %s handle - %x",ports_info[port-1].e1_info.szFifoToE1,ports_info[port-1].fifo_to_e1 );
#endif

#ifdef WIN32

	//TODO - Precisa consistencia

	//uses pipe to communicate
	//create fifo to e1
	sprintf(ports_info[port-1].e1_info.szFifoToE1,"\\\\.\\pipe\\dg_rxe1_%d",port-1);

	//cria evento de notificacao kernelmode->usermode para sinais - comandos da placa
	ports_info[port-1].e1_info.E1Event.hEvent = CreateEvent(NULL,FALSE,FALSE,NULL);
	if (!ports_info[port-1].e1_info.E1Event.hEvent)
		return DG_ERROR_COULD_NOT_CREATE_THREAD;

	ports_info[port-1].e1_info.oOverlapE1.hEvent = ports_info[port-1].e1_info.E1Event.hEvent;

	//create PIPE
	ports_info[port-1].fifo_to_e1 = CreateNamedPipe(ports_info[port-1].e1_info.szFifoToE1,
													PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
													PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,
													PIPE_UNLIMITED_INSTANCES,
													1024,
													1024,
													NMPWAIT_USE_DEFAULT_WAIT,
													NULL);


	ConnectNamedPipe(ports_info[port-1].fifo_to_e1, &ports_info[port-1].e1_info.oOverlapE1);

#endif

	ports_info[port-1].e1_info.port = port;
	//fills default informations about timeouts
	//the default values can be changed with dg_config_e1_handle function
	ports_info[port-1].e1_info.bBlocked = 0;			//desbloqueado
	ports_info[port-1].e1_info.timeout_ocupacao = 7000;  //7s
	ports_info[port-1].e1_info.timeout_retencao = 90000;     // 90s - 
	ports_info[port-1].e1_info.timeout_atendimento = 75000;  // 75s - 75000
	ports_info[port-1].e1_info.timeout_bloqueio_on = 1000;  // 1s - 1000
	ports_info[port-1].e1_info.timeout_bloqueio_off = 2000; // 2s - 2000
	ports_info[port-1].e1_info.timeout_mft = 30000;          // 30s - 30000 TESTE em 70000
	ports_info[port-1].e1_info.timeout_mff = 30000;          // 30s - 30000 TESTE em 70000
	ports_info[port-1].e1_info.category = 1;					//categoria padrao
	ports_info[port-1].e1_info.rx_total_of_digits = 0;			//nao pega nada automaticamente
	ports_info[port-1].e1_info.send_id_digit_pos = 0;
	ports_info[port-1].e1_info.group_b_id = 1;
	ports_info[port-1].e1_info.silence_threshold_signaling = -30;
	ports_info[port-1].e1_info.silence_threshold_after_signaling = -24; 
	ports_info[port-1].e1_info.ring_generate_ringback = 1;			//generates ringback automatically
	ports_info[port-1].e1_info.r2_country = R2_COUNTRY_BR;             //default brazil
	ports_info[port-1].e1_info.sigtype = R2_TYPE_MFC;                  //default MFC
	
	//turn timer off
	SetEnableTimer(&tmr_E1[port-1],FALSE);
	SetEnableTimer(&tmrCallProgress[port-1],FALSE);
	ports_info[port-1].e1_info.enabled = 0;
	write_debug("dg_CreateCBThread: Creating thread - port %d", port);
	//Create E1-R2 protocol thread
	if (digivoice_beginthread(&ports_info[port-1].e1_info.thread_id,Signal_CB_Thread,0,&ports_info[port-1].e1_info)!=0)
	{
			write_debug("dg_CreateCBThread: ERROR_THREAD");
			return DG_ERROR_COULD_NOT_CREATE_THREAD;
	}

#ifdef WIN32
	SetThreadPriority(ports_info[port-1].e1_info.thread_id,THREAD_PRIORITY_NORMAL);
#else
	//TODO: Prioridade de thread em Linux
#endif
	//get port status
	dg_SendR2Command(port,R2_ENABLEDETECTION);	//habilita
	dg_SendR2Command(port, R2_BLOCKED);		//envia bloqueio
	write_debug("dg_CreateCBThread: Created succesfully - port %d", port);
	
	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------------
// This routine configures CB Handle data:
//----------------------------------------------------------------------
short WCDECL dg_ConfigCBThread(short port, short command, int value)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if ((dg_GetPortCardType(port) != VBE13060PCI) && (dg_GetPortCardType(port) != VBE13030PCI) && 
		(dg_GetPortCardType(port) != VBE13060PCI_R) && (dg_GetPortCardType(port) != VBE16060PCI)&&
		(dg_GetPortCardType(port) != VBE16060PCI_R) &&
		(dg_GetPortCardType(port) != VB3030PCIE) && (dg_GetPortCardType(port) != VB6060PCIE) &&
		(dg_GetPortCardType(port) != DGV_1E1F) && (dg_GetPortCardType(port) != DGV_2E1F))
		return DG_FEATURE_NOT_SUPPORTED;

	//verificar constantes
	if (command < E1CFG_SEIZURE_TIMEOUT || command > E1CFG_MAX)
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//the thread was already created
	if (ports_info[port-1].e1_info.thread_id==0)
		return DG_ERROR_THREAD_NOT_RUNNING;

	switch(command)
	{
		case E1CFG_GROUP_II:
			ports_info[port-1].e1_info.category = (char)value;
			break;
		case E1CFG_SEIZURE_TIMEOUT:		//7000ms
			ports_info[port-1].e1_info.timeout_ocupacao = value;
			break;
		case E1CFG_RETENTION_TIMEOUT:	//90000ms
			ports_info[port-1].e1_info.timeout_retencao = value;
			break;
		case E1CFG_ANSWER_TIMEOUT:		//75000ms
			ports_info[port-1].e1_info.timeout_atendimento = value;
			break;
		case E1CFG_BLOCKING_ON:			//1000ms
			ports_info[port-1].e1_info.timeout_bloqueio_on =  value;
			break;
		case E1CFG_BLOCKING_OFF:		//2000ms
			ports_info[port-1].e1_info.timeout_bloqueio_off = value;
			break;
		case E1CFG_MFT_TIMEOUT:			//30000ms
			ports_info[port-1].e1_info.timeout_mft = value;
			break;
		case E1CFG_MFF_TIMEOUT:			//30000ms
			ports_info[port-1].e1_info.timeout_mff = value;
			break;
		case E1CFG_MAXDIGITS_RX:		//padrao zero para tratamento manual dos eventos da thread
			ports_info[port-1].e1_info.rx_total_of_digits = (char)value;
			break;
		case E1CFG_SEND_ID_AFTERDIGIT:	//apos o digito x, envia identificacao
			ports_info[port-1].e1_info.send_id_digit_pos = (char)value;
			break;
		case E1CFG_GROUP_B:
			ports_info[port-1].e1_info.group_b_id = (char)value;
			break;
		case SILENCE_THRESHOLD:		//padrao -36
			ports_info[port-1].e1_info.silence_threshold_signaling = value;
			break;
		case SILENCE_THRESHOLD_AFTER:	//padrao -24
			ports_info[port-1].e1_info.silence_threshold_after_signaling = value;
			break;
		case E1CFG_GENERATE_RINGBACK:	//0 - without ringback - 1 - with ringback (default)
			ports_info[port-1].e1_info.ring_generate_ringback = value;
			break;
		case E1CFG_R2_COUNTRY://br(brazil), ar(argentine), mx(mexico) - default = br
			if (value < 1 || value > 3)
				return DG_ERROR_PARAM_OUTOFRANGE;
			else
				ports_info[port-1].e1_info.r2_country = value;
			break;
		case E1CFG_SIGTYPE://R2_TYPE_MFC = 1, R2_TYPE_CB_FXO = 2, R2_TYPE_CB_FXS = 3 - default = MFC
			if (value < 1 || value > 3)
				return DG_ERROR_PARAM_OUTOFRANGE;
			else
				ports_info[port-1].e1_info.sigtype = value;
			break;
		default:
			return DG_ERROR_PARAM_OUTOFRANGE;
	}
	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// This functions destroy CB handle for a desired port
//----------------------------------------------------------------
short WCDECL dg_DestroyCBThread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	//this functions is avaiable only for E1 cards
	if ((dg_GetPortCardType(port) != VBE13060PCI) && (dg_GetPortCardType(port) != VBE13030PCI) && 
		(dg_GetPortCardType(port) != VBE13060PCI_R) && (dg_GetPortCardType(port) != VBE16060PCI) &&
		(dg_GetPortCardType(port) != VBE16060PCI_R) &&
		(dg_GetPortCardType(port) != VB3030PCIE) && (dg_GetPortCardType(port) != VB6060PCIE) &&
		(dg_GetPortCardType(port) != DGV_1E1F) && (dg_GetPortCardType(port) != DGV_2E1F))
		return DG_FEATURE_NOT_SUPPORTED;


	if (ports_info[port-1].e1_info.thread_id>0)
	{

		dg_SendR2Command(port, R2_BLOCKED);		//bloqueia

		dg_SendR2Command(port, R2_DISABLEDETECTION);

		ports_info[port-1].e1_info.bBlocked=0;	//allow to send C_ENDTHREAD command

		//Send to threads informations to close
		//dg_insert_callctrl_fifo(port,C_ENDTHREAD,0);
		dg_InsertE1Fifo(port,C_ENDTHREAD,0);

		//turn timer off
		SetEnableTimer(&tmr_E1[port-1],FALSE);
		SetEnableTimer(&tmrCallProgress[port-1],FALSE);
	}
	
	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// This functions enabled and reset E1 thread
//----------------------------------------------------------------
short WCDECL dg_EnableCBThread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;
	
	if (ports_info[port-1].e1_info.enabled==0)
	{
		ports_info[port-1].e1_info.enabled = 1;
		dg_InsertE1Fifo(port,C_RESET_THREAD,0);
	}
	return DG_EXIT_SUCCESS;
	
}	
//----------------------------------------------------------------
// This functions disable E1 thread
//----------------------------------------------------------------
short WCDECL dg_DisableCBThread(short port)
{

	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	if (ports_info[port-1].e1_info.thread_id==0)
				return DG_ERROR_THREAD_NOT_RUNNING;

	if (ports_info[port-1].e1_info.enabled)
	{
		dg_InsertE1Fifo(port,C_RESET_THREAD,0);
		ports_info[port-1].e1_info.enabled = 0;
	}
	return DG_EXIT_SUCCESS;
}
//----------------------------------------------------------------
// This functions returns the E1 state
// DG_CB_THREAD_ENABLED 1
// DG_CB_THREAD_DISABLED 0
//----------------------------------------------------------------
short WCDECL dg_GetCBThreadStatus(short port)
{
	//check driver enabled
	if (!FDriverEnabled)
           return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (port < 1 || port > dg_GetPortsCount())
            return DG_ERROR_PORT_OUT_OF_RANGE;

	return ports_info[port-1].e1_info.enabled;

}

//-----------------------------------------------------------------------------------------------
// SetFXCardType: Configures the port type of a VB0404FX/VB0404FX_R card
// Type - DG_FX_TYPE_NONE = 0, DG_FX_TYPE_FXS = 1 or DG_FX_TYPE_FXO = 2
//-----------------------------------------------------------------------------------------------
short WCDECL dg_SetFXCardType(short Port, short Type)
{
	dg_cmd_tx tx_command_e1;
	
	//check driver enabled
	if (!FDriverEnabled)
    	return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (Port < 1 || Port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

    if (Type < 0 || Type > 3)
		return DG_ERROR_PARAM_OUTOFRANGE;

    if (dg_GetCardType(dg_GetCardNumber(Port)) == VB0404FX_R)
        if (Type == DG_FX_TYPE_FXO)
        	Type++;
    
	tx_command_e1.command = CMD_LINE;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = Port-1;
	tx_command_e1.param1 = (unsigned char)Port-1;
	tx_command_e1.param2 = FX_TYPE;
	tx_command_e1.param3 = (unsigned char)Type;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&(tx_command_e1));

	ports_info[Port-1].fx_type = Type;

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
// SetFXCardImpedance: Configures the impedance value of a VB0404FX_R card(ONLY FXO INTERFACE TYPE)
// Impedance - 600 or 900 ohms
//-----------------------------------------------------------------------------------------------
short WCDECL dg_SetFXCardImpedance(short Port, short Impedance)
{
	dg_cmd_tx tx_command_e1;
	
	//check driver enabled
	if (!FDriverEnabled)
    	return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (Port < 1 || Port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

    if (Impedance != 600 && Impedance != 900)
		return DG_ERROR_PARAM_OUTOFRANGE;

	tx_command_e1.command = CMD_LINE;
	tx_command_e1.port_or_card = ASSUME_PORT;
	tx_command_e1.port = Port-1;
	tx_command_e1.param1 = Port-1;
	tx_command_e1.param2 = FX_IMPEDANCE;
	tx_command_e1.param3 = Impedance;
	tx_command_e1.param4 = 0;
	tx_command_e1.param5 = 0;
	write_generic_command(&(tx_command_e1));

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
// WaveToGsm: Convert WavePCM file to GsmDIGI file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_WaveToGsm(char *Source, char *Target)
{
    FILE *src,*dest;
	WGenericHeader hw; 

	unsigned char s [320];
	unsigned char d [33] ;
	int	cc,nr ;

	nr = 0;

    src = fopen((const char*)Source,"rb");

    if (src == NULL)
        return DG_ERROR_CONV_SOURCE;


    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
    {
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }
		
	if (ReadHeaderWave(src, &hw, ffWavePCM) != 0)
		return DG_ERROR_CONV;		

	if (hw.formato != 0x0001)	//WAVE_FORMAT_PCM
		return DG_ERROR_CONV;

	SaveHeaderWave(1,dest,hw.tm,ffGsm610);

	while ((cc = (int)fread( (char *)s, 1, 320, src )) > 0)
	{
		if (cc < sizeof(s) / sizeof(*s))
			memset((char *)(s+cc), 0, sizeof(s)-(cc * sizeof(*s)));

		dg_GsmEncode(s,d);

		if (fwrite((char *)d, sizeof(d), 1, dest) != 1)
			return DG_ERROR_CONV;
	}
	if (cc < 0)
		return DG_ERROR_CONV;

    fclose(src);
    fclose(dest);

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
// Wave49ToGsm: Convert Wave49 file to GsmDIGI file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_Wave49ToGsm(char *Source, char *Target)
{
	FILE *src,*dest;
	WGenericHeader hw;

	unsigned char s [65];
	unsigned char d [66];
	int	cc,nr;

	nr = 0;

    src = fopen((const char*)Source,"rb");

    if (src == NULL)
        return DG_ERROR_CONV_SOURCE;

    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
    {
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }

	if (ReadHeaderWave(src, &hw, ffWave49) != 0)
		return DG_ERROR_CONV;		

	if (hw.formato != 49)	//WAVE_FORMAT_49
		return DG_ERROR_CONV;

	SaveHeaderWave(1,dest,hw.tm,ffGsm610);

	while ((cc = (int)fread(s, 1, 65, src )) > 0)
	{
		if (cc < sizeof(s) / sizeof(*s))
			memset((char *)(s+cc), 0, sizeof(s)-(cc * sizeof(*s)));

		dg_GsmDecode49(s,d);

		if (fwrite((char *)d, sizeof(d), 1, dest) != 1)
			return DG_ERROR_CONV;
	}
	if (cc < 0)
		return DG_ERROR_CONV;

    fclose(src);
    fclose(dest);

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
// Wave49ToGsmRaw: Convert Wave49 file to GsmRAW file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_Wave49ToGsmRaw(char *Source, char *Target)
{
	FILE *src,*dest;
	WGenericHeader hw;

	unsigned char s [65];
	unsigned char d [66];
	int	cc,nr;

	nr = 0;
    src = fopen((const char*)Source,"rb");

    if (src == NULL)
        return DG_ERROR_CONV_SOURCE;

    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
    {
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }

	if (ReadHeaderWave(src, &hw, ffWave49) != 0)
		return DG_ERROR_CONV;		

	if (hw.formato != 49)	//WAVE_FORMAT_49
		return DG_ERROR_CONV;

	while ((cc = (int)fread(s, 1, 65, src )) > 0) 
	{
		if (cc < sizeof(s) / sizeof(*s))
			memset((char *)(s+cc), 0, sizeof(s)-(cc * sizeof(*s)));

		dg_GsmDecode49(s,d);

		if (fwrite((char *)d, sizeof(d), 1, dest) != 1) 
			return DG_ERROR_CONV;
	}
	if (cc < 0) 
		return DG_ERROR_CONV;

    fclose(src);
    fclose(dest);

	return 0;
}

//-----------------------------------------------------------------------------------------------
// GsmToWave: Convert GsmDIGI file to WavePCM file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_GsmToWave(char *Source,char *Target) 
{
    FILE *src,*dest;
	GSMHeader gw;
	long lTamanhoRec = 0L;
	unsigned char	s[ 33 ];
	unsigned char	d[ 320 ];
	int		cc;

    src = fopen((const char*)Source,"rb");
    if (src == NULL)
	{
		write_debug("dg_GsmToWave -> Nao conseguiu abrir arquivo de origem");
        return DG_ERROR_CONV_SOURCE;
	}
	write_debug("dg_GsmToWave -> Abriu arquivo de origem");

    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
    {
		write_debug("dg_GsmToWave -> Não conseguiu abrir arquivo de destino");
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }
	write_debug("dg_GsmToWave -> Abriu arquivo de destino");

	//reads GSM header
	ReadHeaderWave(src, &gw , ffGsm610);
	write_debug("dg_GsmToWave -> Vai comecar a montar cabecalho");
	SaveHeaderWave(1,dest,1,ffWavePCM);

	//starts decoding
	lTamanhoRec = 0L;


	while ((cc = (int)fread(s, 1, sizeof(s), src)) > 0) {

		if (cc != sizeof(s)) 
		{
			if (cc >= 0) 
				 return DG_ERROR_CONV;
		}
		if (dg_GsmDecode( s, d)) 
		{
			write_debug("dg_GsmToWave -> Erro no Decode");
			fclose(src);
			fclose(dest);
			return DG_ERROR_CONV;	//invalid frame
		}

		if ((-( fwrite( (char *)d, sizeof(*d), 320, dest ) != 320 )) < 0) 
		{
			write_debug("dg_GsmToWave -> Erro na escrita");
			fclose(src);
			fclose(dest);

			return DG_ERROR_CONV;	//error writing in the file
		}
		//sum of the samples
		lTamanhoRec = lTamanhoRec + sizeof(d);
	} //while

	write_debug("dg_GsmToWave -> Saiu do while");

	if (cc < 0) 
		return DG_ERROR_CONV;

	write_debug("dg_GsmToWave -> Vai Reescrever o cabecalho com tamanho correto");
	//rewrites header with the correct size
	rewind(dest);
	
	//reescreve o cabecalho
	SaveHeaderWave(1,dest,lTamanhoRec,ffWavePCM);

	fclose(src);
	fclose(dest);

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
// GsmToWave49: Convert GsmDIGI file to Wave49 file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_GsmToWave49(char *Source, char *Target) 
{	
    FILE *src,*dest;
	GSMHeader gw;
	long lTamanhoRec = 0L;
	char	s[ 66 ];
	char	d[ 65 ];
	int		cc;

    src = fopen((const char*)Source,"rb");
    if (src == NULL)
        return DG_ERROR_CONV_SOURCE;  

    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
	{
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }

	//reads GSM header
	ReadHeaderWave(src, &gw , ffGsm610);
	write_debug("dg_GsmToWave -> Vai comecar a montar cabecalho");
	SaveHeaderWave(1,dest,1,ffWave49);

	//starts decoding
	lTamanhoRec = 0L;

	while ((cc = (int)fread(s, 1, sizeof(s), src)) > 0) {

		if (cc != sizeof(s)) 
		{
			if (cc >= 0) 
				return DG_ERROR_CONV;	
			
		}

		if (dg_GsmEncode49(s,d)) 
		{
			fclose(src);
			fclose(dest);

			return DG_ERROR_CONV;	//invalid frame
		}

		if ((-( fwrite( (char *)d, sizeof(*d), 65, dest ) != 65 )) < 0) 
		{
			fclose(src);
			fclose(dest);
			return DG_ERROR_CONV;	//error writing in the file
		}
		//sum of the samples
		lTamanhoRec = lTamanhoRec + sizeof(d);
	} //while

	if (cc < 0)
		return DG_ERROR_CONV;

	//rewrites header with the correct size
	rewind(dest);
	
	//reescreve o cabecalho
	SaveHeaderWave(1,dest,lTamanhoRec,ffWave49);

	fclose(src);
	fclose(dest);
	
	return DG_EXIT_SUCCESS;	
}

//-----------------------------------------------------------------------------------------------
// GsmRawToWave: Convert GsmRAW file to WavePCM file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_GsmRawToWave(char *Source, char *Target) 
{
    FILE *src,*dest;
	long lTamanhoRec = 0L;
	unsigned char	s[ 33  ];
	unsigned char	d[ 320 ];
	int		cc;

    src = fopen((const char*)Source,"rb");
    if (src == NULL)
		return DG_ERROR_CONV_SOURCE;

    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
    {
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }

	write_debug("dg_GsmToWave -> Vai comecar a montar cabecalho");
	SaveHeaderWave(1,dest,1,ffWavePCM);

	//starts decoding
	lTamanhoRec = 0L;

	while ((cc = (int)fread(s, 1, sizeof(s), src)) > 0) {

		if (cc != sizeof(s)) 
		{
			if (cc >= 0) 
				return DG_ERROR_CONV;
		}

		if (dg_GsmDecode( s, d)) 
		{
			fclose(src);
			fclose(dest);

			return DG_ERROR_CONV;	//invalid frame
		}

		if ((-( fwrite( (char *)d, sizeof(*d), 320, dest ) != 320 )) < 0) 
		{
			fclose(src);
			fclose(dest);
			return DG_ERROR_CONV;	//error writing in the file
		}
		//sum of the samples
		lTamanhoRec = lTamanhoRec + sizeof(d)/2;
	} //while

	if (cc < 0)
		return DG_ERROR_CONV;

	//rewrites header with the correct size
	rewind(dest);
	
	//reescreve o cabecalho
	SaveHeaderWave(1,dest,lTamanhoRec,ffWavePCM);

	fclose(src);
	fclose(dest);

	return DG_EXIT_SUCCESS;
}

//-----------------------------------------------------------------------------------------------
// GsmRawToWave49: Convert GsmRAW file to Wave49 file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_GsmRawToWave49(char *Source, char *Target) 
{	
    FILE *src,*dest;
	long lTamanhoRec = 0L;
	unsigned char	c_s[ 66 ];
	unsigned char	c_d[ 65 ]; 
	int		cc;

    src = fopen((const char*)Source,"rb");
    if (src == NULL)
        return DG_ERROR_CONV_SOURCE;

    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
	{
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }

	write_debug("dg_GsmToWave -> Vai comecar a montar cabecalho");
	SaveHeaderWave(1,dest,1,ffWave49);

	//inicia decodificação
	lTamanhoRec = 0L;

	while ((cc = (int)fread(c_s, 1, sizeof(c_s), src)) > 0) {

		if (cc != sizeof(c_s)) 
		{
			if (cc >= 0) 
				return DG_ERROR_CONV;
		}

		if (dg_GsmEncode49(c_s,c_d)) 
		{
			fclose(src);
			fclose(dest);
			return DG_ERROR_CONV;	//invalid frame
		}

		if ((-( fwrite( (char *)c_d, sizeof(*c_d), 65, dest ) != 65 )) < 0) 
		{
			fclose(src);
			fclose(dest);
			return DG_ERROR_CONV;	//error writing in the file
		}
		//sum of the samples
		lTamanhoRec = lTamanhoRec + sizeof(c_d);
	} //while

	if (cc < 0) 
		return DG_ERROR_CONV;

	//rewrites header with the correct size
	rewind(dest);
	
	//reescreve o cabecalho
	SaveHeaderWave(1,dest,lTamanhoRec,ffWave49);

	fclose(src);
	fclose(dest);
	
	return DG_EXIT_SUCCESS;	
}

//-----------------------------------------------------------------------------------------------
// WaveToGsmRaw: Convert WavePCM file to GsmRAW file
// Source - File Source Directory + File Source Name
// Target - File Target Directory + File Target Name
//-----------------------------------------------------------------------------------------------
short WCDECL dg_WaveToGsmRaw(char *Source, char *Target) 
{
    FILE *src,*dest;
	WGenericHeader hw;

	unsigned char s [320];
	unsigned char d [33 ] ;
	int	cc,nr = 0;

    src = fopen((const char*)Source,"rb");
    if (src == NULL)
		return DG_ERROR_CONV_SOURCE;

    dest = fopen((const char*)Target,"w+b");
    if (dest == NULL)
    {
		fclose(src);
        return DG_ERROR_CONV_TARGET;
    }

	if (ReadHeaderWave(src, &hw, ffWavePCM) != 0)
		return DG_ERROR_CONV;		

	if (hw.formato != 0x0001)	//WAVE_FORMAT_PCM
		return DG_ERROR_CONV;

	while ((cc = (int)fread( (char *)s, 1, 320, src )) > 0) 
	{
		if (cc < sizeof(s) / sizeof(*s))
			memset((char *)(s+cc), 0, sizeof(s)-(cc * sizeof(*s)));

		dg_GsmEncode(s, d);

		if (fwrite((char *)d, sizeof(d), 1, dest) != 1) 
			return DG_ERROR_CONV;
	}
	if (cc < 0) 
		return DG_ERROR_CONV;

    fclose(src);
    fclose(dest);

	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Compares array of short with 16bit data from EEPROM ( address from 0x0 to 0xf )
//-------------------------------------------------------------------------
short WCDECL dg_CheckCode( short wCard, short *wData)
{
	short i,wTemp,wAddr;

    //check if card number is out of range
	if (wCard < 1 && wCard > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;


	for(i=0;i<= EEPROM_MAX_ADD-EEPROM_MIN_ADD;i++)
	{
		//add address offset
		wAddr = i + EEPROM_MIN_ADD;

		wTemp = Read_EEPROM(hPlxHandle[wCard-1],wAddr);
		if(wTemp == 0x0000)
			return DG_EXIT_SUCCESS;
		else
			if(wTemp != wData[i])
				return DG_EXIT_FAILURE;
	}
	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Write 16bit data to EEPROM  ( address from 0x0 to 0xf )
//-------------------------------------------------------------------------
short WCDECL dg_WriteCode( short wCard, /*short *wOldData,*/ short *wNewData)
{
    short wAddr,i;

    //check if card number is out of range
	if (wCard < 1 && wCard > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;

    //test if EEPROM is protected
    //wMin = Read_EEPROM(hPlxHandle[wCard-1],EEPROM_MIN_ADD);
	
	/*
	if(wMin != -1) //0xffff
	{
		if(dg_CheckCode(wCard, wOldData) != DG_EXIT_SUCCESS) 
        return DG_ERROR_EEPROM_PROTECTED;
	}*/

	Ewen_EEPROM(hPlxHandle[wCard-1]);//Enable
	for(i=0;i<= EEPROM_MAX_ADD-EEPROM_MIN_ADD;i++)
	{
		//add address offset
		wAddr = i + EEPROM_MIN_ADD;

		//it is a string converted to word array, check the string end
		if((wNewData[i] & 0xff00) == 0)
		{
			Write_EEPROM(hPlxHandle[wCard-1],wAddr,wNewData[i]);
			Write_EEPROM(hPlxHandle[wCard-1],wAddr+1,0);//force one more 0x0000
		}
		else
		if((wNewData[i] & 0xff) == 0)
		{
			Write_EEPROM(hPlxHandle[wCard-1],wAddr,0);//force 0x0000
		}
		else
			Write_EEPROM(hPlxHandle[wCard-1],wAddr,wNewData[i]);
		
	}
	Ewds_EEPROM(hPlxHandle[wCard-1]);//Disable

	return DG_EXIT_SUCCESS;
}

//-------------------------------------------------------------------------
// Reads array of short with 16bit data from EEPROM ( address from 0x0 to 0xf )
//-------------------------------------------------------------------------
short WCDECL dg_ReadCode( short wCard, short *wData)
{
	short i,wAddr;

    //check if card number is out of range
	if (wCard < 1 && wCard > nCardsCount)
		return DG_ERROR_CARD_OUT_OF_RANGE;


	for(i=0;i<= EEPROM_MAX_ADD-EEPROM_MIN_ADD;i++)
	{
		//add address offset
		wAddr = i + EEPROM_MIN_ADD;

		wData[i] = Read_EEPROM(hPlxHandle[wCard-1],wAddr);
		if(wData[i]==0)
			break;
	}
	return DG_EXIT_SUCCESS;
}

//---------------------------------
// convert a return code to string
//---------------------------------
void dg_ReturnCodeToString(short wReturn, char *s)
{
  switch(wReturn)
  {
        case DG_EXIT_SUCCESS:
            sprintf(s,"Success");
            break;
        case DG_EXIT_FAILURE:
            sprintf(s,"Failure");
            break;

        //startvoicerlib errors
        case DG_ERROR_MEMORY_ALLOCATION:
            sprintf(s,"Memory Allocation Error");
            break;
        case DG_ERROR_MAXCARDS:
            sprintf(s,"Number of Cards Detected Error");
            break;
        case DG_ERROR_FIRMWARE_NOT_FOUND:
            sprintf(s,"Firmware not found");
            break;
        case DG_ERROR_FIRMWARE_IO_TIMEOUT:
            sprintf(s,"Firmware load timeout");
            break;
        case DG_ERROR_READING_PORTCOUNT:
            sprintf(s,"Port Count reading error");
            break;
        case DG_ERROR_LOADING_DEVICEDRIVER:
            sprintf(s,"Device Driver load error");
            break;
        case DG_ERROR_CREATING_EVENT:
            sprintf(s,"Could not create Event");
            break;

        //global errors
        case DG_ERROR_DRIVER_CLOSED:
            sprintf(s,"Driver Closed");
            break;
		case DG_ERROR_CARD_OUT_OF_RANGE:
            sprintf(s,"Card number out of range");
            break;
		case DG_ERROR_PORT_OUT_OF_RANGE:
            sprintf(s,"Port number out of range");
            break;
		case DG_ERROR_PARAM_OUTOFRANGE:
            sprintf(s,"Parameter out of range");
            break;
		case DG_ERROR_DRIVER_ALREADY_OPEN:
            sprintf(s,"Driver already opened");
            break;
		case DG_ERROR_CONFIGFILE_NOT_FOUND:
            sprintf(s,"configuration file not found");
            break;
		case DG_FEATURE_NOT_SUPPORTED:
            sprintf(s,"Feature is not supported");
            break;
		case DG_ERROR_RESOURCE_UNAVAILABLE:
            sprintf(s,"Resource is unavailable");
            break;
		case DG_ERROR_RESOURCE_FULL:
            sprintf(s,"Resource is full");
            break;
		case DG_ERROR_INVALIDPARAM:
            sprintf(s,"Invalid parameter");
            break;
		case DG_WARNING_OLDFILEFORMAT:
            sprintf(s,"Warning - Old file format");
            break;

        //threads related errors
		case DG_ERROR_COULD_NOT_CREATE_THREAD:
            sprintf(s,"Could not create thread");
            break;
		case DG_ERROR_THREAD_NOT_RUNNING:
            sprintf(s,"thread is not running");
            break;
		case DG_ERROR_FIFO_UNAVAILABLE:
            sprintf(s,"FIFO is unavailable");
            break;
		case DG_ERROR_THREAD_ALREADY_RUNNING:
            sprintf(s,"thread is already running");
            break;

        //playback related errors
		case DG_ERROR_NOT_PLAYING:
            sprintf(s,"there is nothing playing yet");
            break;
		case DG_ERROR_ALREADY_PLAYING:
            sprintf(s,"this port is already playing");
            break;
		case DG_ERROR_PLAY_OPENFILE:
            sprintf(s,"Error on opening play file");
            break;
		case DG_ERROR_PLAY_EMPTYLIST:
            sprintf(s,"Play list is empty");
            break;
		case DG_ERROR_AUDIO_FORMAT_UNSUPPORTED:
            sprintf(s,"Audio format unsupported");
            break;
		case DG_ERROR_PLAY_INVALID_FILENAME:
            sprintf(s,"Play - invalid file name");
            break;
		case DG_ERROR_PLAY_BUFFER_FULL:
            sprintf(s,"Play buffer full");
            break;

        //record related errors
		case DG_ERROR_REC_STOPPING:
            sprintf(s,"Stop record error");
            break;
		case DG_ERROR_REC_OPENFILE:
            sprintf(s,"Record - open file error");
            break;
		case DG_ERROR_REC_ALREADY_RECORDING:
            sprintf(s,"this port is already recording");
            break;
		case DG_ERROR_REC_NOT_RECORDING:
            sprintf(s,"this port is not recording");
            break;

        //conversion related errors
		case DG_ERROR_CONV_SOURCE:
            sprintf(s,"source file error");
            break;
       case DG_ERROR_CONV_TARGET:
            sprintf(s,"target file error");
            break;
        case DG_ERROR_CONV:
            sprintf(s,"file conversion error");
            break;

        //EEPROM related ERRORS
        case DG_ERROR_ADDRESS_OUT_OF_RANGE:
            sprintf(s,"Address out of range");
            break;

        case DG_ERROR_EEPROM_PROTECTED:
            sprintf(s,"EEPROM is write protected");
            break;

		case DG_ERROR_SERIAL_FAILURE:
            sprintf(s,"SERIAL FAILURE");
            break;

		default:
			sprintf(s,"Undefined Error: %x",wReturn);

  }
}

void dg_ReturnCodeGSMToString(short wReturn, char *s)
{
    switch(wReturn)
    {
        case GSM_AT_IDLE://1
            sprintf(s,"GSM_AT_IDLE");
			break;        
		case GSM_AT_RECEIVING:
            sprintf(s,"GSM_AT_RECEIVING");
			break;
        case GSM_IDLE:
            sprintf(s,"GSM_IDLE");
            break;
		case GSM_EF:
            sprintf(s,"Error sending command AT&F");
            break;
        case GSM_E0:
            sprintf(s,"Error sending command ATE0");
            break;
        case GSM_IPR:
            sprintf(s,"Error sending command AT+IPR");
            break;
        case GSM_CPIN:
            sprintf(s,"Error sending command AT+CPIN?");
            break;
        case GSM_COPS:
            sprintf(s,"Error sending command AT+COPS");
            break;
        case GSM_SNFS:
            sprintf(s,"Error sending command AT^SNFS");
            break;
        case GSM_SAIC:
            sprintf(s,"Error sending command AT^SAIC");
            break;
		case GSM_CLIP:
            sprintf(s,"Error sending command AT+CLIP");
            break;
		case GSM_CMEE:
            sprintf(s,"Error sending command AT+CMEE");
            break;
		case GSM_CLIR:
            sprintf(s,"Error sending command AT+CLIR");
            break;
		case GSM_CSCS:
            sprintf(s,"Error sending command AT+CSCS");
            break;
		case GSM_CSMS:
            sprintf(s,"Error sending command AT+CSMS");
            break;
		case GSM_CNMI:
            sprintf(s,"Error sending command AT+CNMI");
            break;
		case GSM_SMGO:
            sprintf(s,"Error sending command AT^SMGO");
            break;
		case GSM_CPMS:
            sprintf(s,"Error sending command AT+CPMS");
            break;	
		case GSM_CMGF:
            sprintf(s,"Error sending command AT+CMGF");
            break;	
		case GSM_Q3:
            sprintf(s,"Error sending command AT\\Q3");
            break;	
		case GSM_ALL:
            sprintf(s,"Error sending command GSM_ALL");
            break;	
		case GSM_SMS1:
            sprintf(s,"Error sending SMS1");
            break;	
		case GSM_SMS2:
            sprintf(s,"Error sending SMS2");
            break;	
		case GSM_SIM_PIN:
            sprintf(s,"Module is waiting for SIM PIN1");
            break;	
		case GSM_SIM_PUK:
            sprintf(s,"Module is waiting for SIM PUK1");
            break;	
		case GSM_SIM_PIN2:
            sprintf(s,"Module is waiting for PIN2");
            break;	
		case GSM_SIM_PUK2:
            sprintf(s,"Module is waiting for PUK2 to unblock a disabled PIN2");
            break;	
		case GSM_PHSIM_PIN:
            sprintf(s,"Module is waiting for phone-to-SIM card password");
            break;	
		case GSM_PHSIM_PUK:
            sprintf(s,"Module is waiting for Master Phone Code");
            break;	
		case GSM_PHFSIM_PIN:
            sprintf(s,"Module is waiting for phone-to-very-first-SIM card");
            break;	  
		case GSM_PHFSIM_PUK:
            sprintf(s,"Module is waiting for phone-to-very-first-SIM card unblocking password");
            break;	  
		case GSM_PHNET_PUK:
            sprintf(s,"Module is waiting for network personalisation unblocking password");
            break;	  
		case GSM_PHNS_PIN:
            sprintf(s,"Module is waiting for network subset personalisation password");
            break;	  
		case GSM_PHNS_PUK:
            sprintf(s,"Module is waiting for network subset unblocking password");
            break;	  
		case GSM_PHSP_PIN:
            sprintf(s,"Module is waiting for service provider personalisation password");
            break;	  
		case GSM_PHSP_PUK:
            sprintf(s,"Module is waiting for service provider personalisation unblocking password");
            break;	  
		case GSM_PHC_PIN:
            sprintf(s,"Module is waiting for corporate personalisation password");
            break;	  
		case GSM_PHC_PUK:
            sprintf(s,"Module is waiting for corprorate personalisation un-blocking password");
            break;	  
    }
}

//-----------------------------------------------------------------------------------------------
// dg_WriteFXTypeCode: Write to the EEPROM the port type(VB0404FX_R cards only)
// Type - DG_FX_TYPE_NONE = 0, DG_FX_TYPE_FXS = 1 or DG_FX_TYPE_FXO = 2 + 1
//-----------------------------------------------------------------------------------------------
short WCDECL dg_WriteFXTypeCode(short Port, short Type)
{
	int j = 0;
	
	if (!FDriverEnabled)
    	return DG_ERROR_DRIVER_CLOSED;

    if (Port < 1 || Port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;

    if (Type < 0 || Type > 3)
		return DG_ERROR_PARAM_OUTOFRANGE;

    if (dg_GetCardType(dg_GetCardNumber(Port)) == VB0404FX_R)
    {
        j = Read_EEPROM(hPlxHandle[dg_GetCardNumber(Port) - 1], 0x66);
        j&=~(0xf<<((dg_GetRelativeChannelNumber(Port) - 1) * 4));
        
        if (Type == DG_FX_TYPE_FXO) 
        	Type++;
        
        j|=Type<<((dg_GetRelativeChannelNumber(Port) - 1) * 4);              

        Ewen_EEPROM(hPlxHandle[dg_GetCardNumber(dg_GetRelativeChannelNumber(Port)) - 1]);
        Write_EEPROM(hPlxHandle[dg_GetCardNumber(dg_GetRelativeChannelNumber(Port)) - 1], 0x66, j);
        Ewds_EEPROM(hPlxHandle[dg_GetCardNumber(dg_GetRelativeChannelNumber(Port)) - 1]);
    }
    else
    	return DG_FEATURE_NOT_SUPPORTED;

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// This function enables fsk detection
//----------------------------------------------------------------
short WCDECL dg_EnableFSKDetection(short Port, short Enable, short Type)
{
	//check driver enabled
	if (!FDriverEnabled)
		return DG_ERROR_DRIVER_CLOSED;

	//check port
    if (Port < 1 || Port > dg_GetPortsCount())
    	return DG_ERROR_PORT_OUT_OF_RANGE;
    
    if (Enable < 0 || Enable > 1)
    	return DG_ERROR_PARAM_OUTOFRANGE;    
    
    if (Type < 0 || Type > 1)
    	return DG_ERROR_PARAM_OUTOFRANGE;    

	//ports_info[Port-1].fsk_info = Enable;
	ports_info[Port-1].fsk_info.enable = Enable;

	/*
	if (Enable)
	{
		tx_command_fsk.command = CMD_UART0; // enable fsk detection between rings
		tx_command_fsk.port_or_card = ASSUME_PORT;
		tx_command_fsk.port = Port - 1;
		tx_command_fsk.param1 = (unsigned char)Port - 1;
		tx_command_fsk.param2 = 2;//type
		tx_command_fsk.param3 = Type;//0 V.23, 1 Bell212
		tx_command_fsk.param4 = 0;
		tx_command_fsk.param5 = 0;
		write_generic_command(&tx_command_fsk);
	}
	*/

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// This function allows gettings dll and ocx file versions
// Input szVersion - Return String 
// nInfo	0 - DLL 1- OCX
//----------------------------------------------------------------
short WCDECL dg_GetLibVersion( char* szVersion, short nInfo)
{

#ifdef WIN32

 DWORD dwHandle, dwLen;
 UINT BufLen;
 UINT BufLenTr;
 LPTSTR lpData;
 TCHAR szTemp[1000];
 LPVOID pVal;
 UINT i;
 LPTSTR lpTemp;
 LPTSTR LibName;
 size_t Ret;

 struct LANGANDCODEPAGE 
 {
  WORD wLanguage;
  WORD wCodePage;
 }*pTranslate;

 static TCHAR sDLL[] = {'v','o','i','c','e','r','l','i','b','.','d','l','l','\0'};
 static TCHAR sOCX[] = {'v','o','i','c','e','r','l','i','b','.','o','c','x','\0'};
 static TCHAR sBackSlash[] = {'\\','\0'};
 static TCHAR sTranslation[] = {'\\','V','a','r','F','i','l','e','I','n','f','o','\\','T','r','a','n','s','l','a','t','i','o','n','\0'};
 static TCHAR sStringFileInfo[] = {'\\','S','t','r','i','n','g','F','i','l','e','I','n','f','o','\\',
								'%','0','4','x','%','0','4','x','\\','P','r','o','d','u','c','t','V','e','r','s','i','o','n','\0'};
 VS_FIXEDFILEINFO *pFileInfo;

if(nInfo == 0)
	LibName = sDLL;
else
	LibName = sOCX;


	//get file info size
	dwLen = GetFileVersionInfoSize( LibName, &dwHandle );
	if (!dwLen) 
		return DG_EXIT_FAILURE;

	//alloc memory to put file info
	lpData = (LPTSTR) malloc (dwLen);
	if (!lpData) 
		return DG_EXIT_FAILURE;

	//get data
	if( !GetFileVersionInfo( LibName, dwHandle, dwLen, lpData ) )
	{
		free (lpData);
		return DG_EXIT_FAILURE;
	}

	
	//Read the list of languages and code pages.
	if (VerQueryValue(lpData, sTranslation, &pVal, &BufLenTr)) 
	{
		for( i=0; i < (BufLenTr/sizeof(struct LANGANDCODEPAGE)); i++ )
		{
		    pTranslate = (struct LANGANDCODEPAGE*)pVal + i*sizeof(struct LANGANDCODEPAGE);
			wsprintf(szTemp,sStringFileInfo,(WORD)pTranslate->wLanguage,(WORD)pTranslate->wCodePage);

			//try to access string version
			if( VerQueryValue( lpData, szTemp,(LPVOID *)&lpTemp, (PUINT)&BufLen ) ) 
			{
#ifdef UNICODE
				wcstombs_s(&Ret,szVersion,100,lpTemp,BufLen);
#else
				strncpy(szVersion,(LPSTR)lpTemp,BufLen);
				szVersion[BufLen] = '\0';
#endif
			}
		}
		free (lpData);
		return DG_EXIT_SUCCESS;

	}
	else
	if( VerQueryValue( lpData, sBackSlash, (LPVOID *) &pFileInfo, (PUINT)&BufLen ) ) 
	{
		sprintf(szVersion,"%d.%d.%d.%d",HIWORD(pFileInfo->dwFileVersionMS),LOWORD(pFileInfo->dwFileVersionMS),HIWORD(pFileInfo->dwFileVersionLS), LOWORD(pFileInfo->dwFileVersionLS));
		free (lpData);
		return DG_EXIT_SUCCESS;
	}

	free (lpData);

#else
        if (nInfo == 0)
                strlcpy(szVersion, GetLinuxVLibVersion(), 20);
        else
                strlcpy(szVersion, GetLinuxVLibVersionNumber(), 20);

        return DG_EXIT_SUCCESS;
#endif

        return DG_EXIT_FAILURE;
}

//----------------------------------------------------------------
// connects two audio channels
// input:
//       port1
//       port2
//----------------------------------------------------------------
short WCDECL dg_ConnectAudioChannels(short port1,short port2)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port1 <1 || port1 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port2 <1 || port2 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;
	
	if (port1 == port2)
		return DG_ERROR_PORT_OUT_OF_RANGE;

        //save other port
        ports_info[port1-1].connect_port = port2;
        ports_info[port2-1].connect_port = port1;

		//set inputbuffer callback
        dg_SetAudioInputCallback(dg_ConnectAudioCallback);
 
        //enable input buffer to both channels
        dg_EnableInputBuffer(port1,0);
        dg_EnableInputBuffer(port2,0);


	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// disconnects two audio channels
// input:
//       port1
//       port2
//----------------------------------------------------------------
short WCDECL dg_DisconnectAudioChannels(short port1,short port2)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port1 <1 || port1 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port2 <1 || port2 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

        //disable input buffer to both channels
        dg_DisableInputBuffer(port1);
        dg_DisableInputBuffer(port2);

		//disable playbuffer
		dg_StopPlayBuffer(port1);
		dg_StopPlayBuffer(port2);
		

	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// read audio samples from card
// input:
//       port
//----------------------------------------------------------------
short DCALLBACK dg_ConnectAudioCallback(short port, int size, void *SampleData)
{

      short port2;
	  int remaining;
	  short size1,index;
	  short nret;	

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;
	
	digivoice_entercriticalsection(&event_mutex, port);

		//write_debug("dg_ConnectAudioCallback - IN port %d wp %d rp %d size %d", port,ports_info[port-1].connect_wp,ports_info[port-1].connect_rp,size);

		if (port <1 || port > nPortsCount)
		{		
			digivoice_leavecriticalsection(&event_mutex, port);
			return DG_ERROR_PORT_OUT_OF_RANGE;
		}

		//get other channel port
		port2 = ports_info[port-1].connect_port;

		if(size >1024)
			size = 1024;

		//read this port space
		dg_PlayBuffer(port2,SampleData,0,&remaining);	

		if(remaining >= size)
		{
			nret =dg_PlayBuffer(port2,SampleData,size,&remaining);
			if (nret == DG_ERROR_PLAY_BUFFER_FULL) 
			{
				write_debug("DG_ERROR_PLAY_BUFFER_FULL - port %d size %d remaining %d", port,size,remaining);
			}
		    //write_debug("dg_ConnectAudioCallback OUT - port %d size %d remaining %d", port,size,remaining);

		}
		else
			write_debug("dg_ConnectAudioCallback -NO Space - port %d remaing %d size %d", port, remaining,size);

//		write_debug("dg_ConnectAudioCallback OUT - port %d wp %d rp %d size %d", port,ports_info[port-1].connect_wp,ports_info[port-1].connect_rp,size);

	digivoice_leavecriticalsection(&event_mutex, port);
	return DG_EXIT_SUCCESS;
}

short WCDECL dg_EnableMailBoxDetection(short port, short silencetime, short audiotime, short threshold)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	write_debug("dg_EnableMailBoxDetection - port %d ", port);
	dg_DisableCallProgress(port); 
	dg_EnableCallProgress(port,CP_ENABLE_BUSY_OR_FAX);//depois do atendimento

	dg_DisableSilenceDetection(port);
	dg_EnableSilenceDetection(port, silencetime, audiotime);
	
	ports_info[port -1].mbDetec = ON;
	//Save old value
	ports_info[port -1].mbOldThreshold = ports_info[port -1].SilenceThreshold;
	dg_SetSilenceThreshold(port,threshold);

	return DG_EXIT_SUCCESS;

}

short WCDECL dg_DisableMailBoxDetection(short port)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	write_debug("dg_DisableMailBoxDetection - port %d ", port);
	//Restore old value
	dg_SetSilenceThreshold(port,ports_info[port -1].mbOldThreshold);
	dg_DisableSilenceDetection(port);
	write_debug("dg_DisableSilenceDetection - port %d ", port);
	ports_info[port -1].mbDetec = OFF;

	return DG_EXIT_SUCCESS;
}

#ifdef __LINUX__
	//-------------------------------------------------------------------------
	// Reads IRQ number of linux pdev struct
	//-------------------------------------------------------------------------
	short WCDECL dg_ReadIRQNumber(short wCard, char *wData)
	{
		if (wCard < 1 && wCard > nCardsCount)
			return DG_ERROR_CARD_OUT_OF_RANGE;

		sprintf(wData, "%d", sm->Cards[wCard-1].irq_vars.irq);
		write_debug("dg_ReadIRQNumber - card %d, IRQ %d/%s", wCard, sm->Cards[wCard-1].irq_vars.irq, wData);

		return DG_EXIT_SUCCESS;
	}
#endif//#ifdef __LINUX__

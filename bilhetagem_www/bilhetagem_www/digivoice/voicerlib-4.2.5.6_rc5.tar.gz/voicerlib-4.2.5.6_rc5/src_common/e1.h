
/***************************************************************************
 *                                                                         *
 *   VoicerLib - Linux Version                                             *
 *                                                                         * 
 *   Copyright (c) 2004, Digivoice Tecnologia em Eletr�ica Ltda            *
 *                                                                         *
 *   Module:                                                               *
 *                                                                         *
 *   Description:                                                          *
 *                                                                         *
 *                                                                         *
 *                                                                         *
 *  This software is licensed under Digivoice Public License               *
 *                                                                         *
 *	Copyright (c) 2004, Digivoice Tecnologia em Eletr�ica Ltda             *
 *	All rights reserved.                                                   *
 *                                                                         *
 *	Redistribution and use in source and binary forms, with or without     *
 *	modification, are permitted provided that the following conditions     *
 *  are met:                                                               *
 *                                                                         *
 * - Redistributions of source code must retain the above copyright        *
 *   notice, this list of conditions and the following disclaimer.         *
 * - Redistributions in binary form must reproduce the above copyright     *
 *   notice, this list of conditions and the following disclaimer in the   * 
 *   documentation and/or other materials provided with the distribution.  *
 * - Modifications must not alter or remove any copyright notices in       *
 *   the Software and related documents.                                   *
 * - Any modifications in the original source code or modified versions of *
 *   this library must be available under this license.                    *
 * - You may develop application programs, reusable components and other   *
 *   software items that link with the original or modified versions of    *
 *   this library and release them under the license you wish.             *
 * - Neither the name of the Digivoice Tecnologia em Eletr�ica Ltda,       *
 *   VoicerLib nor the names of its contributors may be used to endorse    *
 *   or promote products derived from this software without specific prior *
 *   written permission.                                                   *
 *                                                                         *
 *  DISCLAIMER                                                             *
 *                                                                         *  
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS    *
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT      *
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  *
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  *
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT       *
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  * 
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  *
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT    *
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE  *
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.   *
 *                                                                         *
 ***************************************************************************/

//OBS: No Windows nao esta funcionano este IFNDEF
//Precisa comentar qdo compilar pra windows

#ifndef __E1HEADER_H__
#define __E1HEADER_H__


#define OFF    0x0
#define ON     0x1

#define	NUMBER_SIZE			25

enum
{
	P_MFC_REPOUSO,
	P_MFC_ENTRANTE,
	P_MFC_SAINTE,
	P_MFC_ENVIA_DIGITO,
	P_MFC_RECEBE_GRUPO_A,
	P_MFC_ENVIA_CATEGORIA,
	P_MFC_ENVIA_CATEGORIA_ASSINANTE,
	P_MFC_ENVIA_ASSINANTE,
	P_MFC_RECEBE_GRUPO_B,   //8
	P_MFC_FIM,				 //9
	P_MFC_RECEBE_DIGITO,
	P_MFC_AGUARDA_FIM_DIGITO,
	P_MFC_ENVIA_GRUPO_A,
	P_MFC_RECEBE_ID,
	P_MFC_AGUARDA_FIM_ID,
	P_MFC_RECEBE_CATEGORIA, //f
	P_MFC_ENVIA_GRUPO_B,
	P_MFC_AGUARDA_FIM_GRUPO_I,
	P_MFC_ENVIA_GRUPO_I,
	P_MFC_RECEBE_GRUPO_I,
	P_MFC_ESPERA_MF,		//estados do logger
	P_MFC_ESPERA_FIM_MF,
	P_MFC_A3_PULSADO,
	P_MFC_A3_PULSADO_FIM,
	P_MFC_RECEBE_GRUPO_C
};

/* passos do R2*/
enum {
	P_R2_LIVRE = 0,
	P_R2_ENVIA_CONFIRMACAO,
	P_R2_CONFIRMAOCUPACAO,
	P_R2_DISCANDO,
	P_R2_ATENDIDO_SAINTE,
	P_R2_ENVIA_CONFIRMA,
	P_R2_RECEBENDO_MFC,
	P_R2_BLOQUEIO_DDC,
	P_R2_BLOQUEANDO_DDC,
	P_R2_ATENDIDO_ENTRANTE,
	P_R2_LIGACAOEMCURSO,
	P_R2_AGUARDA_ATENDIMENTO,
	P_R2_AGUARDA_LIVRE,
	P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU
};

#define MFC_A_1  0x1
#define MFC_A_2  0x2
#define MFC_A_3  0x3
#define MFC_A_4  0x4
#define MFC_A_5  0x5
#define MFC_A_6  0x6
#define MFC_A_7  0x7
#define MFC_A_8  0x8
#define MFC_A_9  0x9
#define MFC_A_10 0x0
#define MFC_A_11 0xA
#define MFC_A_12 0xB
#define MFC_A_13 0xC
#define MFC_A_14 0xD
#define MFC_A_15 0xE

#define MFC_B_1  0x1
#define MFC_B_2  0x2
#define MFC_B_3  0x3
#define MFC_B_4  0x4
#define MFC_B_5  0x5
#define MFC_B_6  0x6
#define MFC_B_7  0x7
#define MFC_B_8  0x8
#define MFC_B_9  0x9
#define MFC_B_10 0x0
#define MFC_B_11 0xA
#define MFC_B_12 0xB
#define MFC_B_13 0xC
#define MFC_B_14 0xD
#define MFC_B_15 0xE

#define MFC_C_1  0x1
#define MFC_C_2  0x2
#define MFC_C_3  0x3
#define MFC_C_4  0x4
#define MFC_C_5  0x5
#define MFC_C_6  0x6
#define MFC_C_7  0x7
#define MFC_C_8  0x8
#define MFC_C_9  0x9
#define MFC_C_10 0x0
#define MFC_C_11 0xA
#define MFC_C_12 0xB
#define MFC_C_13 0xC
#define MFC_C_14 0xD
#define MFC_C_15 0xE

/*
//GROUP A specifications
enum
{
#ifdef ARGENTINA
	A_SEND_NEXT = 1,
	A_2,
	A_SEND_CAT_PREPARE_GROUP_B,
	A_CONGESTION,
	A_SEND_CAT_AND_CALLERID,
	A_6,
	A_SEND_DNIS_NM2,
	A_SEND_DNIS_NM3,
	A_SEND_DNIS_NM1,
	A_DNIS_AGAIN,
	A_11,
	A_12,
	A_13,
	A_14,
	A_15
#else//BRAZIL
	A_SEND_NEXT = 1,
	A_DNIS_AGAIN,
	A_SEND_CAT_PREPARE_GROUP_B,
	A_CONGESTION,
	A_SEND_CAT_AND_CALLERID,
	A_6,
	A_SEND_DNIS_NM2,
	A_SEND_DNIS_NM3,
	A_SEND_DNIS_NM1,
	A_10,
	A_11,
	A_12,
	A_13,
	A_14,
	A_15
#endif
};
	
//GRUPO B specifications
enum
{
#ifdef ARGENTINA
	B_NUMBER_CHANGED = 1,
	B_COLLECTCALL,
	B_BUSY,
	B_CONGESTION,
	B_NUMBER_UNKNOWN,
	B_FREE_CALLING,
	B_FREE_WITHOUTBILLING,
	B_OUT_OF_SERVICE
#else//BRAZIL
	B_FREE_CALLING = 1,
	B_BUSY,
	B_NUMBER_CHANGED,
	B_CONGESTION,
	B_FREE_WITHOUTBILLING,
	B_COLLECTCALL,
	B_NUMBER_UNKNOWN,
	B_OUT_OF_SERVICE
#endif
};

//GROUP C specifications(MEXICO)
enum
{
	C_SEND_NEXT_ANI = 1,
	C_DNIS_AGAIN_PREPARE_GROUP_A,
	C_SEND_CAT_PREPARE_GROUP_B,
	C_4,
	C_SEND_NEXT_DNIS_PREPARE_GROUP_A,
	C_SEND_DNIS_NM1_PREPARE_GROUP_A,
	C_7,
	C_8,
	C_9,
	C_10,
	C_11,
	C_12,
	C_13,
	C_14,
	C_15
};
*/
#endif

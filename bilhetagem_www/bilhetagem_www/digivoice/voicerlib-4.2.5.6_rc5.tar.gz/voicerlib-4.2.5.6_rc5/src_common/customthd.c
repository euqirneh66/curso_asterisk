
/************************************************************************************
 *                                                                         			*
 *   VoicerLib - Windows/Linux Version                                     			*
 *                                                                          		*
 *   Copyright (c) 2004-2010 Digivoice Tecnologia em Eletronica Ltda     			*
 *                                                                         			*
 *   Module:  Custom Thread Control                                            		*
 *                                                                         			*
 *   Description: CAS functions				                             			*
 *                                                                         			*
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                         			*
 *   This library is free software; you can redistribute it and/or					*
 *   modify it under the terms of the GNU Lesser General Public						*
 *   License as published by the Free Software Foundation; either					*
 *   version 2.1 of the License, or (at your option) any later version.				*
 *   																				*
 *   This library is distributed in the hope that it will be useful,				*
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of					*
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU				*
 *   Lesser General Public License for more details.								*
 *   																				*
 *   You should have received a copy of the GNU Lesser General Public				*
 *   License along with this library; if not, write to the Free Software			*
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *  
 *           																		*
 ************************************************************************************/

#include "vlibdef.h"
#include "voicerlib.h"
#include "generic.h"

#include <fcntl.h>
#ifdef __LINUX__
	#include <unistd.h>

 	extern void write_debug(char *fmt, ...);


#endif

//extern DIGIVOICE_CRITICAL_SECTION mtx_insert_to_custom;

//------------------------------------------------------------------------
// Thread function to signal in E1 cards
//------------------------------------------------------------------------
void CustomCAS_Thread(void *signal_cas_info)
{
	dg_customCAS_structure *customCAS;
	dg_event_data_structure 	cas_events;
	short line_on=0;

#ifdef __LINUX__
	int fifo_rx;
#else
	HANDLE fifo_rx;
	u32 cbBytesRead;
#endif
	//copy local information
	customCAS = (dg_customCAS_structure *)signal_cas_info;


#ifdef __LINUX__ 
	fifo_rx = open(customCAS->szFifoToCAS,O_RDONLY);
	if (fifo_rx==0)
	{
		//nao conseguiu abrir a fifo
		write_debug("Error openning fifo....");
	}

#endif

#ifdef WIN32

	fifo_rx	= CreateFile(customCAS->szFifoToCAS,
						GENERIC_READ | 
						GENERIC_WRITE,
						0,						//NO SHARING
						NULL,
						OPEN_EXISTING,
						0,
						NULL);

#endif

	while(1)
	{
		//retirar e tratar um evento da fifo
#ifdef __LINUX__
		read(fifo_rx,&cas_events,sizeof(cas_events));
#else

		//windows
		write_debug("CAS (%d)-> Esperar evento", customCAS->port);
		WaitForSingleObject(customCAS->oOverlapCAS.hEvent,INFINITE);
		ReadFile(fifo_rx,        // handle to pipe 
				&cas_events,    // buffer to receive data 
				sizeof(cas_events),      // size of buffer 
				&cbBytesRead, // number of bytes read 
				&customCAS->oOverlapCAS);        // not overlapped I/O 
#endif

		//terminates thread
		if (cas_events.command == C_ENDTHREAD)
		{
			//cancel thread execution
			write_debug("Finalizing CAS thread...");
			break;
		}

		switch(cas_events.command)
		{
			case C_CAS:
				//Analisa dado recebido e envio o evento correspondente para a aplicacao
				write_debug("custom: recebeu CAS codigo %d",customCAS->ring_signal);
				if (cas_events.data==customCAS->ring_signal)
				{
					write_debug("custom: RING  na porta %d",cas_events.port);
					RaiseEvents_ThreadSafe(EV_RINGS, 0, 0,cas_events.port,&port_mutex[cas_events.port-1]);
				}
				else
					if (cas_events.data==customCAS->idle_signal)
					{
						if (line_on)
						{
							//desliga
							write_debug("custom: IDLE");
							RaiseEvents_ThreadSafe(EV_LINEOFF, 0, 0,cas_events.port,&port_mutex[cas_events.port-1]);
							RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,cas_events.port,&port_mutex[cas_events.port-1]);
							line_on=0;
						}
					}
					else
					{
						if (cas_events.data==customCAS->caller_hangup_signal)
						{
							if (line_on)
							{
								write_debug("custom: HANGUP SIGNAL");
								RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,cas_events.port,&port_mutex[cas_events.port-1]);
								RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,cas_events.port,&port_mutex[cas_events.port-1]);
								line_on=0;
							}
						}
						else
						{
							if (cas_events.data==customCAS->answer_cmd)
							{
								write_debug("custom: ANSWERED SIGNAL");
								RaiseEvents_ThreadSafe(EV_ANSWERED, 0,  0,cas_events.port,&port_mutex[cas_events.port-1]);
							}
						}
					}
				break;
			case CPICKUP:
				//send pickup/answer command
				dg_SendR2Command(cas_events.port,customCAS->pickup_cmd);
				line_on=1;
				break;
			case CHANGUP:
				//send pickup
				dg_SendR2Command(cas_events.port,customCAS->pickup_cmd);
				//wait before
				digivoice_sleep(customCAS->drop_delay_before);
				//send drop command
				dg_SendR2Command(cas_events.port,customCAS->drop_cmd);
				line_on=0;
				break;
			case CFLASH:
				//wait before
				digivoice_sleep(customCAS->flash1_delay);
				//send flash1
				dg_SendR2Command(cas_events.port,customCAS->flash1_cmd);
				//wait before
				digivoice_sleep(customCAS->flash2_delay);
				//send flash1
				dg_SendR2Command(cas_events.port,customCAS->flash2_cmd);
				//gera o afterflash
				RaiseEvents_ThreadSafe(EV_AFTERFLASH, 0, 0,cas_events.port,&port_mutex[cas_events.port-1]);
				break;
		}
	} //fim do while(1)

		//close fifos
#ifdef __LINUX__
	close(ports_info[customCAS->port-1].fifo_to_cas);
#else
		//destroi os eventos
	CloseHandle(ports_info[customCAS->port-1].cas_info.CASEvent.hEvent);
#endif

	//fim
#ifdef __LINUX
	close(fifo_rx);
    //close(fifo_to_cas);
#endif
	customCAS->thread_id = 0;	

}

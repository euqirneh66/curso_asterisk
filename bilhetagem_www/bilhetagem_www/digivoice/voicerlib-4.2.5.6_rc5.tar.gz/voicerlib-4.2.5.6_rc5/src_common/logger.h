#ifndef __LOGGERHEADER_H__
#define __LOGGERHEADER_H__


void Logger_Thread(void *signal_logger_info);


#endif



/************************************************************************************
 *                                                                                  *
 *   dg_api.c                                                                       *
 *                                                                                  *
 *   Functions shared between windows and linux                                     *
 *                                                                                  *
 *   Particular functions should be found in win_api.c or linux_api.c               *
 *                                                                                  *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                                  *
 *   This library is free software; you can redistribute it and/or                  *
 *   modify it under the terms of the GNU Lesser General Public                     *
 *   License as published by the Free Software Foundation; either                   *
 *   version 2.1 of the License, or (at your option) any later version.             *
 *                                                                                  *
 *   This library is distributed in the hope that it will be useful,                *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of                 *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU               *
 *   Lesser General Public License for more details.                                *
 *                                                                                  *
 *   You should have received a copy of the GNU Lesser General Public               *
 *   License along with this library; if not, write to the Free Software            *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *
 *                                                                                  *
 ************************************************************************************/

#include <stdio.h>
#include "vlibdef.h"

#ifdef WIN32
	#include "../src_windows/dll/win_api.h"
	#include <windows.h>
	#include <shlobj.h>
#else
	#include "../src_linux/linux_api.h"
	extern void write_debug(char *fmt, ...);
#endif

#include "dg_api.h"
#include "vlibdef.h"
#include "shmem.h"

extern short force_all_single_span;
u16 ContadorGlobal[MAX_CARDS];

//extern DIGIVOICE_CRITICAL_SECTION cmd_mutex;
//extern DIGIVOICE_CRITICAL_SECTION event_mutex;

//Global Variables
extern DG_SHAREDMEMORY *sm;
extern DG_PLAYBACKMEM  *pm[MAX_CARDS*MAX_CHANNELS_CARD];
extern DG_RECMEM		*rm[MAX_CARDS*MAX_CHANNELS_CARD];
extern DG_CCS_MEMORY    *ccsm;           //pointer to CCS_MEMORY



#ifdef WIN32
	extern SET_EVENT		SignalEvent[MAX_CARDS];
#endif

/* converte um valor ascii hexadecimal em int */
int htoi(char c)
{
	c-=48;
	if (c>9) c-=7;
	if (c>15) c-=32;
	return (int)c;
}

/////////////////////////////////////////////////////////
//le um reg no endereco mapeado em memoria na placa
//addr eh o offset do endereco a ser lido pelo pc
/////////////////////////////////////////////////////////
u16 Placa_Ready(VLIB_HANDLE hPlx)
{

	u32 dwData_l=0L,dwData_h=0L;
	u16 wData=0;
	int i=0;
	

  	for(i=0;i<1000;i++)
   	{
		if (hPlx->CardType == VBE13060PCI)		//E1 card rv2 
	    {
		  dwData_h = dgAPI_ReadDword(hPlx, VLIB_ADDR_SPACE0, HPIC);
		  dwData_h &= 0xff;
		  dwData_l = dgAPI_ReadDword(hPlx, VLIB_ADDR_SPACE0, HPIC+4);
		  dwData_l &= 0xff;
		  dwData_l += dwData_h<<8;
		  wData=(u16)dwData_l;
		  wData&=800;
	    }
	    else
	    {
	      wData = (u16)dgAPI_ReadDword(hPlx, VLIB_ADDR_SPACE0, HPIC);
	      wData&=0x8;
	    }
    	if (wData!=0)
     		break;
   	}
  	return (wData);
}


/////////////////////////////////////////////////////////
//le um reg no endereco mapeado em memoria na placa
//addr eh o offset do endereco a ser lido pelo pc
/////////////////////////////////////////////////////////
u16 Placa_Read_Reg(VLIB_HANDLE hPlx, u32 dwAddr)
{
  u32 dwData_l,dwData_h;
	
	if (hPlx->CardType == VBE13060PCI)		//E1 card rv2 
	{
		//habilita EHPI
		dwData_h = dgAPI_ReadDword(hPlx, VLIB_ADDR_SPACE0, dwAddr);
		dwData_h &= 0xff;
		dwData_l = dgAPI_ReadDword(hPlx, VLIB_ADDR_SPACE0, dwAddr+4);
		dwData_l &= 0xff;
		dwData_l += dwData_h<<8;
		return ((u16)dwData_l);
	}
	else	//another new cards
	{
		//write_debug("PLaca_read_reg: tipo placa %x",hPlx->CardType);
		return (u16)dgAPI_ReadDword(hPlx, VLIB_ADDR_SPACE0, (u32)dwAddr);
	}
}

/////////////////////////////////////////////////////////
//Escreve em um reg no endereco mapeado em memoria na placa
//addr eh o offset do endereco a ser escrito pelo pc
/////////////////////////////////////////////////////////
void Placa_Write_Reg(VLIB_HANDLE hPlx, u32 dwAddr, u16 wData)
{
	u32 dwData;

	if (hPlx->CardType == VBE13060PCI)		//E1 card rv2 
	{
		dwData = wData;
		
		dgAPI_WriteDword(hPlx, VLIB_ADDR_SPACE0, dwAddr, dwData>>8);
		dgAPI_WriteDword(hPlx, VLIB_ADDR_SPACE0, dwAddr+4, dwData);
	}
	else
		dgAPI_WriteWord(hPlx, VLIB_ADDR_SPACE0, dwAddr,wData );
}


/////////////////////////////////////////////////////////
//Esta funcao coloca pino HCS (GPIO0) em 1
/////////////////////////////////////////////////////////
void Set_HCS(VLIB_HANDLE hPlx)
{
	u32 dwVal;
    if(hPlx->PlxType == 0x9030)
    {
    	//le o registro GPIO
  	    dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC);

  	    dwVal = dwVal | 0xc00; //bit 11 e 12

  	    //escreve o registro alterado
  	    dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC, dwVal);
	}
}

/////////////////////////////////////////////////////////
//Estas funcao coloca HCS (GPIO0) em 0
/////////////////////////////////////////////////////////
void Reset_HCS(VLIB_HANDLE hPlx)
{
	u32 dwVal;

    if(hPlx->PlxType == 0x9030)
    {
    	//le o registro GPIO
    	//dwVal = P9030_ReadReg(hPlx, P9030_GPIOC);
    	dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC);

    	dwVal = dwVal & 0xfffff7ff; //bit 2

    	//escreve o registro alterado
    	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC, dwVal);
    }
}

/////////////////////////////////////////////////////////
//Esta funcao coloca pino RESET (GPIO1) em 1
/////////////////////////////////////////////////////////
void Set_RESET(VLIB_HANDLE hPlx)
{
		u32 dwVal;

    if(hPlx->PlxType == 0x9030)
    {
      	//read register GPIO
		dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC);

		dwVal = dwVal | 0x20; //bit 5

		//write the modified register
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC, dwVal);
    }
    else
    {
      	//read register GPIO
		dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOCE);

		dwVal |= 0x00080000; //bit 19
		dwVal &= ~0x00010000; //bit 16

		//write the modified register
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOCE, dwVal);
    }
}

/////////////////////////////////////////////////////////
//Estas funcao coloca RESET (GPIO1) em 0
/////////////////////////////////////////////////////////
void Reset_RESET(VLIB_HANDLE hPlx)
{
u32 dwVal;

    if(hPlx->PlxType == 0x9030)
    {

        //read register GPIO
		dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC);

		dwVal = dwVal & 0xffffffd7; //bit 5

		//write the modified register
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC, dwVal);
    }
    else
    {
        //read register GPIO
		dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOCE);

		dwVal |= 0x00080000; //bit 19
		dwVal |= 0x00010000; //bit 16

		//write the modified register
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOCE, dwVal);
    }
}


/////////////////////////////////////////////////////////
//Esta funcao coloca pino RESET2 (GPIO2) em 1
/////////////////////////////////////////////////////////
void Set_RESET2(VLIB_HANDLE hPlx)
{
u32 dwVal;

    if(hPlx->PlxType == 0x9030)
    {

		//le o registro GPIO
		//dwVal = P9030_ReadReg(hPlx, P9030_GPIOC);
		dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC);

		dwVal = dwVal & 0xffffffbf; //clear bit 6
		dwVal = dwVal | 0x180; //set bit 7 e 8

		//escreve o registro alterado
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC, dwVal);
	}

}

/////////////////////////////////////////////////////////
//Estas funcao coloca RESET2 (GPIO2) em 0
/////////////////////////////////////////////////////////
void Reset_RESET2(VLIB_HANDLE hPlx)
{
u32 dwVal;


    if(hPlx->PlxType == 0x9030)
    {
		//le o registro GPIO
		//dwVal = P9030_ReadReg(hPlx, P9030_GPIOC);
		dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC);

		dwVal = dwVal & 0xfffffebf; //
		dwVal = dwVal | 0x80; //

		//escreve o registro alterado
	    //P9030_WriteReg(hPlx, P9030_GPIOC,dwVal);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, VLIB_GPIOC, dwVal);
    }
}


/////////////////////////////////////////////////////////
// Esta funcao le o arquivo (formato hex intel) a ser carregado, converte e
// envia para a placa (So funciona na DARAM)
/////////////////////////////////////////////////////////

int load1(char *arquivo, VLIB_HANDLE hPlx)
{
	unsigned int n,tp=0,i,t,e=0;
	u16  endhpi;
	unsigned int endabs ;
	long cs ;
	char ch=0;
	FILE *fHex;
	write_debug("Carregando bootloader %s ...",arquivo);
	if((fHex = fopen(arquivo , "r")) == NULL)  //abre o arquivo
	{
		write_debug("Nao foi possivel abrir %s",arquivo);
		return DG_ERROR_FIRMWARE_NOT_FOUND;
	}

	while (tp!=1)
	{
		while (ch !=':')
		{
			fread(&ch,1,1,fHex);
		}
		//*inicia checksum */
		cs=0;

		//* recebe numero de dados da linha */
		fread(&ch,1,1,fHex);
		n= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		n+=htoi(ch);
		cs+=n;
		//* recebe endereco */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<12);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<8);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		endabs=t;

		cs+= t&0xff;
		cs+= (t>>8)&0xff;

		//* recebe tipo dos dados */
		fread(&ch,1,1,fHex);
		tp= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		tp+=htoi(ch);

		cs+=tp;
		//seta o endereco HPI
		Placa_Write_Reg(hPlx, HPIA, (u16)(endabs>>1)); // escreve HPIA
		endhpi=(u16)(endabs>>1);

		//* recebe dados */
		for(i=0;i<(n/2);i++)
		{

			fread(&ch,1,1,fHex);
			t= (htoi(ch)<<12);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<8);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<4);
			fread(&ch,1,1,fHex);
			t+=htoi(ch);
			if (hPlx->CardType == VBE13060PCI)
				Placa_Write_Reg(hPlx, HPID_AINC+i*8, (u16)t); // escreve HPIDainc
			else
			{
				//all other cards
                Placa_Write_Reg(hPlx, HPIA, endhpi++); // escreve endereco HPIA e incrementa
                Placa_Write_Reg(hPlx, HPID, (u16)t); // escreve HPIDainc
			}
		
			cs+= t&0xff;
			cs+= (t>>8)&0xff;
		}
		//* recebe verifica checksum */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		cs= (-cs)&0xff;
		if ((long)t!=cs)e|=2;
	}
	fclose(fHex);
	return DG_EXIT_SUCCESS;
}



int testeload1(char *arquivo, VLIB_HANDLE hPlx)
{
	unsigned int n,tp=0,i,j,t,e=0;
	unsigned int endabs ;
	u16  endhpi;
	int cont;
	long cs ;
	char ch=0;
	FILE *fHex;

	u16 wReg;

	if((fHex = fopen(arquivo , "r")) == NULL)  //abre o arquivo
	{
		write_debug("Verificacao de boot - Nao foi possivel abrir %s",arquivo);
		return DG_ERROR_FIRMWARE_NOT_FOUND;
	}
	write_debug("testeload1: Arquivo %s aberto",arquivo);
#ifdef __LINUX__
	write_debug("Verificacao de boot - Placa %d - Tipo %x", hPlx->card, hPlx->CardType);
#endif
	cont=0;
	while (tp!=1)
	{
		while (ch !=':')
		{

			fread(&ch,1,1,fHex);

		}
		//*inicia checksum */
		cs=0;

		//* recebe numero de dados da linha */
		fread(&ch,1,1,fHex);
		n= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		n+=htoi(ch);
		cs+=n;
		//* recebe endereco */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<12);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<8);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		endabs=t;

		cs+= t&0xff;
		cs+= (t>>8)&0xff;

		//* recebe tipo dos dados */
		fread(&ch,1,1,fHex);
		tp= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		tp+=htoi(ch);

		cs+=tp;
		//seta o endereco HPI
		Placa_Write_Reg(hPlx, HPIA, (u16)(endabs>>1)); // escreve HPIA
		endhpi=(u16)(endabs>>1);
		wReg = Placa_Read_Reg(hPlx, HPIA); // le HPIDainc



		//* recebe dados */
		j=0;
		for(i=0;i<(n/2);i++)
		{

			fread(&ch,1,1,fHex);
			t= (htoi(ch)<<12);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<8);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<4);
			fread(&ch,1,1,fHex);
			t+=htoi(ch);
			cont++;
			if (hPlx->CardType == VBE13060PCI)
				wReg = Placa_Read_Reg(hPlx, HPID_AINC+i*8); // le HPIDainc
			else
			{
					Placa_Write_Reg(hPlx, HPIA, endhpi); // escreve endereco HPIA e incrementa
					Placa_Ready(hPlx);
					wReg = Placa_Read_Reg(hPlx, HPID); // escreve HPIDainc
			}

			if (wReg!=t)
			{
				write_debug("(testload1) %d End:%04x Write:%04x Read:%04x", cont,endabs+j,t,wReg);
				fclose(fHex);
				return DG_ERROR_FIRMWARE_IO_TIMEOUT;
			}
			j++;
			endhpi++;
			cs+= t&0xff;
			cs+= (t>>8)&0xff;
		}
		//* recebe verifica checksum */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		cs= (-cs)&0xff;
		if ((long)t!=cs)e|=2;
	}
	fclose(fHex);
	write_debug("testload1: ok");
	return DG_EXIT_SUCCESS;
}

/////////////////////////////////////////////////////////
// Esta funcao le o arquivo (formato hex intel) a ser carregado, converte e
// envia para a placa (Funciona na DARAM e SARAM se boot.i00 estiver rodando)
// O programa de boot roda na DARAM0, o programa a ser carregado nao pode ser 
// colocado nesta area.
/////////////////////////////////////////////////////////

int load2(char *arquivo, VLIB_HANDLE hPlx)
{
	unsigned int n,tp=0,i,j,t,e=0;
	unsigned int endabs ;
	unsigned int endh;
	u16  endhpi;
	long cs ;
	char ch=0;
	FILE *fHex;
	u32 wReg;
	
	if((fHex = fopen(arquivo , "r")) == NULL)  //abre o arquivo
	{
		write_debug("Nao foi possivel abrir %s",arquivo);
		return DG_ERROR_FIRMWARE_NOT_FOUND;
	}

	endh=0x0; // acessa a ram interna 32K u16s
	while (tp!=1)
	{
		while (ch !=':')
		{

			fread(&ch,1,1,fHex);

		}
		//*inicia checksum */
		cs=0;

		//* recebe numero de dados da linha */
		fread(&ch,1,1,fHex);
		n= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		n+=htoi(ch);
		cs+=n;
		//* recebe endereco */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<12);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<8);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		endabs=t;

		cs+= t&0xff;
		cs+= (t>>8)&0xff;

		//* recebe tipo dos dados */
		fread(&ch,1,1,fHex);
		tp= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		tp+=htoi(ch);

		cs+=tp;
   
		
		//seta o endereco HPI
		Placa_Write_Reg(hPlx, HPIA, (u16)(endabs>>1)); // escreve HPIA
		endhpi=(u16)(endabs>>1);
		
		//* recebe dados */
		for(i=0;i<(n/2);i++)
		{

			fread(&ch,1,1,fHex);
			t= (htoi(ch)<<12);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<8);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<4);
			fread(&ch,1,1,fHex);
			t+=htoi(ch);
			if (tp==0x4) 
			{
				endh=t;
			}
			else
			{			
				if (endh==0)
				{
					if (endabs<0x1000)
					{
						fclose(fHex);
						return DG_ERROR_FIRMWARE_IO_TIMEOUT; // sobrescrevendo programa de boot						 
					}

					if (hPlx->CardType == VBE13060PCI)
						Placa_Write_Reg(hPlx, HPID_AINC+i*8, (u16)t); // escreve HPIDainc
					else
					{
                        Placa_Write_Reg(hPlx, HPIA, endhpi++); // escreve endereco HPIA e incrementa
                        Placa_Write_Reg(hPlx, HPID, (u16)t); // escreve HPIDainc
					}
				}
				else
				{	
					//fprintf(ff,"\n----------------------------------------------------------");
					//fprintf(ff,"\n endh: %x  endabs: %x  t: %x",endh,endabs,t);
					wReg=((u32)endh)<<16;
					wReg+=(u32)endabs+2*i;
					wReg>>=1;
					wReg&=0xffff;
					Placa_Write_Reg(hPlx, HPIA, (u16)(BUFFER_WR+2));
					//fprintf(ff,"\nHPIA BUFFER_WR+2 = %x",(u16)(BUFFER_WR+2));

					Placa_Write_Reg(hPlx, HPID, (u16)t); // escreve dado
					//fprintf(ff,"\nHPD t = %x",(u16)(t));

					Placa_Write_Reg(hPlx, HPIA, (u16)(BUFFER_WR+1));
					//fprintf(ff,"\nHPIA BUFFER_WR+2 = %x",(u16)(BUFFER_WR+1));

					Placa_Write_Reg(hPlx, HPID, (u16)wReg); // endereco
					//fprintf(ff,"\nHPD t = %x",(u16)(wReg));


					Placa_Write_Reg(hPlx, HPIA, (u16)(BUFFER_WR));
					//fprintf(ff,"\nHPIA BUFFER_WR = %x",(u16)(BUFFER_WR));

					Placa_Write_Reg(hPlx, HPID, (u16)((endh>>1)+0x100)); // escreve pagina e flag
					//fprintf(ff,"\nHPID (u16)((endh>>1)+0x100) = %x",(u16)((endh>>1)+0x100));

					j=0;
					do
					{
						wReg=Placa_Read_Reg(hPlx, HPID);				
						//fprintf(ff,"\nRead HPD = %x",(u16)(wReg));
						j++;
						if (j>50)
						{
							fclose(fHex);
							return DG_ERROR_FIRMWARE_IO_TIMEOUT; // time out de ecrita
						}
					}while((wReg&0xff00)!=0);
				}
			}			
			cs+= t&0xff;
			cs+= (t>>8)&0xff;
		}
		//* recebe verifica checksum */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		cs= (-cs)&0xff;
		if ((long)t!=cs)e|=2;
	}
	fclose(fHex);
	//fclose(ff);
 return DG_EXIT_SUCCESS;
}

int testeload2(char *arquivo, VLIB_HANDLE hPlx)
{
	unsigned int n,tp=0,i,j,t,e=0;
	unsigned int endabs ;
	unsigned int endh ;
	int cont;
	long cs ;
	char ch=0;
	FILE *fHex;
	u32 wReg;
	u16  endhpi;

	if((fHex = fopen(arquivo , "r")) == NULL)  //abre o arquivo
	{
		write_debug("Nao foi possivel abrir %s",arquivo);
		return DG_ERROR_FIRMWARE_NOT_FOUND;
	}

	cont=0;
	endh=0x0; // acessa a ram interna 32K u16s
	while (tp!=1)
	{
		while (ch !=':')
		{

			fread(&ch,1,1,fHex);

		}
		//*inicia checksum */
		cs=0;

		//* recebe numero de dados da linha */
		fread(&ch,1,1,fHex);
		n= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		n+=htoi(ch);
		cs+=n;
		//* recebe endereco */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<12);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<8);
		fread(&ch,1,1,fHex);
		t+=(htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		endabs=t;

		cs+= t&0xff;
		cs+= (t>>8)&0xff;

		//* recebe tipo dos dados */
		fread(&ch,1,1,fHex);
		tp= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		tp+=htoi(ch);

		cs+=tp;
   
		
		//seta o endereco HPI
		Placa_Write_Reg(hPlx, HPIA, (u16)(endabs>>1)); // escreve HPIA
		endhpi=(u16)(endabs>>1);
		wReg = Placa_Read_Reg(hPlx, HPIA); // le HPIDainc			
		
		//* recebe dados */
		j=0;
		for(i=0;i<(n/2);i++)
		{
			fread(&ch,1,1,fHex);
			t= (htoi(ch)<<12);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<8);
			fread(&ch,1,1,fHex);
			t+=(htoi(ch)<<4);
			fread(&ch,1,1,fHex);
			t+=htoi(ch);
			if (tp==0x4) 
			{
				endh=t;
			}
			else
			{			
			 cont++;	
				if (endh==0)
				{
					if (endabs<0x1000)
					{
						fclose(fHex);
						 return DG_ERROR_FIRMWARE_IO_TIMEOUT; // lendo programa de boot						 
					}
					//Placa_Write_Reg(hPlx, HPID_AINC, (u16)t); // escreve HPIDainc
					if (hPlx->CardType == VBE13060PCI)
						wReg = Placa_Read_Reg(hPlx, HPID_AINC+i*8); // le HPIDainc			
                    else
                    {
                        Placa_Write_Reg(hPlx, HPIA, endhpi); // escreve endereco HPIA e incrementa
                        wReg = Placa_Read_Reg(hPlx, HPID); // escreve HPIDainc
                    }
					if (wReg!=t)
					{
						printf("\n(testload2) %d End_H:%04x End_L:%04x Write:%04x Read:%04x", cont,endh,endabs+j,t,wReg);
						fclose(fHex);
						return DG_ERROR_FIRMWARE_IO_TIMEOUT;
					}
				}
				else
				{				 
					wReg=((u32)endh)<<16;
					wReg+=(u32)endabs+2*i;
					wReg>>=1;
					wReg&=0xffff;
					Placa_Write_Reg(hPlx, HPIA, (u16)(BUFFER_RD+1));
					Placa_Write_Reg(hPlx, HPID, (u16)wReg); // endereco
					Placa_Write_Reg(hPlx, HPIA, (u16)(BUFFER_RD));
					Placa_Write_Reg(hPlx, HPID, (u16)((endh>>1)+0x100)); // escreve pagina e flag
					j=0;
					do
					{			
						wReg=Placa_Read_Reg(hPlx, HPID);				
						if (j>50)
						{
							fclose(fHex);
							return DG_ERROR_FIRMWARE_IO_TIMEOUT; // time out de leitura
						}
					}while((wReg&0xff00)!=0);
					Placa_Write_Reg(hPlx, HPIA, (u16)(BUFFER_RD+2));
					wReg=Placa_Read_Reg(hPlx, HPID);				
					if (wReg!=t)
					{
						printf("\n%d End_H:%04x End_Low:%04x Write:%04x Read:%04x", cont, endh ,endabs+j,t,wReg);
						fclose(fHex);
						return DG_ERROR_FIRMWARE_IO_TIMEOUT;
					}				
				}
			}			
			j++;		
			endhpi++;
			cs+= t&0xff;
			cs+= (t>>8)&0xff;
		}
		//* recebe verifica checksum */
		fread(&ch,1,1,fHex);
		t= (htoi(ch)<<4);
		fread(&ch,1,1,fHex);
		t+=htoi(ch);
		cs= (-cs)&0xff;
		if ((long)t!=cs)e|=2;
	}
	fclose(fHex);
 return DG_EXIT_SUCCESS;
}

//--------------------------------------------------------------------------------
// Reads eeprom address
//--------------------------------------------------------------------------------
u16 Read_EEPROM(VLIB_HANDLE hPlx,u16 wAdr)
{
	int i;
	u32 dwVal;
	u32 dwVal1;
	u32 dwCntrl;
	u16 x;

    write_debug("Read_EEPROM PlxType %x, wAdr %x",hPlx->PlxType, wAdr);
	if(hPlx->PlxType == 0x9030)
    {
      dwCntrl = VLIB_CNTRL;
    }
    else
    {
    	dwCntrl = 0x6c;
    }

	write_debug("Read_EEPROM 1");
	dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	write_debug("Read_EEPROM 1");

    if(hPlx->PlxType != 0x9030)
    {
    	write_debug("Step 1 dwVal: %x", dwVal);
        dwVal &=~0x80000000;
        write_debug("Step 2 dwVal: %x", dwVal);        
        
    }


	dwVal&=~EE_CS;
	dwVal|=EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=0,clk=1
	dwVal|=EE_CS;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=1

	//envia start bit e instrucao READ
	dwVal&=~EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal|=EE_DI;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
	dwVal|=EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal|=EE_DI;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
	dwVal|=EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal&=~EE_DI;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=0
	dwVal|=EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1

	// envia endereco
	for (i=0;i<8;i++)
	{
		dwVal&=~EE_CLK;
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
		if ((wAdr>>(7-i))&1)
			dwVal|=EE_DI;
		else
			dwVal&=~EE_DI;
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
		dwVal|=EE_CLK;
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	}
	dwVal&=~EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	//dummy bit
	dwVal|=EE_CLK;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1

    if(hPlx->PlxType != 0x9030)
        dwVal |=0x80000000;

	// le dado
	x=0;
	for (i=0;i<16;i++)
	{
		x<<=1;
		dwVal&=~EE_CLK;
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
		dwVal1 = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		if (dwVal1 & EE_DO)
			x|=1;
		dwVal|=EE_CLK;
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
		write_debug("Read_EEPROM FOR x %x - dwVal %x - dwVal1 %x", x,dwVal,dwVal1);
	}
	dwVal&=~EE_CS;
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//CS=0;
	write_debug("Read_EEPROM x %x",x);
	return x;
}

//writes in eeprom
void Write_EEPROM(VLIB_HANDLE hPlx,u16 wAdr,u16 wData)
{
	int i;
	u32 dwVal;
    u32 dwCntrl;

    if(hPlx->PlxType == 0x9030)
      dwCntrl = VLIB_CNTRL;
    else
      dwCntrl = 0x6c;

	digivoice_sleep(1);

	dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);

    if(hPlx->PlxType != 0x9030)
        dwVal &=~0x80000000;

	dwVal&=~EE_CS;
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=0,clk=1
	dwVal|=EE_CS;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=1

	//envia start bit e instrucao READ
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal|=EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal&=~EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=0
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal|=EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1

	// envia endereco
	for (i=0;i<8;i++)
	{
		dwVal&=~EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
		if ((wAdr>>(7-i))&1)
			dwVal|=EE_DI;
		else
			dwVal&=~EE_DI;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
		dwVal|=EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	}

	// envia dado
	for (i=0;i<16;i++)
	{
		dwVal&=~EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
		if ((wData>>(15-i))&1)
			dwVal|=EE_DI;
		else
			dwVal&=~EE_DI;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=wData
		dwVal|=EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	}

	dwVal&=~EE_CS;
	dwVal&=~EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	digivoice_sleep(1);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//CS=0, DI=0

	//dwVal|=EE_CS;
	//dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=1

	digivoice_sleep(40);
	//while ((dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, VLIB_CNTRL)&EE_DO)==0);

	//dwVal&=~EE_CS;
	//dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//CS=0, DI=0

}

void Ewen_EEPROM(VLIB_HANDLE hPlx)
{
	int i;
	u32 dwVal;
	u32 dwCntrl;

    if(hPlx->PlxType == 0x9030)
      dwCntrl = VLIB_CNTRL;
    else
      dwCntrl = 0x6c;

	dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);

	digivoice_sleep(1);

    if(hPlx->PlxType != 0x9030)
        dwVal &=~0x80000000;

	dwVal&=~EE_CS;
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=0,clk=1
	dwVal|=EE_CS;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=1

	//envia start bit e instrucao READ
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal|=EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal&=~EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=0
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal&=~EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=0
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1

	// envia endereco
	for (i=0;i<8;i++)
	{
		dwVal&=~EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
		if ((0xc0>>(7-i))&1)// enable write
			dwVal|=EE_DI;
		else
			dwVal&=~EE_DI;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=11000000
		dwVal|=EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	}
	dwVal&=~EE_CS;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//CS=0;
}

void Ewds_EEPROM(VLIB_HANDLE hPlx)
{
	int i;
	u32 dwVal;
	u32 dwCntrl;

    if(hPlx->PlxType == 0x9030)
      dwCntrl = VLIB_CNTRL;
    else
      dwCntrl = 0x6c;

	digivoice_sleep(1);

	dwVal = dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);

    if(hPlx->PlxType != 0x9030)
        dwVal &=~0x80000000;

	dwVal&=~EE_CS;
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=0,clk=1
	dwVal|=EE_CS;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	// CS=1

	//envia start bit e instrucao READ
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal|=EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=1
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal&=~EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=0
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	dwVal&=~EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
	dwVal&=~EE_DI;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=0
	dwVal|=EE_CLK;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1

	// envia endereco
	for (i=0;i<8;i++)
	{
		dwVal&=~EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=0
		dwVal&=~EE_DI;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//DI=00000000
		dwVal|=EE_CLK;
		dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
		dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//clk=1
	}
	dwVal&=~EE_CS;
	dgAPI_ReadDword (hPlx, VLIB_AD_BAR0, dwCntrl);
	dgAPI_WriteDword (hPlx, VLIB_AD_BAR0, dwCntrl, dwVal);	//CS=0;
}

short digivoice_resetcards(short card)
{
	Set_HCS(hPlxHandle[card-1]);
	Set_RESET(hPlxHandle[card-1]);
	Set_RESET2(hPlxHandle[card-1]);
	digivoice_sleep(200);
	Reset_RESET(hPlxHandle[card-1]);   //tira DSP do reset
	Reset_RESET2(hPlxHandle[card-1]); //tira framers do reset
	Reset_HCS(hPlxHandle[card-1]);

	return DG_EXIT_SUCCESS;
}
//-----------------
short digivoice_loadspecific(short card, char *szTemp, char *szFirmwareFile)
{
	int ret;
	short ct;
	u16 wReg=0;
	u16 wRetorno, w7600;
	int conta_loop;



	ct = card-1;
    write_debug("digivoice_loadspecific: Card %d Cardtype = %x - wReg=%d",ct, sm->Cards[ct].CardType, wReg);

	nCardNumberStartError=card;//set card number

	//load boot program
	ret=load1(szTemp,hPlxHandle[ct]);
	if (ret!=0)
		return ret;
	else
	{
		//test
		//write_debug("Vai testar placa tipo %x",hPlxHandle[ct]->CardType)
		ret=testeload1(szTemp,hPlxHandle[ct]);
		if (ret!=0)
		{
			write_debug("Erro carregando programa de boot");
			return ret;
		}
	}
	// read start address of boot program (0x101 was defined previously)
	Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)0x101);
	Placa_Ready(hPlxHandle[ct]);
	wReg=Placa_Read_Reg(hPlxHandle[ct], HPID);

	//runs boot program
	Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)0x61);
	Placa_Write_Reg(hPlxHandle[ct], HPID, wReg );
	Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)0x60);
	Placa_Write_Reg(hPlxHandle[ct], HPID, (u16)0x100);

	digivoice_sleep(200);

	//before load the program, reset ports_count address
	Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)NUMERO_CANAIS);
	Placa_Write_Reg(hPlxHandle[ct], HPID, 0);
	wReg = Placa_Read_Reg(hPlxHandle[ct], HPID);
	if (wReg!=0)
	{
		write_debug("digivoice_load_firmware: Card %d Cardtype = %x - wReg=%d",ct, sm->Cards[ct].CardType, wReg);
	}

	//load firmware
	write_debug("Placa %d Carregando %s ...",ct, szFirmwareFile);

	ret=load2(szFirmwareFile,hPlxHandle[ct]);
	write_debug("Placa %d Retorno de %s = %x...",ct, szFirmwareFile,ret);
	if (ret==0)
	{
		write_debug("Placa %d Vai testar firmware...",ct);
		ret = testeload2(szFirmwareFile,hPlxHandle[ct]);
		write_debug("Placa %d Testou com Retorno de = %x...",ct, ret);
		if (ret!=0)
			return ret;
	}
	else
		return ret;

    write_debug("digivoice_loadspecific: Placa %d - Firmware Carregado",ct);
	//start main program (firmware)
	Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)0x409);
	Placa_Write_Reg(hPlxHandle[ct], HPID, 0x0001 );
    write_debug("Placa %d Starting firmware OK...",ct);
    digivoice_sleep(800);
	//_count address
	Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)NUMERO_CANAIS);
	wReg = Placa_Read_Reg(hPlxHandle[ct], HPID);
    write_debug("Placa %d Checking channel number address...",ct);
	conta_loop = 10;
	while(wReg==0 && conta_loop>0)
	{
		Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)NUMERO_CANAIS);
		wReg = Placa_Read_Reg(hPlxHandle[ct], HPID);
		conta_loop--;
		write_debug("Placa %d Conta=%d...",ct, conta_loop);
		digivoice_sleep(20);
	}
    write_debug("Placa %d Checking channel number address...OK",ct);
	if (sm->Cards[ct].CardType==VB0408PCI || sm->Cards[ct].CardType==VB0408PCIE)
	{
		if (wReg!=4 && wReg!=8)
		{
			//erro indicando que leu o numero errado de canais
			Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)0x7600);
			w7600 = Placa_Read_Reg(hPlxHandle[ct], HPID);
			wRetorno = (w7600 << 8) | wReg;
			write_debug("Placa %d - Erro de carga... tentou ler %d vezes - %d wReg",ct,w7600,wReg);
			//return -(wRetorno);
			return DG_ERROR_READING_PORTCOUNT;
		}
		else
		{
			//erro indicando que leu o numero errado de canais
			Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)0x7600);
			w7600 = Placa_Read_Reg(hPlxHandle[ct], HPID);
			wRetorno = (w7600 << 8) | wReg;
			write_debug("Placa %d - CARREGOU LENDO %d vezes",ct,w7600);
		}
		conta_loop = 10;
		wReg = 0;
		//check if card is interrupting
		while (conta_loop>0)
		{
			if (Placa_Read_Reg(hPlxHandle[ct], HPIC)&0x4)//interrompeu
			{
				wReg++;
				Placa_Write_Reg(hPlxHandle[ct], HPIC, (u16)0x5);//ack
			}
			conta_loop--;
			digivoice_sleep(2);
		}
		write_debug("Placa %d - INTERROMPEU %d vezes",ct, wReg);


	}
    write_debug("Placa %d - Exiting digivoice_loadspecific...",ct);
    digivoice_sleep(100);
	return DG_EXIT_SUCCESS;
}


int digivoice_load_firmware(char *szFirmwarePath)
{
	int ret;
	unsigned short ct;
	short conta;
	short ports=0;
	char szFirmwareFile[DG_MAX_PATH];
	char szTemp[DG_MAX_PATH];
	int cards_count=0;


	write_debug("digivoice_configure: Step 1 Firmware Path %s",szFirmwarePath);

	//first try to find 9030 cards
	cards_count=dgAPI_LocateAndOpenBoard(0x10b5, 0x9030,0);
	sm->nCardsCount = cards_count;

    //then try 9056
    cards_count=dgAPI_LocateAndOpenBoard(0x10b5, 0x9056,cards_count);
    sm->nCardsCount += cards_count;

	write_debug("digivoice_configure: %d cards found- Firmware Path %s",sm->nCardsCount,szFirmwarePath);

	if (sm->nCardsCount<1)  //no cards found!
	{
		write_debug("digivoice_configure: Could not open boards");
		return DG_ERROR_MEMORY_ALLOCATION;
	}

	if (szFirmwarePath[0]==0)
	{
#ifdef WIN32
		SHGetSpecialFolderPath(NULL, szFirmwarePath, CSIDL_PROGRAM_FILES,FALSE);
		strcat(szFirmwarePath,"\\VoicerLib4");
#else
		write_debug("digivoice_configure: Firmware files not found!!!!");
		return DG_ERROR_FIRMWARE_NOT_FOUND;
#endif
	}
	write_debug("digivoice_configure: Firmware Path %s",szFirmwarePath);

	for (ct=1;ct<=sm->nCardsCount;ct++)
    {
		write_debug("digivoice_configure: Step 1 Resetting %d/%d....",ct,sm->nCardsCount);

		digivoice_resetcards(ct);

		/*Set_HCS(hPlxHandle[ct]);
		Set_RESET(hPlxHandle[ct]);
		Set_RESET2(hPlxHandle[ct]);
		digivoice_sleep(200);
		Reset_RESET(hPlxHandle[ct]);   //tira DSP do reset
		Reset_RESET2(hPlxHandle[ct]); //tira framers do reset
		Reset_HCS(hPlxHandle[ct]);*/

	}
	digivoice_sleep(300);

	for (ct=0;ct<sm->nCardsCount ;ct++)
	{

		//Le as informacoes da eeprom para ver o tipo de placa
		//hPlxHandle[ct]->CardType = Read_EEPROM(hPlxHandle[ct],EE_ID_DIGI);
		//sm->Cards[ct].CardType  = hPlxHandle[ct]->CardType;

		write_debug("digivoice_configure: Step 1 Loading card %d/%d....",ct+1,sm->nCardsCount);
		//Le as informacoes da eeprom para ver o tipo de placa
		if(hPlxHandle[ct]->PlxType == 0x9030)
			hPlxHandle[ct]->CardType = Read_EEPROM(hPlxHandle[ct],EE_ID_DIGI);
		else
			hPlxHandle[ct]->CardType = Read_EEPROM(hPlxHandle[ct],0x22);

		sm->Cards[ct].CardType  = hPlxHandle[ct]->CardType;


		/*Set_HCS(hPlxHandle[ct]);
		Set_RESET(hPlxHandle[ct]);
		Set_RESET2(hPlxHandle[ct]);
		digivoice_sleep(200);
		Reset_RESET(hPlxHandle[ct]);   //tira DSP do reset
		Reset_RESET2(hPlxHandle[ct]); //tira framers do reset
		Reset_HCS(hPlxHandle[ct]);*/

		//configura caracteristicas das placas novas
		//rv3
		switch(sm->Cards[ct].CardType)
		{
			case VBE13060PCI:
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e00.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boote1.i00");
				break;
			case VB0408PCI://placa vbox 4/8c - fxo
			case VB0408PCIE://placa vbox 4/8c - fxo				
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"vb00.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boot294.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
			case VBE13060PCI_R:
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e03.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boote1.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
			case VBE16060PCI:
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e05.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boot300.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
			case VBE16060PCI_R:
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e06.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boot300.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
            case VBE13030PCI:
                sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e07.i00");
                sprintf(szTemp,"%s/%s",szFirmwarePath,"boot300.i00");
                Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
                                                                // ordem de escrita dos bytes da HPI
                break;
			case VB0404FX://placa vbox 4c - fx
			case VB0404FX_R://placa vbox 4c - fx
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"vb01.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boot294.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
			case VB6060PCIE:
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e06.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boot300.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
            case VB3030PCIE:
                sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e07.i00");
                sprintf(szTemp,"%s/%s",szFirmwarePath,"boot300.i00");
                Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
                                                                // ordem de escrita dos bytes da HPI
                break;
            case VB0404GSM:
                sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"vb02.i00");
                sprintf(szTemp,"%s/%s",szFirmwarePath,"bootgsm.i00");
                Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
                                                                // ordem de escrita dos bytes da HPI
                break;
			case DGV_2E1F:
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e08.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boot308.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
			case DGV_1E1F:
				sprintf(szFirmwareFile,"%s/%s",szFirmwarePath,"e09.i00");
				sprintf(szTemp,"%s/%s",szFirmwarePath,"boot308.i00");
				Placa_Write_Reg(hPlxHandle[ct], HPIC, 0x0100);	// escreve invertido para alterar
																// ordem de escrita dos bytes da HPI
				break;
		}
		write_debug("load_firmware: Using boot %s and firmware %s", szTemp, szFirmwareFile);

		ret=DG_ERROR_READING_PORTCOUNT;
		conta = 10;
		while(ret==DG_ERROR_READING_PORTCOUNT && conta>0)
		{
			nCardNumberStartError=ct+1;//set card number

			ret = digivoice_loadspecific(ct+1, szTemp, szFirmwareFile);
			if (ret == DG_ERROR_READING_PORTCOUNT)
			{
				//reset card again
				write_debug("load_firmware: Falha na placa %d - tentativa %d", ct+1, ret);
				digivoice_resetcards(ct+1);
				digivoice_sleep(1000);
				conta--;
			}
		}

		if (ret!=0)  //podia haver retornos diferentes com erro que passavam como ok
			return ret;
		digivoice_sleep(100);

		write_debug("Placa %d - Carregou firmware...2",ct+1);

	} //for ct


	return DG_EXIT_SUCCESS;

}


//-------------------------------------------------------
//Insere os comandos da aplicacao para a placa
//-------------------------------------------------------
short InsereCmd_Tx(dg_cmd_tx *tmp)
{
	short card,card_channel;	//variables that will receive correct array position
	u16 ptrTemp;
	//insert received command into Tx FIFo
	if (tmp->port_or_card==ASSUME_PORT && tmp->port >= 0)
	{
		//transforma porta absoluta em placa/canal
		card = ports_info[tmp->port].card - 1;
		card_channel = ports_info[tmp->port].card_channel - 1;

		if ( (tmp->command == CMD_DETECTION_CFG) && (tmp->param1==CFG_DETECT_SILENCE))
		{
			//Caso especial - CMD_DETECTION_CFG com CFG_DETECT_SILENCE
			//a porta sera passada no segundo parametro
			tmp->param2 = (unsigned char)card_channel;

#ifdef DEBUG_LEVEL
				if (sm->Cards[card].debug_level > 1)
				{
					write_verbose("InsereCmd_Tx: Step 1.1 - [card %d, card_channel %d, param2 %d]", card, card_channel, tmp->param2);
				}
#endif//#ifdef DEBUG_LEVEL
		}
		else
		{
			//coloca no parametro 1 a porta em valores placa/canal
			tmp->param1 = (unsigned char)card_channel;
			
#ifdef DEBUG_LEVEL
				if (sm->Cards[card].debug_level > 1)
				{
					write_verbose("InsereCmd_Tx: Step 1.2 - [card %d, card_channel %d, param1 %d]", card, card_channel, tmp->param1);
				}
#endif//#ifdef DEBUG_LEVEL
		}
	}
	else
	{
		//the command doesn't uses port but is passed to indicates the correct card
		//to avoid conflicts is passed as a negative number
		card = (tmp->port) - 1;
		card_channel = 0;
		
#ifdef DEBUG_LEVEL
			if (sm->Cards[card].debug_level > 1)
			{
				write_verbose("InsereCmd_Tx: Step 1.3 - [card %d, card_channel %d]", card, card_channel);
			}
#endif//#ifdef DEBUG_LEVEL
	}

	//Calcula proximo item
	ptrTemp = sm->Cards[card].Fifo_Cmd_Tx.wp + (CMD_SIZE_TX+1);

	if (ptrTemp > (TAM_FIFO_CMD_TX-1))
	{
		ptrTemp = 0l;
	}
	//se o proximo item for diferente do buffer de retirada, entao pode inserir
	if (ptrTemp != sm->Cards[card].Fifo_Cmd_Tx.rp)
	{
		//insere
		sm->Cards[card].Fifo_Cmd_Tx.Cmd[ sm->Cards[card].Fifo_Cmd_Tx.wp ] = tmp->command;
		sm->Cards[card].Fifo_Cmd_Tx.Cmd[ sm->Cards[card].Fifo_Cmd_Tx.wp+1 ] = tmp->param1;
		sm->Cards[card].Fifo_Cmd_Tx.Cmd[ sm->Cards[card].Fifo_Cmd_Tx.wp+2 ] = tmp->param2;
		sm->Cards[card].Fifo_Cmd_Tx.Cmd[ sm->Cards[card].Fifo_Cmd_Tx.wp+3 ] = tmp->param3;

		sm->Cards[card].Fifo_Cmd_Tx.Cmd[ sm->Cards[card].Fifo_Cmd_Tx.wp+4 ] = tmp->param4;
		sm->Cards[card].Fifo_Cmd_Tx.Cmd[ sm->Cards[card].Fifo_Cmd_Tx.wp+5 ] = tmp->param5;
		sm->Cards[card].Fifo_Cmd_Tx.Cmd[ sm->Cards[card].Fifo_Cmd_Tx.wp+6 ] = TXContadorGlobal[card];

#ifdef DEBUG_LEVEL
			if (sm->Cards[card].debug_level > 1)
			{
				write_verbose("InsereCmd_Tx: Step 2.1 - Set parameters Fifo_Cmd_Tx - [card %d, command %x, param1 %x, param2 %x, param3 %x, param4 %x, param5 %x, TXContadorGlobal[card] %x, wp %d]",
	                          card, tmp->command, tmp->param1, tmp->param2, tmp->param3, tmp->param4, tmp->param5, TXContadorGlobal[card], sm->Cards[card].Fifo_Cmd_Tx.wp);
			}
#endif//#ifdef DEBUG_LEVEL
		
		TXContadorGlobal[card]++;
		//soma ponteiro de insercao
		sm->Cards[card].Fifo_Cmd_Tx.wp+=7;

		//faz buffer rodar
		if (sm->Cards[card].Fifo_Cmd_Tx.wp > (TAM_FIFO_CMD_TX-1))
		{
			sm->Cards[card].Fifo_Cmd_Tx.wp = 0l;
			
#ifdef DEBUG_LEVEL
				if (sm->Cards[card].debug_level > 1)
				{
					write_verbose("InsereCmd_Tx: Step 3 - Buffer reset - [card: %d]", card);
				}
#endif//#ifdef DEBUG_LEVEL
		}
		
		return 1;
	}
	else
	{
#ifdef DEBUG_LEVEL
			if (sm->Cards[card].debug_level > 1)
			{
				write_verbose("InsereCmd_Tx: Step 2.2 - Problems to insert Fifo_Cmd_Tx - [card: %d]", card);
			}
#endif//#ifdef DEBUG_LEVEL

		return 0;
	}
}


//-------------------------------------------------------
//Retira os comandos vindos da placa para a aplicacao
//-------------------------------------------------------
short RetiraCmd_Rx(short card,dg_signal_from_device *rxcmd)
{
/*	if (Finished)
		return -1;*/
#ifdef DEBUG_LEVEL	
		if (sm->Cards[card].debug_level > 4)
		{
			write_verbose("RetiraCmd_Rx: Step 1 - [card: %d]", card);
		}
#endif//#ifdef DEBUG_LEVEL
	
	digivoice_entercriticalsection(&event_mutex, 0);
	if (sm->Cards[card].Fifo_Cmd_Rx.rp != sm->Cards[card].Fifo_Cmd_Rx.wp)
	{

		//get all commands and insert into buffer to transfer to dsp
		//command
		rxcmd->command = (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp ];  //command;
		//do some handling to recognize port, card, alarms, an so on
		switch (rxcmd->command & 0x0ff)
		{
			case C_ERROR:
			case C_ERROR2:
			case C_ALARM:
			case C_FRAMER:
			case C_CTBUS:
			case C_ALARME_H100:
				rxcmd->port = card;
				rxcmd->data = (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1];
				rxcmd->data_aux = (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 2];

#ifdef DEBUG_LEVEL
					if (sm->Cards[card].debug_level > 4)
						write_verbose("RetiraCmd_Rx: Step 2 - command received - [card %d, port %x, data %x, data_aux %x]",
								      card, rxcmd->port, rxcmd->data, rxcmd->data_aux);
#endif//#ifdef DEBUG_LEVEL
				break;
			case C_INFO:
				rxcmd->port = sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1] - 1;//sub-command
				rxcmd->data = sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 2];
				rxcmd->data_aux = sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 3];
				break;
			default:

				if ((unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1] < sm->Cards[card].numchannels) //test port number
				{
					//write_debug("retira_rx: %d\n",(unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1]);
					rxcmd->port = reverse_ports[card][ (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1] ] - 1;
				}
				else
				{
					/*write_debug("retira_rx - else: sm->Cards[card].numchannels: card:%d cardtype: %x num_ch: %d - %d\n",card,
											sm->Cards[card].CardType,
											sm->Cards[card].numchannels,
											(unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1]);*/
					rxcmd->port = (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1];
				}
				/*if ((unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1] < MAX_CHANNELS_CARD) //test port number
					rxcmd->port = (u16)((unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1] + (card*sm->Cards[card].numchannels));
				else
					rxcmd->port = (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 1];*/

				rxcmd->data = sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 2];
				rxcmd->data_aux = sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 3];

				break;
		}

#ifdef _DEBUG
		if (ContadorGlobal[card]!=0)
		{
			if ( (ContadorGlobal[card]+1) != (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 4])
			{
				//write_debug("FIFO_RX _ ERRO (rp+4):%d contador global: %d rp: %d wp: %d",(unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 4 ],ContadorGlobal[card], sm->Cards[card].Fifo_Cmd_Rx.rp,sm->Cards[card].Fifo_Cmd_Rx.wp);				
			}
		}
		ContadorGlobal[card] = (unsigned short)sm->Cards[card].Fifo_Cmd_Rx.Cmd[ sm->Cards[card].Fifo_Cmd_Rx.rp + 4];
#endif
		//soma ponteiro de retirada
		sm->Cards[card].Fifo_Cmd_Rx.rp+= (CMD_SIZE_RX+1);   //numero de itens na fifo rx

		//faz buffer rodar
		if (sm->Cards[card].Fifo_Cmd_Rx.rp > (TAM_FIFO_CMD_RX-1))
			sm->Cards[card].Fifo_Cmd_Rx.rp = 0l;

		digivoice_leavecriticalsection(&event_mutex, 0);
		return 0;
	}
	else
	{
		digivoice_leavecriticalsection(&event_mutex, 0);
		return -1;
	}

}

//----------------------------------------------------------------------
// This function sends command to card based on tx_command struct
// It is suitable to all cards
//----------------------------------------------------------------------
void WCDECL write_generic_command(void *tx_command)
{
	//dg_event_data_structure received;

	dg_cmd_tx *tmp = (dg_cmd_tx *)tx_command;

//	write_debug("(%d) write_generic_command 1- cmd=%x - mutex handle=%x", tmp->port, tmp->command, &cmd_mutex);
	digivoice_entercriticalsection(&cmd_mutex, 0);
//	write_debug("(%d) write_generic_command 2- cmd=%x", tmp->port, tmp->command);
	if (InsereCmd_Tx(tx_command)==0)
	{
		//write_debug("(%d) write_generic_command 2,1 - cmd=%x", tmp->port, tmp->command);
		//tenta de novo, se nao der, gera erro
		if (InsereCmd_Tx(tx_command)==0)
		{
	//		write_debug("(%d) write_generic_command 2,2 ERROR 1 ", tmp->port);
			//gera evento de erro
			digivoice_leavecriticalsection(&cmd_mutex, 0);


			RaiseEvents_ThreadSafe(EV_ERRORDETECTED,ERROR_FIFO_FULL,0,1,&card_mutex[0]);
			/*received.command = EV_ERRORDETECTED;
			received.port = 1;	//crava sempre 1 pq este erro nao importa a porta/placa
			received.data = ERROR_FIFO_FULL;
			if (SendEventsToApp!=NULL)
				SendEventsToApp((void *)&received);*/

			write_debug("(%d) write_generic_command 2,2 ERROR 2 - cmd=%x", tmp->port, tmp->command);
		}
		else
			digivoice_leavecriticalsection(&cmd_mutex, 0);
	}
	else
	{
		//write_debug("(%d) write_generic_command 3- cmd=%x", tmp->port, tmp->command);
		digivoice_leavecriticalsection(&cmd_mutex, 0);
		//write_debug("(%d) write_generic_command 4- cmd=%x", tmp->port, tmp->command);
	}

#ifdef WIN32
	//debug options
	if (DebugEnabled)
		dg_write_sent_msg(tx_command );
#endif
}

//----------------------------------------------------------------------------------
// Set path, inodes, etc...
//----------------------------------------------------------------------------------
short WCDECL digivoice_configure(void)
{
 	int ports=0;
	u32 my_card;
	u16 ct;
	u16 card_type=0;
	u16 wReg;
	u16 nGlobalPort = 1;
	dg_cmd_tx tx_command_e1;

	for(my_card=0; my_card < sm->nCardsCount; my_card++)
	{
		//Le as informacoes da eeprom para ver o tipo de placa
		if(hPlxHandle[my_card]->PlxType == 0x9030)
			card_type = Read_EEPROM(hPlxHandle[my_card],EE_ID_DIGI);
		else
			card_type = Read_EEPROM(hPlxHandle[my_card],0x22);

		sm->Cards[my_card].CardType = card_type;		//save information
		hPlxHandle[my_card]->CardType = card_type;	//in both structures

		write_debug("digivoice_configure: Card %d Cardtype = %x",my_card,card_type);

#ifdef __LINUX__
			write_debug("digivoice_configure: reset dgdummy_interrupt flag on Card %d", my_card);
			sm->Cards[my_card].dgdummy_interrupt = 0;//reset flag
#endif//#ifdef __LINUX__
		sm->Cards[my_card].debug_level = 0;//reset debug level

		//wait for ports > 0
		wReg = 0;

		//while (wReg == 0)
		//{
		digivoice_sleep(1500);

		if (card_type == VB0404GSM)
			digivoice_sleep(200);

		Placa_Write_Reg(hPlxHandle[my_card], HPIA, (u16)NUMERO_CANAIS);
		wReg = Placa_Read_Reg(hPlxHandle[my_card], HPID);
		digivoice_sleep(10);
		//}

		switch (card_type)
		{
			case VBE13060PCI:			//E1 3060 rv2
			case VBE13060PCI_R:			//E1 3060 rv3
            case VBE16060PCI:
            case VBE13030PCI:
			case VBE16060PCI_R:
			case VB3030PCIE:
			case VB6060PCIE:
			case DGV_2E1F:
			case DGV_1E1F:
				//TODO: aqui devera ver qtos canais tem cada placa
				//atraves da funcao dg_GetCardPortsCount
				if (force_all_single_span)
				{
					wReg = 1;
					//send command to allow single span only
					//send commands
					tx_command_e1.command = CMD_LIU;
					//set values
					tx_command_e1.port_or_card = ASSUME_CARD;
					tx_command_e1.port = (char)(my_card+1);
					tx_command_e1.param1 = 1; //--- force 1 span
					tx_command_e1.param2 = 0;
					tx_command_e1.param3 = 0;
					tx_command_e1.param4 = 0;
					tx_command_e1.param5 = 0;

					write_generic_command(&tx_command_e1);


				}
				ports += 30 * wReg;
				sm->Cards[my_card].numchannels = 30 * wReg;

				break;
			case VB0408PCI:
			case VB0408PCIE:
				sm->Cards[my_card].numchannels = wReg;
				ports += wReg;
				break;
			case VX5502PCI:
				ports = 0;
				break;
			case VB0404FX:
			case VB0404FX_R:
				sm->Cards[my_card].numchannels = wReg;
				ports += wReg;
				break;
			case VB0404GSM:
				if (wReg > 4)
				{
					write_debug("digivoice_configure: error reading ports count old %d (new %d)", wReg, 0);
					wReg = 0;
				}
				sm->Cards[my_card].numchannels = wReg;
				ports += wReg;
				break;
		} //case
		write_debug("digivoice_configure: numchannels: %d (%d)",sm->Cards[my_card].numchannels,wReg);

		//after setting shared memory informations, fill ports_info structure
		//with default values
		for (ct = nGlobalPort; ct < (nGlobalPort+sm->Cards[my_card].numchannels); ct++)
		{
			ports_info[ct-1].card = my_card + 1;
			ports_info[ct-1].card_channel = (ct - nGlobalPort) + 1;
			//ports_info[ct-1].FCardType = card_type;
			//reverse search - based on card/card_channel retrieves the abs number
			reverse_ports[my_card][ports_info[ct-1].card_channel - 1] = ct;
			sm->Cards[my_card].abs_port[ports_info[ct-1].card_channel-1] = ct;

			ports_info[ct-1].target_port = ct;

			write_debug("digivoice_configure: port:%d card:%d ch:%d",ct,my_card,(ct - nGlobalPort) + 1);
		}
		//save last port
		nGlobalPort = ct;

	} //for my_card
	return ports;
}

//reads from a DSP memory position

short dg_ReadMemory(short card, short addr)
{
	int ret;
    short ct;

	u16 wReg=0;
    ct = card-1;

    // read
    Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)addr);
    Placa_Ready(hPlxHandle[ct]);
    wReg=Placa_Read_Reg(hPlxHandle[ct], HPID);

    return wReg;
}

//writes in a DSP memory position and reads what has been written

short dg_WriteMemory(short card, short addr, short value)
{
	short ct;
	ct = card-1;

    //write
    Placa_Write_Reg(hPlxHandle[ct], HPIA, (u16)addr);
    Placa_Write_Reg(hPlxHandle[ct], HPID, value );

	return dg_ReadMemory(card, addr);

}


#ifdef __LINUX__
	//----------------------------------------------------------------------------------
	// Set the card will send zt_receive and zt_transmit to Asterisk
	//----------------------------------------------------------------------------------
	short WCDECL digivoice_setdgdummycardinterrupt(void)
	{
		u32 my_card;
		int set_card;

		sm->Cards[0].dgdummy_interrupt = 1;//set the first card to send Asterisk information
		set_card = 0;

		for (my_card=1; my_card < sm->nCardsCount; my_card++)
		{
			if (sm->Cards[my_card].numchannels > sm->Cards[set_card].numchannels)
			{
				sm->Cards[set_card].dgdummy_interrupt = 0;
				sm->Cards[my_card].dgdummy_interrupt = 1;//set another one to send Asterisk information
				set_card = my_card;
			}
		} //for (my_card=0; my_card < sm->nCardsCount; my_card++)

		return set_card;
	}
#endif//#ifdef __LINUX__

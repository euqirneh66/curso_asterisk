
/************************************************************************************
 *                                                                         			*
 *   VoicerLib - Windows/Linux Version                                     			*
 *                                                                          		*
 *   Copyright (c) 2007-2010 Digivoice Tecnologia em Eletrônica Ltda     			*
 *                                                                         			*
 *   Module: R2 protocol                                                            *
 *                                                                         			*
 *   Description: Implements R2  protocol                                           *
 *                                                                         			*
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                         			*
 *   This library is free software; you can redistribute it and/or					*
 *   modify it under the terms of the GNU Lesser General Public						*
 *   License as published by the Free Software Foundation; either					*
 *   version 2.1 of the License, or (at your option) any later version.				*
 *   																				*
 *   This library is distributed in the hope that it will be useful,				*
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of					*
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU				*
 *   Lesser General Public License for more details.								*
 *   																				*
 *   You should have received a copy of the GNU Lesser General Public				*
 *   License along with this library; if not, write to the Free Software			*
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *
 *           																		*
 ************************************************************************************/

#include "voicerlib.h"

#include "e1.h"

#ifdef __LINUX__
	#include <assert.h>
	#include <unistd.h>
	#include <stdarg.h>
	#include <stdlib.h>
	#include <stdio.h>
	#include <string.h>
#endif

#ifdef __LINUX__
	extern void write_debug(char *fmt, ...);
	extern int set_e1_timeout(int port, int t);
#endif

//extern DIGIVOICE_CRITICAL_SECTION mtx_insert_to_e1;

#ifdef WIN32

	#ifdef _DEBUG
	//------------------------------------------------------------------------
	// inline function - write to log file: e1-(port).log
	//------------------------------------------------------------------------
	__forceinline int __cdecl write_debug_cb(short port,const char *s, ...)
	{
		FILE *pdebug;
		time_t curSecs;
		struct tm *now_dbg;
		char szTemp[200];
		char szFileName[200];
		va_list argp;
		int retval=0;

		//if (port < 30 || port > 42) return 0;

		curSecs = time(NULL);
		now_dbg = localtime(&curSecs);
		sprintf(szTemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);

	    va_start(argp, s);
		sprintf(szFileName,"c:\\log\\cb-%d.log",port);
		pdebug=fopen(szFileName,"a+");
		if (pdebug!=NULL)
		{
			fprintf(pdebug,"%s-",szTemp);
			retval = vfprintf( pdebug, s, argp);
			fprintf(pdebug,"\n");
	        //let somebody else do the work
			fclose(pdebug);
		}
		va_end(argp);

		return retval;
	}
	#else
	__forceinline void __cdecl write_debug_cb(short port,const char *s, ...)
	{
	}
	#endif
#else
	//LINUX

	#ifdef DEBUG
		void write_debug_cb(short port,char *fmt, ...)
		{

			va_list argptr;
			int     ret;
			FILE    *f;
			time_t curSecs;
			struct tm *now_dbg;
			char szdbgtemp[200];
			char szFileName[200];

			curSecs = time(NULL);				\
			now_dbg = localtime(&curSecs);	\
			sprintf(szdbgtemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);						\

			va_start(argptr, fmt);
			sprintf(szFileName,"/var/log/voicerlib/cb-%d.log",port);
			f = fopen(szFileName, "a+");
			fprintf(f,"%s-",szdbgtemp);
			ret = vfprintf(f,fmt,argptr);
			fprintf(f,"\n");
			fclose(f);
			assert(ret != 0);

			va_end(argptr);
		}
	#else

		void write_debug_cb(short port,char *fmt, ...)
		{
		}
	#endif

#endif	//win32



//------------------------------------------------------------------------
// inline function to end a call and set as free
//------------------------------------------------------------------------
__forceinline int __cdecl end_release(short port, short end_call, int *r2_step)
{
	digivoice_entercriticalsection(&port_mutex[port-1], port);
		// releases port
		dg_SendR2Command(port, R2_IDLE);
		if (end_call)
        {
            write_debug_cb(port,"r2: (%d) end_release - enviando C_ENDCALL",port);
			dg_InsertE1Fifo(port,C_ENDCALL,0);
        }
	digivoice_leavecriticalsection(&port_mutex[port-1], port);

	set_e1_timeout(port,0);
	*r2_step=P_R2_LIVRE;
	return 0;
}

//------------------------------------------------------------------------
// inline function to end a call and wait till called line is free
//------------------------------------------------------------------------
__forceinline int __cdecl end_wait_release(short port, short end_call, int *r2_step)
{
	digivoice_entercriticalsection(&port_mutex[port-1], port);
		// release port
		dg_SendR2Command(port, R2_IDLE);
		if (end_call)
			dg_InsertE1Fifo(port,C_ENDCALL,0);

		//chama habilita pra receber novamente o R2
		dg_SendR2Command(port,R2_ENABLE);

	digivoice_leavecriticalsection(&port_mutex[port-1], port);
	set_e1_timeout(port,0);
	*r2_step=P_R2_AGUARDA_LIVRE;

	return 0;
}

/*
//------------------------------------------------------------------------
// function to set a port timeout
//------------------------------------------------------------------------
int set_e1_timeout(int port, int t)
{
 int ret;
 digivoice_entercriticalsection(&port_mutex[port-1], port);
 	tmr_E1[port-1].Enabled = FALSE;
 	SetEnableTimer(&tmr_E1[port-1],FALSE);
 	tmr_E1[port-1].Interval = t / FACTOR_TIMER;

 	if (t!=0)
 	{
		ret = (int)SetEnableTimer(&tmr_E1[port-1],TRUE);
		tmr_E1[port-1].Enabled = TRUE;
 	}
 	else
		ret = -1;

 digivoice_leavecriticalsection(&port_mutex[port-1], port);
 write_debug_e1(port,"SetTimeout handle %d com tempo %d",ret,t);
 return ret;
}
*/

//------------------------------------------------------------------------
// Thread function to signal in E1 cards
//------------------------------------------------------------------------
void Signal_CB_Thread(void *signal_e1_info)
{
 dg_signal_e1_thread_structure *e1;
 dg_event_data_structure 	e1_events;

#ifdef __LINUX__
 int fifo_rx;
 int fifo_to_ctrl;
#else
 HANDLE fifo_rx;
 u32 cbBytesRead;
#endif

 int r2_step=P_R2_LIVRE;
 int line_state=OFF;
 int blocked_event=0;
 short end_action = EA_NONE;		//flag indicando que gera
 int entrante=0;
 int timeout=0;
 int tmr_h;
 int retencao=OFF;
 int tmr_ha=0;  //timeout de atendimento
 int trata_r2=0;
 int r2i,r2o;
 int flash_rec=0;

    e1 = (dg_signal_e1_thread_structure *)signal_e1_info;


    // force one signal change to wakeup some switches (trick)
    r2i=R2_IDLE;
    r2o=dg_SendR2Command(e1->port, R2_IDLE);
    digivoice_sleep(500);

    r2o=dg_SendR2Command(e1->port, R2_BLOCKED);
    digivoice_sleep(1000);

    r2o=dg_SendR2Command(e1->port, R2_IDLE);

    //reset timer
    tmr_h=set_e1_timeout(e1->port, 0);

#ifdef __LINUX__
    fifo_rx = open(e1->szFifoToE1,O_RDONLY);
    if (fifo_rx==0)
    {
		//error opening fifo
		write_debug_cb(e1->port,"Error openning fifo....");
    }
#endif


#ifdef WIN32
	fifo_rx	= CreateFile(e1->szFifoToE1, GENERIC_READ | GENERIC_WRITE,
							0,	NULL, OPEN_EXISTING, 0,NULL);
#endif

    e1->enabled = 1;

    //enables DTMF detection
    dg_SetDetectionType(e1->port, DETECT_DTMF, DG_ENABLE);

    while(1)
    {

        //get and process fifo events
#ifdef __LINUX__
	   read(fifo_rx,&e1_events,sizeof(e1_events));
#else
	   //windows
	   WaitForSingleObject(e1->oOverlapE1.hEvent,INFINITE);
	   ReadFile(fifo_rx,                // handle to pipe
				&e1_events,             // buffer to receive data
				sizeof(e1_events),      // size of buffer
				&cbBytesRead,           // number of bytes read
				&e1->oOverlapE1);       // not overlapped I/O
#endif
	   //reset values
	   timeout = 0;
	   trata_r2=0;

        //terminates thread
	   if (e1_events.command == C_ENDTHREAD)
	   {
	 		//cancel thread execution
			write_debug_cb(e1->port,"Ending CB thread...");
			break;
	   }


	   switch(e1_events.command)
	   {
			case C_CAS:
				//force 01 in bits 0 and 1 ( c & d)
				r2i = (e1_events.data | 0x1) & 0xd;
                write_debug(">>r2                                                                                                   %x",r2i);
				trata_r2=1;
				break;

			case C_RESET_THREAD:
				//reset thread
				write_debug_cb(e1->port,"CB RESET");
				entrante=0;
				line_state = OFF;
				r2i=R2_IDLE;
				r2_step = P_R2_LIVRE;
				tmr_h=set_e1_timeout(e1->port,0);/*aaa*/
				if (e1->bAtendido != OFF)
				{
					RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
					RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
				}
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
					trata_r2=0;
					e1->bAtendido = OFF;
					tmrRing[e1->port-1].Enabled = FALSE;
					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				break;

			case C_CALLPROGRESS:
				if (!e1->bAtendido)
				{
					//reenables it
					tmrCallProgress[e1_events.port-1].Interval = 5000 / FACTOR_TIMER;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],TRUE);
					tmrCallProgress[e1_events.port-1].Enabled = TRUE;
				}
				else
				{
					//desables it
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
				}
				break;

			case C_RING:
				if (e1->ring_event==1)
				{
                   if (e1->ring_generate_ringback)
                      dg_GenerateMF(e1->port,GENERATE_TONE1,0);
                   e1->ring_event=0;
				   tmrRing[e1->port-1].Interval = 1000 / FACTOR_TIMER;
				   SetEnableTimer(&tmrRing[e1->port-1],TRUE);
				   tmrRing[e1->port-1].Enabled = TRUE;
				   write_debug_cb(e1->port,"cb: RING ON");
				}
				else
                if(e1->ring_event==0)
				{

                   if (e1->ring_generate_ringback)
                       dg_GenerateMF(e1->port,GENERATE_OFF,0);

                   tmrRing[e1->port-1].Interval = 4000 / FACTOR_TIMER;
				   SetEnableTimer(&tmrRing[e1->port-1],TRUE);
				   tmrRing[e1->port-1].Enabled = TRUE;
				   e1->ring_event=1;
                   RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, e1_events.port,&port_mutex[e1->port-1]);
				   write_debug_cb(e1->port,"cb: RING OFF");
				}
				break;

			case CPICKUP:
				write_debug_cb(e1->port,"e1 (%d): Pickup - r2_Step=%d",e1_events.port,r2_step);

					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					{
					   //get r2 state
                       dg_SendR2Command(e1->port,R2_ENABLE);
					   tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					   SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
					}
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

					write_debug_cb(e1->port,"cb (%d): CPICKUP",e1_events.port);
					line_state = ON;	//r2 state-machine
					trata_r2=1;
					end_action = EA_NONE;
				break;

			case CHANGUP:
				write_debug_cb(e1->port,"(%d)ctrl: Hangup com entrante=%d e r2i=%d",e1_events.port,entrante,r2i);

				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					//cancela ring
					e1->ring_event = 99;
					//turn off timers (RING and CallProgress)
					tmrRing[e1->port-1].Enabled = FALSE;
					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				//if (entrante)
				if (ports_info[e1->port-1].idle_info.thread_id > 0)
				{
					write_debug_cb(e1->port,"r2: (%d) CHANGUP- sending EV_LINEOFF",e1->port);
					//Idle thread is running, then send commands to it
					dg_InsertIdleFifo(e1->port, EV_LINEOFF, HOOK_ON);
				}
				
				if(r2i!=R2_IDLE)
				{
					RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
					set_e1_timeout(e1->port,0);/*aaa*/

					// release channel
					if (entrante==1 && r2_step==P_R2_ATENDIDO_ENTRANTE && ports_info[e1->port-1].e1_info.sigtype != R2_TYPE_CB_FXO)
					{
						write_debug_cb(e1->port,"cb: Hangup Entrante - Desliga pra tras");
					}
					else
					{
						write_debug_cb(e1->port,"cb: Hangup Sainte - Manda livre");
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						  dg_SendR2Command(e1->port, R2_IDLE);
						  r2_step=P_R2_AGUARDA_LIVRE;
						  //get r2 state
						  dg_SendR2Command(e1->port,R2_ENABLE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					}
				}
				else
				{
					end_release(e1->port,0, &r2_step);
				}
				entrante = 0;
				line_state = OFF;
				trata_r2=1;
				e1->bAtendido = OFF;
				end_action = EA_NONE;
				break;

			case CFLASH:
				write_debug_cb(e1->port,"(%d)ctrl: Flash com entrante=%d e r2i=%d",e1_events.port,entrante,r2i);
				
		
		
				
				
/*				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					//cancela ring
					e1->ring_event = 99;
					//turn off timers (RING and CallProgress)
					tmrRing[e1->port-1].Enabled = FALSE;
					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);*/

/*				if (ports_info[e1->port-1].idle_info.thread_id > 0)
				{
					write_debug_cb(e1->port,"r2: (%d) CHANGUP- sending EV_LINEOFF",e1->port);
					//Idle thread is running, then send commands to it
					dg_InsertIdleFifo(e1->port, EV_LINEOFF, HOOK_ON);
				}*/
				
//				if(r2i!=R2_IDLE)
//				{
//					RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
					tmr_h=set_e1_timeout(e1->port,0);  //timer off

					// release channel
//					if (entrante==1 && r2_step==P_R2_ATENDIDO_ENTRANTE)
					{
						write_debug_cb(e1->port,"cb: Flash Entrante - Desliga pra tras");

						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						
						r2_step=P_R2_BLOQUEANDO_DDC;
					}
/*					else
					{
						write_debug_cb(e1->port,"cb: Hangup Sainte - Manda livre");
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						  dg_SendR2Command(e1->port, R2_IDLE);
						  r2_step=P_R2_AGUARDA_LIVRE;
						  //get r2 state
						  dg_SendR2Command(e1->port,R2_ENABLE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					}*/
/*				}
				else
				{
					end_release(e1->port,0, &r2_step);
				}
				entrante = 0;
				line_state = OFF;
				trata_r2=1;
				e1->bAtendido = OFF;
				end_action = EA_NONE;				
				
				*/
				
				
				
				break;
				
			case C_ENDCALL:
    				e1->bAtendido = OFF;
    				write_debug_cb(e1->port,"(%d) ctrl: Ligacao Finalizada",e1_events.port);
    				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
    					//desabilita timer de ligacao sainte
    					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
    					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
    					//cancela geracao de tons
    					e1->ring_event = 99;
    					tmrRing[e1->port-1].Enabled = FALSE;
    					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
    				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

    				//chama funcao que libera tudo - com timeout
    				end_wait_release(e1->port,0,&r2_step);
    				tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);

    				RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
    				RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
    				end_action = EA_NONE;

				break;
			case C_SEIZURE:
				trata_r2=1;
				break;

			//----------------------------------------------------
			//Commands received from application
			//----------------------------------------------------
			case C_TIMEOUT:	//recebido do timer
				timeout = (int) e1_events.data;
				write_debug_cb(e1->port,"cb (%d): C_TIMEOUT com dado %d - r2i=%x r2step=%x ",e1->port,timeout,r2i,r2_step);
				//seta flag para tratar maquinas de estado
				trata_r2=1;
				break;
	 } //switch(e1_events.command)

   /******************* trata sinalizacao de linha **********************/
   if (trata_r2)
   {
	  write_debug_cb(e1->port,"cb (%d): r2i = %x   r2_step = %x",e1->port,r2i,r2_step);
	  switch (r2_step)
	  {
		case P_R2_AGUARDA_LIVRE:
			if (timeout!=tmr_h)
			{
				switch(r2i)
				{
					case R2_IDLE:
						entrante=0;
						RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_E1_IDLE,  0,e1->port,&port_mutex[e1->port-1]);
						r2_step=P_R2_LIVRE;
						blocked_event = 0;
                        dg_SendR2Command(e1->port, R2_IDLE);
                        tmr_h=set_e1_timeout(e1->port,0); //turnoff timer
                        line_state = OFF;
						break;

					case R2_BLOCKED:
						if (line_state==ON)
						{
							if (blocked_event==0)
							{
								RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
								RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_UNAVAILABLE,  0,e1_events.port,&port_mutex[e1->port-1]);
								blocked_event = 1;
							}
							else
								blocked_event = 0;
						}
						break;

				}
			}
			else
			{
				//finaliza mandando bloqueio, aguardando 2 segundos e depois livre
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_BLOCKED);
					//chama habilita pra receber novamente o R2
					dg_SendR2Command(e1->port,R2_ENABLE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				digivoice_sleep(2000);

				end_release(e1->port,0,&r2_step);
				line_state = OFF;
			}
		  break;

		case P_R2_LIVRE:
			switch(r2i)
			{
				case R2_IDLE:
				    //received line_state==ON from application ->outgoing call
					if (line_state==ON)
					{
						retencao=OFF; //controled by caller

                        //send seizure
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							r2o=dg_SendR2Command(e1->port, R2_SEIZURE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

						write_debug_cb(e1->port,"cb (%d): Send R2_SEIZURE and set timeout = %d",e1->port,e1->timeout_ocupacao);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_ocupacao);//start timer - timeout 7s
						r2_step=P_R2_CONFIRMAOCUPACAO;
					}
					break;

				case R2_SEIZURE:  //signal from card -> incoming call
					//C_SEIZURE
					entrante = 1;
					e1->ring_event = 99;


                    //CODIGO do P_R2_ENVIA_CONFIRMACAO
                    write_debug_cb(e1->port,"r2 : P_R2_ENVIA_CONFIRMACAO");

                    //some pbx need some time to allow them to recognize seizure ack, then we'll wait 100ms here
                    digivoice_sleep(20);    //changed to fit standards

                    //send seizure ack
                    digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
                         r2o=dg_SendR2Command(e1->port, R2_SEIZURE_ACK);
                    digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

					RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_SEIZURE,  0,e1_events.port,&port_mutex[e1->port-1]);
					RaiseEvents_ThreadSafe(EV_LINEREADY     , 0        ,  0,e1_events.port,&port_mutex[e1->port-1]);
					trata_r2=1;
					
					digivoice_sleep(20);

					write_debug_cb(e1->port,"r2 (%d): P_R2_ENVIA_CONFIRMACAO - CHANNEL BANK",e1->port);
					r2_step=P_R2_AGUARDA_ATENDIMENTO;

					break;

				case R2_ANSWERED:
				case R2_BLOCKED:
					//TODO: Verificar como evitar de gerar duas vezes seguidas
					if (line_state==ON)
					{
						//to avoid r2 dead lock, send a blocked, wait and send idle
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							r2o=dg_SendR2Command(e1->port, R2_BLOCKED);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

						digivoice_sleep(2000);

						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							r2o=dg_SendR2Command(e1->port, R2_IDLE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

						if (blocked_event==0)
						{
							RaiseEvents_ThreadSafe(EV_BUSY          ,0             ,  0,e1_events.port,&port_mutex[e1->port-1]);
							RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_UNAVAILABLE,  0,e1_events.port,&port_mutex[e1->port-1]);
							blocked_event = 1;
						}
						else
							blocked_event = 0;

					}
					break;
			}//switch
			break;

	/*******************  outgoing call **********************/

		case P_R2_CONFIRMAOCUPACAO: //ligacao sainte
			write_debug_cb(e1->port,"P_R2_CONFIRMAOCUPACAO - linestate=%d timeout=%d tmr_h=%d r2=%x",line_state,timeout,tmr_h,r2i);

			if (timeout==tmr_h) //wait for seisure ack - test timeout
			{
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_UNAVAILABLE,  0,e1_events.port,&port_mutex[e1->port-1]);

				r2_step=P_R2_LIVRE;
				blocked_event = 0;
				line_state = OFF;
				write_debug_cb(e1->port,"P_R2_CONFIRMAOCUPACAO - TIMEOUT");
			}
			else
			{
				if (line_state==OFF)//outgoing call linestate should be on
				{
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_IDLE);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					r2_step=P_R2_LIVRE;
					blocked_event = 0;
				}
				else
				{
					switch(r2i)
					{

						case R2_IDLE:         //it is already idle
							break;

						case R2_ANSWERED:     //should never happen
						case R2_SEIZURE:      //doble seizure
							tmr_h=set_e1_timeout(e1->port,0);

                            //sleeps 100ms , wait the other part to be available to
                            //understand the new r2 status
                           digivoice_sleep(20);	//changed to fit standards

							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								tmrCallProgress[e1->port-1].Enabled = FALSE;
								SetEnableTimer(&tmrCallProgress[e1->port-1],FALSE);
								dg_SendR2Command(e1->port, R2_ENABLE);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

							// generate BUSY event wait for idle
							RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1->port,&port_mutex[e1->port-1]);
                            tmr_h=set_e1_timeout(e1->port,120000); //2min to wait
							r2_step=P_R2_AGUARDA_LIVRE;
						break;

						case R2_SEIZURE_ACK:
							tmr_h=set_e1_timeout(e1->port,0);  //timer off

//							RaiseEvents_ThreadSafe(EV_DIALTONE, 0,  0,e1->port,&port_mutex[e1->port-1]);
							RaiseEvents_ThreadSafe(EV_LINEREADY, 0,  0,e1->port,&port_mutex[e1->port-1]); //fxs simulation
							RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_E1_SEIZURE_ACK,  0,e1_events.port,&port_mutex[e1->port-1]);

							write_debug_cb(e1->port,"e1: (%d) Received seizure ack ",e1->port);
							r2_step=P_R2_DISCANDO;

							//reset answer timeout (or set timeout value?????)
							tmr_ha = -1;
							break;
					}

				}
			}
			break;

		case P_R2_DISCANDO: //ligacao sainte

			//**** colacar timeout atendimento iniciado no MFC
			if (timeout != tmr_ha)
			{
				if (line_state==OFF)
				{
					// termina
					end_wait_release(e1->port,0, &r2_step);
					tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					write_debug_cb(e1->port,"e1: P_R2_DISCANDO - Channel released");
				}
				else
				{
					//write_debug_cb(e1->port,"e1: P_R2_DISCANDO - ELSE - VAI ACIONAR SWITCH");
					write_debug_cb(e1->port,"e1: P_R2_DISCANDO - received R2=%d",r2i);
					switch(r2i)
					{
						case R2_SEIZURE_ACK:   //trocando sinalizacao entre registradores
								break;
						case R2_SEIZURE: // nao deve acontecer
								write_debug_cb(e1->port,"e1: P_R2_DISCANDO - Invalid seizure!");
 								end_wait_release(e1->port,0, &r2_step);
								tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);

								//events to application
								RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NOTCOMPLETED,  0,e1->port,&port_mutex[e1->port-1]);
								RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1->port,&port_mutex[e1->port-1]);
								break;
						case R2_IDLE:
								write_debug_cb(e1->port,"e1: P_R2_DISCANDO - R2_IDLE");
								end_release(e1->port,0,&r2_step);

								//events to application
								RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NOTCOMPLETED,  0,e1->port,&port_mutex[e1->port-1]);
								RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1->port,&port_mutex[e1->port-1]);
								break;

						case R2_ANSWERED:
								write_debug_cb(e1->port,"e1: P_R2_DISCANDO - R2_ANSWEREDOC");

									// gerar evento ATENDEU
									e1->bAtendido = ON;  //set flag to answered

									digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
										tmrCallProgress[e1_events.port-1].Enabled = FALSE;
										SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
									digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

									//4.0.3 - generate this event too
									RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_ANSWERED,  0, e1->port,&port_mutex[e1->port-1]);
									RaiseEvents_ThreadSafe(EV_ANSWERED, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
									if (!entrante)
										RaiseEvents_ThreadSafe(EV_LINEREADY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);

									r2_step=P_R2_ATENDIDO_SAINTE;
									flash_rec = 0;
									tmr_h=set_e1_timeout(e1->port,0);//disable timeout
								break;
						}//switch r2
						//write_debug_cb(e1->port,"e1: P_R2_DISCANDO - SAIU DO SWITCH com r2_step=%x",r2_step);
					}
			}
			else
			{
				//answer timout
				write_debug_cb(e1->port,"cb: ANSWER TIMEOUT DURANTE P_R2_DISCANDO");

				// release channel
				end_wait_release(e1->port,0, &r2_step);
				tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);

				//raise busy event
				RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NOTCOMPLETED, 0, e1->port,&port_mutex[e1->port-1]);
				line_state = OFF;

			}
			break;

		case P_R2_ATENDIDO_SAINTE: //outgoing call - answered
			if(timeout != tmr_h)
			{
				if (line_state==OFF)
				{
					write_debug_cb(e1->port,"ATENDIDO_SAINTE: line_state=off");
					e1->bAtendido = OFF;

					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					   r2o=dg_SendR2Command(e1->port, R2_IDLE);
					   dg_SendR2Command(e1->port, R2_ENABLE);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

					r2_step=P_R2_AGUARDA_LIVRE;
					tmr_h=set_e1_timeout(e1->port,0);  //timer off
				}
				else
				{
					write_debug_cb(e1->port,"ATENDIDO_SAINTE: r2i=%d",r2i);
					switch(r2i)
					{
						case R2_CLEAR_BACK:
							if (retencao==ON)//controle do assinante chamado
							{
								digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
									r2o=dg_SendR2Command(e1->port, R2_IDLE);
									dg_SendR2Command(e1->port, R2_ENABLE);
									dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
								digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

								r2_step=P_R2_AGUARDA_LIVRE;
								// gerar evento LIGACAO ENCERRADA

								line_state = OFF;
							}
							else
							{
								//start timer - timeout 800ms
								if (tmr_h==-1)
								{
									tmr_h=set_e1_timeout(e1->port, 800);
								    write_debug_cb(e1->port,"ATENDIDO_SAINTE: flash timer - tmr_h = %d",tmr_h);
									flash_rec = 1;
								}
							}
							break;

						case R2_ANSWERED:
							/* Retornou */
							tmr_h=set_e1_timeout(e1->port,0);
							if (flash_rec == 0)
							{
							     RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_ANSWERED,  0, e1->port,&port_mutex[e1->port-1]);
							}
                            else
                            {   //re-answered before 800ms, Flash
                                flash_rec = 0;
							    RaiseEvents_ThreadSafe(EV_FLASH, 0,  0, e1->port,&port_mutex[e1->port-1]);
                            }
							break;

						case R2_BACKWARD_DISCONNECTION:
						case R2_IDLE:
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							// release channel
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								// gerar evento LIGACAO ENCERRADA
								dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

							r2_step=P_R2_LIVRE;
							line_state = OFF;
							blocked_event = 0;
                            flash_rec = 0;
							break;

					}
				}
			}
			else
			{
              //if(flash_rec ==0)
              {
				//CLEAR BACK timeout
				// release channel
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
					dg_SendR2Command(e1->port, R2_ENABLE);
					// gerar evento LIGACAO ENCERRADA
					dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				r2_step=P_R2_AGUARDA_LIVRE;
				line_state = OFF;
			  }
			  /*else
			  { //start clear back timer

				//timeout 90s
				write_debug_cb(e1->port,"ATENDIDO_SAINTE: flash timer - tmr_h = %d",tmr_h);
				if (tmr_h==-1)
				{
					tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao);
					flash_rec = 0;
					// gerar evento B DESLIGOU
					RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_B_ENDCALL,  0, e1->port,&port_mutex[e1->port-1]);
				}
              }*/
			}
			break;

		case P_R2_AGUARDA_ATENDIMENTO: //recebido aplicacao

			if (line_state==ON)
			{
				e1->bAtendido = ON;
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
				    //cancel ring
				    e1->ring_event = 99;
				    tmrRing[e1->port-1].Enabled = FALSE;
				    SetEnableTimer(&tmrRing[e1->port-1],FALSE);
				    r2o=dg_SendR2Command(e1->port, R2_ANSWERED);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
			    write_debug_cb(e1->port,"cb: (%d) P_R2_AGUARDA_ATENDIMENTO - ANSWERED",e1->port);

				if (e1->ddc==ON)
				{
					r2_step=P_R2_BLOQUEIO_DDC;

					//inicia timer 1s
					tmr_h=set_e1_timeout(e1->port,e1->timeout_bloqueio_on);
				}
				else
				{
					if (ports_info[e1->port-1].idle_info.thread_id > 0)
					{
						write_debug_cb(e1->port,"r2: (%d) P_R2_ATENDIDO_ENTRANTE- sending EV_LINEREADY",e1->port);
						//Idle thread is running, then send commands to it
						dg_InsertIdleFifo(e1->port, EV_LINEREADY, HOOK_OFF);
					}
					
           			r2_step=P_R2_ATENDIDO_ENTRANTE;
				}
			}
			else
			{
				switch(r2i)
				{
					case R2_FAILURE:
						write_debug_cb(e1->port,"r2: (%d) R2_FAILURE DURANTE MFC - enviando C_ENDCALL",e1->port);
					case R2_ANSWERED://nao deve acontecer
						write_debug_cb(e1->port,"r2: (%d) R2_AT DURANTE MFC - enviando C_ENDCALL",e1->port);
						// termina sinalizacao MFC
						end_wait_release(e1->port,1, &r2_step);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
						// gerar evento LIGACAO ENCERRADA
						write_debug_cb(e1->port,"r2: (%d) R2_OC DURANTE MFC - enviando C_ENDCALL",e1->port);
						break;
					case R2_SEIZURE:
						break;

					case R2_IDLE:
						// termina sinalizacao MFC
						end_wait_release(e1->port,0,&r2_step);
						line_state = OFF;

						tmr_h=set_e1_timeout(e1->port,0);  //timer off
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							// libera canal
							r2o=dg_SendR2Command(e1->port, R2_IDLE);
							dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						r2_step=P_R2_LIVRE;
						blocked_event = 0;
						// gerar evento LIGACAO ENCERRADA
						write_debug_cb(e1->port,"r2: (%d) R2_IDLE- enviando C_ENDCALL",e1->port);
						line_state = OFF;
						break;
				}

			}
			break;

		case P_R2_BLOQUEIO_DDC:
			if (timeout==tmr_h)
			{
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				//start timer 2s
				tmr_h=set_e1_timeout(e1->port,e1->timeout_bloqueio_off);
				r2_step=P_R2_BLOQUEANDO_DDC;
			}
			else
			{
				if (line_state==OFF)
				{
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					r2_step=P_R2_ATENDIDO_ENTRANTE;
				}
				else
				{
					switch(r2i)
					{
						case R2_FAILURE:
						case R2_ANSWERED://nao deve acontecer
							// termina sinalizacao MFC
							//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off
							end_wait_release(e1->port,1, &r2_step);
							tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);

							//.......
							line_state = OFF;
							break;
						case R2_SEIZURE:
							break;
						case R2_IDLE:
							// termina sinalizacao MFC
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								// libera canal
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								// gerar evento LIGACAO ENCERRADA
								dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

							r2_step=P_R2_LIVRE;
							blocked_event = 0;
							//.......
							line_state = OFF;

							break;
					}//switch
				}
			}
			break;
		case P_R2_BLOQUEANDO_DDC:
			write_debug_cb(e1->port,"P_R2_BLOQUEANDO_DDC: timeout = %d, tmr_h = %d", timeout, tmr_h);			
			
			//if (timeout==tmr_h)
			{
				if (line_state==ON)
				{
					e1->bAtendido = ON;
					write_debug_cb(e1->port,"r2: (%d) P_R2_BLOQUEANDO_DDC- enviando R2_ANSWERED",e1->port);
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
            			dg_SendR2Command(e1->port, R2_ANSWERED);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				}
				r2_step=P_R2_ATENDIDO_ENTRANTE;
			}
			/*else
			{
				if (line_state==OFF)
				{
					e1->bAtendido = OFF;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					r2_step=P_R2_ATENDIDO_ENTRANTE;
				}
				else
				{
					switch(r2i)
					{

						case R2_SEIZURE:
							break;

						case R2_FAILURE:
						case R2_ANSWERED://nao deve acontecer
							//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off
							end_wait_release(e1->port,1, &r2_step);
							tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
							line_state = OFF;
							break;
						case R2_IDLE:
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								// libera canal
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								// gerar evento LIGACAO ENCERRADA
								dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

							r2_step=P_R2_LIVRE;
							blocked_event = 0;
							//.......
							line_state = OFF;

							break;
						}
				}
			}*/
			break;
		case P_R2_ATENDIDO_ENTRANTE:
			if(timeout != tmr_h)
			{			
				write_debug_cb(e1->port,"P_R2_ATENDIDO_ENTRANTE line_state=%d r2i=%d",line_state,r2i);
				if (line_state==OFF)
				{					
					//desliga flag de atendimento
					e1->bAtendido = OFF;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

					//seta timeout com 10s a mais do controle de retencao
					tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					r2_step = P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU;
				}
				else
				{
					if (line_state==ON)
					{
						//flag de atendimento
						//..
						e1->bAtendido = ON;
						
						if (flash_rec == 0)							
						{
							if (ports_info[e1->port-1].e1_info.sigtype == R2_TYPE_CB_FXS)
							{								
								write_debug_cb(e1->port,"r2: (%d) P_R2_ATENDIDO_ENTRANTE- enviando R2_ANSWERED",e1->port);
								digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								{
									r2o=dg_SendR2Command(e1->port, R2_ANSWERED);
								}
								digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);								
							}
						}
					}
				}
				
				switch(r2i)
				{			
					case R2_SEIZURE:
						write_debug_cb(e1->port,"ATENDIDO_ENTRANTE: R2_SEIZURE on %d", e1->port);
						
						if ((flash_rec == 1) && (ports_info[e1->port-1].e1_info.sigtype == R2_TYPE_CB_FXS)) 
                        {   //re-answered before 800ms, Flash
							/* Retornou */														
							flash_rec = 0;
							
							tmr_h=set_e1_timeout(e1->port,0);
                            
						    RaiseEvents_ThreadSafe(EV_FLASH, 0,  0, e1->port,&port_mutex[e1->port-1]);
						    
		                    write_debug_cb(e1->port,"r2 : P_R2_ENVIA_CONFIRMACAO with flash_rec == 1");		                    
		                    digivoice_sleep(20);    //changed to fit standards

		                    //send seizure ack
		                    digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
		                         r2o=dg_SendR2Command(e1->port, R2_SEIZURE_ACK);
		                    digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
		                    
		                    write_debug_cb(e1->port,"r2 (%d): P_R2_ENVIA_CONFIRMACAO - CHANNEL BANK with flash_rec == 1",e1->port);
		                    
		                    digivoice_sleep(20);    //changed to fit standards		                    
		                    
							write_debug_cb(e1->port,"r2: (%d) P_R2_ATENDIDO_ENTRANTE- enviando R2_ANSWERED",e1->port);
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							{
								r2o=dg_SendR2Command(e1->port, R2_ANSWERED);
							}
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);		                    
                        }
						break;
					case R2_FAILURE:
					case R2_ANSWERED://nao deve acontecer
						write_debug_cb(e1->port,"ATENDIDO_ENTRANTE: R2_ANSWERED on %d", e1->port);
						
						// termina sinalizacao MFC
						//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off
						end_wait_release(e1->port,0, &r2_step);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
						line_state = OFF;
						
						//.......
						break;
					case R2_IDLE:		
						if (ports_info[e1->port-1].e1_info.sigtype == R2_TYPE_CB_FXS)
						{
							// termina sinalizacao MFC
							//tmr_h=set_e1_timeout(e1->port,0);  //timer off
						
							tmr_h=set_e1_timeout(e1->port, 800);
						}
						else
							tmr_h=set_e1_timeout(e1->port, 10);

						write_debug_cb(e1->port,"ATENDIDO_ENTRANTE: flash timer - tmr_h = %d",tmr_h);
						flash_rec = 1;
						
						// libera canal
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						{
							r2o=dg_SendR2Command(e1->port, R2_IDLE);
						}
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							
						break;
				}//switch(r2i)
			}
			else//if(timeout != tmr_h)
			{			
				write_debug_cb(e1->port,"ATENDIDO_ENTRANTE: timeout = %d", timeout);							
				
				flash_rec = 0;
				
				tmr_h=set_e1_timeout(e1->port,0);  //timer off
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
				{
					// libera canal
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
					// gerar evento LIGACAO ENCERRADA
					e1->bAtendido = OFF;
					//desabilita timer de ligacao sainte
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
					//cancela geracao de tons
					e1->ring_event = 99;
					tmrRing[e1->port-1].Enabled = FALSE;
					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
				}
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				//chama funcao que libera tudo - com timeout
				end_release(e1->port,0, &r2_step);
				//...TODO: VALIDAR se retira mesmo
				write_debug_cb(e1->port,"cb (%d): RaiseEvent EV_BUSY", e1->port);
				//RaiseEvents_ThreadSafe(EV_LINEOFF, 0, e1_events.port,&port_mutex[e1->port-1]);
				RaiseEvents_ThreadSafe(EV_BUSY, 0,  0, e1_events.port,&port_mutex[e1->port-1]);
				end_action = EA_NONE;
				line_state = OFF;
				//.......			
			}//if(timeout != tmr_h)			
			break;
		case P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU:
			write_debug_cb(e1->port,"cb (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU",e1->port);
			if (timeout==tmr_h)
			{
				write_debug_cb(e1->port,"cb (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU - deu timeout",e1->port);
				// termina sinalizacao MFC
				tmr_h=set_e1_timeout(e1->port,0);  //timer off
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					// libera canal
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
					if (r2i==R2_IDLE)
						r2_step=P_R2_LIVRE;
					else
					{
						dg_SendR2Command(e1->port, R2_ENABLE);
						r2_step=P_R2_AGUARDA_LIVRE;
					}
					// gerar evento LIGACAO ENCERRADA
					dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
					line_state = OFF;
					e1->bAtendido = OFF;
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				//.......
			}
			else
			{
				write_debug_cb(e1->port,"cb (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU - Recebeu r2i=%d",e1->port,r2i);
				if (line_state==ON)
				{
					//flag de atendimento
					//..
					e1->bAtendido = ON;
					if (r2i==R2_SEIZURE)
					{
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
           					r2o=dg_SendR2Command(e1->port, R2_ANSWERED);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					}
					r2_step = P_R2_ATENDIDO_ENTRANTE;
				}
				switch(r2i)
				{
						case R2_SEIZURE:
							break;
						case R2_FAILURE:
						case R2_ANSWERED://nao deve acontecer
							end_wait_release(e1->port,0, &r2_step);
							tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
							line_state = OFF;
							break;
						case R2_IDLE:
							write_debug_cb(e1->port,"cb (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU - R2_IDLE Recebeu r2i=%d",e1->port,r2i);
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								// libera canal
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								r2_step=P_R2_LIVRE;
								line_state = OFF;
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							
							/*if (ports_info[e1->port-1].idle_info.thread_id > 0)
							{
								write_debug_cb(e1->port,"r2: (%d) P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU - sending EV_LINEOFF",e1->port);
								//Idle thread is running, then send commands to it
								dg_InsertIdleFifo(e1->port, EV_LINEOFF, HOOK_ON);
							}*/
						break;
				}
			}
			break;
		}//fim do r2
	} //if do trata_r2
	} //fim fo while(1)

	e1->enabled = 0;
	write_debug_cb(e1->port,"E1 for port %d closed",e1->port);
		//close fifos
#ifdef __LINUX__
	close(ports_info[e1->port-1].fifo_to_e1);

#else
	//destroi os eventos
	CloseHandle(ports_info[e1->port-1].e1_info.E1Event.hEvent);
#endif

#ifdef __LINUX__
	close(fifo_rx);
#endif
	//
	e1->thread_id = 0;
}

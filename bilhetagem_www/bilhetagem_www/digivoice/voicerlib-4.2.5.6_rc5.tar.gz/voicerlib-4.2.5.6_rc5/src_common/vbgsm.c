
/************************************************************************************
 *                                                                                  *
 *   VoicerLib - Windows/Linux Version                                              *
 *                                                                                  *
 *   Copyright (c) 2004-2015 Digivoice Tecnologia em Eletronica Ltda                *
 *                                                                                  *
 *   Module: GSM Card                                                               *
 *                                                                                  *
 *   Description: Implements GSM's card modules interface                           *
 *                                                                                  *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                                  *
 *   This library is free software; you can redistribute it and/or                  *
 *   modify it under the terms of the GNU Lesser General Public                     *
 *   License as published by the Free Software Foundation; either                   *
 *   version 2.1 of the License, or (at your option) any later version.             *
 *                                                                                  *
 *   This library is distributed in the hope that it will be useful,                *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of                 *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU               *
 *   Lesser General Public License for more details.                                *
 *                                                                                  *
 *   You should have received a copy of the GNU Lesser General Public               *
 *   License along with this library; if not, write to the Free Software            *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *
 *                                                                                  *
 ************************************************************************************/

#include "voicerlib.h"

#include "vbgsm.h"
#include "convcode.h"

#ifdef __LINUX__
#include <assert.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#endif

#ifdef DG_WIN
//WINDOWS
//------------------------------------------------------------------------
// inline function - write to log file: gsm-(port).log
//------------------------------------------------------------------------
__forceinline int __cdecl write_debug_gsm(short port, const char *s, ...)
{
	int retval=0;

#ifndef _DEBUG
	if (GSMDebugEnabled)
	{
#endif
		FILE *pdebug;
		time_t curSecs;
		struct tm *now_dbg;
		char szTemp[512];
		char szFileName[512];
		va_list argp;

		curSecs = time(NULL);
		now_dbg = localtime(&curSecs);
		sprintf(szTemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);

		va_start(argp, s);
		sprintf(szFileName,"c:\\log\\gsm-%d.log",port);
		pdebug=fopen(szFileName,"a+");
		if (pdebug!=NULL)
		{
			fprintf(pdebug,"%s-",szTemp);
			retval = vfprintf( pdebug, s, argp);
			fprintf(pdebug,"\n");
			//let somebody else do the work
			fclose(pdebug);
		}
		va_end(argp);

#ifndef _DEBUG
	}
#endif
	return retval;
}
#else
//LINUX
void write_debug_gsm(short port, char *fmt, ...)
{
#ifndef DEBUG
	if (GSMDebugEnabled)
	{
#endif
		va_list argptr;
		int     ret;
		FILE    *f;
		time_t curSecs;
		struct tm *now_dbg;
		char szdbgtemp[200];
		char szFileName[200];

		curSecs = time(NULL);
		now_dbg = localtime(&curSecs);
		sprintf(szdbgtemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);

		va_start(argptr, fmt);
		sprintf(szFileName,"/var/log/voicerlib/gsm-%d.log",port);
		f = fopen(szFileName, "a+");
		fprintf(f,"%s-",szdbgtemp);
		ret = vfprintf(f,fmt,argptr);
		fprintf(f,"\n");
		fclose(f);
		assert(ret != 0);

		va_end(argptr);
#ifndef DEBUG
	}
#endif
}
#endif

//------------------------------------------------------------------------
// function to set a port timeout
//------------------------------------------------------------------------
int set_gsm_timeout(int port, int t)
{
	int ret;
	digivoice_entercriticalsection(&port_mutex[port-1], port);
	tmr_GSM[port-1].Enabled = FALSE;
	SetEnableTimer(&tmr_GSM[port-1],FALSE);
	tmr_GSM[port-1].Interval = t / FACTOR_TIMER;

	if (t!=0)
	{
		ret = (int)SetEnableTimer(&tmr_GSM[port-1],TRUE);
		tmr_GSM[port-1].Enabled = TRUE;
	}
	else
		ret = -1;

	digivoice_leavecriticalsection(&port_mutex[port-1], port);
	write_debug_gsm(port,"set_gsm_timeout - handle %d com tempo %d",ret,t);
	return ret;
}

//---------------------------------------------------------------------------------------------------------------------------------------------
// function to set a port timeout - Used for GSM command that need to wait time to change the current machine state, like AT+CMGS, AT+CPMS, etc
//---------------------------------------------------------------------------------------------------------------------------------------------
int set_gsm_wait_timeout(int port, int t)
{
	int ret;
	digivoice_entercriticalsection(&port_mutex[port-1], port);
	tmr_GSM_Wait[port-1].Enabled = FALSE;
	SetEnableTimer(&tmr_GSM_Wait[port-1],FALSE);
	tmr_GSM_Wait[port-1].Interval = t / FACTOR_TIMER;

	if (t!=0)
	{
		ret = (int)SetEnableTimer(&tmr_GSM_Wait[port-1],TRUE);
		tmr_GSM_Wait[port-1].Enabled = TRUE;
	}
	else
		ret = -1;

	digivoice_leavecriticalsection(&port_mutex[port-1], port);
	write_debug_gsm(port,"set_gsm_wait_timeout - handle %d com tempo %d",ret,t);
	return ret;
}

//----------------------------------------------------------------------------------------------------------------------------
// function to set a port timeout - Used for enable command dg_GSMClearAllSMS, this command can be used 30s after CPIN command
//----------------------------------------------------------------------------------------------------------------------------
int set_gsm_ClearAllSMS_timeout(int port, int t)
{
	int ret;
	digivoice_entercriticalsection(&port_mutex[port-1], port);
	tmr_GSM_ClearAllSMS[port-1].Enabled = FALSE;
	SetEnableTimer(&tmr_GSM_ClearAllSMS[port-1],FALSE);
	tmr_GSM_ClearAllSMS[port-1].Interval = t / FACTOR_TIMER;

	if (t!=0)
	{
		ret = (int)SetEnableTimer(&tmr_GSM_ClearAllSMS[port-1],TRUE);
		tmr_GSM_ClearAllSMS[port-1].Enabled = TRUE;
	}
	else
		ret = -1;

	digivoice_leavecriticalsection(&port_mutex[port-1], port);
	write_debug_gsm(port,"set_gsm_ClearAllSMS_timeout - handle %d com tempo %d",ret,t);
	return ret;
}

//------------------------------------------------------------------------
// send delayed at command when module is not busy
// szCmd must have CR LF  and must be zero terminated
//------------------------------------------------------------------------
void gsm_puts_delayed(short port, char *szCmd)
{
	int nTempW;
	short nWaitForTimeout = 5000;
	short isDialing = 0;

	if(ports_info[port-1].gsm_info.nGSMStep != GSM_ALL)
	{
		nTempW = (ports_info[port-1].gsm_info.nDelayedCmdIndexW + 1)&3; //round to 4 itens

		if(nTempW != ports_info[port-1].gsm_info.nDelayedCmdIndexR)
		{
			write_debug_gsm(port,"..............................................");
			write_debug_gsm(port,"gsm_puts_delayed: %s", szCmd);

			//copy command to temporary buffer
			strcpy(ports_info[port-1].gsm_info.szDelayedCmd[ports_info[port-1].gsm_info.nDelayedCmdIndexW],szCmd);
			ports_info[port-1].gsm_info.nDelayedCmdIndexW = nTempW;
		}
	}
	else
	{
		//Test if is to dial, change the default timeout
		if (strncmp(szCmd, "ATD", 3) == 0)
			isDialing = 1;
		else
			//Test if is to send SMS and change status
			if( strncmp(szCmd, "AT+CMGS",7)==0)
			{
				ports_info[port-1].gsm_info.nGSMStep = GSM_SMS1_WAIT;
				write_debug_gsm(port, "gsm_puts_delayed: Changing nGSMStep to GSM_SMS1_WAIT and Wait for %d ms", nWaitForTimeout);

				strcpy(ports_info[port-1].gsm_info.szLastCommand, szCmd);

				set_gsm_wait_timeout(port, nWaitForTimeout);

				return;
			}
			else
				//test if is to clear all sms and change status
				if( strncmp(szCmd, "AT+CPMS",7)==0)
				{
					ports_info[port-1].gsm_info.nGSMStep = GSM_CLEAR0_WAIT;
					write_debug_gsm(port, "gsm_puts_delayed: Changing nGSMStep to GSM_CLEAR0_WAIT and Wait for %d ms", nWaitForTimeout);

					strcpy(ports_info[port-1].gsm_info.szLastCommand, szCmd);

					set_gsm_wait_timeout(port, nWaitForTimeout);

					return;
				}
				else
					//test if is to hangup
					if( strncmp(szCmd, "ATH",3)==0)
						ports_info[port-1].gsm_info.nHangupFlag = 1;

		//if the thread state is GSM_ALL send now.
		gsm_puts(port, szCmd);

		switch (ports_info[port-1].gsm_info.nGSMStep)
		{
		case GSM_SMS1_WAIT:
		case GSM_CLEAR0_WAIT:
			//nothing to do...
			break;
		default:
			//set timeout for characters
			if (isDialing)
				set_gsm_timeout(port, 100000);//Change default timeout to 90s (by Anatel) + 10s
			else
				set_gsm_timeout(port, ports_info[port-1].gsm_info.nAnswerTimeout);
		}
	}
}

//------------------------------------------------------------------------
// get delayed at command, if it exists, and send to card's module
//------------------------------------------------------------------------
void gsm_get_delayed(short port)
{
	int nTempR;
	short nWaitForTimeout = 5000;

	nTempR = ports_info[port-1].gsm_info.nDelayedCmdIndexR;

	if(nTempR != ports_info[port-1].gsm_info.nDelayedCmdIndexW)
	{
		//Test if is to send SMS and change status
		if( strncmp(ports_info[port-1].gsm_info.szDelayedCmd[nTempR], "AT+CMGS",7)==0)
		{
			ports_info[port-1].gsm_info.nGSMStep = GSM_SMS1_WAIT;
			write_debug_gsm(port, "gsm_get_delayed: Changing nGSMStep to GSM_SMS1_WAIT and Wait for %d ms", nWaitForTimeout);

			strcpy(ports_info[port-1].gsm_info.szLastCommand, ports_info[port-1].gsm_info.szDelayedCmd[nTempR]);

			set_gsm_wait_timeout(port, nWaitForTimeout);

			ports_info[port-1].gsm_info.nDelayedCmdIndexR = (ports_info[port-1].gsm_info.nDelayedCmdIndexR + 1)&3; //round to 4 itens

			return;
		}
		else
			//test if is to clear all sms and change status
			if( strncmp(ports_info[port-1].gsm_info.szDelayedCmd[nTempR], "AT+CPMS",7)==0)
			{
				ports_info[port-1].gsm_info.nGSMStep = GSM_CLEAR0_WAIT;
				write_debug_gsm(port, "gsm_get_delayed: Changing nGSMStep to GSM_CLEAR0_WAIT and Wait for %d ms", nWaitForTimeout);

				strcpy(ports_info[port-1].gsm_info.szLastCommand, ports_info[port-1].gsm_info.szDelayedCmd[nTempR]);

				set_gsm_wait_timeout(port, nWaitForTimeout);

				ports_info[port-1].gsm_info.nDelayedCmdIndexR = (ports_info[port-1].gsm_info.nDelayedCmdIndexR + 1)&3; //round to 4 itens

				return;
			}

		write_debug_gsm(port,"..............................................");
		write_debug_gsm(port,"gsm_get_delayed: %s",&ports_info[port-1].gsm_info.szDelayedCmd[nTempR]);

		gsm_puts(port,&ports_info[port-1].gsm_info.szDelayedCmd[nTempR][0]);

		//set timeout for characters
		set_gsm_timeout(port,ports_info[port-1].gsm_info.nAnswerTimeout);

		ports_info[port-1].gsm_info.nDelayedCmdIndexR = (ports_info[port-1].gsm_info.nDelayedCmdIndexR + 1)&3; //round to 4 itens
	}
}

//------------------------------------------------------------------------
// send at command to card's module
// szCmd must have CR LF  and must be zero terminated
//------------------------------------------------------------------------
void gsm_puts( short port, char *szCmd )
{

	size_t nLen,i;
	dg_cmd_tx tx_command_gsm;

	write_debug_gsm(port,"..............................................");
	write_debug_gsm(port,"gsm_puts: %s", szCmd);
	strcpy(ports_info[port-1].gsm_info.szLastCommand,szCmd);

	nLen = strlen(szCmd);
	for(i=0;i<nLen;i=i+2)
	{
		if(szCmd[i+1] == '\0')
			tx_command_gsm.command = CMD_UART1;
		else
			tx_command_gsm.command = CMD_UART2;

		//exception @==00
		//if(szCmd[i]== '@')
		//	szCmd[i] = '\0';
		//if(szCmd[i+1]== '@')
		//	szCmd[i+1] = '\0';

		tx_command_gsm.port_or_card = ASSUME_PORT;
		tx_command_gsm.port = port - 1;
		tx_command_gsm.param1 = (unsigned char)port - 1;
		tx_command_gsm.param2 = szCmd[i];
		tx_command_gsm.param3 = szCmd[i+1];
		tx_command_gsm.param4 = 0;
		tx_command_gsm.param5 = 0;
		write_generic_command(&tx_command_gsm);
	}
}

//------------------------------------------------------------------------
// send at command to card's module
// szCmd must have CR LF  
//------------------------------------------------------------------------
void gsm_putn( short port, char *szCmd, int nLen )
{

	int i,tmp;
	dg_cmd_tx tx_command_gsm;

	write_debug_gsm(port,"..............................................");
	write_debug_gsm(port,"gsm_putn: %s nLen %d", szCmd, nLen);
	strcpy(ports_info[port-1].gsm_info.szLastCommand,szCmd);

	tmp=nLen & 0xfe;//keep as an even number
	for(i=0;i<tmp;i=i+2)
	{
		tx_command_gsm.command = CMD_UART2;
		tx_command_gsm.port_or_card = ASSUME_PORT;
		tx_command_gsm.port = port - 1;
		tx_command_gsm.param1 = (unsigned char)port - 1;
		tx_command_gsm.param2 = szCmd[i];
		tx_command_gsm.param3 = szCmd[i+1];
		tx_command_gsm.param4 = 0;
		tx_command_gsm.param5 = 0;
		write_generic_command(&tx_command_gsm);
	}

	if( ((nLen&1) == 1))//send the last one if odd
	{
		tx_command_gsm.command = CMD_UART1;
		tx_command_gsm.port_or_card = ASSUME_PORT;
		tx_command_gsm.port = port - 1;
		tx_command_gsm.param1 = (unsigned char)port - 1;
		tx_command_gsm.param2 = szCmd[nLen-1];
		tx_command_gsm.param3 = 0;
		tx_command_gsm.param4 = 0;
		tx_command_gsm.param5 = 0;
		write_generic_command(&tx_command_gsm);
	}
}

//------------------------------------------------------------------------
// send SMS command to card's module
//------------------------------------------------------------------------
void gsm_send_sms( short port)
{
	char szTemp[256];

	sprintf(szTemp,"AT+CMGS=%s\r\n", ports_info[port-1].gsm_info.szDestNumber);  
	gsm_puts_delayed(port, szTemp);
}

//------------------------------------------------------------------------
// send 'ATDnnnnnnnnnnnnnnnnnnnnnnnnn;' command to card's module
//------------------------------------------------------------------------
void gsm_dial( short port, char *szNumber)
{
	char szTemp[256];

	sprintf(szTemp,"ATD%s;\r\n",szNumber);
	gsm_puts_delayed(port,szTemp);
}

//------------------------------------------------------------------------
// Thread function for GSM cards
//------------------------------------------------------------------------
void Signal_GSM_Thread(void *signal_gsm_info)
{
	dg_signal_gsm_thread_structure *gsm;
	dg_event_data_structure 	 gsm_events;
	dg_cmd_tx                       tx_command_gsm;

#ifdef __LINUX__
	int fifo_rx;
	int fifo_to_ctrl;
#else
	HANDLE fifo_rx;
	//u32 gsmBytesRead;PPPP
	DWORD gsmBytesRead;
#endif

	char szMSGRaw[2][256];
	char szRxMsg[2][256];
	char szTemp[256];
	char szTempIndex[256];
	char szMaxMessage[256];
	char szIndexMessage[256];
	int  nClearCNT = 0;
	//int  nIndexCNT;
	int  nBuff=0;
	int  nRxCnt=0;
	int  nRunGsm=0;
	int  nAnalyse=0;
	//int  nDialFlag=0;
	int  nErrorCnt=0;
	int  nGsmATStep=GSM_AT_IDLE;
	//int  nGsmStep=GSM_IDLE;
	int  i;
	//int  blocked_event=0;
	int  dwError;
	int nLen=0;
	int nSMSHeaderFlag=0;
	//int  entrante=0;

	int  timeout=0;
	int  tmr_h;
	//int  tmr_ha=0;  //timeout de atendimento
	//short card;

	//int cid_received = 0;

	int nStartCount = 0;
	int nStartFlag = 0;

	int nResetState = 0;	//This variable is set when we got the command C_RESET_THREAD

	int nTempR = 0;
	int nTempW = 0;
	int nPINFlag = 0;

	short nTmpCQ = 0;

	gsm_events.data = 0; //PPPP
	gsm_events.port = 0; //PPPP

	gsm = (dg_signal_gsm_thread_structure *)signal_gsm_info;

	/*este bloco esta em dg_StartVoicerLib*/
	//gsm->nDigitTimeout = 10000;
	//gsm->nRetryTimeout = 10000;
	//gsm->nAnswerTimeout = 30000;
	//gsm->nIDRestriction = 0;
	gsm->nGSMStep = GSM_IDLE;


	gsm->nDelayedCmdIndexR = 0;
	gsm->nDelayedCmdIndexW = 0;
	gsm->nDelayedRxIndexR = 0;
	gsm->nDelayedRxIndexW = 0;
	//--------------------------------init module---------------------------------------

	//send ignition to card.
	tx_command_gsm.command = CMD_UART0;
	tx_command_gsm.port_or_card = ASSUME_PORT;
	tx_command_gsm.port = gsm->port-1;
	tx_command_gsm.param1 = (unsigned char)gsm->port-1;
	tx_command_gsm.param2 = 2;	//1-> Send ignition to module
								//2-> Send emergoff and ignition to module
	tx_command_gsm.param3 = 0;
	tx_command_gsm.param4 = 0;
	tx_command_gsm.param5 = 0;
	write_generic_command(&tx_command_gsm);

	//		digivoice_sleep(5000);                  //wait s to go

	//		gsm->nGSMStep = GSM_E0;
	//        nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters

	//restore factory settings
	//		gsm_puts(gsm->port,"AT&F\r\n");

	//set timeout for characters
	//        tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

	gsm->nGSMStep = GSM_SYSSTART;
	nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters

	//set timeout for characters
	tmr_h=set_gsm_timeout(gsm->port,20000);

	//-----------create fifo for signaling----------------------------------------------
#ifdef __LINUX__
	fifo_rx = open(gsm->szFifoToGSM,O_RDONLY);
	if (fifo_rx==0)
	{
		//nao conseguiu abrir a fifo
		write_debug_gsm(gsm->port,"Error openning fifo....");
	}
	else
		write_debug_gsm(gsm->port, "Fifo opened (Thread ID: %d).", gsm->thread_id);
#else
	fifo_rx	= CreateFile(gsm->szFifoToGSM, GENERIC_READ | GENERIC_WRITE,
			0,	NULL, OPEN_EXISTING, 0,NULL);
#endif
	//----------------------------------------------------------------------------------
	gsm->enabled = 1;
	ports_info[gsm->port-1].gsm_info.thread_ready = 1;

	while(1)
	{
		//check if there is delayed commands to send to gsm module
		if(gsm->nGSMStep == GSM_ALL)
		{
			gsm_get_delayed(gsm->port);
		}

		gsm_events.command = 0xffff ; //(-1)
		//--------------------------read FIFO------------------------------------------------
		//retirar e tratar um evento da fifo
#ifdef __LINUX__
		//write_debug_gsm(gsm->port,"GSMEvent (%d): Waiting event...",gsm->port);

		read(fifo_rx,&gsm_events,sizeof(gsm_events));

		//write_debug_gsm(gsm->port,"GSMEvent (%d): Receiving cmd: %x - data: %x",gsm->port,gsm_events.command,gsm_events.data);
		//write_debug("---- GSMEvent (%d): Receiving cmd: %x - data: %x",gsm->port,gsm_events.command,gsm_events.data );
#else
		//windows
		//			if((dwError = WaitForSingleObject(gsm->oOverlapGSM.hEvent,INFINITE))==WAIT_OBJECT_0)
		if((dwError = WaitForSingleObject(gsm->oOverlapGSM.hEvent,1000))==WAIT_OBJECT_0)
		{
			//write_debug_gsm(gsm->port,"GSMEvent - : %d",gsm->port);
			if(ReadFile(fifo_rx,                                     // handle to pipe
					&gsm_events,                                 // buffer to receive data
					sizeof(gsm_events),                          // size of buffer
					&gsmBytesRead,                               // number of bytes read
					&gsm->oOverlapGSM)==FALSE)					// not overlapped I/O
			{
				dwError = GetLastError();
				write_debug_gsm(gsm->port,"GSMEvent (%d): Returned ERROR  %x - cmd: %x - data: %x , Error : %d",gsm->port,gsm->GSMEvent.hEvent,gsm_events.command,gsm_events.data,dwError );
			}
		}
		//else
		//	write_debug_gsm(gsm->port,"GSMEvent (%d): WaitFor SingleObject != WAIT_OBJECT_IO %x ",gsm->port,dwError );
#endif

		//reset values
		timeout = 0;

		//terminates thread
		if (gsm_events.command == C_ENDTHREAD)
		{
			ports_info[gsm->port-1].gsm_info.thread_ready = 1;

			//send "Switch off mobile station (shutdown to module)"
			gsm_puts(gsm->port, "AT^SMSO\r\n");

			//cancel thread execution
			write_debug_gsm(gsm->port, "Finalizing GSM thread for port %d...", gsm->port);
			break;
		}

		switch (gsm_events.command)
		{
		case C_UART1:
			//copy chars to array
			szRxMsg[nBuff][nRxCnt] = gsm_events.data >> 8;
			szMSGRaw[nBuff][nRxCnt++] = szRxMsg[nBuff][nRxCnt]; //copy to raw buffer
			szMSGRaw[nBuff][nRxCnt] = '\0';
			szRxMsg[nBuff][nRxCnt] = '\0';

			write_debug_gsm(gsm->port,"Character received C_UART1: %c",gsm_events.data >> 8);
			nRunGsm = 1;
			break;

		case C_UART2:
			//copy char to array
			szRxMsg[nBuff][nRxCnt] = gsm_events.data >> 8;
			szMSGRaw[nBuff][nRxCnt++] = szRxMsg[nBuff][nRxCnt]; //copy to raw buffer
			szRxMsg[nBuff][nRxCnt] = gsm_events.data & 0xff;
			szMSGRaw[nBuff][nRxCnt++] = szRxMsg[nBuff][nRxCnt]; //copy to raw buffer
			szMSGRaw[nBuff][nRxCnt] = '\0';
			szRxMsg[nBuff][nRxCnt] = '\0';

			write_debug_gsm(gsm->port,"Character received C_UART2: %c %c",gsm_events.data >> 8,gsm_events.data & 0xff);
			nRunGsm = 1;
			break;

		case C_UART3:
			//copy char to array
			szRxMsg[nBuff][nRxCnt] = gsm_events.data >> 8;
			szMSGRaw[nBuff][nRxCnt++] = szRxMsg[nBuff][nRxCnt]; //copy to raw buffer
			szRxMsg[nBuff][nRxCnt] = gsm_events.data & 0xff;
			szMSGRaw[nBuff][nRxCnt++] = szRxMsg[nBuff][nRxCnt]; //copy to raw buffer
			szRxMsg[nBuff][nRxCnt] = '\0';
			szMSGRaw[nBuff][nRxCnt] = '\0';

			write_debug_gsm(gsm->port,"Character received C_UART3: %c %c",gsm_events.data >> 8,gsm_events.data & 0xff);
			nRunGsm = 1;
			break;

		case C_SENDSMS:
			//send command to stard sendind SMS
			gsm_send_sms(gsm->port);
			//gsm->nGSMStep = GSM_SMS1;
			break;

		case C_AUDIO:				//digits or silence
			break;

		case C_RESET_THREAD:
			write_debug_gsm(gsm->port, "C_RESET_THREAD event received");

			nStartCount = 0;
			nStartFlag = 0;
			gsm->nDialFlag = 0;
			gsm->nHangupFlag = 0;
			nResetState = 1;
			nErrorCnt = 0;

			gsm->nGSMStep = GSM_E0;
			nGsmATStep = GSM_AT_IDLE;

			//restore factory settings
			gsm_puts(gsm->port, "AT&F\r\n");

			//set timeout for characters
			tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

			break;

		case C_CALLPROGRESS:
			break;

		case C_ENDCALL:
			break;

			//----------------------------------------------------
			//Comandos recebidos direto de algum ponto da aplicacao
			//----------------------------------------------------
		case CDISCA_TOM:
			//dial number stored in tx_digits (dg_Dial function)
			gsm_dial(gsm_events.port,gsm->tx_digits);

			ports_info[gsm->port-1].FStatusPort = spOffHook;

			//Fires EV_AFTERDIAL - ligacao sainte
			RaiseEvents_ThreadSafe(EV_AFTERDIAL, 0,  0,gsm->port,&port_mutex[gsm->port-1]);
			RaiseEvents_ThreadSafe(EV_LINEREADY, 0,  0,gsm->port,&port_mutex[gsm->port-1]);

			gsm->nDialFlag=1;
			gsm->nHangupFlag=0;
			break;

		case C_TIMEOUT:	//recebido do timer
			write_debug_gsm(gsm_events.port, "C_TIMEOUT: received port %d - gsm_events.command %d, ports_info[port-1].gsm_info.nGSMStep %d", gsm_events.port, gsm_events.command, ports_info[gsm->port-1].gsm_info.nGSMStep);

			if ((ports_info[gsm->port-1].gsm_info.ClearAllSMS_Timeout_Id == gsm_events.data) &&
				(ports_info[gsm->port-1].gsm_info.ClearAllSMS_Enabled == 0))
			{
				ports_info[gsm->port-1].gsm_info.ClearAllSMS_Enabled = 1;
				ports_info[gsm->port-1].gsm_info.ClearAllSMS_Timeout_Id = -1;
				write_debug_gsm(gsm_events.port, "C_TIMEOUT: Set ClearAllSMS_Enabled flag to 1");
				break;
			}

			switch (ports_info[gsm->port-1].gsm_info.nGSMStep)
			{
			case GSM_SMS1_WAIT:
				ports_info[gsm->port-1].gsm_info.nGSMStep = GSM_SMS1;

				//if the thread state is GSM_ALL send now.
				gsm_puts(gsm->port, ports_info[gsm->port-1].gsm_info.szLastCommand);//AT+CMGS

				//set timeout for characters
				set_gsm_timeout(gsm->port, ports_info[gsm->port-1].gsm_info.nAnswerTimeout);

				break;
			case GSM_CLEAR0_WAIT:
				ports_info[gsm->port-1].gsm_info.nGSMStep = GSM_CLEAR0;

				//if the thread state is GSM_ALL send now.
				gsm_puts(gsm->port, ports_info[gsm->port-1].gsm_info.szLastCommand);//AT+CPMS

				//set timeout for characters
				set_gsm_timeout(gsm->port, ports_info[gsm->port-1].gsm_info.nAnswerTimeout);

				break;
			default:
				if ((nStartFlag == 0) && (gsm->nGSMStep != GSM_ALL))
				{
					nStartFlag = 1;

					//if (nStartCount < 15) //removed on 4.2.2.0_rc4
					RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
				}

				gsm->nGSMStep = GSM_ALL;
				timeout = (int) gsm_events.data;
				RaiseEvents_ThreadSafe(EV_GSMTIMEOUT, 0,  0,gsm->port,&port_mutex[gsm->port-1]);
				//nRunGsm=1;
				nRunGsm=0;
				tmr_h=set_gsm_timeout(gsm->port,0);
			}

			break;
		case CPICKUP:
			write_debug_gsm(gsm->port, "CPICKUP event received");
			gsm_puts_delayed(gsm->port, "ATA\r\n");
			RaiseEvents_ThreadSafe(EV_LINEREADY, 0, 0, gsm->port, &port_mutex[gsm->port - 1]);
			break;

		case CHANGUP:
			write_debug_gsm(gsm->port, "CHANGUP event received");
			gsm_puts_delayed(gsm->port, "ATH\r\n");
			ports_info[gsm->port - 1].gsm_info.nDialFlag = 0;
			ports_info[gsm->port - 1].gsm_info.nHangupFlag = 1;

			//RaiseEvents_ThreadSafe(EV_LINEOFF, 0, 0, gsm->port, &port_mutex[gsm->port - 1]);//send lineoff after receiveing ok
			break;
		} //switch (gsm_events.command)

		//----------------------------- run GSM State machine to get modem (AT) strings ---------------------
		if (nRunGsm)
		{
			switch (nGsmATStep)
			{
			case GSM_AT_IDLE:

				if(nRxCnt != 0)
				{

					if( szRxMsg[nBuff][nRxCnt-1] == LF || ((szRxMsg[nBuff][nRxCnt-1] == '>')&&(gsm->nGSMStep==GSM_SMS1)) || nRxCnt >= 250 )
					{
						nAnalyse = 1;

						if(nRxCnt >=250) //test
							nRxCnt = 250;


						if((nRxCnt>1)&& (szRxMsg[nBuff][nRxCnt-1] == LF))
						{
							if(szRxMsg[nBuff][nRxCnt-2] == CR)
								szRxMsg[nBuff][nRxCnt-2] = '\0';      //terminates the string with zero
							else
								szRxMsg[nBuff][nRxCnt-1] = '\0';      //terminates the string with zero
						}
						else
						{
							//in case szRxMsg[nBuff][nRxCnt-1]=='>'
							if( szRxMsg[nBuff][nRxCnt-1] == '>'){
								szRxMsg[nBuff][0] = '>';		//in case of LF+>
								szRxMsg[nBuff][1] = '\0';      //terminates the string with zero
							}
						}

						if(szRxMsg[nBuff][0] != '\0')
						{
							//reset timeout for digits only if it is a valid answer
							//AA tmr_h=set_gsm_timeout(gsm->port,0);
							//copy string to intermediate buffer and raise event to application
							//strncpy(gsm->szGSMMessage,szRxMsg[nBuff],255);
							memcpy(gsm->szGSMMessage,szRxMsg[nBuff],nRxCnt+1);
							RaiseEvents_ThreadSafe(EV_GSMMESSAGE,GSM_AT_RECEIVING ,
									0,gsm_events.port,&port_mutex[gsm->port-1]);

						}
						write_debug_gsm(gsm->port,"GSM_AT_IDLE: LF received: '%s' - nBuff %d",szRxMsg[nBuff],nBuff);

						tmr_h=set_gsm_timeout(gsm->port,0);

						nBuff = (nBuff+1)&1;                 //change nBuff
						nRxCnt = 0;
						szRxMsg[nBuff][0]=0;
						szMSGRaw[nBuff][0]=0;
					}
					else
						if((nRxCnt>1) && (szRxMsg[nBuff][nRxCnt-2] == LF || ((szRxMsg[nBuff][nRxCnt-2] == '>')&&(gsm->nGSMStep==GSM_SMS1))) || nRxCnt >= 250 )
						{
							nAnalyse = 1;

							if(nRxCnt >=250) //test
								nRxCnt = 250;


							if((nRxCnt>2)&& (szRxMsg[nBuff][nRxCnt-2] == LF))
							{
								if(szRxMsg[nBuff][nRxCnt-3] == CR)
									szRxMsg[nBuff][nRxCnt-3] = '\0';      //terminates the string with zero
								else
									szRxMsg[nBuff][nRxCnt-2] = '\0';      //terminates the string with zero
							}else
							{
								//in case szRxMsg[nBuff][nRxCnt-2]=='>'
								if( szRxMsg[nBuff][nRxCnt-2] == '>'){
									szRxMsg[nBuff][0] = '>';		//in case of LF+>
									szRxMsg[nBuff][1] = '\0';      //terminates the string with zero
								}
							}

							if(szRxMsg[nBuff][0] != '\0')
							{
								//reset timeout for digits only if it is a valid answer
								//AA tmr_h=set_gsm_timeout(gsm->port,0);
								//copy string to intermediate buffer and raise event to application
								//strncpy(gsm->szGSMMessage,szRxMsg[nBuff],255);
								memcpy(gsm->szGSMMessage,szRxMsg[nBuff],nRxCnt+1);
								RaiseEvents_ThreadSafe(EV_GSMMESSAGE,GSM_AT_RECEIVING ,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
							}
							write_debug_gsm(gsm->port,"GSM_AT_RECEIVING: LF received: '%s' - nBuff %d",szRxMsg[nBuff],nBuff);

							tmr_h=set_gsm_timeout(gsm->port,0);

							//to avoid loosing characters copy the last one to the other buffer
							szRxMsg[(nBuff+1)&1][0]=szRxMsg[nBuff][nRxCnt-1];
							szMSGRaw[(nBuff+1)&1][0]=szMSGRaw[nBuff][nRxCnt-1];
							szMSGRaw[nBuff][nRxCnt-1] = '\0';

							nBuff = (nBuff+1)&1;					  //change nBuff
							nRxCnt = 1;

						}
						else
						{
							//write_debug_gsm(gsm->port,"GSM_AT_IDLE: character received changing to GSM_AT_RECEIVING nBuff %d",nBuff);

							nGsmATStep = GSM_AT_RECEIVING;         //wait more characters
							//set timeout for digits
							tmr_h=set_gsm_timeout(gsm->port,gsm->nDigitTimeout);
						}

				}
				break;

			case GSM_AT_RECEIVING:

				if (timeout==tmr_h)
				{/*
				if (nStartFlag == 0)
				{
					nStartFlag = 1;

					RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);			
				}*/

					gsm->nGSMStep = GSM_ALL;
					nGsmATStep = GSM_AT_IDLE;
					szRxMsg[nBuff][nRxCnt] = '\0';      //terminates the string with zero
					nBuff = (nBuff+1)&1;				//change nBuff
					nRxCnt = 0;
					nAnalyse = 0;
					gsm->nDialFlag = 0;
					gsm->nHangupFlag = 0;

					//reset set timeout for digits
					tmr_h=set_gsm_timeout(gsm->port,0);

					//RaiseEvents_ThreadSafe(EV_GSMTIMEOUT,GSM_AT_RECEIVING ,
					//                   0,gsm_events.port,&port_mutex[gsm->port-1]);

					//write_debug_gsm(gsm->port,"GSM_AT_RECEIVING: Timeout");

					break;
				}



				if((nRxCnt>1) && ( szRxMsg[nBuff][nRxCnt-2] == LF || ((szRxMsg[nBuff][nRxCnt-2] == '>')&&(gsm->nGSMStep==GSM_SMS1))) || nRxCnt >= 250 )
				{
					nAnalyse = 1;

					if(nRxCnt >=250) //test
						nRxCnt = 250;

					if((nRxCnt>2)&& (szRxMsg[nBuff][nRxCnt-2] == LF))
					{
						if(szRxMsg[nBuff][nRxCnt-3] == CR)
							szRxMsg[nBuff][nRxCnt-3] = '\0';      //terminates the string with zero
						else
							szRxMsg[nBuff][nRxCnt-2] = '\0';      //terminates the string with zero
					}else
					{
						//in case szRxMsg[nBuff][nRxCnt-2]=='>'
						if(szRxMsg[nBuff][nRxCnt-1] ='>'){
							szRxMsg[nBuff][0] = '>';		//in case of LF+>
							szRxMsg[nBuff][1] = '\0';      //terminates the string with zero
						}
					}

					if(szRxMsg[nBuff][0] != '\0')
					{
						//reset timeout for digits only if it is a valid answer
						//AA tmr_h=set_gsm_timeout(gsm->port,0);
						//copy string to intermediate buffer and raise event to application
						//strncpy(gsm->szGSMMessage,szRxMsg[nBuff],255);
						memcpy(gsm->szGSMMessage,szRxMsg[nBuff],nRxCnt+1);
						RaiseEvents_ThreadSafe(EV_GSMMESSAGE,GSM_AT_RECEIVING ,
								0,gsm_events.port,&port_mutex[gsm->port-1]);
					}

					tmr_h=set_gsm_timeout(gsm->port,0);

					write_debug_gsm(gsm->port,"GSM_AT_RECEIVING: LF received: '%s' - nBuff %d",szRxMsg[nBuff],nBuff);

					//to avoid loosing characters copy the last one to the other buffer
					szRxMsg[(nBuff+1)&1][0]=szRxMsg[nBuff][nRxCnt-1];
					szMSGRaw[(nBuff+1)&1][0]=szMSGRaw[nBuff][nRxCnt-1];
					szMSGRaw[nBuff][nRxCnt-1] = '\0';

					nBuff = (nBuff+1)&1;					  //change nBuff
					nRxCnt = 1;

					nGsmATStep = GSM_AT_IDLE;
				}

				else
					if( szRxMsg[nBuff][nRxCnt-1] == LF || ((szRxMsg[nBuff][nRxCnt-1] == '>')&&(gsm->nGSMStep==GSM_SMS1)) || nRxCnt >= 250 )
					{
						nAnalyse = 1;

						if(nRxCnt >=250) //test
							nRxCnt = 250;



						if((nRxCnt>1)&& (szRxMsg[nBuff][nRxCnt-1] == LF))
						{
							if(szRxMsg[nBuff][nRxCnt-2] == CR)
								szRxMsg[nBuff][nRxCnt-2] = '\0';      //terminates the string with zero
							else
								szRxMsg[nBuff][nRxCnt-1] = '\0';      //terminates the string with zero
						}
						else
						{
							//in case szRxMsg[nBuff][nRxCnt-1]=='>'
							if(szRxMsg[nBuff][nRxCnt-1]=='>'){
								szRxMsg[nBuff][0] = '>';		//in case of LF+>
								szRxMsg[nBuff][1] = '\0';      //terminates the string with zero
							}
						}

						if(szRxMsg[nBuff][0] != '\0')
						{
							//reset timeout for digits only if it is a valid answer
							//AA tmr_h=set_gsm_timeout(gsm->port,0);
							//copy string to intermediate buffer and raise event to application
							//strncpy(gsm->szGSMMessage,szRxMsg[nBuff],255);
							memcpy(gsm->szGSMMessage,szRxMsg[nBuff],nRxCnt+1);
							RaiseEvents_ThreadSafe(EV_GSMMESSAGE,GSM_AT_RECEIVING ,
									0,gsm_events.port,&port_mutex[gsm->port-1]);
						}
						write_debug_gsm(gsm->port,"GSM_AT_RECEIVING: LF received: '%s' - nBuff %d",szRxMsg[nBuff],nBuff);

						tmr_h=set_gsm_timeout(gsm->port,0);

						nBuff = (nBuff+1)&1;					  //change nBuff
						nRxCnt = 0;
						szRxMsg[nBuff][0]=0;
						szMSGRaw[nBuff][0]=0;

						nGsmATStep = GSM_AT_IDLE;
					}
					else
					{
						//set timeout for digits
						tmr_h=set_gsm_timeout(gsm->port,gsm->nDigitTimeout);
					}

				break;
			}//switch nGsmATStep

			if (nAnalyse)
			{
				switch (gsm->nGSMStep)
				{
				case GSM_IDLE:
					break;

				case GSM_SYSSTART:
					if( strncmp(szRxMsg[(nBuff+1)&1], "^SYSSTART",9)==0)
					{
						ports_info[gsm->port-1].gsm_info.thread_ready = 2;

						gsm->nGSMStep = GSM_E0;
						//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
						gsm_puts(gsm->port,"AT&F\r\n");//restore factory default

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if( (strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0)||//due to timeout errors this error can be here
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))  //due to timeout errors this error can be here

						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);          //wait 10000ms to go

								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters

								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_EF,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								nErrorCnt = 0;
								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SYSSTART, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SYSSTART, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_E0: //send ATE0 : turn command echo off
					//write_debug_gsm(gsm->port," * GSM_E0: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount = 1;

						digivoice_sleep(100);          //wait 100ms to go

						gsm->nGSMStep = GSM_IPR;
						gsm_puts(gsm->port,"ATE0\r\n");//turn command echo off

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if( (strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0)||//due to timeout errors this error can be here
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))  //due to timeout errors this error can be here

						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);          //wait 10000ms to go

								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters

								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_EF,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								nErrorCnt = 0;
								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "AT&F",4)==0)
							{
								//nothing to do
							}
							else
							{
								//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

								if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
								{
									write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_E0, generating EV_GSMERROR to application!\n");

									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_E0, 0, gsm_events.port, &port_mutex[gsm->port-1]);
									tmr_h=set_gsm_timeout(gsm->port, 0);
									gsm->nGSMStep = GSM_ALL;
								}
							}
					break;

				case GSM_IPR:  //send AT+IPR=57600: set baud rate
					//write_debug_gsm(gsm->port," * GSM_IPR: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;
						nPINFlag= 0;
						//check if is to send PIN NUMBER
						gsm->nGSMStep = GSM_SCKS;

						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT+IPR=57600\r\n");//set baud rate

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters

								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_E0,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "ATE0",4)==0)
							{
								//nothing to do
							}
							else
							{
								//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

								if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
								{
									write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_IPR, generating EV_GSMERROR to application!\n");

									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_IPR, 0, gsm_events.port, &port_mutex[gsm->port-1]);
									tmr_h=set_gsm_timeout(gsm->port, 0);
									gsm->nGSMStep = GSM_ALL;
								}
							}
					break;

				case GSM_SCKS: //query sim and chip card holder status

					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);          //wait 100ms to go

						gsm->nGSMStep = GSM_CPIN;

						gsm_puts(gsm->port,"AT^SCKS=1\r\n");

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_IPR,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SCKS, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SCKS, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CPIN:  //check if PIN is required, send AT+CPIN?"
					//write_debug_gsm(gsm->port," * GSM_CPIN: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						if (nPINFlag == 0)
						{
							if(gsm->nIDRestriction != 3)
							{
								gsm->nGSMStep = GSM_CPIN; //stay here
								digivoice_sleep(300);          //wait 100ms to go
								gsm_puts(gsm->port,"AT+CPIN?\r\n");//check pin

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}
							else
							{
								//for tests purposes if nIDRestriction is 3 stop here the initialization
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;
								gsm_puts(gsm->port,"AT\r\n");//just to get an answer ok

							}

						}
						else
						{
							gsm->nGSMStep = GSM_COPS;
							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
						}

					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: READY",14)==0)
						{
							gsm->nGSMStep = GSM_COPS;
							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: SIM PIN",14)==0)
							{
								nPINFlag = 1;
								if(gsm->szPinNumber[0] != '\0' )
								{
									sprintf(szTemp,"AT+CPIN=%s\r\n",gsm->szPinNumber);
									gsm_puts(gsm->port,szTemp);

									//set timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
								}
								else
								{
									//Send event to application
									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SIM_PIN,
											0,gsm_events.port,&port_mutex[gsm->port-1]);
									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
									gsm->nGSMStep = GSM_ALL;

								}
							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: SIM PUK",14)==0)
								{
									//Send event to application
									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SIM_PUK,
											0,gsm_events.port,&port_mutex[gsm->port-1]);
									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
									gsm->nGSMStep = GSM_ALL;

								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: SIM PIN2",15)==0)
									{
										//Send event to application
										RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SIM_PIN2,
												0,gsm_events.port,&port_mutex[gsm->port-1]);
										//reset timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,0);
										gsm->nGSMStep = GSM_ALL;

									}
									else
										if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: SIM PUK2",15)==0)
										{
											//Send event to application
											RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SIM_PUK2,
													0,gsm_events.port,&port_mutex[gsm->port-1]);
											//reset timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,0);
											gsm->nGSMStep = GSM_ALL;

										}
										else
											if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-SIM PIN",17)==0)
											{
												//Send event to application
												RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHSIM_PIN,
														0,gsm_events.port,&port_mutex[gsm->port-1]);
												//reset timeout for characters
												tmr_h=set_gsm_timeout(gsm->port,0);
												gsm->nGSMStep = GSM_ALL;
											}
											else
												if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-SIM PUK",17)==0)
												{
													//Send event to application
													RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHSIM_PUK,
															0,gsm_events.port,&port_mutex[gsm->port-1]);
													//reset timeout for characters
													tmr_h=set_gsm_timeout(gsm->port,0);
													gsm->nGSMStep = GSM_ALL;
												}
												else
													if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-FSIM PIN",18)==0)
													{
														//Send event to application
														RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHFSIM_PIN,
																0,gsm_events.port,&port_mutex[gsm->port-1]);
														//reset timeout for characters
														tmr_h=set_gsm_timeout(gsm->port,0);
														gsm->nGSMStep = GSM_ALL;

													}
													else
														if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-FSIM PUK",18)==0)
														{
															//Send event to application
															RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHFSIM_PUK,
																	0,gsm_events.port,&port_mutex[gsm->port-1]);
															//reset timeout for characters
															tmr_h=set_gsm_timeout(gsm->port,0);
															gsm->nGSMStep = GSM_ALL;

														}
														else
															if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-NET PUK",17)==0)
															{
																//Send event to application
																RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHNET_PUK,
																		0,gsm_events.port,&port_mutex[gsm->port-1]);
																//reset timeout for characters
																tmr_h=set_gsm_timeout(gsm->port,0);
																gsm->nGSMStep = GSM_ALL;
															}
															else
																if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-NS PIN",16)==0)
																{
																	//Send event to application
																	RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHNS_PIN,
																			0,gsm_events.port,&port_mutex[gsm->port-1]);
																	//reset timeout for characters
																	tmr_h=set_gsm_timeout(gsm->port,0);
																	gsm->nGSMStep = GSM_ALL;
																}
																else
																	if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-NS PUK",16)==0)
																	{
																		//Send event to application
																		RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHNS_PUK,
																				0,gsm_events.port,&port_mutex[gsm->port-1]);
																		//reset timeout for characters
																		tmr_h=set_gsm_timeout(gsm->port,0);
																		gsm->nGSMStep = GSM_ALL;
																	}
																	else
																		if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-SP PIN",16)==0)
																		{
																			//Send event to application
																			RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHSP_PIN,
																					0,gsm_events.port,&port_mutex[gsm->port-1]);
																			//reset timeout for characters
																			tmr_h=set_gsm_timeout(gsm->port,0);
																			gsm->nGSMStep = GSM_ALL;
																		}
																		else
																			if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-SP PUK",16)==0)
																			{
																				//Send event to application
																				RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHSP_PUK,
																						0,gsm_events.port,&port_mutex[gsm->port-1]);
																				//reset timeout for characters
																				tmr_h=set_gsm_timeout(gsm->port,0);
																				gsm->nGSMStep = GSM_ALL;
																			}
																			else
																				if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-C PIN",15)==0)
																				{
																					//Send event to application
																					RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHC_PIN,
																							0,gsm_events.port,&port_mutex[gsm->port-1]);
																					//reset timeout for characters
																					tmr_h=set_gsm_timeout(gsm->port,0);
																					gsm->nGSMStep = GSM_ALL;
																				}
																				else
																					if( strncmp(szRxMsg[(nBuff+1)&1], "+CPIN: PH-C PUK",15)==0)
																					{
																						//Send event to application
																						RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_PHC_PUK,
																								0,gsm_events.port,&port_mutex[gsm->port-1]);
																						//reset timeout for characters
																						tmr_h=set_gsm_timeout(gsm->port,0);
																						gsm->nGSMStep = GSM_ALL;
																					}
																					else
																						if( (strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
																								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
																						{
																							nErrorCnt++;
																							if(nErrorCnt < 3)
																							{
																								tmr_h=set_gsm_timeout(gsm->port,0);
																								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
																								gsm->nGSMStep = GSM_E0;
																								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
																								//restore factory settings
																								gsm_puts(gsm->port,"AT&F\r\n");

																								//set timeout for characters
																								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
																							}else
																							{
																								nErrorCnt = 0;
																								//Send event to application
																								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CPIN,
																										0,gsm_events.port,&port_mutex[gsm->port-1]);
																								//reset timeout for characters
																								tmr_h=set_gsm_timeout(gsm->port,0);
																								gsm->nGSMStep = GSM_ALL;

																								if (nStartFlag == 0)
																								{
																									nStartFlag = 1;

																									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
																									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
																								}
																							}
																						}
																						else
																						{
																							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

																							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
																							{
																								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CPIN, generating EV_GSMERROR to application!\n");

																								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CPIN, 0, gsm_events.port, &port_mutex[gsm->port-1]);
																								tmr_h=set_gsm_timeout(gsm->port, 0);
																								gsm->nGSMStep = GSM_ALL;
																							}
																						}
					break;

				case GSM_COPS:  //send AT+COPS=0 : set automatic carrier detection
					//write_debug_gsm(gsm->port," * GSM_COPS: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						gsm->nGSMStep = GSM_SNFS;
						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT+COPS=0\r\n");//set automatic carrier detection

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if( ( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CPIN,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;


								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_COPS, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_COPS, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;
				case GSM_SNFS:  //send AT^SNFS : select audio hardware set
					//write_debug_gsm(gsm->port," * GSM_SNFS: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						gsm->nGSMStep = GSM_SAIC;
						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT^SNFS=4\r\n");//set automatic carrier detection

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}
					else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_COPS,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SNFS, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SNFS, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_SAIC:  //send AT^SAIC: define digital audio interface
					//write_debug_gsm(gsm->port," * GSM_SAIC: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						gsm->nGSMStep = GSM_SNFO;
						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT^SAIC=1\r\n");//define digital audio interface

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SNFS,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SAIC, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SAIC, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}

					break;
				case GSM_SNFO:  //send AT^SNFO : set audio output
					//write_debug_gsm(gsm->port," * GSM_SNFS: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						gsm->nGSMStep = GSM_CLIP;
						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT^SNFO=0,16384,16384,16384,16384,16384,0,0\r\n");//set audio output

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}
					else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SNFO,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SNFO, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SNFO, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;
				case GSM_CLIP:  //send AT+CLIP=1 : Calling Line Identification Presentation

					//write_debug_gsm(gsm->port," * GSM_CLIP: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						gsm->nGSMStep = GSM_CMEE;
						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT+CLIP=1\r\n");//Calling Line Identification Presentation

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SAIC,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CLIP, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLIP, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CMEE:  //send AT+CMEE=2: enable error codes with verbose
					//write_debug_gsm(gsm->port," * GSM_CMEE: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						gsm->nGSMStep = GSM_CLIR;
						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT+CMEE=2\r\n");//enable error codes with verbose

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLIP,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CMEE, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CMEE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CLIR:  //send AT+CLIR = n :ID Restriction ON/OFF
					//write_debug_gsm(gsm->port," * GSM_CLIR: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);          //wait 100ms to go
						gsm->nGSMStep = GSM_CSCS;
						switch (gsm->nIDRestriction)
						{
						case 0:
							gsm_puts(gsm->port,"AT+CLIR=2\r\n");//ID restriction OFF
							break;

						case 1:
							gsm_puts(gsm->port,"AT+CLIR=1\r\n");//ID Restriction ON
							break;

						case 2:
							gsm->nGSMStep = GSM_CSMS;
							gsm_puts(gsm->port,"AT+CSCS=\"GSM\"\r\n");//Select Character set as GSM
							break;
						}

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,2*gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CMEE,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CLIR, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLIR, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CSCS:  //send AT+CSCS="GSM" : Select Character set as GSM
					//write_debug_gsm(gsm->port," * GSM_CSCS: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);          //wait 100ms to go
						gsm->nGSMStep = GSM_CSMS;
						gsm_puts(gsm->port,"AT+CSCS=\"GSM\"\r\n");//Select Character set as GSM

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLIR,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CSCS, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CSCS, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CSMS:  //select message service
					//write_debug_gsm(gsm->port," * GSM_CSMS: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						gsm->nGSMStep = GSM_CSMS;					//stay here waiting +CSMS
						digivoice_sleep(100);					//wait 100ms to go
						gsm_puts(gsm->port,"AT+CSMS=1\r\n");	//Set Message Service

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "+CSMS:",6)==0)
						{
							nStartCount++;

							gsm->nGSMStep = GSM_CNMI;					//wait for OK

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)
							{
								nErrorCnt++;
								if(nErrorCnt < 3)
								{
									tmr_h=set_gsm_timeout(gsm->port,0);
									digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
									gsm->nGSMStep = GSM_E0;
									//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
									//restore factory settings
									gsm_puts(gsm->port,"AT&F\r\n");

									//set timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
								}else
								{
									nErrorCnt = 0;
									//Send event to application
									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CSCS,
											0,gsm_events.port,&port_mutex[gsm->port-1]);
									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
									gsm->nGSMStep = GSM_ALL;

									if (nStartFlag == 0)
									{
										nStartFlag = 1;

										//if (nStartCount < 15) //removed on 4.2.2.0_rc4
										RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
									}
								}
							}
							else
							{
								//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

								if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
								{
									write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CSMS, generating EV_GSMERROR to application!\n");

									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CSMS, 0, gsm_events.port, &port_mutex[gsm->port-1]);
									tmr_h=set_gsm_timeout(gsm->port, 0);
									gsm->nGSMStep = GSM_ALL;
								}
							}
					break;

				case GSM_CNMI:  //new short message indication
					//write_debug_gsm(gsm->port," * GSM_CNMI: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);					    //wait 100ms to go
						gsm->nGSMStep = GSM_SMGO;
						gsm_puts(gsm->port,"AT+CNMI=2,1,0,1\r\n");  //Enable presentation of URC for incoming SMS

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CSMS,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;				//wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CNMI, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CNMI, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_SMGO:  //set or query sms overflow
					//write_debug_gsm(gsm->port," * GSM_SMGO: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);					//wait 100ms to go
						gsm->nGSMStep = GSM_CPMS;
						gsm_puts(gsm->port,"AT^SMGO=1\r\n");	//Enable SMS overflow presentation mode

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CNMI,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SMGO, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMGO, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CPMS: //prefered sms message storage
					//write_debug_gsm(gsm->port," * GSM_CPMS: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						digivoice_sleep(100);									//wait 100ms to go
						gsm->nGSMStep = GSM_CPMS;									//stay here waiting +CPMS
						gsm_puts(gsm->port,"AT+CPMS=\"MT\",\"MT\",\"MT\"\r\n");	//Set SMS Prefered storage

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "+CPMS:",6)==0)
						{
							nStartCount++;

							//read index
							for (i = (int)strlen(szRxMsg[(nBuff+1)&1]) - 1; i > 0 ; i--)
							{

								if(szRxMsg[(nBuff+1)&1][i] == ',')
								{

									//copy index
									strcpy(szMaxMessage,&szRxMsg[(nBuff+1)&1][i+1]);
									break;
								}
							}

							gsm->nGSMStep = GSM_SNFPT;					//wait for OK

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
						}
						else
							if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
							   (strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
							{
								nErrorCnt++;
								if(nErrorCnt < 3)
								{
									tmr_h=set_gsm_timeout(gsm->port,0);
									digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
									gsm->nGSMStep = GSM_E0;
									//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
									//restore factory settings
									gsm_puts(gsm->port,"AT&F\r\n");

									//set timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
								}else
								{
									nErrorCnt = 0;
									//Send event to application
									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMGO,
											0,gsm_events.port,&port_mutex[gsm->port-1]);
									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
									gsm->nGSMStep = GSM_ALL;

									if (nStartFlag == 0)
									{
										nStartFlag = 1;

										//if (nStartCount < 15) //removed on 4.2.2.0_rc4
										RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
									}
								}
							}
							else
								/*if((strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
								{
									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
									gsm->nGSMStep = GSM_ALL;
									//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
								}
								else*/
								{
									//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

									if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
									{
										write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CPMS, generating EV_GSMERROR to application!\n");

										RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CPMS, 0, gsm_events.port, &port_mutex[gsm->port-1]);
										tmr_h=set_gsm_timeout(gsm->port, 0);
										gsm->nGSMStep = GSM_ALL;
									}
								}
					break;

				case GSM_SNFPT:  //set progress tones
					//write_debug_gsm(gsm->port," * GSM_SNFPT: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						gsm->nGSMStep = GSM_CCWA;
						digivoice_sleep(100);									//wait 100ms to go
						gsm_puts(gsm->port,"AT^SNFPT=0\r\n");	//Set SMS Prefered storage

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CPMS,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SNFPT, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SNFPT, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CCWA:  //call waiting
					//write_debug_gsm(gsm->port," * GSM_CCWA: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						digivoice_sleep(100);									//wait 100ms to go
						gsm->nGSMStep = GSM_CMGF;
						if(gsm->nCallWaitingEnable == 0)
						{
							if(gsm->nDisplayCallWaitingEnable == 0)
								gsm_puts(gsm->port,"AT+CCWA=0,0\r\n");
							else
								gsm_puts(gsm->port,"AT+CCWA=0\r\n");
						}
						else
						{
							if(gsm->nDisplayCallWaitingEnable == 0)
								gsm_puts(gsm->port,"AT+CCWA=1,1\r\n");
							else
								gsm_puts(gsm->port,"AT+CCWA=1\r\n");
						}

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SNFPT,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CCWA, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CCWA, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CMGF:  //select sms message format
					//write_debug_gsm(gsm->port," * GSM_CMGF: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);          //wait 100ms to go
						gsm->nGSMStep = GSM_Q3;
						gsm_puts(gsm->port,"AT+CMGF = 1\r\n");//SMS in Text mode
						//gsm->nGSMStep = GSM_ALL;

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SNFPT,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CMGF, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CMGF, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_Q3:  //set flow control
					//write_debug_gsm(gsm->port," * GSM_Q3: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						gsm->nGSMStep = GSM_CUSD;
						digivoice_sleep(100);          //wait 100ms to go
						gsm_puts(gsm->port,"AT\\Q3\r\n");//Set flow control on

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CMGF,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_Q3, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_Q3, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CUSD: //unstructured suplementary service data
					//write_debug_gsm(gsm->port," * GSM_CUSD: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);          //wait 100ms to go

						if((gsm->nMessageConfirmation == 0) && (gsm->nFlashSMS == 0))
						{
							gsm->nGSMStep = GSM_ALL;
							write_debug_gsm(gsm->port," GSM_CUSD: -> SMS confirmation disabled\n");
						}
						else
						{
							gsm->nGSMStep = GSM_SSCONF;
							write_debug_gsm(gsm->port," GSM_CUSD: -> SMS confirmation enabled\n");
						}
						if(gsm->nUSSDEnable == 0)
							gsm_puts(gsm->port,"AT+CUSD=0\r\n");
						else
							gsm_puts(gsm->port,"AT+CUSD=1\r\n");


						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_Q3,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;

									//if (nStartCount < 15) //removed on 4.2.2.0_rc4
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CUSD, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CUSD, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_SSCONF: //SMS Command configuration

					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);          //wait 100ms to go
						gsm->nGSMStep = GSM_CSMP;

						gsm_puts(gsm->port,"AT^SSCONF=1\r\n");

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CUSD,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SSCONF, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SSCONF, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;

				case GSM_CSMP: //SMS Text mode parameters
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						nStartCount++;

						digivoice_sleep(100);          //wait 100ms to go
						gsm->nGSMStep = GSM_ALL;

						if(gsm->nFlashSMS == 0)
							gsm_puts(gsm->port,"AT+CSMP=49,167,0,0\r\n");//GSMCFG_MESSAGE_CONFIRMATION
						else
							if(gsm->nMessageConfirmation == 0)
								gsm_puts(gsm->port,"AT+CSMP=17,167,0,240\r\n");//GSMCFG_FLASHSMS_ENABLE
							else
								gsm_puts(gsm->port,"AT+CSMP=49,167,0,240\r\n");//GSMCFG_FLASHSMS_ENABLE + GSMCFG_MESSAGE_CONFIRMATION

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR:",11)==0))
						{
							nErrorCnt++;
							if(nErrorCnt < 3)
							{
								tmr_h=set_gsm_timeout(gsm->port,0);
								digivoice_sleep(gsm->nRetryTimeout*nErrorCnt);
								gsm->nGSMStep = GSM_E0;
								//nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters
								//restore factory settings
								gsm_puts(gsm->port,"AT&F\r\n");

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							}else
							{
								nErrorCnt = 0;
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SSCONF,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
								gsm->nGSMStep = GSM_ALL;

								if (nStartFlag == 0)
								{
									nStartFlag = 1;
									RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								}
							}
						}
						else
						{
							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CSMP, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CSMP, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;
				case GSM_ALL:  //after AT+CLIP=1
					nErrorCnt = 3;
					write_debug_gsm(gsm->port," * GSM_ALL: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						if (nStartFlag == 0)
						{
							nStartFlag = 1;

							//if (nStartCount < 15) //removed on 4.2.2.0_rc4
							//RaiseEvents_ThreadSafe(EV_GSMREADY, FALSE, 0, gsm_events.port, &port_mutex[gsm->port-1]); //removed on 4.2.2.0_rc4
							//else //removed on 4.2.2.0_rc4
							RaiseEvents_ThreadSafe(EV_GSMREADY, TRUE, 0, gsm_events.port, &port_mutex[gsm->port-1]);//TODO por true/false
							ports_info[gsm->port-1].gsm_info.ClearAllSMS_Timeout_Id = set_gsm_ClearAllSMS_timeout(gsm_events.port, 30000);
						}

						//reset timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,0);

						if(gsm->nDialFlag == 1)
						{
							gsm->nDialFlag=0;

							//Fires EV_ANSWERED - after calling dg_dial ok comes only on answer
							RaiseEvents_ThreadSafe(EV_ANSWERED, 0, 0, gsm->port, &port_mutex[gsm->port-1]);
						}

						if(gsm->nHangupFlag == 1)
						{
							gsm->nHangupFlag = 0;

							//Fires EV_LINEOFF
							RaiseEvents_ThreadSafe(EV_LINEOFF, 0, 0, gsm->port, &port_mutex[gsm->port-1]);
						}

						gsm->nGSMStep = GSM_ALL;  //stay here
					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "RING",4)==0)//RING received
						{
							gsm->nGSMStep = GSM_ALL;  //stay here
							RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

							gsm->nHangupFlag = 0;

							//reset timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,0);

						}else
							if( strncmp(szRxMsg[(nBuff+1)&1], "^SMGO",5)==0)//SMGO received
							{
								gsm->nGSMStep = GSM_ALL;  //stay here
								RaiseEvents_ThreadSafe(EV_GSMMEMORYFULL, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
							}else
								if( strncmp(szRxMsg[(nBuff+1)&1], "NO CARRIER",10)==0)//NO CARRIER received
								{
									gsm->nGSMStep = GSM_ALL;  //stay here
									RaiseEvents_ThreadSafe(EV_BUSY, 404,  0, gsm_events.port,&port_mutex[gsm->port-1]);

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
								}else
									if( strncmp(szRxMsg[(nBuff+1)&1], "NO DIALTONE",11)==0)//NO DIALTONE received
									{
										gsm->nGSMStep = GSM_ALL;  //stay here
										RaiseEvents_ThreadSafe(EV_BUSY, 503,  0, gsm_events.port,&port_mutex[gsm->port-1]);

										//reset timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,0);
									}else
										if( strncmp(szRxMsg[(nBuff+1)&1], "BUSY",4)==0)//BUSY received
										{
											gsm->nGSMStep = GSM_ALL;  //stay here
											RaiseEvents_ThreadSafe(EV_BUSY, 486,  0, gsm_events.port,&port_mutex[gsm->port-1]);

											//reset timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,0);
										}else
											if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)//sent message confirmation
											{
												strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
												RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												gsm_puts(gsm->port,"AT+CNMA\r\n");

												//set timeout for characters
												tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

											}else
												if( strncmp(szRxMsg[(nBuff+1)&1], "+CLIP:",6)==0)//caller id received
												{
													for(i=0;i<30;i++) //extracts caller ID
													{
														gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
														gsm->rx_id_digits[i+1] = '\0';
														gsm->rx_id_number_of_digits =(char)(i+1);
														if(gsm->rx_id_digits[i]=='"')
														{
															gsm->rx_id_digits[i] = '\0';
															break;
														}
													}
													gsm->nGSMStep = GSM_ALL;  //stay here
													RaiseEvents_ThreadSafe(EV_CALLERID, gsm->rx_id_number_of_digits ,  0, gsm_events.port,&port_mutex[gsm->port-1]);

													//reset timeout for characters
													tmr_h=set_gsm_timeout(gsm->port,0);
												}else
													if( strncmp(szRxMsg[(nBuff+1)&1], "+CCWA:",6)==0)//caller id received
													{
														for(i=0;i<30;i++) //extracts caller ID
														{
															gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
															gsm->rx_id_digits[i+1] = '\0';
															gsm->rx_id_number_of_digits = (char)(i+1);
															if(gsm->rx_id_digits[i]=='"')
															{
																gsm->rx_id_digits[i] = '\0';
																break;
															}
														}
														gsm->nGSMStep = GSM_ALL;  //stay here
														RaiseEvents_ThreadSafe(EV_GSMOTHERCALL, 0, 0, gsm_events.port,&port_mutex[gsm->port-1]);

														//reset timeout for characters
														tmr_h=set_gsm_timeout(gsm->port,0);
													}else
														if( strncmp(szRxMsg[(nBuff+1)&1], "+CMTI:",6)==0) //SMS Text rec
														{
															write_debug_gsm(gsm->port, "Event +CMTI: received: '%s', strlen: %d", szRxMsg[(nBuff+1)&1], strlen(szRxMsg[(nBuff+1)&1]));

															//save CMTI until the message has been read and deleted
															nTempW = (gsm->nDelayedRxIndexW + 1)&15; //round to 16 itens

															if(nTempW != gsm->nDelayedRxIndexR)
															{

																//copy command to temporary buffer
																strcpy(gsm->szDelayedRx[gsm->nDelayedRxIndexW],szRxMsg[(nBuff+1)&1]);
																gsm->nDelayedRxIndexW = nTempW;
															}


															//read index
															for (i = (int)strlen(szRxMsg[(nBuff+1)&1]) - 1; i > 0 ; i--)
															{
																//write_debug_gsm(gsm->port, "+CMTI Parse: %c", szRxMsg[(nBuff+1)&1][i]);

																if(szRxMsg[(nBuff+1)&1][i] == ',')
																{
																	//digivoice_sleep(100);          //wait 100ms to go

																	//copy index
																	strcpy(gsm->szIndex,&szRxMsg[(nBuff+1)&1][i+1]);
																	sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
																	gsm_puts(gsm->port,szTemp);

																	//reset sms header flag
																	nSMSHeaderFlag=0;

																	//set timeout for characters
																	tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
																	break;
																}
															}
															//gsm->nGSMStep = GSM_SMS2;
															gsm->nGSMStep = GSM_ALL;  //stay here
															//RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_ALL,  0, gsm_events.port,&port_mutex[gsm->port-1]);

														}else
															if( strncmp(szRxMsg[(nBuff+1)&1], "+CMGR:",6)==0) //SMS Broadcast Message rec
															{
																//write_debug_gsm(gsm->port," * GSM_ALL  SMS header: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

																//save message received
																strcpy(gsm->szRxSMS,szRxMsg[(nBuff+1)&1]);

																//convert GSM to ANSI only for the text message
																//strGSM2ANSI(gsm->szRxSMS);
																tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
																gsm->nGSMStep = GSM_SMS2;  //wait OK to delete

																nSMSHeaderFlag=1;

															}else
																if( strncmp(szRxMsg[(nBuff+1)&1], "+CMGL:",6)==0) //SMS List Message rec
																{
																	szTempIndex[0] = szRxMsg[(nBuff+1)&1][7];
																	if (szRxMsg[(nBuff+1)&1][8] == ',')
																	{
																		szTempIndex[1] = '\0';
																	}
																	else
																	{
																		szTempIndex[1] = szRxMsg[(nBuff+1)&1][8];
																		szTempIndex[2] = '\0';
																	}
																	strcpy(szIndexMessage,szTempIndex);

																	//save message received
																	//strcpy(gsm->szRxSMS,szRxMsg[(nBuff+1)&1]);

																	tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
																	gsm->nGSMStep = GSM_LIST;

																}else
																	if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
																	{
																		gsm->nGSMStep = GSM_ALL;         //wait for answer characters

																		if (strlen(szRxMsg[(nBuff+1)&1]) >= 9)//Response of Read Command (like ^SCKS: X,X)
																		{
																			//nothing to do
																		}
																		else//Unsolicited Result Code (like ^SCKS: X)
																		{
																			if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
																			{
																				RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
																			}
																			else
																				if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
																				{
																					RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
																				}
																		}
																		//reset timeout for characters
																		tmr_h=set_gsm_timeout(gsm->port,0);
																	}else
																		if( strncmp(szRxMsg[(nBuff+1)&1], "+CSQ:",5)==0)//signal received
																		{
																			nTmpCQ = 0;
																			for(i=5;i<30;i++)
																			{
																				if (nTmpCQ == 0)//extracts signal
																				{
																					gsm->szSQ[i-5] = szRxMsg[(nBuff+1)&1][i];
																					gsm->szSQ[i-5+1] = '\0';
																					if(gsm->szSQ[i-5]==',')
																					{
																						gsm->szSQ[i-5] = '\0';
																						nTmpCQ = i-5+1;
																						continue;
																					}
																				}
																				else//extracts call
																				{
																					gsm->szCQ[i-5-nTmpCQ] = szRxMsg[(nBuff+1)&1][i];
																					gsm->szCQ[i-5-nTmpCQ+1] = '\0';
																					if(szRxMsg[(nBuff+1)&1][i] == '\0')
																					{
																						gsm->szCQ[i-5-nTmpCQ] = '\0';
																						break;
																					}
																				}
																			}

																			gsm->nGSMStep = GSM_ALL;  //stay here

																			RaiseEvents_ThreadSafe(EV_GSMSIGNALQUALITY, GSM_ALL ,  0, gsm_events.port,&port_mutex[gsm->port-1]);

																			//reset timeout for characters
																			tmr_h=set_gsm_timeout(gsm->port,0);
																		}else
																			if( strncmp(szRxMsg[(nBuff+1)&1], "+CME ERROR",10)==0)
																			{

																				//the string is already stored in szGSMMessage
																				RaiseEvents_ThreadSafe(EV_GSMERROR,GSM_ALL ,
																						0,gsm_events.port,&port_mutex[gsm->port-1]);

																				//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

																				//reset timeout for characters
																				tmr_h=set_gsm_timeout(gsm->port,0);
																			}else
																				if( strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0)
																				{

																					//the string is already stored in szGSMMessage
																					RaiseEvents_ThreadSafe(EV_GSMERROR,GSM_ALL ,
																							0,gsm_events.port,&port_mutex[gsm->port-1]);

																					// = GSM_AT_IDLE;         //wait for answer characters

																					//reset timeout for characters
																					tmr_h=set_gsm_timeout(gsm->port,0);
																				}
																				else
																					if( strncmp(szRxMsg[(nBuff+1)&1], "^SYSSTART",9)==0)
																					{
																						write_debug_gsm(gsm->port," * GSM_ALL: Received ^SYSSTART\n");
																						gsm->nGSMStep = GSM_ALL;  //stay here
																						nGsmATStep = GSM_AT_RECEIVING;         //wait for answer characters

																						//reset timeout for characters
																						tmr_h=set_gsm_timeout(gsm->port,0);
																					}
																					else
																						if( strncmp(szRxMsg[(nBuff+1)&1], "+CUSD:",6)==0)//USSD Message Received
																						{
																							gsm->nGSMStep = GSM_ALL;  //stay here

																							strncpy(gsm->szUSSDMessage, szRxMsg[(nBuff+1)&1], 255);
																							RaiseEvents_ThreadSafe(EV_GSMUSSDRECEIVED, 0, 0, gsm_events.port, &port_mutex[gsm->port-1]);

																							gsm->nHangupFlag = 0;

																							//reset timeout for characters
																							tmr_h=set_gsm_timeout(gsm->port,0);

																						}else
																						{
																							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters

																							/* Removed following code, because all messages response are here
																							 * if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
																							{
																								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_ALL, generating EV_GSMERROR to application!\n");

																								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_ALL, 0, gsm_events.port, &port_mutex[gsm->port-1]);
																								tmr_h=set_gsm_timeout(gsm->port, 0);
																								gsm->nGSMStep = GSM_ALL;
																							}*/
																						}
					break;

				case GSM_CLEAR0:
					if( strncmp(szRxMsg[(nBuff+1)&1], "+CPMS:",6)==0) //SMS Text rec
					{

						write_debug_gsm(gsm->port," * GSM_CLEAR0: Received +CPMS - flag %d\n",gsm->flagClear);

						//read index
						for (i = (int)strlen(szRxMsg[(nBuff+1)&1]) - 1; i > 0 ; i--)
						{

							if(szRxMsg[(nBuff+1)&1][i] == ',')
							{
								digivoice_sleep(100);          //wait 100ms to go

								//copy index
								strcpy(szMaxMessage,&szRxMsg[(nBuff+1)&1][i+1]);

								//save to application
								if(szRxMsg[(nBuff+1)&1][i-2] == ',')
									strncpy(gsm->szMemory,&szRxMsg[(nBuff+1)&1][i-1],20);
								else
									strncpy(gsm->szMemory,&szRxMsg[(nBuff+1)&1][i-2],20);

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
								break;
							}
						}

						switch(gsm->flagClear)//tests if is to clear all memory
						{
						case 0: //just show memory usage

							gsm->nGSMStep = GSM_ALL;
							//send evento to application
							RaiseEvents_ThreadSafe(EV_GSMMEMORY, GSM_CLEAR ,  0, gsm_events.port,&port_mutex[gsm->port-1]);

							break;

						case 1: //clear all
							nClearCNT = 1;

							sprintf(szTemp,"AT+CMGD=%d\r\n",nClearCNT);
							gsm_puts(gsm->port, szTemp);				//dg_GSMDeleteSMS(gsm->port,nClearCNT);

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);


							gsm->nGSMStep = GSM_CLEAR;
							break;

						case 2: //reads all messages from sim card
							nClearCNT = 1;

							sprintf(szTemp,"AT+CMGR=%d\r\n",nClearCNT);
							gsm_puts(gsm->port, szTemp);

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

							nSMSHeaderFlag=0;
							gsm->nGSMStep = GSM_SMS4;

							break;
						}

					}
					else
						if((strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							nErrorCnt = 0;
							//Send event to application
							RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLEAR0,
									0,gsm_events.port,&port_mutex[gsm->port-1]);
							//reset timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,0);
							gsm->nGSMStep = GSM_ALL;
						}
						else
						{
							if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
							{
								write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CLEAR0, generating EV_GSMERROR to application!\n");

								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLEAR0, 0, gsm_events.port, &port_mutex[gsm->port-1]);
								tmr_h=set_gsm_timeout(gsm->port, 0);
								gsm->nGSMStep = GSM_ALL;
							}
						}
					break;
				case GSM_CLEAR:
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						digivoice_sleep(100);          //wait 100ms to go
						nClearCNT++;
						if (nClearCNT <= atoi(szMaxMessage))
						{
							sprintf(szTemp,"AT+CMGD=%d\r\n",nClearCNT);
							gsm_puts(gsm->port, szTemp);				//dg_GSMDeleteSMS(gsm->port,nClearCNT);

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

						}
						else
						{
							gsm->nGSMStep = GSM_ALL;

							//Send event to application
							RaiseEvents_ThreadSafe(EV_GSMRETURNOK,GSM_CLEAR ,
									0,gsm_events.port,&port_mutex[gsm->port-1]);
							tmr_h=set_gsm_timeout(gsm->port,0);
						}
					}
					else
						if( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)
						{
							//Send event to application
							RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLEAR,
									0,gsm_events.port,&port_mutex[gsm->port-1]);
							gsm->nGSMStep = GSM_ALL;         //wait for answer characters

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,0);
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0)
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLEAR,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								gsm->nGSMStep = GSM_ALL;         //wait for answer characters

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);

							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
								{
									if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
									{
										RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
									}
									else
										if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
										{
											RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
										}
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);

								}else
									if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
									{
										strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
										RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
										gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");

										//set timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

										gsm->nGSMStep = GSM_ALL;         //wait for answer characters
									}
									else
									{
										if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
										{
											write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_CLEAR, generating EV_GSMERROR to application!\n");

											RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_CLEAR, 0, gsm_events.port, &port_mutex[gsm->port-1]);
											tmr_h=set_gsm_timeout(gsm->port, 0);
											gsm->nGSMStep = GSM_ALL;
										}
									}

					break;

				case GSM_LIST:

					if( strncmp(szRxMsg[(nBuff+1)&1], "+CMGL:",6)==0)
					{
						szTempIndex[0] = szRxMsg[(nBuff+1)&1][7];
						if (szRxMsg[(nBuff+1)&1][8] == ',')
							szTempIndex[1] = '\0';
						else
						{
							szTempIndex[1] = szRxMsg[(nBuff+1)&1][8];
							szTempIndex[2] = '\0';
						}
						strcat(szIndexMessage,",");
						strcat(szIndexMessage,szTempIndex);


						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

						//-------------------------------
						//save message received
						//strcpy(gsm->szRxSMS,szRxMsg[(nBuff+1)&1]);

					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
						{
							gsm->nGSMStep = GSM_ALL;

							strcpy(gsm->szIndexList,szIndexMessage);
							//Send event to application
							RaiseEvents_ThreadSafe(EV_GSMRETURNOK,GSM_LIST ,
									0,gsm_events.port,&port_mutex[gsm->port-1]);

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,0);
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_LIST,
										0,gsm_events.port,&port_mutex[gsm->port-1]);
								gsm->nGSMStep = GSM_ALL;         //wait for answer characters

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0)
								{
									//Send event to application
									RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_LIST,
											0,gsm_events.port,&port_mutex[gsm->port-1]);
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters

									//set timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);

								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
									{
										if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
										{
											RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
										}
										else
											if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
											{
												RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
											}
										gsm->nGSMStep = GSM_ALL;         //wait for answer characters

										//reset timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,0);

									}else
										if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
										{
											strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
											RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
											gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");

											//set timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
											gsm->nGSMStep = GSM_ALL;         //wait for answer characters
										}
										else
										{
											if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
											{
												write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_LIST, generating EV_GSMERROR to application!\n");

												RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_LIST, 0, gsm_events.port, &port_mutex[gsm->port-1]);
												tmr_h=set_gsm_timeout(gsm->port, 0);
												gsm->nGSMStep = GSM_ALL;
											}
										}

					break;

				case GSM_SMS1://after AT+CMGS
					//write_debug_gsm(gsm->port," * GSM_SMS1: Analyse: '%s' - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if(strncmp(szRxMsg[(nBuff+1)&1], ">",1)==0)
					{
						digivoice_sleep(100);          //wait 100ms to go

						nLen = strlen(gsm->szTxSMS);

						//convert ANSI to GSM before sending
						strANSI2GSM((unsigned char *)gsm->szTxSMS);

						gsm->szTxSMS[nLen++] = 0x1a;//append CTRL-Z
						gsm->szTxSMS[nLen]     = '\0';//append 00

						gsm->nGSMStep = GSM_SMS1;  //stay here
						gsm_putn(gsm->port, gsm->szTxSMS,nLen);

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
						{
							//test if has pending CMTI
							nTempR = gsm->nDelayedRxIndexR;
							if(nTempR != gsm->nDelayedRxIndexW)
							{				//read index
								write_debug_gsm(gsm->port, "GSM_SMS1: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);

								for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
								{

									if(gsm->szDelayedRx[nTempR][i] == ',')
									{
										//digivoice_sleep(100);          //wait 100ms to go

										//copy index
										strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
										sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
										gsm_puts(gsm->port,szTemp);

										//reset sms header flag
										nSMSHeaderFlag=0;

										//set timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
										break;
									}
								}
								if(i!=0)
								{
									gsm->nGSMStep = GSM_ALL;

									//updade delayed buffer pointer
									gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
								}
								else
									gsm->nGSMStep = GSM_ALL;

								break;
							}

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,0);

							gsm->nGSMStep = GSM_ALL;      //done
						}
						else
							if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
									(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS1,
										0,gsm_events.port,&port_mutex[gsm->port-1]);

								//test if has pendding CMTI
								nTempR = gsm->nDelayedRxIndexR;
								if(nTempR != gsm->nDelayedRxIndexW)
								{				//read index
									write_debug_gsm(gsm->port, "GSM_SMS1: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);

									for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
									{

										if(gsm->szDelayedRx[nTempR][i] == ',')
										{
											//digivoice_sleep(100);          //wait 100ms to go

											//copy index
											strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
											sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
											gsm_puts(gsm->port,szTemp);

											//reset sms header flag
											nSMSHeaderFlag=0;


											//set timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
											break;
										}
									}
									if(i !=0)
									{
										gsm->nGSMStep = GSM_ALL;

										//updade delayed buffer pointer
										gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
									}
									else
										gsm->nGSMStep = GSM_ALL;
									break;
								}



								gsm->nGSMStep = GSM_ALL;         //wait for answer characters

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);

							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "RING",4)==0)//RING received
								{
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters

									RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "+CLIP:",6)==0)//caller id received
									{
										for(i=0;i<30;i++) //extracts caller ID
										{
											gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
											gsm->rx_id_digits[i+1] = '\0';
											gsm->rx_id_number_of_digits = (char)(i+1);
											if(gsm->rx_id_digits[i]=='"')
											{
												gsm->rx_id_digits[i] = '\0';
												break;
											}
										}
										gsm->nGSMStep = GSM_ALL;         //wait for answer characters

										RaiseEvents_ThreadSafe(EV_CALLERID, gsm->rx_id_number_of_digits , 0, gsm_events.port,&port_mutex[gsm->port-1]);

										//reset timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,0);
									}
									else
										if( strncmp(szRxMsg[(nBuff+1)&1], "+CMTI:",6)==0) //SMS Text rec - save to delayed buffer Rx
										{
											write_debug_gsm(gsm->port," * GSM_SMS1: CMTI - received and saved: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
											nTempW = (gsm->nDelayedRxIndexW + 1)&15; //round to 16 itens

											if(nTempW != gsm->nDelayedRxIndexR)
											{

												//copy command to temporary buffer
												strcpy(gsm->szDelayedRx[gsm->nDelayedRxIndexW],szRxMsg[(nBuff+1)&1]);
												gsm->nDelayedRxIndexW = nTempW;
											}
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
											gsm->nGSMStep = GSM_SMS1;  //stay here
										}
										else
											if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
											{
												if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
												{
													RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												}
												else
													if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
													{
														RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													}

												gsm->nGSMStep = GSM_ALL;         //wait for answer characters

												//reset timeout for characters
												tmr_h=set_gsm_timeout(gsm->port,0);
											}else
												if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
												{
													strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
													RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");

													//set timeout for characters
													tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

													gsm->nGSMStep = GSM_ALL;         //wait for answer characters

												}
												else
													if( strncmp(szRxMsg[(nBuff+1)&1], "+CUSD:",6)==0)//USSD Message Received
													{
														gsm->nGSMStep = GSM_ALL;         //wait for answer characters

														strncpy(gsm->szUSSDMessage, szRxMsg[(nBuff+1)&1], 255);
														RaiseEvents_ThreadSafe(EV_GSMUSSDRECEIVED, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

														//reset timeout for characters
														tmr_h=set_gsm_timeout(gsm->port,0);
													}
													else
														if( strncmp(szRxMsg[(nBuff+1)&1], "+CMGS:",6)==0)//Sending SMS Message
														{
															//Send event to application
															RaiseEvents_ThreadSafe(EV_GSMSMSSENT,0 ,
																	0,gsm_events.port,&port_mutex[gsm->port-1]);

															//gsm->nGSMStep = stay here

															//do not disable timer, wait for OK after +CMGS:
															//tmr_h=set_gsm_timeout(gsm->port,0);
														}
														else
														{
															//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
															//gsm->nGSMStep = GSM_ALL;         //wait for answer characters

															if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
															{
																write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SMS1, generating EV_GSMERROR to application!\n");

																RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS1, 0, gsm_events.port, &port_mutex[gsm->port-1]);
																tmr_h=set_gsm_timeout(gsm->port, 0);
																gsm->nGSMStep = GSM_ALL;
															}
														}
					break;

				case GSM_SMS2:  //after AT+CMGR
					write_debug_gsm(gsm->port," * GSM_SMS2: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						if(strncmp(&gsm->szRxSMS[8], "REC READ",10)!=0)
							RaiseEvents_ThreadSafe(EV_GSMSMSRECEIVED, 0 ,  0, gsm_events.port,&port_mutex[gsm->port-1]);

						//digivoice_sleep(100);          //wait 100ms to go

						//a message has been received, delete it now
						sprintf(szTemp,"AT+CMGD=%s\r\n",gsm->szIndex);
						gsm->nGSMStep = GSM_SMS3;      //done

						gsm_puts(gsm->port,szTemp);

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}
					else
						if( strncmp(szRxMsg[(nBuff+1)&1], "+CMGR:",6)==0) //SMS Broadcast Message rec
						{
							//write_debug_gsm(gsm->port," * GSM_ALL  SMS header: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

							//save message received
							strcpy(gsm->szRxSMS,szRxMsg[(nBuff+1)&1]);

							//convert GSM to ANSI only for the text message
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							gsm->nGSMStep = GSM_SMS2;  //wait OK to delete

							nSMSHeaderFlag=1;

						}else
							if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
									(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS2,
										0,gsm_events.port,&port_mutex[gsm->port-1]);

								//test if has pendding CMTI
								nTempR = gsm->nDelayedRxIndexR;
								if(nTempR != gsm->nDelayedRxIndexW)
								{				//read index
									write_debug_gsm(gsm->port, "GSM_SMS2: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);
									for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
									{
										//write_debug_gsm(gsm->port, "+CMTI Parse: %c", szRxMsg[(nBuff+1)&1][i]);

										if(gsm->szDelayedRx[nTempR][i] == ',')
										{
											//digivoice_sleep(100);          //wait 100ms to go

											//copy index
											strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
											sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
											gsm_puts(gsm->port,szTemp);

											//reset sms header flag
											nSMSHeaderFlag=0;

											//set timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
											break;
										}
									}
									if(i!=0)
									{
										//gsm->nGSMStep = GSM_SMS2;
										gsm->nGSMStep = GSM_ALL;

										//updade delayed buffer pointer
										gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
									}
									else
										gsm->nGSMStep = GSM_ALL;

									break;
								}


								//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
								gsm->nGSMStep = GSM_ALL;      //done

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "RING",4)==0)//RING received
								{
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters
									RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "+CLIP:",6)==0)//caller id received
									{
										for(i=0;i<30;i++) //extracts caller ID
										{
											gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
											gsm->rx_id_digits[i+1] = '\0';
											gsm->rx_id_number_of_digits = (char)(i+1);
											if(gsm->rx_id_digits[i]=='"')
											{
												gsm->rx_id_digits[i] = '\0';
												break;
											}
										}
										gsm->nGSMStep = GSM_ALL;         //wait for answer characters

										RaiseEvents_ThreadSafe(EV_CALLERID, gsm->rx_id_number_of_digits , 0, gsm_events.port,&port_mutex[gsm->port-1]);

										//reset timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,0);
									}
									else
										if( strncmp(szRxMsg[(nBuff+1)&1], "+CMTI:",6)==0) //SMS Text rec - save to delayed buffer Rx
										{
											write_debug_gsm(gsm->port," * GSM_SMS2: CMTI - received and saved: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

											nTempW = (gsm->nDelayedRxIndexW + 1)&15; //round to 16 itens

											if(nTempW != gsm->nDelayedRxIndexR)
											{

												//copy command to temporary buffer
												strcpy(gsm->szDelayedRx[gsm->nDelayedRxIndexW],szRxMsg[(nBuff+1)&1]);
												gsm->nDelayedRxIndexW = nTempW;
											}
											gsm->nGSMStep = GSM_SMS2;  //stay here
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
										}
										else
											if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
											{
												if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
												{
													RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												}
												else
													if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
													{
														RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													}

												gsm->nGSMStep = GSM_ALL;         //wait for answer characters

												//reset timeout for characters
												tmr_h=set_gsm_timeout(gsm->port,0);
											}
											else
												if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
												{
													strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
													RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");
													gsm->nGSMStep = GSM_ALL;         //wait for answer characters
												}
												else
													if( strncmp(szRxMsg[(nBuff+1)&1], "+CUSD:",6)==0)//USSD Message Received
													{
														gsm->nGSMStep = GSM_ALL;         //wait for answer characters

														strncpy(gsm->szUSSDMessage, szRxMsg[(nBuff+1)&1], 255);
														RaiseEvents_ThreadSafe(EV_GSMUSSDRECEIVED, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

														//reset timeout for characters
														tmr_h=set_gsm_timeout(gsm->port,0);
													}
													else
													{
														//save message received
														//strcat(gsm->szRxSMS,"\r\n");

														//test if is a concatenated message and clean aditional information
														if(nSMSHeaderFlag==1)
														{
															if(szMSGRaw[(nBuff+1)&1][0]==0x5)
															{
																//convert GSM to ANSI
																strGSM2ANSI((unsigned char *)&szMSGRaw[(nBuff+1)&1][7]);
																strcat(gsm->szRxSMS,&szMSGRaw[(nBuff+1)&1][7]);
															}
															else
															{
																//convert GSM to ANSI
																strGSM2ANSI((unsigned char *)szMSGRaw[(nBuff+1)&1]);
																strcat(gsm->szRxSMS,szMSGRaw[(nBuff+1)&1]);

															}
															nSMSHeaderFlag=0;

														}
														else
														{
															//convert GSM to ANSI
															strGSM2ANSI((unsigned char *)szMSGRaw[(nBuff+1)&1]);
															strcat(gsm->szRxSMS,szMSGRaw[(nBuff+1)&1]);
														}
														write_debug_gsm(gsm->port," * GSM_SMS2 partial: %s ",gsm->szRxSMS);

														//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
														//gsm->nGSMStep = GSM_ALL;        //done

														/* Removed following code, because we are receiving SMS message
														 * if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
														{
															write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SMS2, generating EV_GSMERROR to application!\n");

															RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS2, 0, gsm_events.port, &port_mutex[gsm->port-1]);
															tmr_h=set_gsm_timeout(gsm->port, 0);
															gsm->nGSMStep = GSM_ALL;
														}*/
													}
					break;

				case GSM_SMS3:  //after AT+CMGD
					//write_debug_gsm(gsm->port," * GSM_SMS3: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{
						//test if there are other CMTI saved
						nTempR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
						if(nTempR == gsm->nDelayedRxIndexW)
							//ok just one, delete CMTI saved, message has alread been been read
							gsm->nDelayedRxIndexR = nTempR;


						//test if has pendding CMTI
						nTempR = gsm->nDelayedRxIndexR;
						if(nTempR != gsm->nDelayedRxIndexW)
						{				//read index
							write_debug_gsm(gsm->port, "GSM_SMS3: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);
							for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
							{

								if(gsm->szDelayedRx[nTempR][i] == ',')
								{
									//digivoice_sleep(100);          //wait 100ms to go

									//copy index
									strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
									sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
									gsm_puts(gsm->port,szTemp);

									//reset sms header flag
									nSMSHeaderFlag=0;

									//set timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
									break;
								}
							}
							if(i!=0)
							{
								//gsm->nGSMStep = GSM_SMS2;
								gsm->nGSMStep = GSM_ALL;

								//updade delayed buffer pointer
								gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
							}
							else
								gsm->nGSMStep = GSM_ALL;

							break;
						}
						gsm->nGSMStep = GSM_ALL;      //done

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,0);
					}
					else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							//Send event to application
							RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS3,
									0,gsm_events.port,&port_mutex[gsm->port-1]);

							//test if has pendding CMTI
							nTempR = gsm->nDelayedRxIndexR;
							if(nTempR != gsm->nDelayedRxIndexW)
							{				//read index
								write_debug_gsm(gsm->port, "GSM_SMS3: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);
								for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
								{
									//write_debug_gsm(gsm->port, "+CMTI Parse: %c", szRxMsg[(nBuff+1)&1][i]);

									if(gsm->szDelayedRx[nTempR][i] == ',')
									{
										//digivoice_sleep(100);          //wait 100ms to go

										//copy index
										strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
										sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
										gsm_puts(gsm->port,szTemp);

										//reset sms header flag
										nSMSHeaderFlag=0;

										//set timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
										break;
									}
								}
								if(i!=0)
								{
									//gsm->nGSMStep = GSM_SMS2;
									gsm->nGSMStep = GSM_ALL;
									//updade delayed buffer pointer
									gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
								}
								else
									gsm->nGSMStep = GSM_ALL;

								break;
							}

							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
							gsm->nGSMStep = GSM_ALL;      //done

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,0);
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "RING",4)==0)//RING received
							{
								//				gsm->nGSMStep = GSM_SMS3;  //stay here
								gsm->nGSMStep = GSM_ALL;         //wait for answer characters

								RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "+CLIP:",6)==0)//caller id received
								{
									for(i=0;i<30;i++) //extracts caller ID
									{
										gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
										gsm->rx_id_digits[i+1] = '\0';
										gsm->rx_id_number_of_digits = (char)(i+1);
										if(gsm->rx_id_digits[i]=='"')
										{
											gsm->rx_id_digits[i] = '\0';
											break;
										}
									}
									//				gsm->nGSMStep = GSM_SMS3;  //stay here
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters

									RaiseEvents_ThreadSafe(EV_CALLERID, gsm->rx_id_number_of_digits , 0, gsm_events.port,&port_mutex[gsm->port-1]);

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "+CMTI:",6)==0) //SMS Text rec - save to delayed buffer Rx
									{
										write_debug_gsm(gsm->port," * GSM_SMS3: CMTI - received and saved: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

										nTempW = (gsm->nDelayedRxIndexW + 1)&15; //round to 16 itens

										if(nTempW != gsm->nDelayedRxIndexR)
										{

											//copy command to temporary buffer
											strcpy(gsm->szDelayedRx[gsm->nDelayedRxIndexW],szRxMsg[(nBuff+1)&1]);
											gsm->nDelayedRxIndexW = nTempW;
										}
										gsm->nGSMStep = GSM_SMS3;  //stay here
										tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
									}
									else
										if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
										{
											if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
											{
												RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
											}
											else
												if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
												{
													RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												}

											gsm->nGSMStep = GSM_ALL;         //wait for answer characters

											//reset timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,0);
										}else
											if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
											{
												strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
												RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");
												gsm->nGSMStep = GSM_ALL;         //wait for answer characters
											}
											else
												if( strncmp(szRxMsg[(nBuff+1)&1], "+CUSD:",6)==0)//USSD Message Received
												{
													//				gsm->nGSMStep = GSM_SMS3;  //stay here
													gsm->nGSMStep = GSM_ALL;         //wait for answer characters

													strncpy(gsm->szUSSDMessage, szRxMsg[(nBuff+1)&1], 255);
													RaiseEvents_ThreadSafe(EV_GSMUSSDRECEIVED, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

													//reset timeout for characters
													tmr_h=set_gsm_timeout(gsm->port,0);
												}
												else
												{
													if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
													{
														write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SMS3, generating EV_GSMERROR to application!\n");

														RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS3, 0, gsm_events.port, &port_mutex[gsm->port-1]);
														tmr_h=set_gsm_timeout(gsm->port, 0);
														gsm->nGSMStep = GSM_ALL;
													}
												}
					break;

				case GSM_SMS4: //list all sms stored and send as new sms the unread ones

					//write_debug_gsm(gsm->port," * GSM_SMS4: Analyse: '%s' - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "+CMGR:",6)==0) //SMS Broadcast Message rec
					{
						//write_debug_gsm(gsm->port," * GSM_SMS4  SMS header: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

						//save message received
						strcpy(gsm->szRxSMS,szRxMsg[(nBuff+1)&1]);

						//convert GSM to ANSI only for the text message
						//strGSM2ANSI(gsm->szRxSMS);
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

						gsm->nGSMStep = GSM_SMS5;  //wait OK to delete

						nSMSHeaderFlag=1;


					}else
						if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
						{

							//reset sms header flag
							nSMSHeaderFlag=0;

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

							//stay here
						}
						else
							if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
									(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS4,
										0,gsm_events.port,&port_mutex[gsm->port-1]);

								//test if has pendding CMTI
								nTempR = gsm->nDelayedRxIndexR;
								if(nTempR != gsm->nDelayedRxIndexW)
								{				//read index
									write_debug_gsm(gsm->port, "GSM_SMS4: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);
									for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
									{
										//write_debug_gsm(gsm->port, "+CMTI Parse: %c", szRxMsg[(nBuff+1)&1][i]);

										if(gsm->szDelayedRx[nTempR][i] == ',')
										{
											//digivoice_sleep(100);          //wait 100ms to go

											//copy index
											strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
											sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
											gsm_puts(gsm->port,szTemp);

											//reset sms header flag
											nSMSHeaderFlag=0;


											//set timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
											break;
										}
									}
									if(i !=0)
									{
										gsm->nGSMStep = GSM_ALL;

										//updade delayed buffer pointer
										gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
									}
									else
										gsm->nGSMStep = GSM_ALL;
									break;
								}



								gsm->nGSMStep = GSM_ALL;         //wait for answer characters

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);

							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "RING",4)==0)//RING received
								{
									//				gsm->nGSMStep = GSM_SMS4;  //stay here
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters

									RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "+CLIP:",6)==0)//caller id received
									{
										for(i=0;i<30;i++) //extracts caller ID
										{
											gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
											gsm->rx_id_digits[i+1] = '\0';
											gsm->rx_id_number_of_digits = (char)(i+1);
											if(gsm->rx_id_digits[i]=='"')
											{
												gsm->rx_id_digits[i] = '\0';
												break;
											}
										}
										//				gsm->nGSMStep = GSM_SMS4;  //stay here
										gsm->nGSMStep = GSM_ALL;         //wait for answer characters

										RaiseEvents_ThreadSafe(EV_CALLERID, gsm->rx_id_number_of_digits , 0, gsm_events.port,&port_mutex[gsm->port-1]);

										//reset timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,0);
									}
									else
										if( strncmp(szRxMsg[(nBuff+1)&1], "+CMTI:",6)==0) //SMS Text rec - save to delayed buffer Rx
										{
											write_debug_gsm(gsm->port," * GSM_SMS4: CMTI - received and saved: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

											nTempW = (gsm->nDelayedRxIndexW + 1)&15; //round to 16 itens

											if(nTempW != gsm->nDelayedRxIndexR)
											{

												//copy command to temporary buffer
												strcpy(gsm->szDelayedRx[gsm->nDelayedRxIndexW],szRxMsg[(nBuff+1)&1]);
												gsm->nDelayedRxIndexW = nTempW;
											}
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
											gsm->nGSMStep = GSM_SMS4;  //stay here
										}
										else
											if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
											{
												if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
												{
													RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												}
												else
													if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
													{
														RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													}

												gsm->nGSMStep = GSM_ALL;         //wait for answer characters

												//reset timeout for characters
												tmr_h=set_gsm_timeout(gsm->port,0);
											}else
												if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
												{
													strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
													RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");

													//set timeout for characters
													tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

													gsm->nGSMStep = GSM_ALL;         //wait for answer characters

												}
												else
													if( strncmp(szRxMsg[(nBuff+1)&1], "+CUSD:",6)==0)//USSD Message Received
													{
														//				gsm->nGSMStep = GSM_SMS4;  //stay here
														gsm->nGSMStep = GSM_ALL;         //wait for answer characters

														strncpy(gsm->szUSSDMessage, szRxMsg[(nBuff+1)&1], 255);
														RaiseEvents_ThreadSafe(EV_GSMUSSDRECEIVED, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

														//reset timeout for characters
														tmr_h=set_gsm_timeout(gsm->port,0);
													}
													else
													{
														//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
														//gsm->nGSMStep = GSM_ALL;         //wait for answer characters

														if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
														{
															write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SMS4, generating EV_GSMERROR to application!\n");

															RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS4, 0, gsm_events.port, &port_mutex[gsm->port-1]);
															tmr_h=set_gsm_timeout(gsm->port, 0);
															gsm->nGSMStep = GSM_ALL;
														}
													}
					break;

				case GSM_SMS5:  //after AT+CMGR
					write_debug_gsm(gsm->port," * GSM_SMS5: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

					if(( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0) ||
							(strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)) //Process it like a OK message to exec an AT+CMGD command
					{
						if(strncmp(&gsm->szRxSMS[8], "REC UNREAD",10)==0)
							RaiseEvents_ThreadSafe(EV_GSMSMSRECEIVED, 0 ,  0, gsm_events.port,&port_mutex[gsm->port-1]);

						if(strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0)
							RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS5,
									0,gsm_events.port,&port_mutex[gsm->port-1]);

						//a message has been received, delete it now
						sprintf(szTemp,"AT+CMGD=%d\r\n",nClearCNT);
						gsm->nGSMStep = GSM_SMS6;      //done

						gsm_puts(gsm->port,szTemp);

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
					}
					else
						if( strncmp(szRxMsg[(nBuff+1)&1], "+CMGR:",6)==0) //SMS Broadcast Message rec
						{
							//write_debug_gsm(gsm->port," * GSM_SMS5  SMS header: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

							//save message received
							strcpy(gsm->szRxSMS,szRxMsg[(nBuff+1)&1]);

							//convert GSM to ANSI only for the text message
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
							gsm->nGSMStep = GSM_SMS5;  //wait OK to delete

							nSMSHeaderFlag=1;

						}else

							if(/*( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||*/ //Process it like a OK message to exec an AT+CMGD command
									(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
							{
								//Send event to application
								RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS5,
										0,gsm_events.port,&port_mutex[gsm->port-1]);

								//test if has pendding CMTI
								nTempR = gsm->nDelayedRxIndexR;
								if(nTempR != gsm->nDelayedRxIndexW)
								{				//read index
									write_debug_gsm(gsm->port, "GSM_SMS5: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);
									for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
									{
										//write_debug_gsm(gsm->port, "+CMTI Parse: %c", szRxMsg[(nBuff+1)&1][i]);

										if(gsm->szDelayedRx[nTempR][i] == ',')
										{
											//digivoice_sleep(100);          //wait 100ms to go

											//copy index
											strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
											sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
											gsm_puts(gsm->port,szTemp);

											//reset sms header flag
											nSMSHeaderFlag=0;

											//set timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
											break;
										}
									}
									if(i!=0)
									{
										//gsm->nGSMStep = GSM_SMS2;
										gsm->nGSMStep = GSM_ALL;

										//updade delayed buffer pointer
										gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
									}
									else
										gsm->nGSMStep = GSM_ALL;

									break;
								}

								//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
								gsm->nGSMStep = GSM_ALL;      //done

								//set timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "RING",4)==0)//RING received
								{
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters
									RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "+CLIP:",6)==0)//caller id received
									{
										for(i=0;i<30;i++) //extracts caller ID
										{
											gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
											gsm->rx_id_digits[i+1] = '\0';
											gsm->rx_id_number_of_digits = (char)(i+1);
											if(gsm->rx_id_digits[i]=='"')
											{
												gsm->rx_id_digits[i] = '\0';
												break;
											}
										}
										//				gsm->nGSMStep = GSM_SMS2;  //stay here
										gsm->nGSMStep = GSM_ALL;         //wait for answer characters

										RaiseEvents_ThreadSafe(EV_CALLERID, gsm->rx_id_number_of_digits , 0, gsm_events.port,&port_mutex[gsm->port-1]);

										//reset timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,0);
									}
									else
										if( strncmp(szRxMsg[(nBuff+1)&1], "+CMTI:",6)==0) //SMS Text rec - save to delayed buffer Rx
										{
											write_debug_gsm(gsm->port," * GSM_SMS5: CMTI - received and saved: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
											nTempW = (gsm->nDelayedRxIndexW + 1)&15; //round to 16 itens

											if(nTempW != gsm->nDelayedRxIndexR)
											{

												//copy command to temporary buffer
												strcpy(gsm->szDelayedRx[gsm->nDelayedRxIndexW],szRxMsg[(nBuff+1)&1]);
												gsm->nDelayedRxIndexW = nTempW;
											}
											gsm->nGSMStep = GSM_SMS5;  //stay here
											tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
										}
										else
											if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
											{
												if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
												{
													RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												}
												else
													if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
													{
														RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													}

												gsm->nGSMStep = GSM_ALL;         //wait for answer characters

												//reset timeout for characters
												tmr_h=set_gsm_timeout(gsm->port,0);
											}
											else
												if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
												{
													strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
													RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
													gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");
													gsm->nGSMStep = GSM_ALL;         //wait for answer characters
												}
												else
													if( strncmp(szRxMsg[(nBuff+1)&1], "+CUSD:",6)==0)//USSD Message Received
													{
														gsm->nGSMStep = GSM_ALL;         //wait for answer characters

														strncpy(gsm->szUSSDMessage, szRxMsg[(nBuff+1)&1], 255);
														RaiseEvents_ThreadSafe(EV_GSMUSSDRECEIVED, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

														//reset timeout for characters
														tmr_h=set_gsm_timeout(gsm->port,0);
													}
													else
													{
														//save message received
														//strcat(gsm->szRxSMS,"\r\n");

														//test if is a concatenated message and clean aditional information
														if(nSMSHeaderFlag==1)
														{
															if(szMSGRaw[(nBuff+1)&1][0]==0x5)
															{
																//convert GSM to ANSI
																strGSM2ANSI((unsigned char *)&szMSGRaw[(nBuff+1)&1][7]);
																strcat(gsm->szRxSMS,&szMSGRaw[(nBuff+1)&1][7]);
															}
															else
															{
																//convert GSM to ANSI
																strGSM2ANSI((unsigned char *)szMSGRaw[(nBuff+1)&1]);
																strcat(gsm->szRxSMS,szMSGRaw[(nBuff+1)&1]);

															}
															nSMSHeaderFlag=0;

														}
														else
														{
															//convert GSM to ANSI
															strGSM2ANSI((unsigned char *)szMSGRaw[(nBuff+1)&1]);
															strcat(gsm->szRxSMS,szMSGRaw[(nBuff+1)&1]);
														}
														write_debug_gsm(gsm->port," * GSM_SMS5 partial: %s ",gsm->szRxSMS);

														/* Removed following code, because we are receiving SMS message
														 * if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
														{
															write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SMS5, generating EV_GSMERROR to application!\n");

															RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS5, 0, gsm_events.port, &port_mutex[gsm->port-1]);
															tmr_h=set_gsm_timeout(gsm->port, 0);
															gsm->nGSMStep = GSM_ALL;
														}*/
													}
					break;

				case GSM_SMS6:  //after AT+CMGD
					//write_debug_gsm(gsm->port," * GSM_SMS6: Analyse: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);
					if( strncmp(szRxMsg[(nBuff+1)&1], "OK",2)==0)
					{

						digivoice_sleep(100);          //wait 100ms to go
						nClearCNT++;
						if (nClearCNT <= atoi(szMaxMessage))
						{
							sprintf(szTemp,"AT+CMGR=%d\r\n",nClearCNT);
							gsm_puts(gsm->port, szTemp);				//dg_GSMDeleteSMS(gsm->port,nClearCNT);

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);

							gsm->nGSMStep = GSM_SMS4;
							break;

						}

						//ok delete CMTI saved, message has been read
						//nTempR = gsm->nDelayedRxIndexR;
						//if(nTempR != gsm->nDelayedRxIndexW)
						//		gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens

						//test if has pendding CMTI
						nTempR = gsm->nDelayedRxIndexR;
						if(nTempR != gsm->nDelayedRxIndexW)
						{				//read index
							write_debug_gsm(gsm->port, "GSM_SMS6: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);
							for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
							{
								//write_debug_gsm(gsm->port, "+CMTI Parse: %c", szRxMsg[(nBuff+1)&1][i]);

								if(gsm->szDelayedRx[nTempR][i] == ',')
								{
									//digivoice_sleep(100);          //wait 100ms to go

									//copy index
									strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
									sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
									gsm_puts(gsm->port,szTemp);

									//reset sms header flag
									nSMSHeaderFlag=0;

									//set timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
									break;
								}
							}
							if(i!=0)
							{
								gsm->nGSMStep = GSM_ALL;

								//updade delayed buffer pointer
								gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
							}
							else
								gsm->nGSMStep = GSM_ALL;

							break;
						}
						gsm->nGSMStep = GSM_ALL;      //done

						//Send event to application
						RaiseEvents_ThreadSafe(EV_GSMRETURNOK, GSM_CLEAR, atoi(szMaxMessage), gsm_events.port, &port_mutex[gsm->port-1]);

						//set timeout for characters
						tmr_h=set_gsm_timeout(gsm->port,0);
					}
					else
						if(( strncmp(szRxMsg[(nBuff+1)&1], "ERROR",5)==0) ||
								(strncmp(szRxMsg[(nBuff+1)&1], "+CMS ERROR",10)==0))
						{
							//Send event to application
							RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS6,
									0,gsm_events.port,&port_mutex[gsm->port-1]);

							//test if has pendding CMTI
							nTempR = gsm->nDelayedRxIndexR;
							if(nTempR != gsm->nDelayedRxIndexW)
							{				//read index
								write_debug_gsm(gsm->port, "GSM_SMS6: pending +CMTI : %s", szRxMsg[(nBuff+1)&1]);
								for (i = (int)strlen(gsm->szDelayedRx[nTempR]) - 1; i > 0 ; i--)
								{
									//write_debug_gsm(gsm->port, "+CMTI Parse: %c", szRxMsg[(nBuff+1)&1][i]);

									if(gsm->szDelayedRx[nTempR][i] == ',')
									{
										//digivoice_sleep(100);          //wait 100ms to go

										//copy index
										strcpy(gsm->szIndex,&gsm->szDelayedRx[nTempR][i+1]);
										sprintf(szTemp,"AT+CMGR=%s\r\n",gsm->szIndex); //read message
										gsm_puts(gsm->port,szTemp);

										//reset sms header flag
										nSMSHeaderFlag=0;

										//set timeout for characters
										tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
										break;
									}
								}
								if(i!=0)
								{
									gsm->nGSMStep = GSM_ALL;
									//updade delayed buffer pointer
									gsm->nDelayedRxIndexR = (gsm->nDelayedRxIndexR + 1)&15; //round to 16 itens
								}
								else
									gsm->nGSMStep = GSM_ALL;

								break;
							}

							//nGsmATStep = GSM_AT_IDLE;         //wait for answer characters
							gsm->nGSMStep = GSM_ALL;      //done

							//set timeout for characters
							tmr_h=set_gsm_timeout(gsm->port,0);
						}
						else
							if( strncmp(szRxMsg[(nBuff+1)&1], "RING",4)==0)//RING received
							{
								gsm->nGSMStep = GSM_ALL;         //wait for answer characters

								RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

								//reset timeout for characters
								tmr_h=set_gsm_timeout(gsm->port,0);
							}
							else
								if( strncmp(szRxMsg[(nBuff+1)&1], "+CLIP:",6)==0)//caller id received
								{
									for(i=0;i<30;i++) //extracts caller ID
									{
										gsm->rx_id_digits[i] = szRxMsg[(nBuff+1)&1][i+8];
										gsm->rx_id_digits[i+1] = '\0';
										gsm->rx_id_number_of_digits = (char)(i+1);
										if(gsm->rx_id_digits[i]=='"')
										{
											gsm->rx_id_digits[i] = '\0';
											break;
										}
									}
									gsm->nGSMStep = GSM_ALL;         //wait for answer characters

									RaiseEvents_ThreadSafe(EV_CALLERID, gsm->rx_id_number_of_digits , 0, gsm_events.port,&port_mutex[gsm->port-1]);

									//reset timeout for characters
									tmr_h=set_gsm_timeout(gsm->port,0);
								}
								else
									if( strncmp(szRxMsg[(nBuff+1)&1], "+CMTI:",6)==0) //SMS Text rec - save to delayed buffer Rx
									{
										write_debug_gsm(gsm->port," * GSM_SMS6: CMTI - received and saved: %s - !nBuff %d\n",szRxMsg[(nBuff+1)&1],(nBuff+1)&1);

										nTempW = (gsm->nDelayedRxIndexW + 1)&15; //round to 16 itens

										if(nTempW != gsm->nDelayedRxIndexR)
										{

											//copy command to temporary buffer
											strcpy(gsm->szDelayedRx[gsm->nDelayedRxIndexW],szRxMsg[(nBuff+1)&1]);
											gsm->nDelayedRxIndexW = nTempW;
										}
										gsm->nGSMStep = GSM_SMS6;  //stay here
										tmr_h=set_gsm_timeout(gsm->port,gsm->nAnswerTimeout);
									}
									else
										if( strncmp(szRxMsg[(nBuff+1)&1], "^SCKS:",6)==0) //SIM Card
										{
											if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 1",8)==0)
											{
												RaiseEvents_ThreadSafe(EV_GSMSIM, TRUE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
											}
											else
												if (strncmp(szRxMsg[(nBuff+1)&1], "^SCKS: 0",8)==0)
												{
													RaiseEvents_ThreadSafe(EV_GSMSIM, FALSE,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												}

											gsm->nGSMStep = GSM_ALL;         //wait for answer characters

											//reset timeout for characters
											tmr_h=set_gsm_timeout(gsm->port,0);
										}else
											if (strncmp(szRxMsg[(nBuff+1)&1], "+CDS:",5)==0)
											{
												strncpy(gsm->szSMSConfirmation, szRxMsg[(nBuff+1)&1],255);
												RaiseEvents_ThreadSafe(EV_GSMSMSCONFIRMATION, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);
												gsm_puts_delayed(gsm->port,"AT+CNMA\r\n");
												gsm->nGSMStep = GSM_ALL;         //wait for answer characters
											}
											else
												if( strncmp(szRxMsg[(nBuff+1)&1], "+CUSD:",6)==0)//USSD Message Received
												{
													gsm->nGSMStep = GSM_ALL;         //wait for answer characters

													strncpy(gsm->szUSSDMessage, szRxMsg[(nBuff+1)&1], 255);
													RaiseEvents_ThreadSafe(EV_GSMUSSDRECEIVED, 0,  0, gsm_events.port,&port_mutex[gsm->port-1]);

													//reset timeout for characters
													tmr_h=set_gsm_timeout(gsm->port,0);
												}
												else
												{
													if (strlen(szRxMsg[(nBuff+1)&1]) > 1)
													{
														write_debug_gsm(gsm->port, "Unknown response at gsm->nGSMStep GSM_SMS6, generating EV_GSMERROR to application!\n");

														RaiseEvents_ThreadSafe(EV_GSMERROR, GSM_SMS6, 0, gsm_events.port, &port_mutex[gsm->port-1]);
														tmr_h=set_gsm_timeout(gsm->port, 0);
														gsm->nGSMStep = GSM_ALL;
													}
												}
					break;

				}//switch gsm->nGSMStep
				nAnalyse=0;
			}//if nAnalyse
		}//if nRunGsm
	}//fim fo while(1)

	write_debug_gsm(gsm->port, "GSM for port %d closed (step 1, thread_id %d)", gsm->port, gsm->thread_id);
	//close fifos
#ifdef __LINUX__
	close(ports_info[gsm->port-1].fifo_to_gsm);

#else
	//destroi os eventos
	CloseHandle(ports_info[gsm->port-1].gsm_info.GSMEvent.hEvent);
#endif

#ifdef __LINUX__
	close(fifo_rx);
#endif

	gsm->thread_id = 0;

	write_debug_gsm(gsm->port, "GSM for port %d closed (step 2, thread_id %d)", gsm->port, gsm->thread_id);
}

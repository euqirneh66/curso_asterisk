/************************************************************************************
 *                                                                         	    *
 *   VoicerLib - Windows/Linux Version                                     	    *
 *                                                                          	    *
 *   Copyright (c) 2004-2010 Digivoice Tecnologia em Eletronica Ltda     	    *
 *                                                                         	    *
 *   Module:  Main module                                                  	    *
 *                                                                         	    *
 *   Description: Implements exposed functions                             	    *
 *                                                                         	    *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                         	    *
 *   This library is free software; you can redistribute it and/or		    *
 *   modify it under the terms of the GNU Lesser General Public			    *
 *   License as published by the Free Software Foundation; either		    *
 *   version 2.1 of the License, or (at your option) any later version.		    *
 *   										    *
 *   This library is distributed in the hope that it will be useful,		    *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of		    *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU		    *
 *   Lesser General Public License for more details.				    *
 *   										    *
 *   You should have received a copy of the GNU Lesser General Public		    *
 *   License along with this library; if not, write to the Free Software	    *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *
 *           									    *
 ************************************************************************************/

 #include "voicerlib.h"
 #include "vlibdef.h"

//----------------------------------------------------------------
// connects two audio channels
// input:
//       port1
//       port2
//----------------------------------------------------------------
short WCDECL dg_ConnectAudioChannels(short port1,short port2)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port1 <1 || port1 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port2 <1 || port2 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;
	
	if (port1 == port2)
		return DG_ERROR_PORT_OUT_OF_RANGE;

        //check if it is already connected
        if(ports_info[port1-1].connect_buf != NULL)
                return DG_ERROR_RESOURCE_UNAVAILABLE;

        //check if it is already connected
        if(ports_info[port2-1].connect_buf != NULL)
                return DG_ERROR_RESOURCE_UNAVAILABLE;

        //set direction index
        ports_info[port1-1].connect_index = 1;
        ports_info[port2-1].connect_index = 2;

        //try to alloc buffer
        ports_info[port1-1].connect_buf = malloc(sizeof(ConBuff));
        if(ports_info[port1-1].connect_buf == NULL)
               return DG_ERROR_MEMORY_ALLOCATION;

        //save buufer size
        ports_info[port1-1].connect_buf_size = CONMAXBUFF;
        ports_info[port2-1].connect_buf_size = CONMAXBUFF;

        //save other port
        ports_info[port1-1].connect_port = port2;
        ports_info[port2-1].connect_port = port1;

        ports_info[port2-1].connect_buf = ports_info[port1-1].connect_buf;

        //set inputbuffer callback
        dg_SetAudioInputCallback(dg_ConnectAudioCallback);

        //enable input buffer to both channels
        dg_EnableInputBuffer(port1,0);
        dg_EnableInputBuffer(port2,0);


	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// disconnects two audio channels
// input:
//       port1
//       port2
//----------------------------------------------------------------
short WCDECL dg_DisconnectAudioChannels(short port1,short port2)
{
	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port1 <1 || port1 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	if (port2 <1 || port2 > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

        //disable input buffer to both channels
        dg_DisableInputBuffer(port1);
        dg_DisableInputBuffer(port2);

		//disable playbuffer
		dg_StopPlayBuffer(port1);
		dg_StopPlayBuffer(port2);
		
		//release buffer memory
        if(ports_info[port1-1].connect_buf != NULL)
                free(ports_info[port1-1].connect_buf);

        ports_info[port1-1].connect_buf = NULL;
        ports_info[port2-1].connect_buf = NULL;

        //reset direction index
        ports_info[port1-1].connect_index = 0;
        ports_info[port2-1].connect_index = 0;


	return DG_EXIT_SUCCESS;
}

//----------------------------------------------------------------
// read audio samples from card
// input:
//       port
//----------------------------------------------------------------
short WCDECL dg_ConnectAudioCallback(short port, short size, void *SampleData)
{
      short index;
      short wp;
      short port2;
	  int remaining;

	if (!FDriverEnabled)
        return DG_ERROR_DRIVER_CLOSED;

	if (port <1 || port > dg_GetPortsCount())
		return DG_ERROR_PORT_OUT_OF_RANGE;

	//get other channel port
	port2 = ports_info[port-1].connect_port;

    index = ports_info[port2-1].connect_index -1;

    wp = ports_info[port2-1].connect_wp;

	//copy data to other channel buffer
    if(wp != ports_info[port2-1].connect_rp)
    {
        if(size <= 33)
			memcpy(&ports_info[port2-1].connect_buf[index][wp], (unsigned char*)SampleData,size);

		ports_info[port2-1].connect_wp++;
        if(ports_info[port2-1].connect_wp >= ports_info[port2-1].connect_buf_size)
            ports_info[port2-1].connect_wp = 0;

	}
	//get this port index
	index = ports_info[port-1].connect_index -1;

	//play data from other channel
	dg_PlayBuffer(port,&ports_info[port-1].connect_buf[index][ports_info[port-1].connect_rp],size,&remaining);
	ports_info[port-1].connect_rp++;
    if(ports_info[port-1].connect_rp >= ports_info[port-1].connect_buf_size)
            ports_info[port-1].connect_rp = 0;


	return DG_EXIT_SUCCESS;
}



//---

#ifndef __SHMEM_H__
#define __SHMEM_H__


#include "vlibdef.h"




#ifdef __LINUX__
typedef struct local_irq_structure {
	int Index;    /* Index of current card */
  	int thiscard;
	u8  active_buffer;
	u32 tmp32;
	u16 num_cmds;
	u16 tmp16;
	u8 bBufferOverflow;		//flag indicating buffers errors
	u16 addr_buffer;
	u16 addr_buffer_play;	
	u8  CallDPC;
	u32	ContaInt;
	u32 sync[10];
	u32 sync_rec[4];
	u32 gsm_ct[MAX_CHANNELS_CARD];
	u16 bit;
	unsigned int irq;
    //todo: u16  ccs_state[MAX_SPANS];
	
} local_irq_structure;
#endif

//Fifo de comandos CCS Rx
typedef  struct
{
  u16			wp;
  u16			rp;
  u16			partial;            //partial data position 
  u16           frame_size[CCS_LINES];
  u8			data[CCS_LINES][CCS_DATA_SIZE];		//5 �a qtde de elementos no STCOMANDO_RX
} STFIFO_CCS_RX;

//Fifo de comandos CCS tx
typedef  struct
{
  u16			wp;
  u16			rp;
  u16			partial;            //partial data position 
  u16           last_buffer;
  u16           buffer_addr_1;
  u16           buffer_addr_2;
  u16           frame_size[CCS_LINES];
  u8			data[CCS_LINES][CCS_DATA_SIZE];		//
} STFIFO_CCS_TX;


//Fifo de comandos de recepcao
typedef  struct //stFifoCmdRx
{
  u16			wp;
  u16			rp;
  u8			Cmd[TAM_FIFO_CMD_RX];		//5 �a qtde de elementos no STCOMANDO_RX
} STFIFO_CMD_RX;

//Fifo de comandos de transmissao
typedef  struct
{
  u16				wp;
  u16				rp;
  u8				Cmd[TAM_FIFO_CMD_TX];
} STFIFO_CMD_TX;

typedef  struct 
{
	u16				numchannels;
	u16				CardType;
	u32             PlxType;
#ifdef __LINUX__
	struct pci_dev  *digivoice_dev;	/* PCI device */
	unsigned long 	addr_base0; 		/*address base in BAR0*/
	unsigned int 	addr_base0_len; 	/*addr_base0 length*/
	unsigned long 	addr_base2; 		/*address_base in BAR2*/
	unsigned int 	addr_base2_len; 	/*address_base_2 length*/
	local_irq_structure irq_vars;
#endif
	u16				abs_port[MAX_CHANNELS_CARD];
	u16				playing[MAX_CHANNELS_CARD];			//playing
	u16				input_buffer[MAX_CHANNELS_CARD];	    //recording thread
	u16				recording_stop[MAX_CHANNELS_CARD];	    //indica que esta parando de gravar
	u32				gsm_ready[MAX_CHANNELS_CARD];	    //gsm on/off
	u16				gsm_state_play[MAX_CHANNELS_CARD];
	u16				gsm_state_rec[MAX_CHANNELS_CARD];
#ifdef CCS_ENABLE
    u8              ccs_enabled[MAX_SPANS];                     //max 2 spans
#endif
	STFIFO_CMD_RX	Fifo_Cmd_Rx;	//
	STFIFO_CMD_TX   Fifo_Cmd_Tx;                    // [MAX_CHANNELS_CARD];	//fifo unica para a placa toda
#ifdef __LINUX__
		unsigned int	dgdummy_interrupt;
#endif//#ifdef __LINUX__
	unsigned int	debug_level;

#ifdef K_ECHO
		u8 ec[MAX_CHANNELS_CARD];
#endif//#ifdef K_ECHO
} DG_CARDSTRUCT;

//Strucutures to shared memory between lib and kernel part
typedef  struct {
	HANDLE			hWD_Global;
	u32				nCardsCount;
	unsigned long				dwRegSpace[MAX_CARDS];		//BAR0
	unsigned long				dwBar1[MAX_CARDS];		//Bar1
	unsigned long				dwMemSpace[MAX_CARDS];		//Bar2
	DG_CARDSTRUCT   Cards[MAX_CARDS];			// card structure
} DG_SHAREDMEMORY;

typedef  struct {
   //fifo to CCS signalling
   STFIFO_CCS_RX	Fifo_CCS_Rx[MAX_SPANS];
   STFIFO_CCS_TX   Fifo_CCS_Tx[MAX_SPANS]; 
} DG_CCS_MEMORY_ITEMS;

typedef  struct {
    DG_CCS_MEMORY_ITEMS   Cards[MAX_CARDS];
} DG_CCS_MEMORY;


//Shared memory to playback
typedef struct {
#ifdef __LINUX__
  u8				play_thread;	//SLEEPING ou WAKEDUP
#endif
  u8				play_mode;		//	PLAY_FILE = 1,	PLAY_BUFFER = 2
  u8				format;		//formato do playback
  u16				port;
  short				rp;		//retrieve pointer - kernel mode access
  short				wp;		//write poiter - user mode access
  u8 data[WRITE_BUFFER_LINES][SAMPLES_GSM_LEN];	//double-buffer
												//todo: +1 equivale ao contador
} DG_PLAYBACKMEM;

//----------------------------
//Shared memory to recording
//----------------------------
typedef struct {
  u16				port;
#ifdef __LINUX__
  u8				rec_thread;	//SLEEPING ou WAKEDUP
#endif
  u16				wp[2];		//ponteiro de inser�o para cada um
  u8				kb;			//indica o buffer ativo para o kernel
  u8				ub;			//indica o buffer ativo para a aplicacao
  u8 				ub_readed;		//
  u8 				data[2][READ_BUFFER_SIZE];	//os 2 buffers
} DG_RECMEM;

//A estrutura rmk conter�MAX_REC_GROUP canais 
//para utilizacao em cada INODE.
typedef struct {
	u8			 max_port;
	u8			 ch[MAX_REC_PORTS_PER_GROUP];			//hold the absolute number of the channel
	DG_RECMEM	 rec[MAX_REC_PORTS_PER_GROUP];
} DG_GROUPED_RECMEM;

//A estrutura pmk conter�MAX_PLAY_GROUP canais 
//para utilizacao em cada INODE.
typedef struct {
	u8			 		max_port;
	u8			 		ch[MAX_PLAY_PORTS_PER_GROUP];			//hold the absolute number of the channel
	DG_PLAYBACKMEM	 	play[MAX_PLAY_PORTS_PER_GROUP];
} DG_GROUPED_PLAYMEM;


#endif

/*-----------------------------------------------------------------------------
   vlibdef.h
   
   Common defines to Windows and Linux
-----------------------------------------------------------------------------*/

#ifndef __VLIBDEF_H__
#define __VLIBDEF_H__

#ifdef WIN32
	#ifdef _DESENV_
		#include "c:/lp/windriver/include/windrvr.h"
	#endif
#else
	#include <linux/version.h>
#endif

//--------------------------------------------------------------------


#define     DG_MIN_STACKSIZE    512*1024        /* thread stack size */

#define MAX_CHANNELS      600              /* Maximum channels in one PC */
#ifdef __LINUX__
	#define MAX_CARDS          7                  /* Maximum Boards in one PC */
#else
	#define MAX_CARDS          10                 /* Maximum Boards in one PC */
#endif

#define MAX_CHANNELS_VPPCI	1		/* Maximum channels in voicerphone card */
#define MAX_CHANNELS_VBPCI	4		/* Maximum channels in voicerphone card */
#define MAX_CHANNELS_VBE1	60		/* Maximum channels in voicerphone card */

#define SAMPLES_SIZE_GSM			33


//shared memory grouping - allowing 360 channels per PC
//!!!!!!!!!!!!!!! VERY IMPORTANT !!!!!!!!!!!!!!!!!!
//IF MAX_xxx_GROUP is changed, you must update vlibd_load.sh and vlibd.init scritps !!!!!!!!!!!1
//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#define 		MAX_REC_GROUP					 60		//GROUPS
#define 		MAX_REC_PORTS_PER_GROUP			  6		//ports per group

#define 		MAX_PLAY_GROUP					 72
#define 		MAX_PLAY_PORTS_PER_GROUP		  5		//ports per group



/* cross-plattaform definitions */
#ifdef __LINUX__
	#define VLIB_MAJOR 239

	#define __forceinline	
	#define __cdecl	

	#define VLIB_SHM_DEVICE			"/dev/vlibdshm"
	#define VLIB_DEVICE				"/dev/vlibd"
	#define VLIB_DEVICE_SIGNAL		"/dev/vlibd_s"
	#define VLIB_DEVICE_REC_SIGNAL	"/dev/vlibd_rs"
	#define VLIB_DEVICE_PLAY_SIGNAL	"/dev/vlibd_ps"
	#define VLIB_SHM_REC			"/dev/vlibd_r"
	#define VLIB_SHM_PLAY			"/dev/vlibd_p"
    #define VLIB_SHM_CCS			"/dev/vlibdshm_ccs"
    #define VLIB_DEVICE_CCS		    "/dev/vlibd_ccs"

	//IOCTL defines
	#define VPPCI_IOCTL_WCMD      			_IOR(VLIB_MAJOR, 0, void *)  /* Device test   */
	#define VPPCI_IOCTL_OFRMW     			_IO(VLIB_MAJOR,  1)          /* Open  firmware */
	#define VPPCI_IOCTL_WFRMW     			_IOW(VLIB_MAJOR, 2, void *)  /* Write firmware */
	#define VPPCI_IOCTL_CFRMW     			_IO(VLIB_MAJOR,  3)          /* Close firmware */
	#define VPPCI_IOCTL_UPLMODE   			_IO(VLIB_MAJOR,  4)          /* Upload mode    */
	#define VPPCI_IOCTL_NRMMODE   			_IO(VLIB_MAJOR,  5)          /* Normal mode    */
	#define VPPCI_IOCTL_GETSETPLAYSTATUS 	_IOWR(VLIB_MAJOR,  6, void *)          /* Get port status from kernel structures */
	#define VPPCI_IOCTL_RFRMW     			_IOW(VLIB_MAJOR, 7, void *)  /* Read firmware */
	#define VPPCI_IOCTL_RELEASERESET         _IOW(VLIB_MAJOR, 8, void *)  /* Release card reset register */
	#define VPPCI_IOCTL_GETSETRECSTATUS 	_IOWR(VLIB_MAJOR,  9, void *)          /* Get port status from kernel structures */
	#define VPE1_IOCTL_WRHPIA 				_IOW(VLIB_MAJOR,  10, void *)          /* sets HPIA address for E1 cards */
	#define VPE1_IOCTL_INITBOOT             _IOW(VLIB_MAJOR,  11, void *)          /* */
	#define VPPCI_IOCTL_VERSION             _IOW(VLIB_MAJOR,  12, void *)          /* */
	#define VPPCI_IOCTL_GETRECBUFFERSIZE    _IOWR(VLIB_MAJOR,  13, void *)          /* */
	
	#define VLIB_IOCTL_DMALOCK    	_IOWR(VLIB_MAJOR,  14, void *)          /* shared memory */
	#define VLIB_IOCTL_DMAUNLOCK    _IOWR(VLIB_MAJOR,  15, void *)          /* shared memory */
	#define VLIB_IOCTL_OPENBOARDS	_IOWR(VLIB_MAJOR,  16, void *)          /* shared memory */
	#define VLIB_IOCTL_CLOSEBOARDS	_IOWR(VLIB_MAJOR,  17, void *)          /* shared memory */

	//IOCTL
	#define VLIB_IOCTL_READU32				_IOWR(VLIB_MAJOR,  18, void *)
	#define VLIB_IOCTL_WRITEU32				_IOWR(VLIB_MAJOR,  19, void *)
	#define VLIB_IOCTL_WRITEU16				_IOWR(VLIB_MAJOR,  20, void *)
	#define VLIB_IOCTL_COUNTCARDS			_IOWR(VLIB_MAJOR,  21, void *)
	#define VLIB_IOCTL_ENABLE_ISR			_IOWR(VLIB_MAJOR,  22, void *)
	#define VLIB_IOCTL_DISABLE_ISR			_IOWR(VLIB_MAJOR,  23, void *)
	
	#define VLIB_IOCTL_REC_LOCK				_IOWR(VLIB_MAJOR,  24, void *)
	#define VLIB_IOCTL_REC_UNLOCK			_IOWR(VLIB_MAJOR,  25, void *)

	#define VLIB_IOCTL_PLAY_LOCK			_IOWR(VLIB_MAJOR,  26, void *)
	#define VLIB_IOCTL_PLAY_UNLOCK			_IOWR(VLIB_MAJOR,  27, void *)

	#define VLIB_IOCTL_CCS_LOCK			    _IOWR(VLIB_MAJOR,  28, void *)
	#define VLIB_IOCTL_CCS_UNLOCK			_IOWR(VLIB_MAJOR,  29, void *)

	#define VLIB_IOCTL_END_THREADS			_IOWR(VLIB_MAJOR,  30, void *) /* finish rec, play, ccs and command fifos and threads */

	#ifndef __KERNEL__

		typedef unsigned int u32;
		typedef unsigned short u16;
		typedef unsigned char u8;
		
	#endif

	typedef int HANDLE;				/* Handle is the main file descriptor */
	/* PCI base address spaces (BARs) */
	enum {
		AD_PCI_BAR0 = 0,
		AD_PCI_BAR1 = 1,
		AD_PCI_BAR2 = 2,
		AD_PCI_BAR3 = 3,
		AD_PCI_BAR4 = 4,
		AD_PCI_BAR5 = 5,
		AD_PCI_BARS = 6,
	};
	
	/*Command struct fot IOCtl command that allocs struct for shared memory */
	typedef struct
	{
	  u16 group;
	  u16 port;
	  u32 size;
	}  ALLOC_STRUCT ;	
	//
	#define 	SLEEPING	0
	#define 	WAKEDUP		1

	//access rights for fifos
	#define DG_FIFO_ACCESS_RIGHTS	( S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH )

	#define DG_VARLIB_PATH			"/var/lib/voicerlib/"
	#define DG_FIFO_PATH			"/var/lib/voicerlib/fifos"
	#define DG_FIRMWARE_PATH		"/var/lib/voicerlib/firmware"
    #define DG_LOG_PATH             "/var/log/voicerlib/"

#else
	

	/* -----------------------------------------------
		PCI configuration registers offsets - pci_regs.h
	----------------------------------------------- */
	#ifndef _PCI_REGS_H_
	#define _PCI_REGS_H_
	#endif

	enum {
		PCI_VID   = 0x00, /* Vendor ID */
		PCI_DID   = 0x02, /* Device ID */
		PCI_CR    = 0x04, /* Command register */
		PCI_SR    = 0x06, /* Status register */
		PCI_REV   = 0x08, /* Revision ID */
		PCI_CCR   = 0x09, /* Class code */
		PCI_CCSC  = 0x0a, /* Sub class code */
		PCI_CCBC  = 0x0b, /* Base class code */
		PCI_CLSR  = 0x0c, /* Cache line size */
		PCI_LTR   = 0x0d, /* Latency timer */
		PCI_HDR   = 0x0e, /* Header type */
		PCI_BISTR = 0x0f, /* Built-in self test */
		PCI_BAR0  = 0x10, /* Base address register */
		PCI_BAR1  = 0x14, /* Base address register */
		PCI_BAR2  = 0x18, /* Base address register */
		PCI_BAR3  = 0x1c, /* Base address register */
		PCI_BAR4  = 0x20, /* Base address register */
		PCI_BAR5  = 0x24, /* Base address register */
		PCI_CIS   = 0x28, /* CardBus CIS pointer */
		PCI_SVID  = 0x2c, /* Sub-system vendor ID */
		PCI_SDID  = 0x2e, /* Sub-system device ID */
		PCI_EROM  = 0x30, /* Expansion ROM base address */
		PCI_CAP   = 0x34, /* New capability pointer */
		PCI_ILR   = 0x3c, /* Interrupt line */
		PCI_IPR   = 0x3d, /* Interrupt pin */
		PCI_MGR   = 0x3e, /* Minimum required burst period */
		PCI_MLR   = 0x3f  /* Maximum latency - How often device must gain PCI bus access */
	};

	#define PCI_HDR_NORMAL 0
	#define PCI_HDR_BRIDGE 1
	#define PCI_HDR_CARDBUS 2

	/* Size of PCI configuration space */
	#define PCI_CONFIG_SPACE_SIZE 0x100

	/* PCI base address spaces (BARs) */
	enum {
		AD_PCI_BAR0 = 0,
		AD_PCI_BAR1 = 1,
		AD_PCI_BAR2 = 2,
		AD_PCI_BAR3 = 3,
		AD_PCI_BAR4 = 4,
		AD_PCI_BAR5 = 5,
		AD_PCI_BARS = 6
	};

	//generic types for both plataforms
	typedef unsigned short u16;
	typedef unsigned char  u8;
	typedef unsigned int   u32;

	#define DG_FIRMWARE_PATH		"\\Arquivos de Programas\\VoicerLib4"

#endif

#define MAX_SPANS           2

#define MAX_CHANNELS_CARD	MAX_CHANNELS_VBE1

#define HALF_CHANNELS		(MAX_CHANNELS_CARD/2)

#ifdef __LINUX__
	#define WRITE_BUFFER_LINES						512//4.1.0.3_rc5
#else
	#define WRITE_BUFFER_LINES						512
#endif

#define CCS_LINES                                   32

#ifdef __LINUX__
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,26) 
	#define CCS_DATA_SIZE                           1024
#else
	#define CCS_DATA_SIZE                           128
#endif
#else
	#define CCS_DATA_SIZE                           256
#endif

#define WRITE_BUFFER_UNIT 						496
#define WRITE_AUDIO_BUFFER_SIZE 				(30*WRITE_BUFFER_UNIT)
#define WRITE_AUDIO_BUFFER_SIZE_GSM				4950 //(150*33)

#ifdef __LINUX__
	#define READ_BUFFER_UNIT 						(24*SAMPLES_SIZE_GSM)    //1120 - gsm tem frame de 33 bytes
#else
	#define READ_BUFFER_UNIT 						(32*SAMPLES_SIZE_GSM)    //1120 - gsm tem frame de 33 bytes
#endif

#define READ_BUFFER_SIZE						(READ_BUFFER_UNIT*4)

#define	SAMPLES_SIZE						16

#define SAMPLES_LEN							320				/* Size suitable to gsm and wave samples */
#define SAMPLES_GSM_LEN						33
#define SAMPLES_WAVEPCM_LEN					16
#define SAMPLES_WAVE_LEN					8

#define GSM_E1_SIZE					495			//15*33 samples
#define EXPANDED_GSM_SIZE			160

/*PC -> DSP commands*/
#define CRESET               0x80       /*Reset*/
#define CNULO                0x81       /*Null Command*/

//#define CATENDE             0x102      /*Anwser Call*/
//#define CDESLIGA             0x83       /*Hang up*/
#define CPICKUP             0x102      /*Anwser Call*/
#define CHANGUP             0x83       /*Hang up*/
#define CPULSE_ON            0x84       /*Enable pulse detection*/
#define CPULSE_OFF            0x85       /*Disable pulse detection*/
#define CBUSY_ON             0x86       /**/
#define CBUSY_OFF             0x87       /**/
//#define CLIGTOM              0x88       /*Enable tones detection*/
#define CENABLECALLPROGRESS  0x88       /*Enable tones detection*/
//#define CDESTOM              0x89       /*Disable tones detection*/
#define CDISABLECALLPROGRESS	0x89       /*Disable tones detection*/
#define CSTOPPLAY				0x8A       /*Stop reprodution CDESFALA */
#define CSTARTPLAY              0x100      /*Start reprodution CFALA*/
#define CDISCA_TOM				0x82       /*Make a call using tone*/
#define CDISCA_PULSO			0x101      /*Make a call using pulse*/
#define CDT_DTMF_MFP			0x103      /* set detection type*/
//#define CECO                 0x8E       /**/
//#define SND_CAIXAS           0x0f       /**/
#define CPHONE_ON           0x8b       /*Turn the hearfone enable*/
#define CPHONE_OFF	        0x8c       /*Turn the hearfone disable*/
#define CMIC_ON            0x8d       /*Turn the microfonde enable*/
#define CMIC_OFF         0x8e       /*Turn the microfone disable*/
#define CIMP_600             0x8f       /*Set line impedance to 600*/
#define CIMP_900             0x90       /*Set line impedance to 900*/
#define CFLASH               0x91       /*Flash*/
#define CLIGHIBRIDA          0x92       /**/
#define CDESHIBRIDA          0x93       /**/
#define CGANHO_1             0x94       /*Set handset gain to 1*/
#define CGANHO_2             0x95       /*Set handset gain to 2*/
#define CGANHO_3             0x96       /*Set handset gain to 3*/
#define CANSW_ON             0x97       /**/
#define CANSW_OFF               0x98       /**/
#define FIM_CMD              0x99       /**/
#define READ_EEP             0x104      /**/
#define WRITE_EEP            0x105      /**/

#define CSTART_REC           0x116      /* START RECORD */
#define CSTOP_REC            0x117     /* START RECORD */

#define CATT_DTMF						 0x106			//Seta atenuacao low e high
#define CATT_TIME_DTMF			 0x107			//seta duracao de tom e pausa

#define CFREQFAX1							0x128			//Comando para setar freq DO FAX
#define CFREQFAX2							0x129			//Comando para setar freq DO FAX

#define CSETDTMFSENS					0x12a			//Comando para setar tone and busy twist

/*PC -> DSP commands*/
#define EV_RINGS                0x1b       /*Ring detected*/
#define EV_DTMF                 0x1c       /*Digit detected*/
#define EV_DIALTONE             0x1e       /*Line tone detected*/
#define EV_BUSY                 0x21       /*Busy tone detected*/
#define EV_CALLING              0x1d       /*Call tone detected*/
#define EV_ANSWERED             0x1f       /*generate afterpickup*/
#define EV_FAX                  0x22       /*Fax tone detected (CNG or CED) */
#define EV_FAX_CNG              0x23       /*Fax (T_FAX1 = CP_TONE2 = 1100Hz = CNG = DSP_FAXMODE_DETECT_CNG = 'f' = 1)*/
#define EV_FAX_CED              0x24       /*Fax (T_FAX2 = CP_TONE3 = 2100Hz = CED = DSP_FAXMODE_DETECT_CED = 'e' = 2)*/
#define EV_LINEREADY            0x25       /*Line read to make call*/

#define EV_LINEOFF              0x27       /*Line closed*/
#define EV_END_CMD              0x99       /*assyncronous command finished CDISCA_TOM, CDISCA_PULSO, FLASH*/
#define EV_PLAYSTOP				0x29				/* old number 0x119*/
#define EV_PLAYSTART			0x2a        /* old number 0x118*/
#define EV_AFTERDIAL			0x2b				/* old number 0x114*/
#define EV_AFTERFLASH			0x2c				/* old number 0x115*/
#define EV_AFTERPICKUP			0x2d 				/* old number 0x11f*/
#define EV_RECORDSTART		    0x2e
#define EV_RECORDSTOP			0x2f
#define EV_RECORDING           	0x30				//recording
#define EV_DIGITSRECEIVED		0x31			//evento ondigitsreceived
#define EV_CALLERID           	0x32				//caller id message from E1 thread
#define EV_E1CHANGESTATUS      	0x33				//E1 generic events
#define EV_GROUP_B           	0x34				//E1 events to group b messages
#define EV_R2           		0x35				//E1 R2 signals to app
#define EV_CALLSTATECHANGE		0x36				//ON CALL STATE CHANGE
#define EV_LOGGEREVENT			0x37				//Evento durante Logger OnLoggerEvent
#define EV_E1_ALARM        		0x38				//E1 R2 alarms
#define EV_ERRORDETECTED		0x39				//Erros da placa
#define EV_CTBUS				0x3a				//evento ctbus
#define EV_FRAMER				0x3b				//evento framer

//eventos de callprogress
#define EV_CALLPROGRESS_TIMEOUT	0x3c
#define EV_GENERIC_TONE			0x3d				
#define EV_AUDIO_SIGNAL			0x3e				//manda qualquer audio para a aplicacao
#define EV_SILENCE				0x3f				//silence detection	

//eventos fxs
#define EV_FLASH				0x40				//envia evento de flash para a aplicacao

//eventos mailbox
#define EV_MBDETECTED                   0x45

//eventos gsm
#define EV_GSMTIMEOUT			0x50
#define EV_GSMMESSAGE			0x51
#define EV_GSMSMSSENT			0x52
#define EV_GSMERROR				0x53
#define EV_GSMSMSRECEIVED		0x54
#define EV_GSMREADY				0x55
#define EV_GSMSIGNALQUALITY		0x56
#define EV_GSMRETURNOK			0x57
#define EV_GSMOTHERCALL			0x58
#define EV_GSMMEMORY			0x59
#define EV_GSMMEMORYFULL		0x60
#define EV_GSMSIM				0x62
#define EV_GSMSMSCONFIRMATION	0x63
#define EV_GSMUSSDRECEIVED		0x64

//eventos ISDN
#define EV_CHANNEL				0x70
#define EV_NAMEID				0x71
#define EV_TEXT					0x72
#define EV_REVERSECHARGING		0x73
#define EV_ERROR_NODE_CONFIG	0x74
#define EV_ISDN_ERROR			0x75
#define EV_AFTERHANGUP			0x76				//after hangup - port is free

#define EV_INFORECEIVED			0x80

//Configuracoes de Framer
//CMD_FRAMER, R_W, Device, Page, Address, Data
#define CFG_FRAMER_READ			1
#define CFG_FRAMER_WRITE		0
#define CFG_FRAMER_E1_A			1
#define CFG_FRAMER_E1_B			2
#define CFG_FRAMER_CRC4_PAGE	1	
#define CFG_FRAMER_CRC4_ADDR	0x10	
#define CFG_FRAMER_CRC4_ON		0x13	
#define CFG_FRAMER_CRC4_OFF		0x37

#define CFG_FRAMER_CRC4_AIS_ON	0x93	
#define CFG_FRAMER_AIS_ON		0xb7

//generic options
#define	DG_ENABLE				1
#define	DG_DISABLE				0

//generic options
#define	DG_ENABLE_AGC				1
#define	DG_DISABLE_AGC				0

//generic options
#define	DG_PAUSE				1
#define	DG_RELEASE				0


//silence detection constants
#define DG_SILENCE_DETECTED		1
#define DG_AUDIO_DETECTED		0

#define ERRORBUFFERATIVO        0x112      /*active buffer error*/

#define CTONEFREQ   	        0x11a			//Comando para setar freq de 425 CFREQTOM
#define CSETRECGAIN	        0x12d			//Seta ganho de gravacao por canalCSETAGANHO_GRAVA

#define DATA_SIZE_TX            30

//defines for internal use
#define RESETSOFT			0x110			//Programa TMS reiniciado
#define ERROBUFFERATIVO     0x112			//O Driver passa para o programa erro de buffer ativo
#define FIFOGRAVACAOCHEIA   0x113			//...


#define	ERRO_INT			0x116			//Indica que parou de interromper

#define RECORDSTART				0x11b
#define RECORDSTOP				0x11c
#define RECORDING         0x11d			//Gravando...
#define SAMPLETOAPP				0x11e			//Sinaliza amostras para a aplicacao
//#define AFTERPICKUP			0x11f


#define EV_STARTPLAY			0x120
#define EV_MAKECALLSTOP			0x121
#define EV_PAUSEAFTERANSWER		0x122
#define MENUSTOP				0x223
#define PROMPTSTOP				0x224
#define PLAYNUMEROPROMPT		0x225

#define CPEDEVERSAOFIRMWARE	0x126
#define CPEDEVERSAODRIVER	0x127

//--------------------------------------------------------
//Input Buffer States
//--------------------------------------------------------
#define INPUT_BUFFER_OFF				0
#define INPUT_BUFFER_ON					1
#define INPUT_BUFFER_INITIAL			2
#define INPUT_BUFFER_WAIT        		3
#define SAMPLE_ON						4
#define INPUT_BUFFER_ENDING  	  		5
#define INPUT_BUFFER_FLUSHING			6
#define INPUT_BUFFER_AFTERFLUSHING		7

//--------------------------------------------------------
// Playback states
//--------------------------------------------------------
#define PLAY_OFF			0       //Nao esta falando
#define PLAY_ON				1       //Indica pro Kernel para ler da fifo e enviar
#define PLAY_ENDING			2		//Acabou de ler o arquivo e indica pro kernel que qdo
									//a fifo estiver vazia, deve enviar o CFALA_OFF de volta
#define PLAY_WAIT         	3
#define PLAY_START          4
#define PLAY_STARTING       5
#define NOSET          		10

#define ASSUME_PORT			1
#define ASSUME_CARD			2

//E1ChangeStatus data events
#define R2_IDLE						0x9					//R2_AVAILABLE
#define R2_CLEAR_FOWARD				0x9			//R2_FOWARDRELEASE
#define R2_SEIZURE					0x1
#define R2_BACKWARD_DISCONNECTION	0x1
#define R2_SEIZURE_ACK				0xd     //R2_SEIZURE_CONFIRMATION
#define R2_BILLING					0xd
#define R2_CLEAR_BACK				0xd			//R2_BACKWARD_RELEASE
#define R2_ANSWERED					0x5
#define R2_BLOCKED					0xd
#define R2_FAILURE					0xd
#define R2_ENABLEDETECTION				0x10
#define R2_DISABLEDETECTION				0x20


//defines para comunicacao do e1-thread pro callcontrol threadC_TIMEOUT,
//..#define   C_OCUPA					0x1000
//..#define   C_LIVRE					0x1001
//..#define   C_DIAL					0x1002
//..#define   C_PEDECATEGORIA			0x1003
//..#define   C_ENVIACATEGORIA			0x1004
#define   C_GRUPO_B					0x1005
#define   C_NEXT_DIGIT				0x1006
#define   C_ENDTHREAD				0x1007
#define   C_TIMEOUT					0x1008

#define   C_ASK_FOR_ID				0x1009
#define   C_ID_RECEIVED				0x100a

#define   C_SEIZURE					0x100b
#define   C_WAITFORDIGITS			0x100c
#define   C_NUMBER_RECEIVED			0x100d
#define   C_END_MF					0x100e

#define   C_BUSY					0x100f
#define   C_ENDCALL					0x1010
#define   C_UNAVAILABLE				0x1011
#define   C_ANSWERED				0x1012
#define   C_CONGESTION				0x1013	//congestionamento
#define   C_B_ENDCALL				0x1014
#define   C_NOTCOMPLETED			0x1015

#define   C_PREP_RX_GRUPO_II		0x1016
#define   C_GROUP_II				0x1017		//C_CATEGORIA
#define   C_PEDE_GRUPO_B			0x1018

#define   C_SEND_ID					0x1019   //C_ENVIAID
#define   C_PEDE_GRUPO_I			0x101a
#define   C_ENVIA_GRUPO_A			0x101b
#define   C_GROUP_I					0x101c
#define   C_RING					0x101d	//evento para a thread gerar o ring
#define   C_CALLPROGRESS			0x101e  //evento para a thread gerar o callprogress
#define   C_RESET_THREAD            0x101f  //evento para resetar os estados da threadE1

#define   C_E1_IDLE					0x102a	//sinaliza que a thread recebeu o e1

#define   C_SET_CALLPROGRESS		0x102b	//comando para setar tipo de callprogress

#define   C_TIMEOUT_AUDIO			0x102c	//timeout for audio events in callprogress

#define   C_E1_SEIZURE_ACK			0x102d	//e1 - Confirm Ocupacao

#define   C_SEND_GROUP_B			0x102e	//send group b

#define   C_SEND_BACKWARD_SIGNAL    0x102f  //send custom backward signal

//-----------------------------------------------------------------------------------
//VoicerBox PCI/E1 definitions
//-----------------------------------------------------------------------------------
#define BUFFER_WR 0x400  //hardcoded address
#define RUN_PROGRAM 0x409 //hardcoded address
#define BUFFER_RD 0x403  //hardcoded address

#define CMD_SIZE_RX		4		//size of command received from card
#define CMD_SIZE_TX		6		//size of command received to card

#define HPIC	  0x0000
#define HPIA	  0x8000
#define HPID_AINC 0x10000
#define HPID	  0x18000

//DSP -> Host (Card to PC)

//Command buffers address
#define CMD_DSP_HOST0	0x7700
#define CMD_DSP_HOST1	0x7780

#define CMD_CTR_DSP		0x763f	//holds the number of data, active buffer and error indicator flag
								//0x0000 there are no commands - > 0x0000 indicates the number of commands
								//Active buffer indicated by BIT14 - 0 = HOST0, 1 = HOST1
								//if BIT15 is set, there are a buffer overflow error.

#define CMD_INT_COUNT   0x7635

#define CMD_CTR_HOST	0x763e	//number of data to be transfered to dsp

#define CMD_HOST_DSP	0x7640	//buffer TX address

#define NUMERO_CANAIS	 0x7637	//number of physical ports

//gsm sync addresses
#define GSM_SYNC			0x7639  //(the sync are in 0x7639, 0x763a, 0x763b and 0x763c)

#define GSM_SYNC_REC		0x7630	// 0x7630 - 0x7631 - 0x7632 - 0x7633

//samples addresses
#define SAMPLES_ACTIVE_BUFFER		0x763d

#define SAMPLES_HOST_DSP0			0x7c00
#define SAMPLES_HOST_DSP1			0x7e00

#define SAMPLES_DSP_HOST0			0x7800
#define SAMPLES_DSP_HOST1			0x7a00

//addresses to control ccs mode 
#define CCS1_CTR_HOST       0x349c
#define CCS1_CTR_DSP        0x349d
#define CCS2_CTR_HOST       0x349e
#define CCS2_CTR_DSP        0x349f
// buffers to transfer data through CCS canal 16(ISDN)
#define CCS1_DSP_HOST0      0x34ac
#define CCS1_DSP_HOST1      0x34bc
#define CCS1_HOST_DSP0      0x34cc
#define CCS1_HOST_DSP1      0x34dc
 
#define CCS2_DSP_HOST0      0x34ec
#define CCS2_DSP_HOST1      0x34fc
#define CCS2_HOST_DSP0      0x350c
#define CCS2_HOST_DSP1      0x351c

#define MAX_TX_DATA_LEN 			30

//MUDEI port de char pra short
typedef struct  {
	unsigned char command;
	unsigned char param1;
	unsigned char param2;
	unsigned char param3;
	unsigned char param4;
	unsigned char param5;
	short port;			//pass the card when port is Not Applicable -1 is ignored
	char port_or_card;  //ASSUME_PORT , ASSUME_CARD
	unsigned short wContador;
}  dg_cmd_tx;





/*Command struct fot IOCtl command that issues write commands to dsp */
typedef struct
{
  unsigned short port;
  unsigned short command;
  unsigned short ndata;
  unsigned short data[MAX_TX_DATA_LEN];
}  send_command ;

//structure receive from driver
typedef struct {
    unsigned short command;
    unsigned short data; 
    unsigned short port;
	unsigned short data_aux; 
} dg_signal_from_device;


#define GSM_WAIT	 0
#define GSM_PART1	 1
#define GSM_PART2	2
#define GSM_PART3	3
#define GSM_DUMMY1	4
#define GSM_DUMMY2	5
#define GSM_DUMMY3	6
#define GSM_OFF		7				//indicates that isn't using gsm 

//acoes ao termino da discagem E1
#define EA_NONE						0
#define EA_GENERATE_CALLING			1
#define EA_GENERATE_BUSY			2

//contantes utilizadas no comando de pedido de alarme ou configuracao do modo
#define ALARM_GETSTATUS				0
#define ALARM_MANUAL_NOTIFY			1
#define ALARM_AUTOMATIC_NOTIFY		2

#define CCS_FRAME_SIZE              0x20

//File Format
enum EnumFileFormat {ffWaveULaw,ffSig,ffWavePCM,ffGsm610,ffWaveALaw,ffWave49} ;

/* CCS mode constants */
enum
{
  CCS_FIRST=0x100,
  CCS_LAST=0x200,
  CCS_BAD=0x400,
  CCS_BUF0=0x0000,
  CCS_BUF1=0x1000
};

// PLX register definitions 
enum {
    E1_LAS0RR      = 0x00,
    E1_LAS1RR      = 0x04,
    E1_LAS2RR      = 0x08,
    E1_LAS3RR      = 0x0c,
    E1_EROMRR      = 0x10,
    E1_LAS0BA      = 0x14,
    E1_LAS1BA      = 0x18,
    E1_LAS2BA      = 0x1c,
    E1_LAS3BA      = 0x20,
    E1_EROMBA      = 0x24,
    E1_LAS0BRD     = 0x28,
    E1_LAS1BRD     = 0x2c,
    E1_LAS2BRD     = 0x30,
    E1_LAS3BRD     = 0x34,
    E1_EROMBRD     = 0x38,
    E1_CS0BASE     = 0x3c,
    E1_CS1BASE     = 0x40,
    E1_CS2BASE     = 0x44,
    E1_CS3BASE     = 0x48,
    //E1_INTCSR      = 0x4c,
    E1_PROT_AREA   = 0x4e,
    E1_CNTRL       = 0x50,
    E1_GPIOC       = 0x54,
    E1_PMDATASEL   = 0x70,
    E1_PMDATASCALE = 0x74,
};

//-----------------------------------------
// Constants used in CMD_DIAL_CFG command
//-----------------------------------------
enum
{
 DIAL_CFG_GAINDTMF,
 DIAL_CFG_GAINMFT,
 DIAL_CFG_GAINMFF,
 DIAL_CFG_GAINMF,
 DIAL_CFG_GAINTONE1,
 DIAL_CFG_GAINTONE2,

 DIAL_CFG_FREQDTMF,
 DIAL_CFG_FREQMFT,
 DIAL_CFG_FREQMFF,
 DIAL_CFG_FREQMF,
 DIAL_CFG_FREQTONE1,
 DIAL_CFG_FREQTONE2
};

/* analogic cards states */ 
enum
{
 HOOK_ON,
 HOOK_OFF,
 HOOK_CHANGE,
 RING_START,
 RING_STOP,
 RING_ON,
 FLASH,
 FR,    /* Forward/Reverse */
 FLASH_MIN,
 FLASH_MAX,
 POLARITY_CHANGE,
 FX_TYPE,
 FX_BLOQUEADO,
 FX_IMPEDANCE
};

//ANSWERED types
enum 
{ 
 AUDIO_DETECTED, 
 TIMEOUT_DETECTED
};

//------------------------------------------------------------
// Commands
//------------------------------------------------------------
enum
{
 CMD_DIAL,
 CMD_DIAL_CFG,
 CMD_PLAY,
 CMD_REC,
 CMD_DETECTION_CFG,	//4
 CMD_DETECTION,
 CMD_DETECTION_DTMF20,	//removido na versao 4.0.7.4
 CMD_R2,			//7
 CMD_FRAMER,
 CMD_SETBUSCONNECTION,
 CMD_H100_CFG,
 CMD_ALARM,
 CMD_MIXER,
 CMD_AGC,
 CMD_CNG,
 CMD_ECHO,
 CMD_CONFERENCE,
 CMD_ERROR,
 CMD_LOOP, //18
 CMD_GAIN, //19
 CMD_FILTER,
 CMD_PULSE,
 CMD_CTBUS,
 CMD_AGC_CFG,
 CMD_G168_TESTE,
 CMD_RESYNC,    //CMD_RESET
 CMD_GAIN_PGA,
 CMD_LINE,
 CMD_LINESTATE,
 CMD_INPUT,
 CMD_CCS=0x20,// sinalizacao canal comum (ISDN)
 CMD_ALARME_H100,
 CMD_BENCHMARK=0x22,
 CMD_TWIST=0x23,
 CMD_UART0=0x24,
 CMD_UART1=0x25,
 CMD_UART2=0x26,
 CMD_INFO=0x27,
 CMD_TEST=0x55
};
//---------------------------------------------------
//constants used in CMD_R2
//---------------------------------------------------
#define R2_AVAILABLE							0x9
#define R2_FOWARDRELEASE						0x9
#define R2_SEIZURE								0x1
#define R2_BACKWARD_DISCONNECTION				0x1
#define R2_SEIZURE_CONFIRMATION					0xd
#define R2_BILLING								0xd
#define R2_BACKWARD_RELEASE						0xd
#define R2_ANSWERED								0x5
#define R2_BLOCKED								0xd
#define R2_FAILURE								0xd
#define R2_ENABLE								0x10
#define R2_DISABLE								0x20

//-------------------------------------------------
// TONE generation types - CMD_DIAL command
//-------------------------------------------------
enum 	
{
	GENERATE_OFF,
	GENERATE_DTMF,
	GENERATE_MFT,
	GENERATE_MFF,
	GENERATE_MF,
	GENERATE_TONE1,
	GENERATE_TONE2
};
//-------------------------------------------------
// CMD_PLAY command parameters
//-------------------------------------------------
enum
{
	E1_PLAY_OFF,
	E1_PLAY_A,
	E1_PLAY_U,
	E1_PLAY_GSM
};

//-------------------------------------------------
// CMD_REC command parameters
//-------------------------------------------------
enum
{
	E1_REC_OFF,
	E1_REC_A,
	E1_REC_U,
	E1_REC_GSM
};

enum //config do Conecta (CMD_CONECTA)
{
 LOCAL_LOCAL, //ch(0-63/255),ch(0-63/255)
 LOCAL_H100,  //ch(0-63/255),h100fr(0-31),h100slot(0-127)
 H100_LOCAL,  //ch(0-63/255),h100fr(0-31),h100slot(0-127)
 H100_H100_CH,//ch(0-63/255)
 H100_H100_SW,//h100fr(0-31),h100slot(0-127),h100fr(0-31),h100slot(0-127)
 H100_RESET=0x5,
 RX_TX,        // ch(0-059),ch(0-59),conecta o audio da entrada Rx na saida Tx (0->NCANAIS-1)
 H100_PATERN, //teste
 H100_DEFAULT  //restaura conexao padrao entere DSP e framers
};
//--------------------------------
// CMD_ERROR Parameters
//--------------------------------
enum
{
	DONTSEND_ERROR,
	SEND_ERRORCODE
};


//forces double span E1 card to be single span
#define CMD_LIU			0x1e


//-------------------------------------------------
// CMD_DETECTION command parameters
//-------------------------------------------------
enum
{
DETECT_OFF=0x0000, 	//turns off detection
DETECT_DTMF=0x0001, 	//enables dtmf detection
DETECT_MFT=0x0002, 	//enables "mf back"
DETECT_MFF=0x0004, 	//enables "mf ahead"
DETECT_MF=0x0008, 	  //enables user-defined mf
DETECT_TONE1=0x0010,   //enables pure 425hz detection
DETECT_TONE2=0x0020, 	//enables pure 1100hz detection (fax)
DETECT_TONE3=0x0040,   //enables pure 2100hz detection (fax)
DETECT_TONE4=0x0080, 	//enables pure user-defined tone
DETECT_AUDIO=0x0100,  //qualquer sinal diferente de silencio e os outros tons habilitados
DETECT_TONE5=0x0200, 	
DETECT_TONE6=0x0400,
DETECT_TONE7=0x0800,
DETECT_TONE8=0x1000,
DETECT_ALL_MF=0x7000,	//not used by cards - only for voicerlib internal control
DETECT_ALL_TONE=0x7001	//not used by cards - only for voicerlib internal control
};


/* tipos de sinal detectados */
enum
{
 CP_SILENCE=0x20,
 CP_AUDIO,
 CP_TONE1,
 CP_TONE2,
 CP_TONE3,
 CP_TONE4,
 CP_TONE5,
 CP_TONE6,
 CP_TONE7,
 CP_TONE8,
 CP_UNDEFINED = 0x40,	//0x2a
 CP_INVALID
};

//------------------------------
//cmd_detecta_cfg configuration
//------------------------------
enum
{
 CFG_DETECT_SILENCE,
 CFG_DETECT_FREQDTMF,
 CFG_DETECT_FREQMFT,
 CFG_DETECT_FREQMFF,
 CFG_DETECT_FREQMF,
 CFG_DETECT_FREQTONE1, //5
 CFG_DETECT_FREQTONE2,
 CFG_DETECT_FREQTONE3,
 CFG_DETECT_FREQTONE4,
 CFG_DETECT_FREQTONE5,
 CFG_DETECT_FREQTONE6,
 CFG_DETECT_FREQTONE7,
 CFG_DETECT_FREQTONE8
};


enum //eventos para o host
{
 C_ERROR=0x43,
 C_ERROR2=0x44,
 C_CAS=1,
 C_AUDIO,
 C_FRAMER,
 C_ALARM,
 C_PULSE,
 C_CTBUS,
 C_LINESTATE,
 C_ALARME_H100=0x8,			//-> placa e1 VB6060PCI
 C_UART1=0x10,              //GSM card
 C_UART2=0x11,
 C_SENDSMS=0x12,
 C_UART3=0x13,
 C_INFO=0x14
};

//--------------------------------
// C_ERROR Codes
//--------------------------------
#define ERROR_INTERRUPT			0x01
#define ERROR_PROCESSO			0x02
#define ERROR_CMD_INVALIDO		0x10
#define ERROR_FIFO_FULL			0x79
#define ERROR_READ_FAILURE      0x80
#define ERROR_CMD_OVERFLOW      0x98
#define ERROR_CARD_RESET        0x99

//--------------------------------
// C_ERROR2 Codes
//--------------------------------
enum
{
	ERROR_CLR2				= 0x00,
	ERROR_1024TAPS			= 0x76,
	ERROR_UART_FIFO_FULL	= 0X77
};

//--------------------------------
// INFO Codes
//--------------------------------
#define INFO_VERSION			0x01
#define INFO_LECCOUNT			0x02

enum 	//framer looping types
{
	FRAMER_LOOP_OFF,
	FRAMER_LOOP_REMOTE,
	FRAMER_LOOP_LOCAL
};

enum 	//framer looping types
{
	E1_A = 1,
	E1_B = 2
};


//array for call progress detections
enum
{
 T_AUDIO,
 T_LINE,
 T_CALLING,
 T_BUSY,
 T_FAX1,
 T_FAX2,
 T_GTONE,
 T_GTONE2,
 T_GTONE3,
 T_GTONE4,
 T_GTONE5,
 T_SILENCE,
 T_OPINC,	//operacao incorreta - future implementation
};

enum //config do H100 (CMD_H100_CFG)
{
 H100_MASTER,
 H100_SLAVE,
 H100_CT_NETREF,
 H100_SCBUS,
 H100_MVIP90,
 H100_HMVIP,
 H100_TERMINAL,
 H100_STREAM_RATE,
 H100_SYNC
 };


/*************** conf sincronismo *******************/
// somente para a placa vb6060pci
enum //config do sincronismo (CMD_H100_CFG)
{
	SYNC_LINE_A=1,        //sync line A  \___  igual  aos 3 ultimos  - frame_1 padrao
	SYNC_LINE_B=2,       //sync line B  /     o framer faz o sincronismo
	SYNC_INTERNAL=3,       //internal
	SYNC_H100_CT_A=4,
	SYNC_H100_CT_B=5,
	SYNC_H100_SCBUS_2048=6,
	SYNC_H100_SCBUS_4096=7,
	SYNC_H100_SCBUS_8192=8,
	SYNC_H100_MVIP=9,
	SYNC_H100_H_MVIP=10,
	SYNC_H100_CT_NETREF=11,
	SYNC_H100_CLK_LINE_A=12,    //sync lina A  \___  igual aos 3 primeiros
	SYNC_H100_CLK_LINE_B=13,    //sync line b  /     quem faz o sincronismo 
	SYNC_H100_INTERNAL=14,      //internarl          o chip do H100

	//constantes para manter compatibilidade com placa antiga
	MASTER_INTERNAL_SYNC=SYNC_INTERNAL,
	MASTER_SYNC_A=SYNC_LINE_A,
	MASTER_SYNC_B=SYNC_LINE_B,
	SLAVE_MODE=SYNC_H100_CT_A
};


/*************** conf Master PLL  *******************/
enum //config do H100 MASTER
{
 H100_MS_SEL,
 H100_MS_REF,
 H100_MS_REFFR
};
enum //config do H100 MASTER SEL   //TODO: documentar que é  necessario chamar o DISABLE para desabilitar tudo anter de habilitar a opcao desejada, pois eh possivel habilitar todas ao mesmo tempo
{
 H100_MS_DISABLE=0,
 H100_MS_CT_A=1,
 H100_MS_CT_B=3,
 H100_MS_SCBUS=4,
 H100_MS_MVIP=5
};
enum //config do H100 MASTER REF
{
 H100_MS_NONE=0,
 H100_MS_CT_NETREF1=6,
 H100_MS_CT_NETREF2=7,
 H100_MS_L_NETREF0=9,
 H100_MS_L_NETREF1=8,
 H100_MS_L_NETREF2=10
};
enum //config do H100 MASTER REFFR
{
 H100_MS_8KHz=0,
 H100_MS_1536MHz=1,
 H100_MS_1544MHz=2,
 H100_MS_2048MHz=3
};

/*************** conf SLAVE PLL  *******************/
enum //config do H100 SLAVE
{
 H100_SL_CT_A,
 H100_SL_CT_B,
 H100_SL_SCBUS,
 H100_SL_MVIP,
 H100_SL_LOCAL0,
 H100_SL_LOCAL1
};

/*************** conf CT_NETREF  *******************/
enum //config do H100 CT_NETREF
{
 H100_REF_SOURCE1,
 H100_REF_SOURCE2,
 H100_REF_DIV1,
 H100_REF_DIV2
};
enum //config do H100 REF_SOURCE
{
 H100_REF_NONE=0,
 H100_REF_L_NETREF0=9,
 H100_REF_L_NETREF1=8,
 H100_REF_L_NETREF2=10,

 //abaixo somente placa VB6060PCI
 H100_REF_L_NETREF3=11, // c4
 H100_REF_L_NETREF4=12, // f0
 H100_REF_LINE_A=0x20, //Exclk (2M_2) djat externo (inverte framers na placa)
 H100_REF_LINE_B=0x21, //Exclk (2M_1) djat externo (inverte framers na placa
 H100_REF_CLK_LINE_A=0x22, //Exclk (2M_2) djat externo (inverte framers na placa)
 H100_REF_CLK_LINE_B=0x23, //Exclk (2M_1) djat externo (inverte frame
 H100_REF_INTERNAL=0x24, // freerun Clock interno
 H100_REF_FRAME_CLK=0x25, // C2 2MHz from framers (reservado, nao usar)
 H100_REF_FRAME_F0=0x26 // f0 8Khz from framers   (reservado, nao usar)
 
};
enum //config do H100 REF_DIV
{
 H100_REF_D1,
 H100_REF_D192,
 H100_REF_D193,
 H100_REF_D256,
 H100_REF_DX			//VB6060PCI
};

/*************** conf SCBus    *******************/
enum //config do H100 SCBUS
{
 H100_SC_SEL,
 H100_SC_FREQ
};
enum //config do H100 SC_SEL
{
 H100_SC_ENABLE=1,
 H100_SC_DISABLE=0
};
enum //config do H100 SC_FREQ
{
 H100_SC_2048,
 H100_SC_4096,
 H100_SC_8192,
 H100_SC_OFF		//placa VB6060pci
};

/*************** conf MVIP90    *******************/
enum //config do H100 MVIP90
{
 H100_MV_ENABLE=1,
 H100_MV_DISABLE=0
};

/*************** conf H-MVIP    *******************/
enum //config do H100 HMVIP
{
 H100_HMV_ENABLE=1,
 H100_HMV_DISABLE=0
};

/*************** conf do TERMINAL do H100  ********/
enum //config do TERMINAL
{
 H100_TERM_ENABLE=1,
 H100_TERM_DISABLE=0
};

/*************** conf do Stream Rate  ********/
enum //config do H100 STREAM_RATE
{
 H100_ST_0_3=0,
 H100_ST_4_7=2, 
 H100_ST_8_11=4,
 H100_ST_12_15=6,
 //placa VB6060pci
 H100_ST_16_19=8,
 H100_ST_20_23=10,
 H100_ST_24_27=12,
 H100_ST_28_31=14
};
enum //config do H100 STREAM_RATE (freq)
{
 H100_ST_2048,
 H100_ST_4096,
 H100_ST_8192,
 H100_ST_DISABLE
};

enum 
{
	TX_GAIN=0,
	RX_GAIN=1,
	REC_GAIN=2,
	PLAY_GAIN=3
};

enum
{
	NORMAL_DETECTION=0,
	FAST_DETECTION=1
};

//play mode for internal control
enum 
{
	PLAY_FILE = 1,
	PLAY_BUFFER = 2
};

/*//GRUPO B specifications(on version 4.0.9.4 it is in e1.h)
enum
{
	B_FREE_CALLING = 1,
	B_BUSY,
	B_NUMBER_CHANGED,
	B_CONGESTION,
	B_FREE_WITHOUTBILLING,
	B_COLLECTCALL,
	B_NUMBER_UNKNOWN,
	B_OUT_OF_SERVICE
};*/

//Idle XXXX FORMAT defines
enum { wtDTMF, wtMFP, wtCustom };


#define TAM_FIFO_CMD_RX			512 * (CMD_SIZE_RX+1)
#define TAM_FIFO_CMD_TX			1024 * (CMD_SIZE_TX+1) /* MAX_CHANNELS_CARD*/		//tamanho das FIFOS de comandos


enum
{
    VLIB_ADDR_REG     = AD_PCI_BAR0,
    VLIB_ADDR_REG_IO  = AD_PCI_BAR1,
    VLIB_ADDR_SPACE0  = AD_PCI_BAR2,
    VLIB_ADDR_SPACE1  = AD_PCI_BAR3,
    VLIB_ADDR_SPACE2  = AD_PCI_BAR4,
    VLIB_ADDR_SPACE3  = AD_PCI_BAR5,
    VLIB_ADDR_EPROM   = AD_PCI_BARS
};


enum { VLIB_DEFAULT_VENDOR_ID = 0x10b5 };
enum { VLIB_DEFAULT_DEVICE_ID = 0x9030 };

enum
{
    VLIB_MODE_BYTE   = 0,
    VLIB_MODE_WORD   = 1,
    VLIB_MODE_DWORD  = 2
};

enum
{
    VLIB_AD_BAR0 = AD_PCI_BAR0,
    VLIB_AD_BAR1 = AD_PCI_BAR1,
    VLIB_AD_BAR2 = AD_PCI_BAR2,
    VLIB_AD_BAR3 = AD_PCI_BAR3,
    VLIB_AD_BAR4 = AD_PCI_BAR4,
    VLIB_AD_BAR5 = AD_PCI_BAR5,
    VLIB_AD_EPROM = AD_PCI_BARS,
};

// PLX register definitions 
enum {
    VLIB_LAS0RR      = 0x00,
    VLIB_LAS1RR      = 0x04,
    VLIB_LAS2RR      = 0x08,
    VLIB_LAS3RR      = 0x0c,
    VLIB_EROMRR      = 0x10,
    VLIB_LAS0BA      = 0x14,
    VLIB_LAS1BA      = 0x18,
    VLIB_LAS2BA      = 0x1c,
    VLIB_LAS3BA      = 0x20,
    VLIB_EROMBA      = 0x24,
    VLIB_LAS0BRD     = 0x28,
    VLIB_LAS1BRD     = 0x2c,
    VLIB_LAS2BRD     = 0x30,
    VLIB_LAS3BRD     = 0x34,
    VLIB_EROMBRD     = 0x38,
    VLIB_CS0BASE     = 0x3c,
    VLIB_CS1BASE     = 0x40,
    VLIB_CS2BASE     = 0x44,
    VLIB_CS3BASE     = 0x48,
    VLIB_INTCSR      = 0x4c,
	VLIB_INTCSRE     = 0x68,
    VLIB_PROT_AREA   = 0x4e,
	VLIB_CNTRL		 = 0x50,
	VLIB_GPIOC		 = 0x54,
	VLIB_GPIOCE		 = 0x6c,
    VLIB_PMDATASEL   = 0x70,
    VLIB_PMDATASCALE = 0x74,
};
//-----------------------------------------
// Card types identifications
//-----------------------------------------
enum {
#ifdef WINVISTA
		VBE13060PCI			= 0x3391,	//0x4400, PLACA e1 3060 
		VB0408PCI			= 0x3383,	//0x4401, placa vbox 4/8c - fxo
		VBE13060PCI_R		= 0x3392,	//0x4402, PLACA e1 3060 revisao 3
		VBE16060PCI			= 0x3381,	//0x4405, nova placa E1 - VB6060PCI
		VBE16060PCI_R		= 0x3393,	//0x4406, nova placa E1 - VB6060PCI
		VBE13030PCI         = 0x3382,	//0x4407, placa e1 - 1 span
		VB0404FX_R			= 0x3384,	//0x4408, placa vbox 4c - fx
		VB6060PCIE          = 0x3386,	//0x4409, placa E1 PCIe 60
		VB3030PCIE          = 0x3387,	//0x440b  placa E1 PCIe 30
#else
		VBE13060PCI			= 0x4400,
		VB0408PCI			= 0x4401,
		VBE13060PCI_R		= 0x4402,
		VBE16060PCI			= 0x4405,
		VBE16060PCI_R		= 0x4406,
                VBE13030PCI			= 0x4407,	      	
		VB6060PCIE			= 0x4409,
		VB3030PCIE			= 0x440b,
		VB0404FX_R			= 0x440c,   //placa vbox 4c - fx
#endif
		VX5502PCI			= 0x4404,	//placa processadora
		VB0404GSM			= 0x3389,	//placa GSM
		VB1224PCIE			= 0x3414,	//placa FXO
		VB0404FX			= 0x4408,
		VB0408PCIE			= 0x3388,	//placa PCIe 4/8c
		VB1200PCIE			= 0x3399,	//placa PCIe 1200
		DGV_2E1F			= 0x3415,	//placa PCIe DGV_2E1F
		DGV_1E1F			= 0x3416	//placa PCIe DGV_1E1F

};   //ATENCAO: atualizar vlibdrv.c quando acrescentar nova placa!!!

// gsm mode
enum {
	GSM_DIGIVOICE,	//proprietary hearder, same encoding
	GSM_RAW			//raw mode - without header
};

//input buffer size
enum {
	INPUT_BUFFER_NO_DELAY=1,		//Para uso em streaming
	INPUT_BUFFER_REC_DELAY=2		//Para uso em gravacao
};

//silence detection state constants
enum {
	SILENCE_OFF = 0,
	SILENCE_ON = 1
};

enum {
	DG_E1_THREAD_DISABLED = 0,
	DG_E1_THREAD_ENABLED = 1
};

enum {
	DG_CB_THREAD_DISABLED = 0,
	DG_CB_THREAD_ENABLED = 1
};

enum {
	ECHO_FREE         =0x0,
	ECHO_ALLOC_DEFAULT=0x1,
	ECHO_ALLOC        =0x2,
	ECHO_ADAPT        =0x3,
	ECHO_RESET        =0x4,
	ECHO_TRAINING     =0x5,
	ECHO_NLP          =0x6,
	ECO_NLP_MODE	  =0x07,
	ECO_NOISEINJ	  =0x08,
	ECO_TONEDETECT	  =0x09,
	ECO_G165		  =0x0A,
	ECO_NB			  =0x0B,
	ECO_OFFSET		  =0x0C,
	ECO_MUTE		  =0x0D,
	ECO_MU_PROF_FD	  =0x0E,
	ECO_MU_PROF_NS	  =0x0F,
	ECO_MU_PROF_SSC	  =0x10,
	ECO_INSTABDETECT  =0x11,
	ECO_SUPDEC		  =0x12,
	ECO_SLOW		  =0x13,
	ECO_DTDT		  =0x14,
	ECO_NLPTHR		  =0x15,
	ECO_MU			  =0x16,
	ECO_GAIN		  =0x17,
	ECO_REG_READ	  =0x18,
	ECO_REG_WRITE	  =0x19,
	ECO_RST_DEFAULT	  =0x1A
};

enum {
	SIN = 0,
	SOUT,
	RIN,
	ROUT
};

//defines de TAPS
enum {
	ECHO_TAPS_16 = 0,
	ECHO_TAPS_32 = 1,
	ECHO_TAPS_64 = 2,
	ECHO_TAPS_128 = 3,
	ECHO_TAPS_256 = 4,
	ECHO_TAPS_512 = 5,
	ECHO_TAPS_1024 = 6
};

//definition of echo types
enum {
	ECHO_HW_DSP = 0,
	ECHO_SW_LEC = 1
};

#endif


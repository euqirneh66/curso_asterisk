
/************************************************************************************
 *                                                                         			*
 *   VoicerLib - Windows/Linux Version                                     			*
 *                                                                          		*
 *   Copyright (c) 2004-2010 Digivoice Tecnologia em Eletronica Ltda     			*
 *                                                                         			*
 *   Module: E1 protocol                                                            *
 *                                                                         			*
 *   Description: Implements R2 and MF protocol                                     *
 *                                                                         			*
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                         			*
 *   This library is free software; you can redistribute it and/or					*
 *   modify it under the terms of the GNU Lesser General Public						*
 *   License as published by the Free Software Foundation; either					*
 *   version 2.1 of the License, or (at your option) any later version.				*
 *   																				*
 *   This library is distributed in the hope that it will be useful,				*
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of					*
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU				*
 *   Lesser General Public License for more details.								*
 *   																				*
 *   You should have received a copy of the GNU Lesser General Public				*
 *   License along with this library; if not, write to the Free Software			*
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *  
 *           																		*
 ************************************************************************************/

#include "voicerlib.h"

#include "e1.h"

#ifdef __LINUX__
	#include <assert.h>
	#include <unistd.h>
	#include <stdarg.h>
	#include <stdlib.h>
	#include <stdio.h>
	#include <string.h>
#endif

#ifdef __LINUX__
	extern void write_debug(char *fmt, ...);
#endif

//extern DIGIVOICE_CRITICAL_SECTION mtx_insert_to_e1;

int set_e1_timeout(int port, int t);

#ifdef WIN32

	#ifdef _DEBUG
	//------------------------------------------------------------------------
	// inline function - write to log file: e1-(port).log
	//------------------------------------------------------------------------
	__forceinline int __cdecl write_debug_e1(short port,const char *s, ...)
	{
		FILE *pdebug;
		time_t curSecs;
		struct tm *now_dbg;
		char szTemp[200];
		char szFileName[200];
		va_list argp;
		int retval=0;

		//if (port < 30 || port > 42) return 0;

		curSecs = time(NULL);
		now_dbg = localtime(&curSecs);
		sprintf(szTemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);

	    va_start(argp, s);
		sprintf(szFileName,"c:\\log\\e1-%d.log",port);
		pdebug=fopen(szFileName,"a+");
		if (pdebug!=NULL)
		{
			fprintf(pdebug,"%s-",szTemp);
			retval = vfprintf( pdebug, s, argp);
			fprintf(pdebug,"\n");
	        //let somebody else do the work
			fclose(pdebug);
		}
		va_end(argp);

		return retval;
	}
	#else
	__forceinline void __cdecl write_debug_e1(short port,const char *s, ...)
	{
	}
	#endif
#else
	//LINUX

	#ifdef DEBUG
		void write_debug_e1(short port,char *fmt, ...)
		{

			va_list argptr;
			int     ret;
			FILE    *f;
			time_t curSecs;
			struct tm *now_dbg;
			char szdbgtemp[200];
			char szFileName[200];

			curSecs = time(NULL);				\
			now_dbg = localtime(&curSecs);	\
			sprintf(szdbgtemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);						\

			va_start(argptr, fmt);
			sprintf(szFileName,"/var/log/voicerlib/e1-%d.log",port);
			f = fopen(szFileName, "a+");
			fprintf(f,"%s-",szdbgtemp);
			ret = vfprintf(f,fmt,argptr);
			fprintf(f,"\n");
			fclose(f);
			assert(ret != 0);

			va_end(argptr);
		}
	#else

		void write_debug_e1(short port,char *fmt, ...)
		{
		}
	#endif

#endif	//win32



//------------------------------------------------------------------------
// inline function to end a call and set as free
//------------------------------------------------------------------------
__forceinline int __cdecl termina_libera(short port, short end_call, int *mfc_step, int *r2_step)
{
	digivoice_entercriticalsection(&port_mutex[port-1], port);
		dg_GenerateMF (port, GENERATE_OFF, 0);
		dg_SetDetectionType(port, DETECT_ALL_MF, DG_DISABLE);
        //disables fast detection
        dg_SetFastDetection(port,DG_DISABLE);
		// releases port
		dg_SendR2Command(port, R2_IDLE);
		if (end_call)
        {
            write_debug_e1(port,"r2: (%d) termina_libera - enviando C_ENDCALL",port);
			dg_InsertE1Fifo(port,C_ENDCALL,0);
        }
	digivoice_leavecriticalsection(&port_mutex[port-1], port);

	set_e1_timeout(port,0);
	*mfc_step=P_MFC_REPOUSO;
	*r2_step=P_R2_LIVRE;

	return 0;
}

//------------------------------------------------------------------------
// inline function to end a call and wait till called line is free
//------------------------------------------------------------------------
__forceinline int __cdecl termina_aguarda_libera(short port, short end_call, int *mfc_step, int *r2_step)
{
	digivoice_entercriticalsection(&port_mutex[port-1], port);
		dg_GenerateMF (port, GENERATE_OFF, 0);
		dg_SetDetectionType(port,DETECT_ALL_MF,DG_DISABLE);
		// libera canal
		dg_SendR2Command(port, R2_IDLE);
		if (end_call)
			dg_InsertE1Fifo(port,C_ENDCALL,0);

		//chama habilita pra receber novamente o R2
		dg_SendR2Command(port,R2_ENABLE);

	digivoice_leavecriticalsection(&port_mutex[port-1], port);
	set_e1_timeout(port,0);
	*mfc_step=P_MFC_REPOUSO;
	*r2_step=P_R2_AGUARDA_LIVRE;

	return 0;
}

//------------------------------------------------------------------------
// function to set a port timeout
//------------------------------------------------------------------------
int set_e1_timeout(int port, int t)
{
 int ret;
 digivoice_entercriticalsection(&port_mutex[port-1], port);
 	tmr_E1[port-1].Enabled = FALSE;
 	SetEnableTimer(&tmr_E1[port-1],FALSE);
 	tmr_E1[port-1].Interval = t / FACTOR_TIMER;

 	if (t!=0)
 	{
		ret = (int)SetEnableTimer(&tmr_E1[port-1],TRUE);
		tmr_E1[port-1].Enabled = TRUE;
 	}
 	else
		ret = -1;

 digivoice_leavecriticalsection(&port_mutex[port-1], port);
 write_debug_e1(port,"SetTimeout handle %d com tempo %d",ret,t);
 return ret;
}

//------------------------------------------------------------------------
// Thread function to signal in E1 cards
//------------------------------------------------------------------------
void Signal_E1_Thread(void *signal_e1_info)
{
 dg_signal_e1_thread_structure *e1;
 dg_event_data_structure 	e1_events;

#ifdef __LINUX__
 int fifo_rx;
 int fifo_to_ctrl;
#else
 HANDLE fifo_rx;
 u32 cbBytesRead;
#endif

 int r2_step=P_R2_LIVRE;
 int mfc_step=P_MFC_REPOUSO;

 char tx_digits[NUMBER_SIZE];
 unsigned short tx_number_of_digits=0;

 int line_state=OFF;
 int retencao=OFF;
 int pulsado=OFF;
 int a5=OFF;
 int blocked_event=0;

 int rx_count=0;
 int tx_count=0;
 int id_count=0;

// int recebe=OFF;
 int grupo_a=0;
 int grupo_b=0;
 int grupo_c=0;
 int grupo_i=0;
 int grupo_ii=0;

 short end_action = EA_NONE;		//flag indicando que gera

 int entrante=0;

 int timeout=0;
 int tmr_h;
 int tmr_ha=0;  //timeout de atendimento

 int trata_r2=0;
 int trata_mfc=0;

 int a3_pulsado=0;

 int pickup_after_mfc_fim = 0;

 short card;

 int r2i,r2o,mfci/*=CP_SILENCE */,mfco;

 int cid_received = 0;

 e1 = (dg_signal_e1_thread_structure *)signal_e1_info;


 // enable E1 channel
 r2i=R2_IDLE;
 r2o=dg_SendR2Command(e1->port, R2_IDLE);
 digivoice_sleep(500);

 r2o=dg_SendR2Command(e1->port, R2_BLOCKED);
 digivoice_sleep(1000);

 r2o=dg_SendR2Command(e1->port, R2_IDLE);

 dg_SetDetectionType (e1->port, DETECT_ALL_MF,DG_DISABLE);
 mfco=dg_GenerateMF (e1->port, GENERATE_OFF, 0);

#ifdef __LINUX__
 fifo_rx = open(e1->szFifoToE1,O_RDONLY);
 if (fifo_rx==0)
 {
		//nao conseguiu abrir a fifo
		write_debug_e1(e1->port,"Error openning fifo....");
 }
#endif


#ifdef WIN32
	fifo_rx	= CreateFile(e1->szFifoToE1, GENERIC_READ | GENERIC_WRITE,
							0,	NULL, OPEN_EXISTING, 0,NULL);
#endif

	e1->enabled = 1;
 
	/* R2 group A backward signals */
 	e1->a_1  = MFC_A_1;
 	e1->a_2  = MFC_A_2;
 	e1->a_3  = MFC_A_3;
 	e1->a_4  = MFC_A_4;
 	e1->a_5  = MFC_A_5;
 	e1->a_6  = MFC_A_6;
 	e1->a_7  = MFC_A_7;
 	e1->a_8  = MFC_A_8;
 	e1->a_9  = MFC_A_9;
 	e1->a_10 = MFC_A_10;
 	e1->a_11 = MFC_A_11;
 	e1->a_12 = MFC_A_12;
 	e1->a_13 = MFC_A_13;
 	e1->a_14 = MFC_A_14;
 	e1->a_15 = MFC_A_15;
 	
 	/* R2 group B backward signals */
 	e1->b_1  = MFC_B_1;
 	e1->b_2  = MFC_B_2;
 	e1->b_3  = MFC_B_3;
 	e1->b_4  = MFC_B_4;
 	e1->b_5  = MFC_B_5;
 	e1->b_6  = MFC_B_6;
 	e1->b_7  = MFC_B_7;
 	e1->b_8  = MFC_B_8;
 	e1->b_9  = MFC_B_9;
 	e1->b_10 = MFC_B_10;
 	e1->b_11 = MFC_B_11;
 	e1->b_12 = MFC_B_12;
 	e1->b_13 = MFC_B_13;
 	e1->b_14 = MFC_B_14;
 	e1->b_15 = MFC_B_15;
 	
 	/* R2 group C backward signals - MEXICO */ 	
 	e1->c_1  = MFC_C_1;
 	e1->c_2  = MFC_C_2;
 	e1->c_3  = MFC_C_3;
 	e1->c_4  = MFC_C_4;
 	e1->c_5  = MFC_C_5;
 	e1->c_6  = MFC_C_6;
 	e1->c_7  = MFC_C_7;
 	e1->c_8  = MFC_C_8;
 	e1->c_9  = MFC_C_9;
 	e1->c_10 = MFC_C_10;
 	e1->c_11 = MFC_C_11;
 	e1->c_12 = MFC_C_12;
 	e1->c_13 = MFC_C_13;
 	e1->c_14 = MFC_C_14;
 	e1->c_15 = MFC_C_15; 	
 	
 	switch (e1->r2_country)
	{
		case R2_COUNTRY_BR:			
			write_debug_e1(e1->port, "r2_country = R2_COUNTRY_BR");			

			/* R2 group A backward signals */
			e1->a_send_next                     = MFC_A_1;
			e1->a_dnis_again                    = MFC_A_2;
			e1->a_send_cat_prepare_group_b      = MFC_A_3;
			e1->a_congestion                    = MFC_A_4;
			e1->a_send_cat_and_callerid         = MFC_A_5;
			e1->a_send_dnis_nm2                 = MFC_A_7;
			e1->a_send_dnis_nm3                 = MFC_A_8;
			e1->a_send_dnis_nm1                 = MFC_A_9;
			e1->a_address_complete_charge_setup = MFC_A_10;

		 	/* R2 group B backward signals */
		 	e1->b_free_calling        = MFC_B_1;
		 	e1->b_busy                = MFC_B_2;
		 	e1->b_number_changed      = MFC_B_3;
		 	e1->b_congestion          = MFC_B_4;
		 	e1->b_free_withoutbilling = MFC_B_5;
		 	e1->b_collectcall         = MFC_B_6;
		 	e1->b_number_unknown      = MFC_B_7;
		 	e1->b_out_of_service      = MFC_B_8;

		 	e1->group_i_end_of_ani = 15;

			break;
		case R2_COUNTRY_AR:
			write_debug_e1(e1->port, "r2_country = R2_COUNTRY_AR");

			/* R2 group A backward signals */
			e1->a_send_next                     = MFC_A_1;
			e1->a_dnis_again                    = MFC_A_10;
			e1->a_send_cat_prepare_group_b      = MFC_A_3;
			e1->a_congestion                    = MFC_A_4;
			e1->a_send_cat_and_callerid         = MFC_A_5;
			e1->a_send_dnis_nm2                 = MFC_A_7;
			e1->a_send_dnis_nm3                 = MFC_A_8;
			e1->a_send_dnis_nm1                 = MFC_A_2;//MFC_A_9;
			e1->a_address_complete_charge_setup = MFC_A_6;

		 	/* R2 group B backward signals */
		 	e1->b_free_calling        = MFC_B_6;
		 	e1->b_busy                = MFC_B_3;
		 	e1->b_number_changed      = MFC_B_1;
		 	e1->b_congestion          = MFC_B_4;
		 	e1->b_free_withoutbilling = MFC_B_7;
		 	e1->b_collectcall         = MFC_B_2;
		 	e1->b_number_unknown      = MFC_B_5;
		 	e1->b_out_of_service      = MFC_B_8;

		 	e1->group_i_end_of_ani = 12;
			
			break;			
		case R2_COUNTRY_MX:
			write_debug_e1(e1->port, "r2_country = R2_COUNTRY_MX");

			grupo_c = 1;

			/* R2 group A backward signals */
			e1->a_send_next                     = MFC_A_1;
			e1->a_dnis_again                    = MFC_A_2;
			e1->a_send_cat_prepare_group_b      = MFC_A_3;
			e1->a_congestion                    = MFC_A_4;
			e1->a_send_cat_and_callerid         = MFC_A_5;
			e1->a_send_dnis_nm2                 = MFC_A_7;
			e1->a_send_dnis_nm3                 = MFC_A_8;
			e1->a_send_dnis_nm1                 = MFC_A_9;
			e1->a_address_complete_charge_setup = MFC_A_10;

		 	/* R2 group B backward signals */
		 	e1->b_free_calling        = MFC_B_1;
		 	e1->b_busy                = MFC_B_2;
		 	e1->b_number_changed      = MFC_B_3;
		 	e1->b_congestion          = MFC_B_4;
		 	e1->b_free_withoutbilling = MFC_B_5;
		 	e1->b_collectcall         = MFC_B_6;
		 	e1->b_number_unknown      = MFC_B_7;
		 	e1->b_out_of_service      = MFC_B_8;
		 	
		 	/* R2 group C backward signals - MEXICO */
		 	e1->c_send_next_ani					 = MFC_C_1;
		 	e1->c_dnis_again_prepare_group_a	 = MFC_C_2;
		 	e1->c_send_cat_prepare_group_b		 = MFC_C_3;
		 	e1->c_send_next_dnis_prepare_group_a = MFC_C_5;
		 	e1->c_send_dnis_nm1_prepare_group_a	 = MFC_C_6;

		 	e1->group_i_end_of_ani = 15;
		 	  
			break;
		default:
			write_debug_e1(e1->port, "r2_country = R2_COUNTRY_BR (case default)");

			/* R2 group A backward signals */
			e1->a_send_next                     = MFC_A_1;
			e1->a_dnis_again                    = MFC_A_2;
			e1->a_send_cat_prepare_group_b      = MFC_A_3;
			e1->a_congestion                    = MFC_A_4;
			e1->a_send_cat_and_callerid         = MFC_A_5;
			e1->a_send_dnis_nm2                 = MFC_A_7;
			e1->a_send_dnis_nm3                 = MFC_A_8;
			e1->a_send_dnis_nm1                 = MFC_A_9;
			e1->a_address_complete_charge_setup = MFC_A_10;

		 	/* R2 group B backward signals */
		 	e1->b_free_calling        = MFC_B_1;
		 	e1->b_busy                = MFC_B_2;
		 	e1->b_number_changed      = MFC_B_3;
		 	e1->b_congestion          = MFC_B_4;
		 	e1->b_free_withoutbilling = MFC_B_5;
		 	e1->b_collectcall         = MFC_B_6;
		 	e1->b_number_unknown      = MFC_B_7;
		 	e1->b_out_of_service      = MFC_B_8;

		 	e1->group_i_end_of_ani = 15;

			break;
	} //switch (e1->r2_country)	
	
 	while(1)
 	{

   //retirar e tratar um evento da fifo
#ifdef __LINUX__
	 //write_debug_e1(e1->port,"E1Event (%d): Waiting event...",e1->port);
	 read(fifo_rx,&e1_events,sizeof(e1_events));
	 //write_debug_e1(e1->port,"E1Event (%d): Receiving cmd: %x - data: %x",e1->port,e1_events.command,e1_events.data );
     //write_debug("---- E1Event (%d): Receiving cmd: %x - data: %x",e1->port,e1_events.command,e1_events.data );
#else
	//windows
	 WaitForSingleObject(e1->oOverlapE1.hEvent,INFINITE);
	 ReadFile(fifo_rx,        // handle to pipe
				&e1_events,    // buffer to receive data
				sizeof(e1_events),      // size of buffer
				&cbBytesRead, // number of bytes read
				&e1->oOverlapE1);        // not overlapped I/O

	//write_debug_e1(e1->port,"E1Event (%d): Receiving event %x - cmd: %x - data: %x",e1->port,e1->E1Event.hEvent,e1_events.command,e1_events.data );
#endif
	//reset values
	timeout = 0;

	trata_r2=0;
	trata_mfc=0;

	 //terminates thread
	 if (e1_events.command == C_ENDTHREAD)
	 {
	 		//cancel thread execution
			write_debug_e1(e1->port,"Finalizing E1 thread...");
			break;
	 }


	 switch(e1_events.command)
	 {
			case C_CAS:
				//dado R2 tem q ser filtrado so para pegar o R2
				r2i = (e1_events.data | 0x1) & 0xd;
                write_debug(">>r2                                                                                                   %x",r2i);
				trata_r2=1;
				break;
			case C_AUDIO:				//digits or silence
				mfci = e1_events.data;
				//write_debug_e1(e1->port,"Receiving MF signal -----------------------------------------------------------------> %x", mfci);
                write_debug(">>mf                                                                                               %x",mfci);
				trata_mfc=1;
				break;

			case C_RESET_THREAD:
				//reseta os estados da thread
				write_debug_e1(e1->port,"E1 RESET");
				entrante=0;
				line_state = OFF;
				r2i=R2_IDLE;
				r2_step = P_R2_LIVRE;
				mfc_step = P_MFC_REPOUSO;
				tmr_h=set_e1_timeout(e1->port,0);/*aaa*/
				if (e1->bAtendido != OFF)
				{
					RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
					RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
				}
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
					trata_r2=0;
					trata_mfc=0;
					e1->bAtendido = OFF;
					tmrRing[e1->port-1].Enabled = FALSE;
					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				break;
			case C_END_MF:
				//evento gerado no termino do mfc para prever situacoes de atendimento
				//antes da deteccao do silencio do ultimo mf
				trata_r2=1;
				break;
			case C_CALLPROGRESS:
				if (!e1->bAtendido)
				{
//					RaiseEvents_ThreadSafe(EV_CALLING, 0, e1_events.port,&port_mutex[e1->port-1]);
					//reenables it
					tmrCallProgress[e1_events.port-1].Interval = 5000 / FACTOR_TIMER;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],TRUE);
					tmrCallProgress[e1_events.port-1].Enabled = TRUE;
				}
				else
				{
					//desables it
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
				}
				break;
			case C_RING:
				if (e1->ring_event==1)
				{
                                   if (e1->ring_generate_ringback)
                                      dg_GenerateMF(e1->port,GENERATE_TONE1,0);

                                   e1->ring_event=0;
				   tmrRing[e1->port-1].Interval = 1000 / FACTOR_TIMER;
				   SetEnableTimer(&tmrRing[e1->port-1],TRUE);
				   tmrRing[e1->port-1].Enabled = TRUE;
				   write_debug_e1(e1->port,"e1: RING ON");
				}
				else
				{
					//desliga ring
                                   if (e1->ring_generate_ringback)
                                      dg_GenerateMF(e1->port,GENERATE_OFF,0);

                                   tmrRing[e1->port-1].Interval = 4000 / FACTOR_TIMER;
				   SetEnableTimer(&tmrRing[e1->port-1],TRUE);
				   tmrRing[e1->port-1].Enabled = TRUE;
				   e1->ring_event=1;
                                   RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, e1_events.port,&port_mutex[e1->port-1]);
					write_debug_e1(e1->port,"e1: RING OFF");
				}
				break;
			case CPICKUP:
				write_debug_e1(e1->port,"e1 (%d): Pickup - mfc_Step=%d",e1_events.port,mfc_step);
				if (mfc_step==P_MFC_REPOUSO)
				{
					//cancela geracao de tons
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					//chama habilita pra receber novamente o R2
					dg_SendR2Command(e1->port,R2_ENABLE);

					//cancela ring
					//cancela timer do chamando
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
					if (entrante==1)
					{
                                                //disables fast detection
                                                dg_SetFastDetection(e1->port,DG_DISABLE);

						dg_GenerateMF(e1_events.port,GENERATE_OFF,0);
						//seta limiar de silencio para usar durante conversa�o
						dg_SetSilenceThreshold(e1_events.port, (short)e1->silence_threshold_after_signaling);
					}
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					write_debug_e1(e1->port,"e1 (%d): Pickup - entrante==%d",e1_events.port,entrante);
					line_state = ON;	//r2 state-machine
					trata_r2=1;
					end_action = EA_NONE;
					pickup_after_mfc_fim = 0;
				}
				else
				{
					write_debug_e1(e1->port,"e1 (%d): Pickup atrasado para o fim ",e1_events.port);
					pickup_after_mfc_fim = 1;
				}
				break;
			case CHANGUP:
				write_debug_e1(e1->port,"(%d)ctrl: Hangup com entrante=%d e r2i=%d",e1_events.port,entrante,r2i);
				//cancela geracao de tons
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					//cancela ring
					e1->ring_event = 99;
					//desliga timers de RING ou CallProgress
					tmrRing[e1->port-1].Enabled = FALSE;
					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				if(r2i!=R2_IDLE)
				{
					RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
					//termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
					set_e1_timeout(e1->port,0);/*aaa*/
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						dg_GenerateMF (e1->port, GENERATE_OFF, 0);
						dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
                                        //disables fast detection
                                        dg_SetFastDetection(e1->port,DG_DISABLE);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					// libera canal
					if (entrante==1 && r2_step==P_R2_ATENDIDO_ENTRANTE)
					{
						write_debug_e1(e1->port,"e1: Hangup Entrante - Desliga pra tras");
					//	dg_SendR2Command(e1->port, R2_CLEAR_BACK);
					}
					else
					{
						write_debug_e1(e1->port,"e1: Hangup Sainte - Manda livre");
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						dg_SendR2Command(e1->port, R2_IDLE);
						r2_step=P_R2_AGUARDA_LIVRE;
						mfc_step=P_MFC_REPOUSO;
						//chama habilita pra receber novamente o R2
						dg_SendR2Command(e1->port,R2_ENABLE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					}
				}
				else
				{
					termina_libera(e1->port,0,&mfc_step, &r2_step);
				}
				entrante = 0;
				line_state = OFF;
				trata_r2=1;
				e1->bAtendido = OFF;
				end_action = EA_NONE;
				break;
			case C_ENDCALL:
//..				trata_r2=0;
    				e1->bAtendido = OFF;
    				write_debug_e1(e1->port,"(%d) ctrl: Ligacao Finalizada",e1_events.port);
    				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
    					//desabilita timer de ligacao sainte
    					tmrCallProgress[e1_events.port-1].Enabled = FALSE;
    					SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
    					//cancela geracao de tons
    					e1->ring_event = 0;
    					tmrRing[e1->port-1].Enabled = FALSE;
    					SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
    				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

    				//chama funcao que libera tudo - com timeout
    				termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
    				tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);

                                //disables fast detection
                                dg_SetFastDetection(e1->port,DG_DISABLE);


    				RaiseEvents_ThreadSafe(EV_LINEOFF, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
    				RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
    				end_action = EA_NONE;

				break;
			case C_SEIZURE:
				a3_pulsado=0;
				trata_r2=1;
				break;
			case CDISCA_TOM:
				//In MF signals, digit 0 is digit "A"
				if (e1_events.data==0)
					e1_events.data=0xa;

				tx_digits[tx_number_of_digits]= (char)e1_events.data;
				if (tx_number_of_digits<NUMBER_SIZE)
					tx_number_of_digits++;

				write_debug_e1(e1->port,"r2: * C_DIAL -> %d! - %d",e1_events.data,tx_number_of_digits);
				trata_mfc = 1;
				break;
			//4.0.6
			case C_WAITFORDIGITS:			
				if ((grupo_c) && (cid_received))
				{
					cid_received=0;
					grupo_a = e1->c_send_next_dnis_prepare_group_a;//C_SEND_NEXT_DNIS_PREPARE_GROUP_A;					
				}
                else
					grupo_a = e1->a_send_next;//A_SEND_NEXT;	

				trata_mfc=1;
				break;
			case C_PREP_RX_GRUPO_II:
				write_debug_e1(e1->port,"(%d) --- ctrl: C_PREP_RX_GRUPO_II",e1_events.port);
				grupo_a=3;
				trata_mfc=1;

				//SE FOR PULSADO  muda estado mfc_step
				if (e1_events.data && mfc_step==P_MFC_RECEBE_DIGITO)
				{
					a3_pulsado=1;
					set_e1_timeout(e1->port,0);
					mfc_step=P_MFC_A3_PULSADO;
					//seta timeout de 100ms antes de gerar o A3 pulsado
					tmr_h = set_e1_timeout(e1->port,100);
				}
				break;
			//recebe finalizacao de ligacao
			case C_NUMBER_RECEIVED:
				//recebeu os numeros iniciais, entao pode pedir mais a=1 ou
				//a identificacao a=5
				write_debug_e1(e1->port,"(%d) --- ctrl: C_NUMBER_RECEIVED",e1_events.port);
/*
				//tratamento automatico
				if (e1->rx_total_of_digits > 0)
				{
					if ((e1->rx_total_remaining > 0) && (e1->send_id_digit_pos > 0) )
						grupo_a=5;
					else
						if (e1->rx_total_remaining == 0) //pede categoria
							grupo_a=3;

				}
				trata_mfc=1;

				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NUMBER_RECEIVED, e1_events.port,&port_mutex[e1->port-1]);
				*/
				break;

			case C_ID_RECEIVED:
				//e1 preencheu a propriedade com os digitos de identificacao
				write_debug_e1(e1->port,"(%d) ******** ctrl: C_ID_RECEIVED",e1_events.port);
				//tratamento automatico, se houver
/*
				if (e1->rx_total_remaining > 0)
				{
					e1->rx_number_of_digits = e1->rx_total_remaining;
					e1->rx_total_remaining = 0;
					write_debug_e1(e1->port,"(%d) r2: Recebeu que deve esperar %d digitos",e1_events.port, e1->rx_number_of_digits);
					rx_count = 0;
					grupo_a=1;
				}
				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_ID_RECEIVED, e1_events.port,&port_mutex[e1->port-1]);
				RaiseEvents_ThreadSafe(EV_CALLERID, e1->rx_id_number_of_digits , e1_events.port,&port_mutex[e1->port-1]);
				trata_mfc=1;
				*/
				break;
			case C_GROUP_II:
				//envia o grupo B
				//tratamento automatico
				//comentado com ... para funcionar tanto no modo automatico como manual
				//...if (e1->rx_total_of_digits > 0)
				//...{
					//dg_InsertE1Fifo(e1_events.port,C_GRUPO_B,e1->group_b_id);
				//if (!a3_pulsado)
				grupo_b = e1->group_b_id;
				/*else
					grupo_b = 0; //espera aplicacao fornecer grupo B*/

				//...}
				write_debug_e1(e1->port,"(%d) ctrl: Recebeu categoria %d",e1_events.port,e1_events.data);
				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_GROUP_II,  0,e1_events.port,&port_mutex[e1->port-1]);
				trata_mfc=1;
				break;

			case C_SEND_GROUP_B:
				write_debug_e1(e1->port,"(%d) ctrl: Recebeu C_SEND_GROUP_B-%d - mfc_step=%x",e1_events.port,e1_events.data, mfc_step);
				if (mfc_step==P_MFC_ENVIA_GRUPO_B)
				{
					if (e1_events.data==0)
						grupo_b = e1->group_b_id;
					else
						grupo_b = e1_events.data;		//allow sending 1-ok, 2-busy, 4- congestion
					write_debug_e1(e1->port,"(%d) ctrl: Recebeu C_SEND_GROUP_B-%d",e1_events.port,grupo_b);
					//grupo_b = e1->group_b_id;
					trata_mfc=1;
				}
				break;
			//----------------------------------------------------
			//Comandos recebidos direto de algum ponto da aplicacao
			//----------------------------------------------------
                        case C_SEND_BACKWARD_SIGNAL:
                                write_debug_e1(e1->port,"r2: (%d) Recebeu custom MFT %x", e1_events.port, e1_events.data);
                                grupo_a=e1_events.data;
                                trata_mfc=1;
                        break;
			case C_ASK_FOR_ID:
				write_debug_e1(e1->port,"r2: (%d) Recebeu pedido de identificacao", e1_events.port);
				
				if (grupo_c)
					grupo_a= e1->a_6;//A_6;				
				else
					grupo_a= e1->a_send_cat_and_callerid;//A_SEND_CAT_AND_CALLERID;				
				
				trata_mfc=1; //4.0.6
				break;

			case C_TIMEOUT:	//recebido do timer
				timeout = (int) e1_events.data;
				write_debug_e1(e1->port,"e1 (%d): C_TIMEOUT com dado %d - r2i=%x r2step=%x mfci=%x mfc_step=%x",
        				e1->port,
        				timeout,
        				r2i,
        				r2_step,
        				mfci,
        				mfc_step
                 			 );
				//seta flag para tratar maquinas de estado
				trata_r2=1;
				trata_mfc=1;
				break;

			case C_GROUP_I:
				grupo_i = e1_events.data;
				write_debug_e1(e1->port,"r2: Vai enviar grupo_I no. %d",e1_events.data);
				break;
	 }



   /******************* trata sinalizacao de linha **********************/
   if (trata_r2)
   {
	  write_debug_e1(e1->port,"e1 (%d): r2i = %x   r2_step = %x",e1->port,r2i,r2_step);
	  switch (r2_step)
	  {
		case P_R2_AGUARDA_LIVRE:
			if (timeout!=tmr_h)
			{
				switch(r2i)
				{
					case R2_IDLE:
						entrante=0;
						RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_E1_IDLE,  0,e1->port,&port_mutex[e1->port-1]);
						r2_step=P_R2_LIVRE;
						blocked_event = 0;
                                                dg_SendR2Command(e1->port, R2_IDLE);
                                                //teste - tj
                                                tmr_h=set_e1_timeout(e1->port,0); //turnoff timer
                                                line_state = OFF;

						break;
					//se estiver bloqueado no aguarda_libera, gera o evento
					case R2_BLOCKED:
						if (line_state==ON)
						{
							if (blocked_event==0)
							{
								RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
								RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_UNAVAILABLE,  0,e1_events.port,&port_mutex[e1->port-1]);
								blocked_event = 1;
							}
							else
								blocked_event = 0;
						}
						break;

				}
			}
			else
			{
				//finaliza mandando bloqueio, aguardando 2 segundos e depois livre
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_BLOCKED);
					//chama habilita pra receber novamente o R2
					dg_SendR2Command(e1->port,R2_ENABLE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				digivoice_sleep(2000);

				termina_libera(e1->port,0,&mfc_step,&r2_step);
				line_state = OFF;
				//write_debug_e1(e1->port,"Sleep 2000 - por timeout P_R2_AGUARDA_LIVRE");
			}
		  break;
		case P_R2_LIVRE:
			switch(r2i)
			{
				case R2_IDLE:
					if (line_state==ON) //ligacao sainte
					{
						retencao=OFF; //controle do chamador

                                                //enables fast detection
                                                dg_SetFastDetection(e1->port,DG_ENABLE);


						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							mfco=dg_GenerateMF(e1->port, GENERATE_OFF, 0);
							r2o=dg_SendR2Command(e1->port, R2_SEIZURE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

						write_debug_e1(e1->port,"e1 (%d): Envia R2_SEIZURE e seta timeout de %d",e1->port,e1->timeout_ocupacao);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_ocupacao);//inicia timer - timeout 7s
						r2_step=P_R2_CONFIRMAOCUPACAO;
					}
					break;

				case R2_SEIZURE:  //ligacao entrante
					cid_received=0;
								
					grupo_a=0;
					//C_SEIZURE
					entrante = 1;
					e1->ring_event = 0;

                                        //Set detection type to FAST mode
                                        dg_SetFastDetection(e1->port,DG_ENABLE);
                                        //disable all detections
					dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
					//configura limiar de silencio para troca de sinalizacao
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						dg_SetSilenceThreshold(e1_events.port, (short)e1->silence_threshold_signaling);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

                                        //CODIGO do P_R2_ENVIA_CONFIRMACAO
                                        write_debug_e1(e1->port,"r2 (%d): NOVO P_R2_ENVIA_CONFIRMACAO - grupo_a %x",e1->port,grupo_a);

                                        //some pbx need some time to allow them to recognize seizure ack, then we'll wait 100ms here
                                        digivoice_sleep(20);    //changed to fit standards

                                        digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
                                                r2o=dg_SendR2Command(e1->port, R2_SEIZURE_ACK);
                                                //r2o=dg_SendR2Command(e1->port, R2_SEIZURE_ACK);
                                        digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);


					RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_SEIZURE,  0,e1_events.port,&port_mutex[e1->port-1]);

					//se > 0, o tratamento eh todo feito dentro das threads
					if (e1->rx_total_of_digits > 0)
					{
						//seta o numero inicial a receber, ate o digito indicado para comecar a enviar sinalizacao
						if (e1->send_id_digit_pos > 0)
							e1->rx_number_of_digits = e1->send_id_digit_pos;
						else
							e1->rx_number_of_digits = e1->rx_total_of_digits;
						//guarda os digitos que faltam
						e1->rx_total_remaining = e1->rx_total_of_digits - e1->rx_number_of_digits;
					}
					rx_count = 0;
					grupo_a=1;
					trata_r2=1;
					//write_debug_e1(e1->port,"(%d)e1: C_SEIZURE - Ligacao entrante",e1_events.port);
					//-------

					if (e1->rx_number_of_digits>0) // inicia sinalizacao entre registradores
					{
						//write_debug_e1(e1->port,"r2 (%d): P_R2_ENVIA_CONFIRMACAO - Vai pro MFC_ENTRANTE");
						rx_count=0;//zera contador de digitos recebidos
						e1->rx_complete_count=0;
						mfc_step=P_MFC_ENTRANTE;
						r2_step=P_R2_RECEBENDO_MFC;
						trata_mfc=1;
					}
					else //R2 sem sinalizacao entre registradores
					{
						// gerar envento FIM MFC
						write_debug_e1(e1->port,"r2 (%d): P_R2_ENVIA_CONFIRMACAO - SEM MFC ",e1->port);
						//..dg_insert_callctrl_fifo(e1->port,C_END_MF,0);
						mfc_step=P_MFC_REPOUSO;
						r2_step=P_R2_AGUARDA_ATENDIMENTO;
						//--- FINALIZACAO DE LIGACAO ----
						if (entrante==1)
						{
							//gera tom de chamada e evento de ring
							e1->ring_event = 0;

                                                        mfc_step=P_MFC_FIM;
                                                        trata_mfc++;
                                                        mfci=CP_SILENCE;
                                                        tmr_h=set_e1_timeout(e1->port,e1->timeout_atendimento);

							/*digivoice_entercriticalsection(&port_mutex[e1->port-1]);
								dg_GenerateMF(e1->port,GENERATE_TONE1,0);
								//primeira intera�o do timer de 1 segundo
								tmrRing[e1->port-1].Interval = 1000 / FACTOR_TIMER;
								SetEnableTimer(&tmrRing[e1->port-1],TRUE);
								tmrRing[e1->port-1].Enabled = TRUE;
							digivoice_leavecriticalsection(&port_mutex[e1->port-1]);
							//write_debug_e1(e1->port,"e1 (%d): GENERATE RING TONE em P_R2_ENVIA_CONFIRMACAO");
							RaiseEvents_ThreadSafe(EV_RINGS, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
                            */

						}
						else
						{
							//turn off status flag
							ports_info[e1->port-1].FStatusPort = spNone;							
							
							//Fires EV_AFTERDIAL - ligacao sainte
							RaiseEvents_ThreadSafe(EV_AFTERDIAL, 0,  0,e1->port,&port_mutex[e1->port-1]);
						}							
					}

					break;
				case R2_ANSWERED:
				case R2_BLOCKED:
					//TODO: Verificar como evitar de gerar duas vezes seguidas
					if (line_state==ON)
					{
						//para evitar situacoes de deadlock, neste caso
						//a thread manda pra frente um bloqueio, espera um pouco e manda um
						//livre
						//write_debug_e1(e1->port,"Sleep 2000 - por receber R2_BLOCKED");
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							r2o=dg_SendR2Command(e1->port, R2_BLOCKED);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						digivoice_sleep(2000);
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							r2o=dg_SendR2Command(e1->port, R2_IDLE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						// gerar evento NAO DISPONIVEL
  						//..dg_insert_callctrl_fifo(e1->port,C_UNAVAILABLE,0);
						if (blocked_event==0)
						{
							RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
							RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_UNAVAILABLE,  0,e1_events.port,&port_mutex[e1->port-1]);
							blocked_event = 1;
						}
						else
							blocked_event = 0;

					}
					break;
			}//switch
			break;

	/*******************  ligacao sainte **********************/


		case P_R2_CONFIRMAOCUPACAO: //ligacao sainte
			write_debug_e1(e1->port,"P_R2_CONFIRMAOCUPACAO - linestate=%d timeout=%d tmr_h=%d r2=%x",line_state,timeout,tmr_h,r2i);
			if (timeout==tmr_h)
			{
				// gera evento NAO DISPONIVEL - timeout
				//..dg_insert_callctrl_fifo(e1->port,C_UNAVAILABLE,0);
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				r2_step=P_R2_LIVRE;
				blocked_event = 0;
				line_state = OFF;
				write_debug_e1(e1->port,"P_R2_CONFIRMAOCUPACAO - ",EV_BUSY);
				RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
				//write_debug_e1(e1->port,"P_R2_CONFIRMAOCUPACAO - ",C_UNAVAILABLE);
				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_UNAVAILABLE,  0,e1_events.port,&port_mutex[e1->port-1]);
			}
			else
			{
				if (line_state==OFF)
				{
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_IDLE);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					r2_step=P_R2_LIVRE;
					blocked_event = 0;
				}
				else
				{
					switch(r2i)
					{

						case R2_IDLE:// nao acontece ja estava livre
							break;

						case R2_ANSWERED://nunca acontece
						case R2_SEIZURE:   //dupla ocupacao
							r2_step=P_R2_AGUARDA_LIVRE;
							tmr_h=set_e1_timeout(e1->port,0);

                                                        //sleeps 100ms to wait the other part is available to
                                                        //understand the new r2 status
                                                        digivoice_sleep(20);	//changed to fit standards

							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								tmrCallProgress[e1->port-1].Enabled = FALSE;
								SetEnableTimer(&tmrCallProgress[e1->port-1],FALSE);
								dg_SendR2Command(e1->port, R2_ENABLE);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							// gerar evento OCUPADO
							RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1->port,&port_mutex[e1->port-1]);

                                                        tmr_h=set_e1_timeout(e1->port,120000); //2min to wait
						break;
						case R2_SEIZURE_ACK:
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							tx_count=0; // zera contador de digitos
							RaiseEvents_ThreadSafe(EV_DIALTONE, 0,  0,e1->port,&port_mutex[e1->port-1]);
							RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_E1_SEIZURE_ACK,  0,e1_events.port,&port_mutex[e1->port-1]);
							write_debug_e1(e1->port,"e1: (%d) Origem recebeu confirmacao, vai para P_MFC_SAINTE",e1->port);
							// gerar evento LIVRE PARA DISCAR
							//configura limiar de silencio para troca de sinalizacao
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								dg_SetSilenceThreshold(e1_events.port, (short)e1->silence_threshold_signaling);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							//generate OnDialToneDetected
							trata_mfc=1;
							mfc_step=P_MFC_SAINTE;
							r2_step=P_R2_DISCANDO;
							//reset answer timeout
							tmr_ha = -1;

							break;
					}

				}
			}
			break;
		case P_R2_DISCANDO: //ligacao sainte

			//colacar timeout atendimento iniciado no MFC
			if (timeout != tmr_ha)
			{
				if (line_state==OFF)
				{
					// termina sinalizacao MFC
					//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off

					termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
					tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					write_debug_e1(e1->port,"e1: P_R2_DISCANDO - Liberou canal");
				}
				else
				{
					//write_debug_e1(e1->port,"e1: P_R2_DISCANDO - ELSE - VAI ACIONAR SWITCH");
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					write_debug_e1(e1->port,"e1: P_R2_DISCANDO - recebeu R2=%d",r2i);
					switch(r2i)
					{
						case R2_SEIZURE_ACK:   //trocando sinalizacao entre registradores
								//mf sendo tratado no switch MFC_SAINTE
								break;
						case R2_SEIZURE: // nao deve acontecer
								write_debug_e1(e1->port,"e1: P_R2_DISCANDO - Ocupacao Invalida!");

								termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
								tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
								//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off

								//eventos para a aplicacao
								RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NOTCOMPLETED,  0,e1->port,&port_mutex[e1->port-1]);
								RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1->port,&port_mutex[e1->port-1]);
								write_debug_e1(e1->port,"e1: C_NOTCOMPLETED - situacao 1");
								break;
						case R2_IDLE:
								//write_debug_e1(e1->port,"e1: P_R2_DISCANDO - R2_IDLE");
								// termina sinalizacao MFC
								termina_libera(e1->port,0,&mfc_step,&r2_step);
								// gerar evento LIGACAO NAO COMPLETADA
								RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NOTCOMPLETED,  0,e1->port,&port_mutex[e1->port-1]);
								RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1->port,&port_mutex[e1->port-1]);
								break;

						case R2_ANSWERED:
								write_debug_e1(e1->port,"e1: P_R2_DISCANDO - R2_ANSWERED com mfcstep=%x",mfc_step);
								if (mfc_step!=P_MFC_REPOUSO)//nao deve acontecer
								{

									if (mfc_step != P_MFC_FIM)
									{
										termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
										tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
										//eventos para a aplicacao
										RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NOTCOMPLETED,  0,e1->port,&port_mutex[e1->port-1]);
										RaiseEvents_ThreadSafe(EV_BUSY, 0,  0, e1->port,&port_mutex[e1->port-1]);
										write_debug_e1(e1->port,"e1: C_NOTCOMPLETED - situacao 3");
									}
									else
									{
										//atendimento durante o MFC_FIM, faz ir la e tratar
										mfci = 0x20;
										trata_mfc = 1;
									}
								}
								else
								{
									// gerar evento ATENDEU
									//..dg_insert_callctrl_fifo(e1->port,C_ANSWERED,0);
									e1->bAtendido = ON;  //muda flag para atendido

									digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
										tmrCallProgress[e1_events.port-1].Enabled = FALSE;
										SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
										//seta limiar de silencio para usar durante conversação
										dg_SetSilenceThreshold(e1_events.port, (short)e1->silence_threshold_after_signaling);
									digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

                                    //disables fast detection
                                    dg_SetFastDetection(e1->port,DG_DISABLE);

									//4.0.3 - generate this event too
									RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_ANSWERED,  0, e1->port,&port_mutex[e1->port-1]);

									RaiseEvents_ThreadSafe(EV_ANSWERED, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
									if (!entrante)
										RaiseEvents_ThreadSafe(EV_LINEREADY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
									//..........
									r2_step=P_R2_ATENDIDO_SAINTE;
									tmr_h=set_e1_timeout(e1->port,0);//disable timeout
								}
								break;
						}//switch r2
						write_debug_e1(e1->port,"e1: P_R2_DISCANDO - SAIU DO SWITCH com r2_step=%x",r2_step);
					}
			}
			else
			{
				//s�deve considerar timeout de atendimento na hora que tiver acabado
				//a discagem
				if (mfc_step==P_MFC_REPOUSO)
				{
					//answer timout
					write_debug_e1(e1->port,"e1: ANSWER TIMEOUT DURANTE P_R2_DISCANDO");

					// libera canal
					termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
					tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					//raise busy event
					RaiseEvents_ThreadSafe(EV_BUSY, 0,  0,e1_events.port,&port_mutex[e1->port-1]);
					RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NOTCOMPLETED, 0, e1->port,&port_mutex[e1->port-1]);
					write_debug_e1(e1->port,"e1: C_NOTCOMPLETED - situacao 4");
					line_state = OFF;
				}
				else
				{
					write_debug_e1(e1->port,"e1: P_R2_DISCANDO - Situacao sem tratamento - timeout=%d  tmr_ha=%d mfc_step=%x",timeout,tmr_ha,mfc_step);
				}
			}
			break;

		case P_R2_ATENDIDO_SAINTE: //ligacao sainte
			if(timeout != tmr_h) //teste de timeout de "desliga pra tras"
			{
				if (line_state==OFF)
				{
					write_debug_e1(e1->port,"ATENDIDO_SAINTE: line_state=off");
					e1->bAtendido = OFF;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_IDLE);
						dg_SendR2Command(e1->port, R2_ENABLE);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					r2_step=P_R2_AGUARDA_LIVRE;
					tmr_h=set_e1_timeout(e1->port,0);  //timer off
				}
				else
				{
					write_debug_e1(e1->port,"ATENDIDO_SAINTE: r2i=%d",r2i);
					switch(r2i)
					{
						case R2_CLEAR_BACK:
							if (retencao==ON)//controle do assinante chamado
							{
								digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
									r2o=dg_SendR2Command(e1->port, R2_IDLE);
									dg_SendR2Command(e1->port, R2_ENABLE);
									dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
								digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
								r2_step=P_R2_AGUARDA_LIVRE;
								// gerar evento LIGACAO ENCERRADA

								line_state = OFF;
							}
							else
							{
								//inicia timer - timeout 90s
								write_debug_e1(e1->port,"ATENDIDO_SAINTE: timer de retencao - tmr_h = %d",tmr_h);
								if (tmr_h==-1)
								{
									tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao);
									// gerar evento B DESLIGOU
									RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_B_ENDCALL,  0, e1->port,&port_mutex[e1->port-1]);
								}
							}
							break;
						case R2_ANSWERED:
							/* Retornou */
							tmr_h=set_e1_timeout(e1->port,0);
							RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_ANSWERED,  0, e1->port,&port_mutex[e1->port-1]);

							break;
						case R2_BACKWARD_DISCONNECTION:
						case R2_IDLE:
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							// libera canal
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								// gerar evento LIGACAO ENCERRADA
								dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

							r2_step=P_R2_LIVRE;
							line_state = OFF;
							blocked_event = 0;

							break;

					}
				}
			}
			else
			{
				//timeout de desliga pra tras
				// libera canal
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);

					r2o=dg_SendR2Command(e1->port, R2_IDLE);
					dg_SendR2Command(e1->port, R2_ENABLE);
					// gerar evento LIGACAO ENCERRADA
					dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				r2_step=P_R2_AGUARDA_LIVRE;
				line_state = OFF;
			}
			break;
		case P_R2_RECEBENDO_MFC: //ligacao entrante
		case P_R2_AGUARDA_ATENDIMENTO: //ligacao entrante
			write_debug_e1(e1->port,"e1: (%d) P_R2_RECEBENDO_MFC",e1->port);

			if (line_state==ON)
			{
				write_debug_e1(e1->port,"e1: (%d) P_R2_RECEBENDO_MFC - line_state=ON",e1->port);
				if (mfc_step!=P_MFC_REPOUSO)
				{
					//nao deve acontecer, aplicacao ja sabe que esta entrando ligacao
					// gerar evento RECEBENDO ????
					//.......
					write_debug_e1(e1->port,"e1 (%d): P_R2_RECEBENDO_MFC - <> REPOUSO",e1->port);
				}
				else
				{
					//write_debug_e1(e1->port,"e1: (%d) P_R2_RECEBENDO_MFC = mfc_step=%x",e1->port,mfc_step);
					e1->bAtendido = ON;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						//cancela ring
						e1->ring_event = 99;
						dg_GenerateMF(e1->port,GENERATE_OFF,0);
						tmrRing[e1->port-1].Enabled = FALSE;
						SetEnableTimer(&tmrRing[e1->port-1],FALSE);
						write_debug_e1(e1->port,"e1: DESLIGANDO RING NO P_R2_AGUARDA_ATENDIMENTO");

						r2o=dg_SendR2Command(e1->port, R2_ANSWERED);

					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

					if (e1->ddc==ON)
					{
						r2_step=P_R2_BLOQUEIO_DDC;

						//inicia timer 1s
						tmr_h=set_e1_timeout(e1->port,e1->timeout_bloqueio_on);
					}
					else
					{
               			r2_step=P_R2_ATENDIDO_ENTRANTE;
					}
				}
			}
			else
			{
				switch(r2i)
				{
					case R2_FAILURE:
						write_debug_e1(e1->port,"r2: (%d) R2_FAILURE DURANTE MFC - enviando C_ENDCALL",e1->port);
					case R2_ANSWERED://nao deve acontecer
						write_debug_e1(e1->port,"r2: (%d) R2_AT DURANTE MFC - enviando C_ENDCALL",e1->port);
						// termina sinalizacao MFC
						termina_aguarda_libera(e1->port,1,&mfc_step, &r2_step);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
						// gerar evento LIGACAO ENCERRADA
						write_debug_e1(e1->port,"r2: (%d) R2_OC DURANTE MFC - enviando C_ENDCALL",e1->port);
						break;
					case R2_SEIZURE:
						break;

					case R2_IDLE:
						// termina sinalizacao MFC
						termina_libera(e1->port,0,&mfc_step,&r2_step);
						line_state = OFF;

						tmr_h=set_e1_timeout(e1->port,0);  //timer off
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							dg_GenerateMF (e1->port, GENERATE_OFF, 0);
							dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
							// libera canal
							r2o=dg_SendR2Command(e1->port, R2_IDLE);
							dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

						mfc_step=P_MFC_REPOUSO;
						r2_step=P_R2_LIVRE;
						blocked_event = 0;
						// gerar evento LIGACAO ENCERRADA
						write_debug_e1(e1->port,"r2: (%d) R2_IDLE- enviando C_ENDCALL",e1->port);
						line_state = OFF;
						break;
				}

			}
			break;
		case P_R2_BLOQUEIO_DDC:
			if (timeout==tmr_h)
			{
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				//inicia timer 2s
				tmr_h=set_e1_timeout(e1->port,e1->timeout_bloqueio_off);
				r2_step=P_R2_BLOQUEANDO_DDC;
			}
			else
			{
				if (line_state==OFF)
				{
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					r2_step=P_R2_ATENDIDO_ENTRANTE;
				}
				else
				{
					switch(r2i)
					{
						case R2_FAILURE:
						case R2_ANSWERED://nao deve acontecer
							// termina sinalizacao MFC
							//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off
							termina_aguarda_libera(e1->port,1,&mfc_step, &r2_step);
							tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);

							//.......
							line_state = OFF;
							break;
						case R2_SEIZURE:
							break;
						case R2_IDLE:
							// termina sinalizacao MFC
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								dg_GenerateMF (e1->port, GENERATE_OFF, 0);
								dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
								// libera canal
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								// gerar evento LIGACAO ENCERRADA
								dg_InsertE1Fifo(e1->port,C_ENDCALL,0);

							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

							mfc_step=P_MFC_REPOUSO;

							r2_step=P_R2_LIVRE;
							blocked_event = 0;
							//.......
							line_state = OFF;

							break;
					}//switch
				}
			}
			break;
		case P_R2_BLOQUEANDO_DDC:
			if (timeout==tmr_h)
			{
				if (line_state==ON)
				{
					e1->bAtendido = ON;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
            			dg_SendR2Command(e1->port, R2_ANSWERED);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				}
				r2_step=P_R2_ATENDIDO_ENTRANTE;
			}
			else
			{
				if (line_state==OFF)
				{
					e1->bAtendido = OFF;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					r2_step=P_R2_ATENDIDO_ENTRANTE;
				}
				else
				{
					switch(r2i)
					{

						case R2_SEIZURE:
							break;

						case R2_FAILURE:
						case R2_ANSWERED://nao deve acontecer
							//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off
							termina_aguarda_libera(e1->port,1,&mfc_step, &r2_step);
							tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
							line_state = OFF;
							break;
						case R2_IDLE:
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								// termina geracao de sinal
								dg_GenerateMF (e1->port, GENERATE_OFF, 0);
								dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
								// libera canal
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								// gerar evento LIGACAO ENCERRADA
								dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

							mfc_step=P_MFC_REPOUSO;
							r2_step=P_R2_LIVRE;
							blocked_event = 0;
							//.......
							line_state = OFF;

							break;
						}
				}
			}
			break;
		case P_R2_ATENDIDO_ENTRANTE:
			write_debug_e1(e1->port,"P_R2_ATENDIDO_ENTRANTE line_state=%d r2i=%d",line_state,r2i);
			if (line_state==OFF)
			{
					//desliga flag de atendimento
					e1->bAtendido = OFF;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						r2o=dg_SendR2Command(e1->port, R2_CLEAR_BACK);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

					//seta timeout com 10s a mais do controle de retencao
					tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					r2_step = P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU;
			}
			else
			{
				if (line_state==ON)
				{
					//flag de atendimento
					//..
					e1->bAtendido = ON;
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
           				r2o=dg_SendR2Command(e1->port, R2_ANSWERED);
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				}
			}
			switch(r2i)
			{
					case R2_SEIZURE:
						break;
					case R2_FAILURE:
					case R2_ANSWERED://nao deve acontecer
						// termina sinalizacao MFC
						//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off
						termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);

						line_state = OFF;

						//.......
						break;
					case R2_IDLE:
						// termina sinalizacao MFC
						tmr_h=set_e1_timeout(e1->port,0);  //timer off
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							dg_GenerateMF (e1->port, GENERATE_OFF, 0);
							dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
							// libera canal
							r2o=dg_SendR2Command(e1->port, R2_IDLE);
							// gerar evento LIGACAO ENCERRADA
							e1->bAtendido = OFF;
							//desabilita timer de ligacao sainte
							tmrCallProgress[e1_events.port-1].Enabled = FALSE;
							SetEnableTimer(&tmrCallProgress[e1_events.port-1],FALSE);
							//cancela geracao de tons
							e1->ring_event = 0;
							tmrRing[e1->port-1].Enabled = FALSE;
							SetEnableTimer(&tmrRing[e1_events.port-1],FALSE);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						//chama funcao que libera tudo - com timeout
						termina_libera(e1->port,0,&mfc_step, &r2_step);
						//...TODO: VALIDAR se retira mesmo
						//RaiseEvents_ThreadSafe(EV_LINEOFF, 0, e1_events.port,&port_mutex[e1->port-1]);
						RaiseEvents_ThreadSafe(EV_BUSY, 0,  0, e1_events.port,&port_mutex[e1->port-1]);
						end_action = EA_NONE;
						line_state = OFF;
						//.......
					break;
			}
			break;
		case P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU:
			write_debug_e1(e1->port,"e1 (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU",e1->port);
			if (timeout==tmr_h)
			{
				write_debug_e1(e1->port,"e1 (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU - deu timeout",e1->port);
				// termina sinalizacao MFC
				tmr_h=set_e1_timeout(e1->port,0);  //timer off
				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					dg_GenerateMF (e1->port, GENERATE_OFF, 0);
					dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
					mfc_step=P_MFC_REPOUSO;
					// libera canal
					r2o=dg_SendR2Command(e1->port, R2_IDLE);
					if (r2i==R2_IDLE)
						r2_step=P_R2_LIVRE;
					else
					{
						dg_SendR2Command(e1->port, R2_ENABLE);
						r2_step=P_R2_AGUARDA_LIVRE;
					}
					// gerar evento LIGACAO ENCERRADA
					dg_InsertE1Fifo(e1->port,C_ENDCALL,0);
					line_state = OFF;
					e1->bAtendido = OFF;
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
				//.......
			}
			else
			{
				write_debug_e1(e1->port,"e1 (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU - Recebeu r2i=%d",e1->port,r2i);
				if (line_state==ON)
				{
					//flag de atendimento
					//..
					e1->bAtendido = ON;
					if (r2i==R2_SEIZURE)
					{
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
           					r2o=dg_SendR2Command(e1->port, R2_ANSWERED);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					}
					r2_step = P_R2_ATENDIDO_ENTRANTE;
				}
				switch(r2i)
				{
						case R2_SEIZURE:
							break;
						case R2_FAILURE:
						case R2_ANSWERED://nao deve acontecer
							// termina sinalizacao MFC
							//aaa tmr_h=set_e1_timeout(e1->port,0);  //timer off
							
							termina_aguarda_libera(e1->port,0,&mfc_step, &r2_step);
							tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
							line_state = OFF;

							//.......
							break;
						case R2_IDLE:
							// termina sinalizacao MFC
							write_debug_e1(e1->port,"e1 (%d): P_R2_ATENDIDO_ENTRANTE_APP_DESLIGOU - R2_IDLE Recebeu r2i=%d",e1->port,r2i);
							tmr_h=set_e1_timeout(e1->port,0);  //timer off
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								dg_GenerateMF (e1->port, GENERATE_OFF, 0);
								dg_SetDetectionType(e1->port,DETECT_ALL_MF ,DG_DISABLE);
								mfc_step=P_MFC_REPOUSO;
								// libera canal
								r2o=dg_SendR2Command(e1->port, R2_IDLE);
								r2_step=P_R2_LIVRE;
								// gerar evento LIGACAO ENCERRADA

								//>>>dg_InsertE1Fifo(e1->port,C_ENDCALL,0);

								line_state = OFF;
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							//.......
						break;
				}
			}
			break;
		}//fim do r2
	} //if do trata_r2
	//r2i =-1;
/******************* trata sinalizacao entre registardores - mfc **********************/
	while(trata_mfc>0)
	{
		write_debug_e1(e1->port,"e1 (%d): MFC_step = %x com mfci=%d",e1->port,mfc_step,mfci);
		switch (mfc_step)
		{
			case P_MFC_REPOUSO:
				break;

			case P_MFC_ENTRANTE:
				write_debug_e1(e1->port,"e1: (%d) Habilita DETECT_MFF",e1->port);

				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					dg_SetDetectionType(e1->port,DETECT_MFF ,DG_ENABLE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							//..mfci=

				mfc_step=P_MFC_RECEBE_DIGITO;
				grupo_a=0;
				grupo_b=0;
				rx_count=0;
				e1->rx_complete_count=0;
				//iniciar timer 30s - timeout MFC
				tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);

				break;

			case P_MFC_SAINTE:

				digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
					dg_SetDetectionType(e1->port,DETECT_MFT ,DG_ENABLE);
				digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

				write_debug_e1(e1->port,"e1 (%d): P_MFC_SAINTE - Habilita MFT ",e1->port);
				//..mfci=DETECTA_MFT;

				mfc_step=P_MFC_ENVIA_DIGITO;
				grupo_i=0;
				grupo_ii=0;
				tx_count=0;
				tx_number_of_digits=0;

				a5=OFF;
				pulsado=OFF; //desabilita deteccao de A3 e A4 pulsado
				//iniciar timer 30s - timeout MFC
				tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);

				break;
		/************** tratamento da ligacao sainte *************************/
			case P_MFC_ENVIA_DIGITO:
				write_debug_e1(e1->port,"e1: P_MFC_ENVIA_DIGITO -> timeout=%d tmr_h=%d",timeout,tmr_h);
				if (timeout!=tmr_h)
				{
					write_debug_e1(e1->port,"e1: P_MFC_ENVIA_DIGITO mfci=%x tx_number_of_digits=%d tx_count=%d",mfci,tx_number_of_digits,tx_count);

					if (mfci==CP_SILENCE)
					{
						pulsado=ON; //habilita deteccao de A3 e A4 pulsado

						if (tx_number_of_digits> tx_count)
						{
								//write_debug_e1(e1->port,"e1 (%d): GENERATE_MFF %d",e1->port,tx_digits[tx_count]);
								write_debug_e1(e1->port,"Sending MFF signal ----------------------------------------------------------------->         %x", tx_digits[tx_count]);
								digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
									mfco=dg_GenerateMF(e1->port, GENERATE_MFF, tx_digits[tx_count]);
								digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

								if (tx_count<NUMBER_SIZE)
										tx_count++;

								mfc_step=P_MFC_RECEBE_GRUPO_A;
								//iniciar timer 30s - timeout MFC
								tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						}
						else
						{
							//est�sendo esperado mais digito
							write_debug_e1(e1->port,"e1: else tx_number_of_digits=%d tx_count=%d",tx_number_of_digits,tx_count);
						}
					}
					else
					{
						if (pulsado == ON)//deteccao de A3, A4, A5 e A6(4.1.0.3_rc4) pulsado
						{
							if (mfci == e1->a_send_cat_prepare_group_b)
							{
								//enviar evento PEDE CATEGORIA
								grupo_ii = e1->category;
								trata_mfc++;
								mfc_step=P_MFC_ENVIA_CATEGORIA;
								//iniciar timer 30s - timeout MFC
								tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
							}
							else if (mfci == e1->a_congestion)
							{
								//encerra ligacao congestinamento
							}
							else if (mfci == e1->a_send_cat_and_callerid)
							{
								if (a5==OFF)
								{
									// enviar evento PEDE ID
									id_count=0;
									mfc_step=P_MFC_ENVIA_CATEGORIA_ASSINANTE;
									grupo_ii = e1->category;
									a5 = ON;
									trata_mfc++;
								}
								else
								{
									mfc_step=P_MFC_ENVIA_ASSINANTE;
									trata_mfc++;
								}
								tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
							}
							else if (mfci == e1->a_address_complete_charge_setup)//bypassing the use of group B and II tones 
							{
								mfc_step=P_MFC_FIM;
								tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);

								//marca flag para gerar chamando no FIM MF
								end_action = EA_GENERATE_CALLING;

								RaiseEvents_ThreadSafe(EV_GROUP_B, e1->b_free_calling, 0, e1_events.port, &port_mutex[e1->port-1]);
								trata_mfc++;	
							}							
						}//if (pulsado == ON)
					}
				}  //SILENCE
				else
				{//encerra ligacao timeout
					// termina sinalizacao MFC
					write_debug_e1(e1->port,"e1 sainte (%d): TIMEOUT MFF  - Finaliza ",e1->port);
					termina_libera(e1->port,1,&mfc_step,&r2_step);

					line_state = OFF;

					//chama reset da placa
					card = ports_info[e1->port-1].card;
					if (card==0) card=1;
					write_debug_e1(e1->port,"resync ponto 1");
					dg_ReSync(card);
				}
				break;
			case P_MFC_RECEBE_GRUPO_A:
				write_debug_e1(e1->port,"e1 sainte (%d): entrou P_MFC_RECEBE_GRUPO_A com mfci=%x ",e1->port,mfci);
				if (timeout!=tmr_h)
				{
					if ((mfci>=1)&&(mfci<=15))
					{
						//iniciar timer 30s - timeout MFC
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
						pulsado=OFF;
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							mfco=dg_GenerateMF(e1->port, GENERATE_OFF, 0);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						
						if (mfci == e1->a_send_next)//send next digit
						{			
               				a5=OFF;
               				mfc_step=P_MFC_ENVIA_DIGITO;
						}
						else if (mfci == e1->a_dnis_again)//send NDIS again
						{
              				a5=OFF;
              				tx_count=0;
              				mfc_step=P_MFC_ENVIA_DIGITO;
						}
						else if (mfci == e1->a_send_cat_prepare_group_b)//send category and prepare to group B
						{
              				grupo_ii = e1->category;
              				trata_mfc++;
              				a5=OFF;
              				mfc_step=P_MFC_ENVIA_CATEGORIA;
						}
						else if (mfci == e1->a_congestion)//congestion
						{
              				// enviar evento CONGESTIONAMENTO
              				//dg_insert_callctrl_fifo(e1->port,C_CONGESTION,0);
              				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_CONGESTION,  0, e1->port,&port_mutex[e1->port-1]);
              				RaiseEvents_ThreadSafe(EV_BUSY, 0,  0, e1->port,&port_mutex[e1->port-1]);
              				//.............
              				mfc_step=P_MFC_FIM;
              				//iniciar timer 30s - timeout MFC
              				// tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
              				trata_mfc++;
						}
						else if (mfci == e1->a_send_cat_and_callerid)//send category and Caller ID
						{
              				if (a5==OFF)
              				{
              					// enviar evento PEDE ID
              					id_count=0;
              					mfc_step=P_MFC_ENVIA_CATEGORIA_ASSINANTE;
           						grupo_ii = e1->category;
           						a5 = ON;
           						trata_mfc++;
                           	}
           					else
           					{
           						mfc_step=P_MFC_ENVIA_ASSINANTE;
           						trata_mfc++;
           					}
              				//iniciar timer 30s - timeout MFC
              				// tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
						}
						else if (mfci == e1->a_send_dnis_nm2)//send dnis(n-2)
						{
              				a5=OFF;
              				tx_count-=3;
              				if (tx_count<0)
              					tx_count=0;
              				mfc_step=P_MFC_ENVIA_DIGITO;
						}
						else if (mfci == e1->a_send_dnis_nm3)//send dnis(n-3)
						{
              				a5=OFF;
              				tx_count-=4;
              				if (tx_count<0)tx_count=0;
              					mfc_step=P_MFC_ENVIA_DIGITO;
						}
						else if (mfci == e1->a_send_dnis_nm1)//send dnis(n-1)
						{
              				a5=OFF;
              				tx_count-=2;

              				if (tx_count<0)
              					tx_count=0;

              				mfc_step=P_MFC_ENVIA_DIGITO;
						}
						else if (mfci == e1->a_address_complete_charge_setup)//bypassing the use of group B and II tones
						{
							mfc_step=P_MFC_FIM;
							tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);

							//marca flag para gerar chamando no FIM MF
							end_action = EA_GENERATE_CALLING;

							RaiseEvents_ThreadSafe(EV_GROUP_B, e1->b_free_calling, 0, e1_events.port, &port_mutex[e1->port-1]);
							trata_mfc++;
						}
						else if ((mfci == e1->a_6 ) || 
							   //(mfci == e1->a_10) ||after ARGENTINA								
								 (mfci == e1->a_11) ||  
								 (mfci == e1->a_12) ||  
								 (mfci == e1->a_13) || 
								 (mfci == e1->a_14) || 
								 (mfci == e1->a_15))							
						{
							if ((mfci == e1->a_6) && (grupo_c))
              				{
              					//send group_ii and prepare to send ANI
              					id_count=0;
              					mfc_step=P_MFC_ENVIA_CATEGORIA_ASSINANTE;
              					grupo_ii = e1->category;
              					a5 = ON;
              					trata_mfc++;
              				}//only breaks if the signaling has group_c
							else
							{							
              					// enviar evento PEDE GRUPO I
              					//.......
              					//dg_insert_callctrl_fifo(e1->port,C_PEDE_GRUPO_I,0);
              					RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_GROUP_I,  0, e1_events.port,&port_mutex[e1->port-1]);
              					trata_mfc++;
              					a5=OFF;
              					mfc_step=P_MFC_ENVIA_GRUPO_I;
              					//iniciar timer 30s - timeout MFC
              					// tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
							}
						}//if (mfci == e1->a_XX)
					}  //if ((mfci>=1)&&(mfci<=15))
				} //timeout
				else
				{ //encerra ligacao timeout
					// termina sinalizacao MFC
					write_debug_e1(e1->port,"e1: timeout P_MFC_RECEBE_GRUPO_A",e1->port);
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;

					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					write_debug_e1(e1->port,"resync ponto 2");
					dg_ReSync(card);
					//..........
				}
				break;

			case P_MFC_RECEBE_GRUPO_C:
				write_debug_e1(e1->port,"e1 sainte (%d): entrou P_MFC_RECEBE_GRUPO_C com mfci=%x ",e1->port,mfci);
				if (timeout!=tmr_h)
				{
					if ((mfci>=1)&&(mfci<=15))
					{
						//iniciar timer 30s - timeout MFC
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
						pulsado=OFF;
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							mfco=dg_GenerateMF(e1->port, GENERATE_OFF, 0);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						
						if (mfci == e1->c_send_next_ani)//send next digit
						{
              				mfc_step=P_MFC_ENVIA_ASSINANTE;
              				trata_mfc++;
						}
						else if (mfci == e1->c_dnis_again_prepare_group_a)//send NDIS again switch to A
						{
              				a5=OFF;
              				tx_count=0;
              				mfc_step=P_MFC_ENVIA_DIGITO;
              				//grupo_c=0;
						}
						else if (mfci == e1->c_send_cat_prepare_group_b)//send category and prepare to group B
						{
              				grupo_ii = e1->category;
              				trata_mfc++;
              				a5=OFF;
              				mfc_step=P_MFC_ENVIA_CATEGORIA;
              				//grupo_c=0;
						}
						else if (mfci == e1->c_send_next_dnis_prepare_group_a)//send next digit
						{
              				a5=OFF;
              				mfc_step=P_MFC_ENVIA_DIGITO;
						}
						else if (mfci == e1->c_send_dnis_nm1_prepare_group_a)//send dnis(n-1)
						{							
              				a5=OFF;
              				tx_count-=2;

              				if (tx_count<0)
              					tx_count=0;

              				mfc_step=P_MFC_ENVIA_DIGITO;
              				//grupo_c=0;
						}
						else
						{             					
              				// enviar evento PEDE GRUPO I
              				//.......
              				//dg_insert_callctrl_fifo(e1->port,C_PEDE_GRUPO_I,0);
              				RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_GROUP_I,  0, e1_events.port,&port_mutex[e1->port-1]);
              				trata_mfc++;
              				a5=OFF;
              				mfc_step=P_MFC_ENVIA_GRUPO_I;
              				//iniciar timer 30s - timeout MFC
              				// tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
						}//if (mfci == e1->c_XX)
					}  //if ((mfci>=1)&&(mfci<=15))
				} //timeout
				else
				{ //encerra ligacao timeout
					// termina sinalizacao MFC
					write_debug_e1(e1->port,"e1: timeout P_MFC_RECEBE_GRUPO_C",e1->port);
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;

					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					write_debug_e1(e1->port,"resync ponto 2");
					dg_ReSync(card);
					//..........
				}
				break;

			case P_MFC_ENVIA_CATEGORIA:   //categoria em resposta ao A-3
				if (timeout!=tmr_h)
				{
					if (mfci==CP_SILENCE)
					{
						if (grupo_ii)
						{
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								mfco=dg_GenerateMF(e1->port, GENERATE_MFF, (char)grupo_ii);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							write_debug_e1(e1->port,"Sending MFF signal ----------------------------------------------------------------->         %x", grupo_ii);
							//write_debug_e1(e1->port,"e1: P_MFC_ENVIA_CATEGORIA - Grupo ii - GENERATE_MFF %d",grupo_ii);
							mfc_step=P_MFC_RECEBE_GRUPO_B;
							//iniciar timer 30s - timeout MFC
							tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
							grupo_ii=0;
						}
					}
				}
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					write_debug_e1(e1->port,"e1: timeout P_MFC_RECEBE_GRUPO_A",e1->port);
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//.......

					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 3");
					dg_ReSync(card);

				}
				break;
			case P_MFC_ENVIA_CATEGORIA_ASSINANTE:		//categoria antes do ID A (em resposta ao A-5)
				if (timeout!=tmr_h)
				{
					if (mfci==CP_SILENCE)
					{
						if (grupo_ii)
						{
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								mfco=dg_GenerateMF(e1->port, GENERATE_MFF, (char)grupo_ii);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							write_debug_e1(e1->port,"Sending MFF signal ----------------------------------------------------------------->         %x", grupo_ii);
							//write_debug_e1(e1->port,"e1: P_MFC_ENVIA_CATEGORIA_ASSINANTE - Grupo ii - GENERATE_MFF %d",grupo_ii);
                            if(grupo_c)
							   mfc_step=P_MFC_RECEBE_GRUPO_C;
                            else
							   mfc_step=P_MFC_RECEBE_GRUPO_A;
							//iniciar timer 30s - timeout MFC
							tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
							grupo_ii=0;
						}
					}
				}
				else
				{
						//encerra ligacao timeout
						// termina sinalizacao MFC
						termina_libera(e1->port,1,&mfc_step,&r2_step);
						line_state = OFF;
						//.......
						//chama reset da placa
						card = ports_info[e1->port-1].card;

						if (card==0) card=1;
						write_debug_e1(e1->port,"resync ponto 4");
						dg_ReSync(card);
				}
				break;
			case P_MFC_ENVIA_ASSINANTE:
				if (timeout!=tmr_h)
				{
					if (mfci==CP_SILENCE)
					{
						if (a5==ON)//ja recebeu ID
						{
							if (e1->tx_id_number_of_digits==0)
							{
								digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
									mfco=dg_GenerateMF(e1->port, GENERATE_MFF, e1->group_i_end_of_ani); //fim de numero
																			//o valor 12, de "pedido recusado" n� est�																			//sendo tratado nos equip. Digivoice
								digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
								write_debug_e1(e1->port,"Sending MFF signal ----------------------------------------------------------------->         f");
								//write_debug_e1(e1->port,"e1: P_MFC_ENVIA_ASSINANTE - GENERATE_MFF 15");
								if(grupo_c)
									mfc_step=P_MFC_RECEBE_GRUPO_C;
								else
								    mfc_step=P_MFC_RECEBE_GRUPO_A;
								    
								//iniciar timer 30s - timeout MFC
								tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
							}
							else
							{
								if (e1->tx_id_number_of_digits>id_count)
								{
									//write_debug_e1(e1->port,"e1>: P_MFC_ENVIA_ASSINANTE - GENERATE_MFF %d",e1->tx_id_digits[id_count]);
									write_debug_e1(e1->port,"Sending MFF signal ----------------------------------------------------------------->         %x",e1->tx_id_digits[id_count]);
									digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
										mfco=dg_GenerateMF(e1->port, GENERATE_MFF, e1->tx_id_digits[id_count++]);
									digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

									if(grupo_c)
										mfc_step=P_MFC_RECEBE_GRUPO_C;
									else
								    	mfc_step=P_MFC_RECEBE_GRUPO_A;
								    	
									//iniciar timer 30s - timeout MFC
									tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
								}
								else
								{
									digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
										mfco=dg_GenerateMF(e1->port, GENERATE_MFF, e1->group_i_end_of_ani);//end of number
									digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
									write_debug_e1(e1->port,"Sending MFF signal ----------------------------------------------------------------->         f");
									//write_debug_e1(e1->port,"e1: P_MFC_ENVIA_ASSINANTE - GENERATE_MFF 15 - else");
									if(grupo_c)
										mfc_step=P_MFC_RECEBE_GRUPO_C;
									else
									    mfc_step=P_MFC_RECEBE_GRUPO_A;

									//iniciar timer 30s - timeout MFC
									tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
								}
							}
						}//a5
					} //CP_SILENCE
				} //timeout
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//.......
					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					write_debug_e1(e1->port,"resync ponto 5");
					dg_ReSync(card);

				}
				break;
			case P_MFC_ENVIA_GRUPO_I:
				if (timeout!=tmr_h)
				{
					if (mfci==CP_SILENCE)
					{
					     if (grupo_i)
					     {
						    digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							   mfco=dg_GenerateMF(e1->port, GENERATE_MFF, (char)grupo_i);
						    digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						    write_debug_e1(e1->port,"Sending MFF signal ----------------------------------------------------------------->         %x",grupo_i);
						    //write_debug_e1(e1->port,"e1: P_MFC_ENVIA_GRUPO_I - GENERATE_MFF %d",grupo_i);
						    mfc_step=P_MFC_RECEBE_GRUPO_A;
						    //iniciar timer 30s - timeout MFC
						    tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
						    grupo_i=0;
             			    }
					}
				}
				else
				{
						//encerra ligacao timeout
						// termina sinalizacao MFC
					    termina_libera(e1->port,1,&mfc_step,&r2_step);
						line_state = OFF;
						//.......
					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					write_debug_e1(e1->port,"resync ponto 6");
					dg_ReSync(card);
				}
				break;
   			case P_MFC_RECEBE_GRUPO_B:/* aguarda grupo B e envia SILENCE */
				if (timeout!=tmr_h)
				{
					if ((mfci>=1)&&(mfci<=15))
					{
						pulsado=OFF;
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							mfco=dg_GenerateMF (e1->port, GENERATE_OFF, 0);/* para de enviar sinal para frente */
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

						mfc_step=P_MFC_FIM;

						if (mfci == e1->b_collectcall/*B_COLLECTCALL*/)/* assinante livre com tarifacao controle retencao com chamado */
							retencao = ON;
						else
              				retencao = OFF;

						//..iniciar timer 30s - timeout MFC
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mft);
						//tmr_h=set_e1_timeout(e1->port,0);

						// gerar evento GRUPO_B
						//dg_insert_callctrl_fifo(e1->port, C_GRUPO_B,mfci);
						write_debug_e1(e1->port,"P_MFC_RECEBE_GRUPO_B - mfci=%d",mfci);
						
						if (mfci == e1->b_free_calling)
						{
							//marca flag para gerar chamando no FIM MF
							end_action = EA_GENERATE_CALLING;
						}
						else if ( (mfci == e1->b_busy      ) ||
								  (mfci == e1->b_congestion) )
						{
							end_action = EA_GENERATE_BUSY;
						}
						else if (mfci == e1->b_free_withoutbilling)
						{
							//marca flag para gerar chamando no FIM MF
							end_action = EA_GENERATE_CALLING;
						}
						else if (mfci == e1->b_collectcall)
						{
							//marca flag para gerar chamando no FIM MF
							end_action = EA_GENERATE_CALLING;
						}
						else if (mfci == e1->b_number_unknown)
						{
							end_action = EA_GENERATE_CALLING;
						}
						else if (mfci == e1->b_number_changed)
						{
							end_action = EA_GENERATE_CALLING;
						}
						else if (mfci == e1->b_out_of_service)
						{
							end_action = EA_GENERATE_CALLING;
						}
						else
						{
							end_action = EA_NONE;						
						}
					
						RaiseEvents_ThreadSafe(EV_GROUP_B, e1_events.data, 0, e1_events.port, &port_mutex[e1->port-1]);
						trata_mfc++;
	     			}
				}
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//.......
					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					write_debug_e1(e1->port,"resync ponto 8");
					dg_ReSync(card);
				}
				break;
			case P_MFC_FIM:
				if (timeout!=tmr_h)
				{
					write_debug_e1(e1->port,"P_MFC_FIM - mfci=%d - ent=%d",mfci,entrante);
					if (mfci==CP_SILENCE)
					{
						mfc_step=P_MFC_REPOUSO;
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							dg_GenerateMF (e1->port, GENERATE_OFF, 0);
							dg_SetDetectionType(e1->port,DETECT_ALL_MF, DG_DISABLE);
							dg_InsertE1Fifo(e1->port,C_END_MF,0);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						//enables timeout
						tmr_ha=set_e1_timeout(e1->port,e1->timeout_atendimento);

						//--- FINALIZACAO DE LIGACAO ----
						trata_mfc++;
						if (entrante==1)
						{
							//gera tom de chamada e evento de ring
                            if (e1->rx_total_of_digits > 0)
                            {
                                e1->ring_event = 0;
                                //RaiseEvents_ThreadSafe(EV_RINGS, 0,  0, e1_events.port,&port_mutex[e1->port-1]);
    							write_debug_e1(e1->port,"e1: GENERATE_TONE1 in P_MFC_FIM");
    							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);

                                    if (e1->ring_generate_ringback)
                                        dg_GenerateMF(e1->port,GENERATE_TONE1,0);

    								//primeira intera�o do timer de 1 segundo
    								tmrRing[e1->port-1].Interval = 1000 / FACTOR_TIMER;
    								SetEnableTimer(&tmrRing[e1->port-1],TRUE);
    								tmrRing[e1->port-1].Enabled = TRUE;
    							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
                                write_debug_e1(e1->port,"e1: LIGANDO TIMER DO RING = %x",tmrRing[e1->port-1]);
                            }
                            else
                            {
                                e1->ring_event = 1;
                                digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
                                    if (e1->ring_generate_ringback)
                                        dg_GenerateMF(e1->port,GENERATE_TONE1,0);

                                    //primeira intera�o do timer de 1 segundo
                                    tmrRing[e1->port-1].Interval = 300 / FACTOR_TIMER;
                                    SetEnableTimer(&tmrRing[e1->port-1],TRUE);
                                    tmrRing[e1->port-1].Enabled = TRUE;
                                digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
                            }

							if (pickup_after_mfc_fim)
							{
								dg_InsertE1Fifo(e1->port,CPICKUP,0);
								write_debug_e1(e1->port,"CPICKUP atrasado");
							}

						}
						else
						{
							//turn off status flag
							ports_info[e1->port-1].FStatusPort = spNone;							
							
							//Fires EV_AFTERDIAL - ligacao sainte
							RaiseEvents_ThreadSafe(EV_AFTERDIAL, 0,  0, e1->port,&port_mutex[e1->port-1]);

							switch(end_action)
							{
								case EA_GENERATE_CALLING:
									//enables timer to emulate call progress
									digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
										tmrCallProgress[e1_events.port-1].Interval = 300 / FACTOR_TIMER;
										SetEnableTimer(&tmrCallProgress[e1_events.port-1],TRUE);
										tmrCallProgress[e1_events.port-1].Enabled = TRUE;
									digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
									break;
								case EA_GENERATE_BUSY:
									RaiseEvents_ThreadSafe(EV_BUSY, 0,  0, e1_events.port,&port_mutex[e1->port-1]);
									break;

							}
							end_action = EA_NONE;

						}
					}
				}
				else
				{

					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//.......
					//chama reset da placa
					card = ports_info[e1->port-1].card;
					if (card==0) card=1;
					write_debug_e1(e1->port,"resync ponto 9");
					dg_ReSync(card);
				}
				break;
		/************** tratamento da ligacao entrante *************************/
   			case P_MFC_RECEBE_DIGITO:
				if (timeout!=tmr_h)
				{
					if ((mfci>=1)&&(mfci<=15))
					{
						if (mfci==15)//fim de numero
						{
								write_debug_e1(e1->port,"I-15 receiced ----------------------------------------------------------------->         1");
								//added under version 4.1.0.3_rc3
								e1->rx_number_of_digits=rx_count;
								
               					// gerar evento NUMERO_RECEBIDO
								grupo_a = 0;  //zerar grupo_a para esperar que a aplicacao diga o que fazer

               					mfc_step=P_MFC_ENVIA_GRUPO_A;
								//tratamento automatico
								if (e1->rx_total_of_digits > 0)
								{
									if ((e1->rx_total_remaining > 0) && (e1->send_id_digit_pos > 0) )
									{
										if(grupo_c)
											//send category and switch to group C
											grupo_a = e1->a_6;//A_6;
										else
											grupo_a = e1->a_send_cat_and_callerid;//A_SEND_CAT_AND_CALLERID;
									}
									else
										if (e1->rx_total_remaining == 0) //pede categoria
											grupo_a = e1->a_send_cat_prepare_group_b;//A_SEND_CAT_PREPARE_GROUP_B;
									
									
									trata_mfc++;
									RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NUMBER_RECEIVED,  0, e1_events.port,&port_mutex[e1->port-1]);
									
									tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
									break;									
								}
								else									
								{
									trata_mfc++;
									//RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NUMBER_RECEIVED,  0, e1_events.port,&port_mutex[e1->port-1]);
									
									tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
									break;									
								}
						}
						else
						{
								e1->rx_digits[rx_count++]=(char)mfci;
								e1->rx_complete_digits[e1->rx_complete_count]=mfci;
								e1->rx_complete_digits[e1->rx_complete_count+1]=0;
								e1->rx_complete_count++;
						}
						if (rx_count < e1->rx_number_of_digits)
						{
								//write_debug_e1(e1->port,"e1 (%d): GENERATE_MFT 1",e1->port);
								write_debug_e1(e1->port,"Sending MFT signal ----------------------------------------------------------------->         1");
								digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
									mfco=dg_GenerateMF(e1->port, GENERATE_MFT, (char)e1->a_send_next/*A_SEND_NEXT*/);	//pede proximo algarismo - A-1
								digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
								mfc_step=P_MFC_AGUARDA_FIM_DIGITO;
						}
						else
						{
               					// gerar evento NUMERO_RECEBIDO
								grupo_a = 0;  //zerar grupo_a para esperar que a aplicacao diga o que fazer

								/*digivoice_entercriticalsection(&port_mutex[e1->port-1]);
									dg_InsertE1Fifo(e1->port,C_NUMBER_RECEIVED,0);
								digivoice_leavecriticalsection(&port_mutex[e1->port-1]);*/

               					mfc_step=P_MFC_ENVIA_GRUPO_A;
								//tratamento automatico
								if (e1->rx_total_of_digits > 0)
								{
									
									if ((e1->rx_total_remaining > 0) && (e1->send_id_digit_pos > 0) )
									{
										
										if(grupo_c)
									        //send category and switch to group C
											grupo_a = e1->a_6;//A_6;
										else
										    grupo_a = e1->a_send_cat_and_callerid;//A_SEND_CAT_AND_CALLERID;
									}
									else
										if (e1->rx_total_remaining == 0) //pede categoria
										{
											
											if ((e1->send_id_digit_pos > 0) && (e1->send_id_digit_pos == e1->rx_total_of_digits))
											{
												if(grupo_c)
											        //send category and switch to group C
													grupo_a = e1->a_6;//A_6;
												else
												    grupo_a = e1->a_send_cat_and_callerid;//A_SEND_CAT_AND_CALLERID;

												
											}
											else											
												grupo_a = e1->a_send_cat_prepare_group_b;//A_SEND_CAT_PREPARE_GROUP_B;
										}
								}
								trata_mfc++;
								RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_NUMBER_RECEIVED,  0, e1_events.port,&port_mutex[e1->port-1]);
						}
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
					}
				}
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC

					termina_aguarda_libera(e1->port,1,&mfc_step, &r2_step);
					tmr_h=set_e1_timeout(e1->port,e1->timeout_retencao+10000);
					line_state = OFF;
					//.......
					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 10");
					dg_ReSync(card);
				}
				break;
			case P_MFC_AGUARDA_FIM_DIGITO:
				if (timeout!=tmr_h)
				{
					if (mfci==CP_SILENCE)
					{
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						mfco=dg_GenerateMF (e1->port, GENERATE_OFF, 0);/* para de enviar sinal para tras */
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						mfc_step=P_MFC_RECEBE_DIGITO;
					}
				}
				else
				{
					write_debug_e1(e1->port,"e1 (%d): P_MFC_AGUARDA_FIM_DIGITO - TIMEOUT",e1->port);
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//.......
				}
				break;
			case P_MFC_A3_PULSADO:
				//aguardao 100ms de silencio
				if (timeout==tmr_h)
				{
					set_e1_timeout(e1->port,0);
					//gera a3 e aguarda 150ms para
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						mfco=dg_GenerateMF(e1->port, GENERATE_MFT, (char)grupo_a);//envia a3
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					write_debug_e1(e1->port,"Sending MFT signal ----------------------------------------------------------------->         %x",grupo_a);
					tmr_h=set_e1_timeout(e1->port,150);
					mfc_step=P_MFC_A3_PULSADO_FIM;

				}
				break;
			case P_MFC_A3_PULSADO_FIM:
				//aguarda 150ms para parar de mandar a3
				if (timeout==tmr_h)
				{
					set_e1_timeout(e1->port,0);
					//gera a3 e aguarda 150ms para
					digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
						mfco=dg_GenerateMF(e1->port, GENERATE_OFF, 0);//envia a3
					digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
					//seta timeout para esperar categoria
					tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
					mfc_step=P_MFC_RECEBE_CATEGORIA;
				}
				break;
			case P_MFC_ENVIA_GRUPO_A:
				if (timeout!=tmr_h)
				{
					if (grupo_a)  //so pode ser diferente de zero, apos a aplicacao receber o C_NUMBER_RECEIVED
					{
						//write_debug_e1(e1->port,"e1 (%d): P_MFC_ENVIA_GRUPO_A = %d",e1->port,grupo_a);
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							mfco=dg_GenerateMF(e1->port, GENERATE_MFT, (char)grupo_a);//pede primeiro digito
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						write_debug_e1(e1->port,"Sending MFT signal ----------------------------------------------------------------->         %x",grupo_a);

						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						mfc_step=P_MFC_AGUARDA_FIM_GRUPO_I;
					}
				}
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//.......
					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 11");
					dg_ReSync(card);
				}
				break;

			case P_MFC_AGUARDA_FIM_GRUPO_I:
				if (timeout!=tmr_h)
				{
					if (mfci==CP_SILENCE)
					{
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							dg_GenerateMF (e1->port, GENERATE_OFF, 0);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						
						//test if is is returning from group C
						if((grupo_c==1) && (grupo_a == e1->c_send_next_dnis_prepare_group_a/*C_SEND_NEXT_DNIS_PREPARE_GROUP_A*/))
							grupo_a = e1->a_send_next;//A_SEND_NEXT;
							
						if (grupo_a == 0)
						{
							//nothing to do
						}
						else if (grupo_a == e1->a_send_next)
						{
							mfc_step=P_MFC_RECEBE_DIGITO;
						}						
						else if (grupo_a == e1->a_dnis_again)
						{
							rx_count=0;
							mfc_step=P_MFC_RECEBE_DIGITO;
						}		
						else if (grupo_a == e1->a_send_cat_prepare_group_b)
						{
							mfc_step=P_MFC_RECEBE_CATEGORIA;
						}		
						else if (grupo_a == e1->a_congestion)
						{
							mfc_step=P_MFC_FIM;
						}		
						else if (grupo_a == e1->a_send_cat_and_callerid)//pede ID
						{
							mfc_step=P_MFC_RECEBE_ID;
			 				id_count = 0;
							a5=ON;
						}		
						else if (grupo_a == e1->a_send_dnis_nm2)
						{
							rx_count-=2;
							if (rx_count<0)rx_count=0;
								mfc_step=P_MFC_RECEBE_DIGITO;						
						}		
						else if (grupo_a == e1->a_send_dnis_nm3)
						{
							rx_count-=3;
							if (rx_count<0)rx_count=0;
								mfc_step=P_MFC_RECEBE_DIGITO;							
						}		
						else if (grupo_a == e1->a_send_dnis_nm1)
						{
							rx_count-=1;
							if (rx_count<0)rx_count=0;
								mfc_step=P_MFC_RECEBE_DIGITO;
						}
						else if ((grupo_a == e1->a_6 ) ||
							   //(grupo_a == e1->a_10) ||after ARGENTINA
								 (grupo_a == e1->a_11) ||
								 (grupo_a == e1->a_12) ||
								 (grupo_a == e1->a_13) ||
								 (grupo_a == e1->a_14) ||
								 (grupo_a == e1->a_15))
						{
						    if ((grupo_a == e1->a_6) && (grupo_c))
							{
								mfc_step=P_MFC_RECEBE_ID;
			 				    id_count = 0;
							    a5=ON;
							}
						    else
						    {								
								mfc_step=P_MFC_RECEBE_GRUPO_I;
						    }
						}//if (grupo_a == e1->a_XX)
						
						grupo_a=0;
					}
				}
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//.......
					//chama reset da placa
					card = ports_info[e1->port-1].card;
					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 12");
					dg_ReSync(card);
				}
				break;


		case P_MFC_RECEBE_ID:
				if (timeout!=tmr_h)
				{
					if ((mfci>=1)&&(mfci<=15))
					{
						if (mfci>=11)    //fim de numero(15) ou indisponivel(12) - qquer coisa > 11
						{
							cid_received = 1;
							
							e1->rx_id_number_of_digits=(char)id_count;
							a5=OFF;

							grupo_a = 0;  //zerar grupo_a para evitar que gere outro A-5 e esperar que
										//a aplicacao diga o que fazer

							//enviar evento RECEBEU_ID
							mfc_step=P_MFC_ENVIA_GRUPO_A;
							//digivoice_entercriticalsection(&port_mutex[e1->port-1]);
								//envia msg reentrante
							//	dg_InsertE1Fifo(e1->port,C_ID_RECEIVED,0);
							//digivoice_leavecriticalsection(&port_mutex[e1->port-1]);
							if (e1->rx_total_remaining > 0)
							{
								e1->rx_number_of_digits = e1->rx_total_remaining;
								e1->rx_total_remaining = 0;
								write_debug_e1(e1->port,"(%d) r2: Recebeu que deve esperar %d digitos",e1_events.port, e1->rx_number_of_digits);
								rx_count = 0;
								if(grupo_c)
									grupo_a = e1->c_send_next_dnis_prepare_group_a;//C_SEND_NEXT_DNIS_PREPARE_GROUP_A;
                                else
									grupo_a = e1->a_send_next;//A_SEND_NEXT;
							}
							else
								if ((e1->rx_total_remaining == 0) && (e1->rx_total_of_digits > 0)) //pede categoria
									if (e1->send_id_digit_pos > 0)
										grupo_a = e1->a_send_cat_prepare_group_b;

							RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_ID_RECEIVED,  0, e1_events.port,&port_mutex[e1->port-1]);
							RaiseEvents_ThreadSafe(EV_CALLERID, e1->rx_id_number_of_digits ,  0, e1_events.port,&port_mutex[e1->port-1]);
							trata_mfc++;
						}
						else
 						{
								//write_debug_e1(e1->port,"e1: P_MFC_RECEBE_ID - Enviando 5");
								digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								if(grupo_c)
									mfco=dg_GenerateMF(e1->port, GENERATE_MFT, (char)e1->c_send_next_ani/*C_SEND_NEXT_ANI*/);//pede proximo ID
                                else
								    mfco=dg_GenerateMF(e1->port, GENERATE_MFT, (char)e1->a_send_cat_and_callerid/*A_SEND_CAT_AND_CALLERID*/);//pede proximo ID
								    
								digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

								write_debug_e1(e1->port,"Sending MFT signal ----------------------------------------------------------------->         5");
								//write_debug_e1(e1->port,"e1 (%d): P_MFC_RECEBE_ID->GENERATE_MFT 5",e1->port);
								e1->rx_id_digits[id_count++]=(char)mfci;
								mfc_step=P_MFC_AGUARDA_FIM_ID;
						}
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
					}
				}
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
					//chama reset da placa
					card = ports_info[e1->port-1].card;
					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 13");
					dg_ReSync(card);
				}
				break;
			case P_MFC_AGUARDA_FIM_ID:
				if (timeout!=tmr_h)
				{
					if (mfci==CP_SILENCE)
					{
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							mfco=dg_GenerateMF (e1->port, GENERATE_OFF, 0);/* para de enviar sinal para tras */
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);

						if (a5==ON)
							mfc_step=P_MFC_RECEBE_ID;
						else
							mfc_step=P_MFC_ENVIA_GRUPO_A;
					}
				}
				else
				{
					//encerra ligacao timeout

					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;

					//chama reset da placa
					card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 14");
					dg_ReSync(card);
				}
				break;
		case P_MFC_RECEBE_CATEGORIA:
				write_debug_e1(e1->port,"P_MFC_RECEBE_CATEGORIA");
				if (timeout!=tmr_h)
				{
						if ((mfci>=1)&&(mfci<=15))
						{
							mfc_step=P_MFC_ENVIA_GRUPO_B;
							grupo_b = 0;  //zera pra ficar esperando dado da aplicacao
							// gerar envento CATEGORIA
							digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
								dg_InsertE1Fifo(e1->port,C_GROUP_II,(unsigned short)mfci);
							digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
							write_debug_e1(e1->port,"P_MFC_RECEBE_CATEGORIA, vai gerar EV_E1CHANGESTATUS");
							//gerar evento C_PEDE_GRUPO_B
							//dg_insert_callctrl_fifo(e1->port,C_PEDE_GRUPO_B,mfci);
							RaiseEvents_ThreadSafe(EV_E1CHANGESTATUS, C_GRUPO_B,  0, e1_events.port,&port_mutex[e1->port-1]);
							trata_mfc++;
							tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						}
				}
      			else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;

					//chama reset da placa
					 card = ports_info[e1->port-1].card;

					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 15");
					dg_ReSync(card);
				}
				break;
			case P_MFC_ENVIA_GRUPO_B:
				if (timeout!=tmr_h)
				{
					if (grupo_b)
					{
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						write_debug_e1(e1->port,"e1 (%d): P_MFC_ENVIA_GRUPO_B =",e1->port,grupo_b);
						digivoice_entercriticalsection(&port_mutex[e1->port-1], e1->port);
							mfco=dg_GenerateMF(e1->port, GENERATE_MFT, grupo_b);
						digivoice_leavecriticalsection(&port_mutex[e1->port-1], e1->port);
						write_debug_e1(e1->port,"Sending MFT signal ----------------------------------------------------------------->         %x",grupo_b);

						mfc_step=P_MFC_FIM;
						grupo_b=0;
					}
				}
				else
				{
					//encerra ligacao timeout
					// termina sinalizacao MFC
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;
				}
				break;
		case P_MFC_RECEBE_GRUPO_I:
				if (timeout!=tmr_h)
				{
				if ((mfci>=1)&&(mfci<=15))
					{
						// gerar envento GRUPO I
						mfc_step=P_MFC_ENVIA_GRUPO_A;
						tmr_h=set_e1_timeout(e1->port,e1->timeout_mff);
						trata_mfc++;
						//dg_insert_callctrl_fifo(e1->port,C_GROUP_I, mfci);
						//...precisa implementar este evento

					}
				}
				else
				{
					//encerra ligacao timeout
					termina_libera(e1->port,1,&mfc_step,&r2_step);
					line_state = OFF;

					//chama reset da placa
					card = ports_info[e1->port-1].card;
					if (card==0) card=1;
					//write_debug_e1(e1->port,"resync ponto 16");
					dg_ReSync(card);
				}
				break;
			}//fim do mfc
			trata_mfc--;
		} //while trata_mfc

		//write_debug_e1(e1->port,"E1 fim do while - port %d",e1->port);
	}//fim fo while(1)
	e1->enabled = 0;
	write_debug_e1(e1->port,"E1 for port %d closed",e1->port);
		//close fifos
#ifdef __LINUX__
	close(ports_info[e1->port-1].fifo_to_e1);
	
#else 
	//destroi os eventos
	CloseHandle(ports_info[e1->port-1].e1_info.E1Event.hEvent);
#endif

#ifdef __LINUX__
	close(fifo_rx);
#endif
	//
	e1->thread_id = 0;
}




/***************************************************************************
 *                                                                         *
 *   VoicerLib															   *
 *                                                                         *
 *   Copyright (c) 2005, Digivoice Tecnologia em Eletronica Ltda           *
 *                                                                         *
 *   Module: Idle Functions                                                *
 *                                                                         *
 *   Description: Implements IdleXXXX functions used in version 2 ActiVeX  *
 *                                                                         *
 *   Author: Paulo Garcia                                                  *                                                
 *   paulo@digivoice.com.br                                                *
 *                                                                         
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *   
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *   
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************/

#include "generic.h"
#include "vlibdef.h"
#include "voicerlib.h"


#include <fcntl.h>
#ifdef __LINUX__
	#include <pthread.h>
	#include <unistd.h>
  #include <string.h>
	#include <stdio.h>
  #include <stdarg.h>
#else
	#include <math.h>

#endif

//extern DIGIVOICE_CRITICAL_SECTION mtx_insert_to_idle;

//machine states
enum {
	IDLE_NONE,
	IDLE_RECEIVING_DTMF,
	IDLE_RINGING,
	IDLE_START_AFTERANSWER_GETDIGITS,
	IDLE_HANDLE_AFTERPICKUP_DIGITS,
	IDLE_RECEIVING_DTMF_AFTER_ANSWER,
	IDLE_CONVERSATION
};


int set_idle_timeout(int,int);
unsigned int last_tick_idle=0;

#ifdef WIN32

#ifdef _DEBUG
//------------------------------------------------------------------------
//  inline function to write a log file: cp-(canal).log
//------------------------------------------------------------------------
__forceinline int __cdecl write_debug_idle(short port,const char *s, ...)
{

	FILE *pdebug;
	time_t curSecs;
	struct tm *now;
	char szTemp[200];
	char szFileName[200];
	va_list argp;
	int retval=0;
	unsigned int tick;

	if (port>60)
		return 0;

	curSecs = time(NULL);
	now = localtime(&curSecs);
	tick = GetTickCount();
	sprintf(szTemp,"<%02d:%02d:%02d:%06d>",now->tm_hour, now->tm_min, now->tm_sec,tick-last_tick_idle);
	last_tick_idle=tick;
       va_start(argp, s);
	sprintf(szFileName,"c:\\log\\idle-%d.log",port);
	pdebug=fopen(szFileName,"a+");
	if (pdebug!=NULL)
	{
		fprintf(pdebug,"%s-",szTemp);
		retval = vfprintf( pdebug, s, argp);
		fprintf(pdebug,"\n");
                //let somebody else do the work
		fclose(pdebug);
	}
	va_end(argp);

	return retval;
}
#else
__forceinline void __cdecl write_debug_idle(short port,const char *s, ...)
{

}
#endif
#else
	//LINUX
#ifdef DEBUG
		void write_debug_idle(short port,char *fmt, ...)
		{
			va_list argptr;
			int     ret;
			FILE    *f;
			time_t curSecs;
			struct tm *now_dbg;
			char szdbgtemp[200];
			char szFileName[200];

			curSecs = time(NULL);				\
			now_dbg = localtime(&curSecs);	\
			sprintf(szdbgtemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);						\

			va_start(argptr, fmt);
			sprintf(szFileName,"/var/log/voicerlib/idle-%d.log",port);
			f = fopen(szFileName, "a+");
			fprintf(f,"%s-",szdbgtemp);
			ret = vfprintf(f,fmt,argptr);
			fprintf(f,"\n");
			fclose(f);
			
			va_end(argptr);
}

#else
		void write_debug_idle(short port,char *fmt, ...)
		{

		}
#endif	//debug	- linux

#endif


//------------------------------------------------------------------------
// function to set channel timeout
//------------------------------------------------------------------------
int set_idle_timeout(int port,int t)
{
	int ret;
	digivoice_entercriticalsection(&port_mutex[port-1], port);

 	tmr_IdleThread[port-1].Enabled = FALSE;
 	SetEnableTimer(&tmr_IdleThread[port-1],FALSE);
 	tmr_IdleThread[port-1].Interval = t / FACTOR_TIMER;

 	if (t!=0)
 	{
		ret = (int)SetEnableTimer(&tmr_IdleThread[port-1],TRUE);
		tmr_IdleThread[port-1].Enabled = TRUE;
 	}
 	else
		ret = -1;

	digivoice_leavecriticalsection(&port_mutex[port-1], port);
	return ret;
}

//------------------------------------------------------------------------
// Thread - Call Progress
//------------------------------------------------------------------------
void Idle_Thread(void *idle_info)
{
 dg_idle_structure *idle; //call progress parameters structure
 dg_event_data_structure     cp_events; //event passing structure

#ifdef __LINUX__
 int fifo_cp;
#else
 HANDLE fifo_cp;
 u32 cbBytesRead;
#endif

 int timeout=0;
 int tmr_h;		//global timeout

 char cFinal;
 short nSt = IDLE_NONE;
 char  cDig;
 short	nDigitCount;						//received digits counter
 short repeat=1;

 idle = (dg_idle_structure *)idle_info;


//create fifo
#ifdef __LINUX__
       fifo_cp = open(idle->szFifoToIdle,O_RDONLY);
/*       if (fifo_cp==0)
       {
					write_debug("Error openning idle fifo....");
       }*/
#else
	fifo_cp	= CreateFile(idle->szFifoToIdle, GENERIC_READ | GENERIC_WRITE,
					 0,	NULL, OPEN_EXISTING, 0,NULL);
#endif

	//initialized variables
	nDigitCount = 0;
	idle->bHookOff	= 0;

	//infinite loop
	while(1)
	{

         //get fifo events
#ifdef __LINUX__
	 read(fifo_cp,&cp_events,sizeof(cp_events));
#else
	//windows
	 WaitForSingleObject(idle->oOverlapIdle.hEvent,INFINITE);
	 ReadFile(fifo_cp,                      // handle to pipe
			&cp_events,             // buffer to receive data
			sizeof(cp_events),       // size of buffer
			&cbBytesRead,           // number of bytes read
			&idle->oOverlapIdle);       // not overlapped I/O

#endif
	//reset values
	timeout = 0;
	tmr_h = 1;//tmr_h <> timeout at 4.0.9.9

		write_debug_idle(idle->port,"IDLE (%d): Receiving cmd: %x - data: %x",
																							 idle->port,
                                               cp_events.command,
																							cp_events.data );

	 //terminates thread
	 if (cp_events.command == C_ENDTHREAD)
	 {
	 		//cancel thread execution
			write_debug_idle(idle->port,"Ending idle thread...");
			break;
	 }

	 switch(cp_events.command)
	 {
			case C_RESET_THREAD:
				//reseta os estados da thread
				write_debug_idle(idle->port,"CALL PROGRESS RESET");				

				tmr_h=set_idle_timeout(idle->port,0);/*aaa*/
				break;
			case C_TIMEOUT:
				tmr_h=set_idle_timeout(idle->port,0);//timeout = (int) cp_events.data; at 4.0.9.9
				nSt = IDLE_NONE;				
				//reset counter
				nDigitCount = 0;
				
				write_debug_idle(idle->port,"cp (%d): C_TIMEOUT com dado %d - nCpi=%x ",				

						idle->port,
						timeout,
						cp_events.data);

				break;
			case EV_LINEOFF:
				//lineoff when in lineoff means ring -- until firmware is not fixed
				/* rem at 4.0.9.9 if (!idle->bHookOff)
				{
					dg_InsertIdleFifo(idle->port, EV_RINGS, cp_events.data);
					break;
				}*/

				write_debug_idle(idle->port,"EV_LINEOFF: Estado=%x", nSt);				

				//restart counters, reset timers, etc
				idle->bHookOff = 0;
				idle->nRingCount = 0;
				tmr_h = set_idle_timeout(idle->port,0);
				dg_CancelGetDigits(idle->port);
				//also cancel afterpickup timer 
				SetEnableTimer(&tmrAfterPickUp[cp_events.port-1],FALSE);


				nSt = IDLE_NONE;
                switch(ports_info[idle->port-1].idle_info.nFormat)
                {
                    case dtMFP:
                        dg_SetDetectionType(idle->port,DETECT_MFF,DG_ENABLE);	//MFF -  mesmo MFP
                        break;
                    default:
                        dg_SetFastDetection(idle->port,DG_ENABLE);
                        dg_SetDetectionType(idle->port,DETECT_DTMF,DG_ENABLE);
                        break;
                }
				
				break;
			case EV_LINEREADY:
				//answered - modif. to 4.0.7.5
				if (!idle->bHookOff)
				{
					idle->bHookOff = 1;

					switch(ports_info[idle->port-1].idle_info.nFormat)
					{
						case dtMFP:
							dg_SetDetectionType(idle->port,DETECT_MFF,DG_ENABLE);	//MFF - same as MFP
							break;
						default:
							dg_SetFastDetection(idle->port, DG_DISABLE);
							dg_SetDetectionType(idle->port,DETECT_DTMF,DG_ENABLE);
							break;
					}

					if (idle->bWatchTrunkAfter)
						//pickup command was called manually by user and needs to start getdigits
						nSt = IDLE_START_AFTERANSWER_GETDIGITS;
					else
						//nSt = IDLE_HANDLE_AFTERPICKUP_DIGITS;
						nSt = IDLE_CONVERSATION;	

					write_debug_idle(idle->port,"EV_LINEREADY: Estado=%x", nSt);
					
					
				}
				break;
			case EV_RINGS:				
				if (nSt != IDLE_CONVERSATION)
					nSt = IDLE_RINGING;
				break;
			case EV_DTMF:				
				if (nSt != IDLE_CONVERSATION)
					nSt = IDLE_RECEIVING_DTMF;
				cDig = (char)cp_events.data;
                write_debug_idle(idle->port, "EV_DTMF foi %c", cDig);

				break;
			case EV_DIGITSRECEIVED:	//getdigits response				
				if (nSt != IDLE_CONVERSATION)
					nSt = IDLE_HANDLE_AFTERPICKUP_DIGITS;
				break;
	 } //switch

	 repeat=1;
	 while (repeat)
	 {
		switch(nSt)
		{
			case IDLE_RINGING:
				write_debug_idle(idle->port,"IDLE_RINGING");				
				if (tmr_h == timeout)
				{
					idle->nRingCount = 0;
					tmr_h = set_idle_timeout(idle->port,0);
				}
				else
				{
					idle->nRingCount++;
					tmr_h = set_idle_timeout(idle->port,7000);
					if (idle->nRingCount>=idle->nRingsToAnswer && idle->bAutoPickUp)
					{
						tmr_h = set_idle_timeout(idle->port,0);
						if (!idle->bWatchTrunkAfter)
							dg_PickUp(cp_events.port,idle->nPauseAfterPickUp);
						else
						{
							//call pickup withouy afterpickup event
							dg_PickUp(cp_events.port,-1);							
							//start after pickup dtmf monitoring
							nSt = IDLE_START_AFTERANSWER_GETDIGITS; 
							repeat++;	//force repeat loop
						}
					}
				} //else timeout
				break;
			case IDLE_RECEIVING_DTMF:
				write_debug_idle(idle->port,"IDLE_RECEIVING_DTMF - %c", cDig);				
				if (tmr_h == timeout)
				{
                    write_debug_idle(idle->port,"IDLE_RECEIVING_DTMF - Timeout - resseting counter when counter=%d",nDigitCount);					
					//reset counter
					nDigitCount = 0;
					tmr_h = set_idle_timeout(idle->port, 0);
					nSt = IDLE_NONE;
				}
				else
				{
					//This handling is done only before the first ring
					if (!idle->bHookOff && idle->bWatchTrunkBefore)
					{
							if (idle->nFormat == wtDTMF)
								cFinal = 'C';
							else
								if (idle->nFormat == wtMFP)
									cFinal = '#';
								else
								{
									//wtCustom handling
									//cFinal will hold the correct char 
									cFinal = *(strchr(idle->sTermDigit,cDig));
								}
							if (cDig != cFinal)
							{
								write_debug_idle(idle->port,"CALLERID TEMP 1 = %s",idle->sDigitsDetected);								
								idle->sDigitsDetected[nDigitCount++] = cDig;
								//set 2s timeout between dtmf
								tmr_h = set_idle_timeout(idle->port, idle->TimeOut);
								write_debug_idle(idle->port,"CALLERID TEMP 2 = %s",idle->sDigitsDetected);								
							}
							else
							{
								tmr_h = set_idle_timeout(idle->port,0);
                                write_debug_idle(idle->port,"PEGOU CALLERID 1 = %s",idle->sDigitsDetected);								
								//probabily this is an caller id then, raise event
								strlcpy(idle->sDigitsDetected, idle->sDigitsDetected+1, strlen(idle->sDigitsDetected));
								//idle->sDigitsDetected[strlen(idle->sDigitsDetected) -2] = 0;
                                write_debug_idle(idle->port,"PEGOU CALLERID 2 = %s",idle->sDigitsDetected);								
								idle->sNameDetected[0] = '\0';
								RaiseEvents_ThreadSafe(EV_CALLERID,0,  0,cp_events.port,&port_mutex[idle->port-1]);  									
								//reset counter
								nDigitCount = 0;
							}
						
					}
				} //else timeout    
				break;
			case IDLE_START_AFTERANSWER_GETDIGITS:
				write_debug_idle(idle->port,"IDLE_START_AFTERANSWER_GETDIGITS");				
				//call getdigits using PauseAfterPickup as global timeout and 
				//Timeout as interdigit timeout
				dg_GetDigits(cp_events.port,idle->nStringMaxSize, idle->sTermDigit,
											idle->nPauseAfterPickUp, idle->TimeOut);

				//set a security timeout with pause after plus 5 secs
				tmr_h = set_idle_timeout(idle->port,idle->nPauseAfterPickUp+5000);
				nSt = IDLE_RECEIVING_DTMF_AFTER_ANSWER;
				break;
			case IDLE_RECEIVING_DTMF_AFTER_ANSWER:
				write_debug_idle(idle->port,"IDLE_RECEIVING_DTMF_AFTER_ANSWER");				
				//watch trunk after
				if (tmr_h == timeout)
				{
					tmr_h = set_idle_timeout(cp_events.port,0);
					nSt = IDLE_NONE;
				}
				break;
			case IDLE_HANDLE_AFTERPICKUP_DIGITS:
				write_debug_idle(idle->port,"IDLE_HANDLE_AFTERPICKUP_DIGITS");				
				//handle getdigits response
				//force afterpickup event 1,5s after getdigits response
				tmrAfterPickUp[cp_events.port-1].Interval = 1000 / FACTOR_TIMER;
				SetEnableTimer(&tmrAfterPickUp[cp_events.port-1],TRUE);
				//conversation avoids handling after afterpickup
				nSt = IDLE_CONVERSATION;
				break;
		} //switch
		repeat--;
	 } //while

  } //fim fo while(1)
		//close fifos
#ifdef __LINUX__
		close(ports_info[idle->port-1].fifo_to_idle);
#else
		//destroi os eventos
		CloseHandle(ports_info[idle->port-1].idle_info.IdleEvent.hEvent);
#endif
#ifdef __LINUX__
	close(fifo_cp);
#endif
	idle->thread_id = 0;
	idle->enabled = 0;
}





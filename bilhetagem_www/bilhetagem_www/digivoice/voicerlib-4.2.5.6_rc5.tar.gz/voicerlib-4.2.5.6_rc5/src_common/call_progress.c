/***************************************************************************
 *                                                                         *
 *   VoicerLib															   *
 *                                                                         *
 *   Copyright (c) 2005, Digivoice Tecnologia em Eletronica Ltda           *
 *                                                                         *
 *   Module: Call Progress                                                 *
 *                                                                         *
 *   Description: Implements call_progress thread                          *
 *                                                                         *
 *   Author: Armando Porto                                                 *
 *   armando@digivoice.com.br                                              *
 *                                                                         *
 *   This library is free software; you can redistribute it and/or
 *   modify it under the terms of the GNU Lesser General Public
 *   License as published by the Free Software Foundation; either
 *   version 2.1 of the License, or (at your option) any later version.
 *   
 *   This library is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *   Lesser General Public License for more details.
 *   
 *   You should have received a copy of the GNU Lesser General Public
 *   License along with this library; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 **************************************************************************/

#include "generic.h"
#include "call_progress.h"
#include "vlibdef.h"
#include "voicerlib.h"

#include <fcntl.h>
#include <math.h>
#include <assert.h>

#ifdef __LINUX__
	#include <unistd.h>
	#include <stdarg.h>
#else
	
#endif

#ifdef __LINUX__
	extern void write_debug(char *fmt, ...);
#endif

unsigned int last_tick=0;


//extern DIGIVOICE_CRITICAL_SECTION mtx_insert_to_cp;

int set_cp_timeout(int,int);

#ifdef WIN32

#ifdef _DEBUG
//------------------------------------------------------------------------
//  inline function to write a log file: cp-(canal).log
//------------------------------------------------------------------------
__forceinline int __cdecl write_debug_cp(short port,const char *s, ...)
{
	
	FILE *pdebug;
	time_t curSecs;
	struct tm *now;
	char szTemp[200];
	char szFileName[200];
	va_list argp;
	int retval=0;
	unsigned int tick;

	curSecs = time(NULL);
	now = localtime(&curSecs);
	tick = GetTickCount();
	sprintf(szTemp,"<%02d:%02d:%02d:%06d>",now->tm_hour, now->tm_min, now->tm_sec,tick-last_tick);
	last_tick=tick;
      va_start(argp, s);
	sprintf(szFileName,"c:\\log\\cp-%d.log",port);
	pdebug=fopen(szFileName,"a+");
	if (pdebug!=NULL)
	{
		fprintf(pdebug,"%s-",szTemp);
		retval = vfprintf( pdebug, s, argp);
		fprintf(pdebug,"\n");
                //let somebody else do the work
		fclose(pdebug);
	}
	va_end(argp);

	return retval;
}
#else
__forceinline void __cdecl write_debug_cp(short port,const char *s, ...)
{
	
}
#endif
#else
	//LINUX
#ifdef DEBUG
	void write_debug_cp(short port,char *fmt, ...)
	{

			va_list argptr;
			int     ret;
			FILE    *f;
			time_t curSecs;
			struct tm *now_dbg;
			char szdbgtemp[200];
			char szFileName[200];	
			
			curSecs = time(NULL);				\
			now_dbg = localtime(&curSecs);	\
			sprintf(szdbgtemp,"<%02d:%02d:%02d>",now_dbg->tm_hour, now_dbg->tm_min, now_dbg->tm_sec);						\
		
			va_start(argptr, fmt);
			sprintf(szFileName,"/var/log/voicerlib/cp-%d.log",port);	
			f = fopen(szFileName, "a+");
			fprintf(f,"%s-",szdbgtemp);	
			ret = vfprintf(f,fmt,argptr);
			fprintf(f,"\n");	
			fclose(f);
			assert(ret != 0);
		
			va_end(argptr);
	}

#else
	void write_debug_cp(short port,char *fmt, ...) 
	{
	}
#endif	//debug	- linux

#endif


//------------------------------------------------------------------------
// function to set channel timeout
// due to timer resolution is 100ms t should be tested for values less then 100
//------------------------------------------------------------------------
int set_cp_timeout(int port,int t)
{
	int ret;
	if((t>0) && (t<100))
		t=100;
	digivoice_entercriticalsection(&port_mutex[port-1], port);
 	tmr_CPThread[port-1].Enabled = FALSE;
 	SetEnableTimer(&tmr_CPThread[port-1],FALSE);
 	tmr_CPThread[port-1].Interval = t / FACTOR_TIMER;

 	if (t!=0)
 	{
		ret = (int)SetEnableTimer(&tmr_CPThread[port-1],TRUE);
		tmr_CPThread[port-1].Enabled = TRUE;
 	}
 	else
		ret = -1;

 digivoice_leavecriticalsection(&port_mutex[port-1], port);
 return ret;
}
//------------------------------------------------------------------
// Function to set audio timeout to detect answer
// due to timer resolution is 100ms t should be tested for values less then 100
//------------------------------------------------------------------
int set_audio_timeout(int port,int t)
{
	int ret;
	if((t>0) && (t<100))
		t=100;
	digivoice_entercriticalsection(&port_mutex[port-1], port);
 	tmr_CP_AudioCtrl[port-1].Enabled = FALSE;
 	SetEnableTimer(&tmr_CP_AudioCtrl[port-1],FALSE);
 	tmr_CP_AudioCtrl[port-1].Interval = t / FACTOR_TIMER;

 	if (t!=0)
 	{

		ret = (int)SetEnableTimer(&tmr_CP_AudioCtrl[port-1],TRUE);
		tmr_CP_AudioCtrl[port-1].Enabled = TRUE;
		
 	}
 	else
		ret = -1;

 digivoice_leavecriticalsection(&port_mutex[port-1], port);

 return ret;
}

//-----------------------------------------------
//get the current windows tick count
//-----------------------------------------------
void get_now(void *cp_info)

{
 dg_call_progress_thread_structure *cp; //call progress parameters structure
 cp = (dg_call_progress_thread_structure *)cp_info;

 cp->ulTimeNow = digivoice_gettick();

}

//-----------------------------------------------
//get the current delay from get_now
//-----------------------------------------------
u32 get_diff(void *cp_info)

{
 unsigned long ulTemp;
 dg_call_progress_thread_structure *cp; //call progress parameters structure
 cp = (dg_call_progress_thread_structure *)cp_info;


 ulTemp = digivoice_gettick();
 if(ulTemp < cp->ulTimeNow)
 {
	 
    return (u32)((pow(2,32)-1)-cp->ulTimeNow+ulTemp);
 }
 else
 	return (ulTemp-cp->ulTimeNow);
}

//------------------------------------------------------------------------
// Thread - Call Progress
//------------------------------------------------------------------------
void Call_Progress_Thread(void *cp_info)
{
 dg_call_progress_thread_structure *cp; //call progress parameters structure
 dg_event_data_structure     cp_events; //event passing structure

#ifdef __LINUX__
 int fifo_cp;
#else
 HANDLE fifo_cp;
 u32 cbBytesRead;
#endif

 u32 ulTimer1=0L;
 int timeout=0;
 int tmr_h;		//global timeout

 int timeout_audio=0;
 int tmr_haudio=0;  //timeout audio

 //----------------------
	int i;
	int j;
	int nA,nEnable=-1;
	int nCicles;
    int nBusyCount=0;
	int nAudio;
	unsigned long ulTone[4];
	int nSt;
//-----------------------



 cp = (dg_call_progress_thread_structure *)cp_info;


//-------------------------------------------------------------
//for tests purposes
//
	/*cp->nAnswerSensitivity = 3;
	cp->nGenericToneTimeout = 15000;		//ms
	cp->nGenericToneTime = 500; 			//ms
	cp->nLineToneTimeout = 15000;			//ms
	cp->nLineToneTime = 1500;			//ms must be greater than ulBusyMaxTime
	cp->nFaxToneTimeout = 60000;			//ms
	cp->nFaxToneTime = 1500;			//ms must be greater than ulBusyMaxTime

	cp->nCallProgressTimeout = 15000;		//ms

	cp->ulBusyMinTime = 100; 			//ms
	cp->ulBusyMaxTime = 600; 			//ms

	cp->ulCallingMinToneTime = 700; 		//ms should be greater than ulBusyMaxTime
	cp->ulCallingMaxToneTime = 2500; 		//ms

     	cp->ulCallingMinSilTime = 700; 		//ms
	cp->ulCallingMaxSilTime = 5000; 		//ms

	cp->ulToneInterruptionMinTime = 20;		//ms
	cp->ulToneInterruptionMaxTime = 350;      //ms

	cp->ulLineToneMinTime = 1000; 			//ms
	cp->ulLineToneMaxTime = 2500;			//ms	
*/

//-------------------------------------------------------------

	
//create fifo
#ifdef __LINUX__
       fifo_cp = open(cp->szFifoToCP,O_RDONLY);
       if (fifo_cp==0)
       {
			write_debug_cp(cp->port,"Error openning fifo....");
       }
#else
	fifo_cp	= CreateFile(cp->szFifoToCP, GENERIC_READ | GENERIC_WRITE,
					 0,	NULL, OPEN_EXISTING, 0,NULL);
#endif
	write_debug_cp(cp->port,"1....");
	nSt=CP_ST_INIT;
	nCicles=0;
    nBusyCount=0;
	nAudio=0;
	for(j=0;j<4;j++)
	    ulTone[j]=0l;
	ulTimer1=0;
    write_debug_cp(cp->port,"2....");
    cp->thread_ready = 1;
    write_debug_cp(cp->port,"3....");
 while(1)
 {
     //get fifo events

	 write_debug_cp(cp->port,"4....");
#ifdef __LINUX__
	 read(fifo_cp,&cp_events,sizeof(cp_events));
	 write_debug_cp(cp->port,"callprogress (%d) : read cmd: %x - data: %x",cp_events.command,cp_events.data);
#else
	//windows
	 WaitForSingleObject(cp->oOverlapCP.hEvent,INFINITE);
	 ReadFile(fifo_cp,                      // handle to pipe
			&cp_events,             // buffer to receive data
			sizeof(cp_events),       // size of buffer
			&cbBytesRead,           // number of bytes read
			&cp->oOverlapCP);       // not overlapped I/O

	write_debug_cp(cp->port,"CPEvent (%d): Receiving event %x - cmd: %x - data: %x",cp->port,cp->CPEvent.hEvent,
                                               cp_events.command,cp_events.data );
#endif
	//reset values
	timeout = 0;

	 //terminates thread
	 if (cp_events.command == C_ENDTHREAD)
	 {
	 		//cancel thread execution
			write_debug_cp(cp->port,"Ending Call Progress thread...");
			break;
	 }


	 switch(cp_events.command)
	 {
			case C_AUDIO:				//digits or silence
				nA = cp_events.data;
				//if a signal different of CP_AUDIO was received, reset the audio timeout timer
				if ((nA!=CP_AUDIO) && (nA != CP_SILENCE))
				{
					write_debug_cp(cp->port,"C_AUDIO--NOT AUDIO OR SILENCE zerou timer");
					nAudio = 0;
					tmr_haudio = set_audio_timeout(cp->port,0);
					/*if (cp->answer_enabled)
					{
						cp->ulTimeStartAudio = 0;
						write_debug_cp(cp->port,"ANSWERED por audio com tempo minimo");
						RaiseEvents_ThreadSafe(EV_ANSWERED,AUDIO_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);  //answer ??
					}*/

/*					if (cp->ulTimeStartAudio>0)
					{
						if ( (digivoice_gettick() - cp->ulTimeStartAudio) > cp->nAnswerSensitivityTime)  //TODO: customizar
						{
							if (cp->answer_enabled)
							{
								cp->ulTimeStartAudio = 0;
								write_debug_cp(cp->port,"ANSWERED por audio com tempo minimo");
								RaiseEvents_ThreadSafe(EV_ANSWERED,AUDIO_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);  //answer ??
							}
						}
					}*/
					cp->ulTimeStartAudio = 0;
				}
				break;
			case C_SET_CALLPROGRESS:	//configura tipo de deteccao
				//-------------------------------------
				//initialise tone detection parameters
				//-------------------------------------
				if ((cp_events.data==CP_ENABLE_ALL)||(cp_events.data==CP_ENABLE_GENERIC_TONE) 
					||(cp_events.data==CP_ENABLE_LINETONE_OR_BUSY)||(cp_events.data==CP_ENABLE_BUSY_OR_FAX))
 				{
					nEnable = cp_events.data;
	   				nSt=CP_ST_INIT;
					nCicles=0;
					nAudio=0;
	   				for(j=0;j<4;j++)    
	      				ulTone[j]=0l;
					ulTimer1=0;
					
					//4.0.9.1
					nBusyCount=0;
				}else
				{
					if (cp_events.data==CP_DISABLE)
					{
						tmr_h=set_cp_timeout(cp->port,0); //stop timer	
						nEnable = cp_events.data;
					}
				}
				break;
			case C_RESET_THREAD:
				//reseta os estados da thread
				write_debug_cp(cp->port,"CALL PROGRESS RESET");

				tmr_h=set_cp_timeout(cp->port,0);/*aaa*/

				break;

			case C_TIMEOUT_AUDIO:
				timeout_audio = (int) cp_events.data;
				write_debug_cp(cp->port,"cp (%d): C_TIMEOUT_AUDIO com dado %d - nCpi=%x ",
						cp->port,
						tmr_haudio,
						cp_events.data);

				if (timeout_audio == tmr_haudio)
				{
					tmr_haudio=set_audio_timeout(cp->port,0);
					if ((cp->answer_enabled) && (nAudio>=cp->nAnswerSensitivity))
					{
						write_debug_cp(cp->port,"ANSWERED por audio com timeout = %x", timeout_audio);
						RaiseEvents_ThreadSafe(EV_ANSWERED,AUDIO_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);  //answer ??
					}
				}
				else
				{
					write_debug_cp(cp->port,"C_TIMEOUT_AUDIO--zerou timer");
					tmr_haudio=set_audio_timeout(cp->port,0);
				}

				break;

			case C_TIMEOUT:
				timeout = (int) cp_events.data;
				write_debug_cp(cp->port,"cp (%d): C_TIMEOUT com dado %d - nCpi=%x ",
						cp->port,
						timeout,
						cp_events.data);

				break;
	 }


	if(nEnable == CP_ENABLE_GENERIC_TONE) //generic tone detection
	{
		switch(nSt)
		{
			case CP_ST_UNDEFINED:
				//check for timeout
				if(timeout == tmr_h)
				{
					write_debug_cp(cp->port,"CP_ENABLE_GENERIC_TONE->CP_ST_UNDEFINED: EV_TIMEOUT");
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					//teste de cvs linux e windows
					if (cp->answer_enabled)
						RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
						RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					nSt = CP_ST_INIT; //restart

				}
				else
				if((nA == cp->nToneType[T_GTONE])  || (nA == cp->nToneType[T_GTONE2])|| 
				   (nA == cp->nToneType[T_GTONE3]) || (nA == cp->nToneType[T_GTONE4])||
				   (nA == cp->nToneType[T_GTONE5]))
				{
					nSt=CP_ST_MEASURING_TONE;
					tmr_h=set_cp_timeout(cp->port,cp->nGenericToneTime);
				}
			break;

			case CP_ST_MEASURING_TONE:
				//check for timeout
				if(timeout == tmr_h)
				{
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					RaiseEvents_ThreadSafe(EV_GENERIC_TONE, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					nSt = CP_ST_INIT; //restart
				}
				else
					if((nA != cp->nToneType[T_GTONE]) && (nA != cp->nToneType[T_GTONE2])
						&& (nA != cp->nToneType[T_GTONE3]) && (nA != cp->nToneType[T_GTONE4])
						&& (nA != cp->nToneType[T_GTONE5]))
					{
						nSt = CP_ST_INIT; //restart
					}
                break;
  		}//switch
		if(nSt==CP_ST_INIT)
		{
			nSt=CP_ST_UNDEFINED;
			tmr_h=set_cp_timeout(cp->port,cp->nGenericToneTimeout); //max time to wait tone
			write_debug_cp(cp->port,"CP_ENABLE_GENERIC_TONE->CP_ST_INIT");
		}
 	}else
    if(nEnable == CP_ENABLE_LINETONE_OR_BUSY) //line tone & busy tone detection (before dialing or after flash)
	{
		switch(nSt)
		{

			case CP_ST_UNDEFINED:
				write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_UNDEFINED");
				//check for timeout
				if(timeout == tmr_h)
				{
					write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_UNDEFINED: EV_TIMEOUT");
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					if (cp->answer_enabled)
						RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
						RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					nSt = CP_ST_INIT; //restart

				}
				else
					if((nA == cp->nToneType[T_LINE]) || (nA == cp->nToneType[T_BUSY]))
					{
						write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_UNDEFINED: CP_ST_MEASURING_TONE (%x)", nA);
						nSt=CP_ST_MEASURING_TONE;
						tmr_h=set_cp_timeout(cp->port,cp->nLineToneTime);
						get_now(cp); //save tick count
					}
				//else do nothing
			break;

			case CP_ST_MEASURING_TONE:
				//check for timeout
				write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_MEASURING_TONE: CP_ST_MEASURING_TONE (%x)", nA);
				if(timeout == tmr_h)
				{
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					if(nA == cp->nToneType[T_LINE])
						RaiseEvents_ThreadSafe(EV_DIALTONE, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
						RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					nSt = CP_ST_INIT; //restart
				}
				else
					if(nA == cp->nToneType[T_SILENCE])
					{
						tmr_h=set_cp_timeout(cp->port,cp->nLineToneTimeout); //reset max time to wait tone
						ulTimer1 = get_diff(cp); 	 //get tone time
						for (i=3;i>0;i--) 		 //delay tone/silence time
							ulTone[i]=ulTone[i-1];
						ulTone[0]=ulTimer1;
						nCicles++;
						get_now(cp);
						nSt = CP_ST_MEASURING_SILENCE;
						write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_MEASURING_TONE: CP_ST_MEASURING_SILENCE");
					}
                    //else do nothing
					break;

			case CP_ST_MEASURING_SILENCE:
				//check for timeout
				write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_MEASURING_SILENCE: (%x)", nA);
				if(timeout == tmr_h)
				{
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					nSt = CP_ST_INIT; //restart
					write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_MEASURING_SILENCE: TIMEOUT ");	
				}
				else
				if((nA == cp->nToneType[T_LINE]) || (nA == cp->nToneType[T_BUSY]))
				{
					ulTimer1 = get_diff(cp);
					for (i=3;i>0;i--) //delay tone/silence time
						ulTone[i]=ulTone[i-1];
					ulTone[0]=ulTimer1;
					nCicles++;

					j=0;
					for (i=0;i<4;i++) //test cadence
						if((ulTone[i]<cp->ulBusyMinTime) || (ulTone[i]>cp->ulBusyMaxTime))
							j=1;
					if (j==0 && nCicles>2)	//tests for busy
					{
						tmr_h=set_cp_timeout(cp->port,0); //stop timer
						RaiseEvents_ThreadSafe(EV_BUSY, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
						nSt = CP_ST_INIT; //restart
						write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_MEASURING_SILENCE: BUSY - reset state ");	
					}
					else
					{
						nSt=CP_ST_MEASURING_TONE;
						tmr_h=set_cp_timeout(cp->port,cp->nLineToneTime);
						get_now(cp); //save tick count
						write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_MEASURING_SILENCE: NOT BUSY");	
					}
                }
                // else do nothing
                break;
  		}
		if (nSt==CP_ST_INIT)
		{
			write_debug_cp(cp->port,"LINETONE_OR_BUSY->CP_ST_INIT");
			nSt=CP_ST_UNDEFINED;
			tmr_h=set_cp_timeout(cp->port,cp->nLineToneTimeout);//max time to wait tone
			nCicles=0;
	   		for(j=0;j<4;j++)
	      		ulTone[j]=0l;
		}
 	}else
    if(nEnable == CP_ENABLE_BUSY_OR_FAX) //busy tone & Fax tone detection (after answering a call)
	{
		//TODO: Criar mecanismo de deteccao de secretaria eletronica e silencio
        //TODO: Retirar checagens de atendimento

		write_debug_cp(cp->port,"BUSY_OR_FAX-> nSt=%x nA=%x timeout=%x tmr=%x",nSt,nA,timeout,tmr_h);
		switch(nSt)
		{
			case CP_ST_UNDEFINED:
				//check for timeout
				if(timeout == tmr_h)
				{
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					if (cp->answer_enabled)
						RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
						RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					nSt = CP_ST_INIT; //restart
                    nBusyCount=0;
				}
				else
				if((nA == cp->nToneType[T_FAX1]) || (nA == cp->nToneType[T_FAX2]) || (nA == cp->nToneType[T_BUSY]))
				{
					write_debug_cp(cp->port,"BUSY_OR_FAX->CP_ST_INIT: CP_ST_UNDEFINED nA=%x - fax tone time=%d",nA,cp->nFaxToneTime);
					nSt=CP_ST_MEASURING_TONE;
                    if (nA == cp->nToneType[T_BUSY])
                        tmr_h=set_cp_timeout(cp->port,cp->ulBusyMaxTime);
                    else
                        tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTime);

					get_now(cp); //save tick count
				}
				//else do nothing
			break;

			case CP_ST_MEASURING_TONE:
				//check for timeout
				if(timeout == tmr_h)
				{
                    write_debug_cp(cp->port,"BUSY_OR_FAX->CP_ST_MEASURING_TONE nA=%x - fax tone time=%d busycount=%d",nA,cp->nFaxToneTime, nBusyCount);
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					if((nA == cp->nToneType[T_FAX1]) || (nA == cp->nToneType[T_FAX2]))
					{
						if (nA == cp->nToneType[T_FAX1])
							RaiseEvents_ThreadSafe(EV_FAX_CNG, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
						else
							RaiseEvents_ThreadSafe(EV_FAX_CED, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);

						RaiseEvents_ThreadSafe(EV_FAX, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					}
					else
					{
						if (cp->answer_enabled)
							RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
						else
							RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					}
					nSt = CP_ST_INIT; //restart
                    nBusyCount=0;
				}
				else
				if(nA == cp->nToneType[T_SILENCE])
				{
					write_debug_cp(cp->port,"BUSY_OR_FAX->CP_ST_MEASURING_TONE (SILENCE) nA=%x",nA);
					//tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTimeout); //reset max time to wait tone
                    if (nA == cp->nToneType[T_BUSY])
                        tmr_h=set_cp_timeout(cp->port,cp->ulBusyMaxTime);
                    else
                        tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTimeout);

					ulTimer1 = get_diff(cp); 	 //get tone time
					for (i=3;i>0;i--) 		 //delay tone/silence time
						ulTone[i]=ulTone[i-1];
					ulTone[0]=ulTimer1;
					nCicles++;
					get_now(cp);
					nSt = CP_ST_MEASURING_SILENCE;
                 }
                        //else do nothing
			break;

			case CP_ST_MEASURING_SILENCE:
				//check for timeout
				if(timeout == tmr_h)
				{
                	write_debug_cp(cp->port,"BUSY_OR_FAX->CP_ST_MEASURING_SILENCE - timeout nA=%x - nBusyCount=%d",nA, nBusyCount);
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					
					if (cp->answer_enabled)
						RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
						RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);

					nSt = CP_ST_INIT; //restart
                    nBusyCount=0;
				}
				else
				if((nA == cp->nToneType[T_BUSY]) || (nA == cp->nToneType[T_FAX1]) || (nA == cp->nToneType[T_FAX2]))
				{
		            write_debug_cp(cp->port,"BUSY_OR_FAX->CP_ST_MEASURING_SILENCE - nA=%x - BusyCount=%d",nA, nBusyCount);
					ulTimer1 = get_diff(cp);
					for (i=3;i>0;i--) //delay tone/silence time
						ulTone[i]=ulTone[i-1];
					ulTone[0]=ulTimer1;
					nCicles++;

					j=0;
					for (i=0;i<4;i++) //test cadence
						if((ulTone[i]<cp->ulBusyMinTime) || (ulTone[i]>cp->ulBusyMaxTime))
							j=1;
					if (j==0 && nCicles>2)	//tests for busy
					{
						tmr_h=set_cp_timeout(cp->port,0); //stop timer
                        nBusyCount++;
                        write_debug_cp(cp->port,"BUSY_OR_FAX->CP_ST_MEASURING_SILENCE - nA=%x - nBusyCount=%d",nA, nBusyCount);
                        if (nBusyCount >= cp->nBusySensibility) {

    						RaiseEvents_ThreadSafe(EV_BUSY, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
    						nSt = CP_ST_INIT; //restart
                            nBusyCount=0;
                        }
                        else
                        {
                            write_debug_cp(cp->port,"BUSY_OR_FAX->CP_ST_MEASURING_SILENCE - WAITING NEXT BUSY nA=%x - nBusyCount=%d",nA, nBusyCount);
                            nSt = CP_ST_INIT; //restart to wait another busies
                            //dont reset nBusyCount!!!!!
                        }

					}
					else
					{
						nSt=CP_ST_MEASURING_TONE;

						//tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTime);
                        if (nA == cp->nToneType[T_BUSY])
                            tmr_h=set_cp_timeout(cp->port,cp->ulBusyMaxTime);
                        else
                            tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTime);

						get_now(cp); //save tick count
					}
                }
                // else do nothing
				break;
  		}//switch
		if (nSt==CP_ST_INIT)
		{
			nSt=CP_ST_UNDEFINED;
			tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTimeout);//max time to wait tone
			nCicles=0;
	   		for(j=0;j<4;j++)
	      		ulTone[j]=0l;
		}


      }
      else
      if(nEnable == CP_ENABLE_ALL) //call progress after dialing
	  {
		//write_debug_cp(cp->port,"ALL-> nSt=%x nA=%x timeout=%x tmr=%x",nSt,nA,timeout,tmr_h);
		switch(nSt)
		{

			case CP_ST_UNDEFINED:
				//check for timeout
				if(timeout == tmr_h)
				{
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					if (cp->answer_enabled)
						RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
						RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);

					nSt = CP_ST_INIT; //restart
				}
				else
				if((nA == cp->nToneType[T_BUSY]) || (nA == cp->nToneType[T_CALLING]) ||
				   (nA == cp->nToneType[T_LINE]))
				{
					nSt=CP_ST_MEASURING_TONE;
					tmr_h=set_cp_timeout(cp->port,cp->ulLineToneMaxTime);
					get_now(cp); //save tick count
					write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_UNDEFINED->CP_ST_MEASURING_TONE (%x)",nA);
					nAudio=0;//reset nAudio
				}
				else
				{
					if((nA == cp->nToneType[T_FAX1]) || (nA == cp->nToneType[T_FAX2]))
					{
						nSt=CP_ST_MEASURING_TONE;
						tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTime);
						get_now(cp); //save tick count
						write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_UNDEFINED->FAX->CP_ST_MEASURING_TONE (%x)",nA);
					}
					else
					if(nA == cp->nToneType[T_AUDIO])
					{
						if (cp->nAnswerSensitivity == 0 )
						{
							write_debug_cp(cp->port,"CP_ENABLE_ALL->UNDEFINED-> nAnswerSensitivity == 0");
							RaiseEvents_ThreadSafe(EV_ANSWERED,AUDIO_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
						}
						else
						{
							write_debug_cp(cp->port,"CP_ENABLE_ALL->UNDEFINED-> nAnswerSensitivity <> 0");
							nAudio++;
			
							if(nAudio==cp->nAnswerSensitivity)
							{
								cp->ulTimeStartAudio = digivoice_gettick();  //guarda tempo atual
								write_debug_cp(cp->port,"CP_ENABLE_ALL->UNDEFINED->AUDIO");
								tmr_haudio=set_audio_timeout(cp->port,cp->nAnswerSensitivityTime); 

								//????? nSt = CP_ST_INIT; //restart

							}
						}
					}
					else
					if((nA == cp->nToneType[T_GTONE])|| (nA == cp->nToneType[T_GTONE2]) ||
					   (nA == cp->nToneType[T_GTONE3]) || (nA == cp->nToneType[T_GTONE4]) ||
					   (nA == cp->nToneType[T_GTONE5]))
					{
						nAudio = -1;
						//stay here
					}
					   
				}			

				//else do nothing
			break;

			case CP_ST_MEASURING_TONE:
				//check for timeout
				if(timeout == tmr_h)
				{
					write_debug_cp(cp->port,"CP_ENABLE_ALL->TImeout no CP_ST_MEASURING_TONE (%x)",nA);
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					if(nA == cp->nToneType[T_LINE])
						RaiseEvents_ThreadSafe(EV_DIALTONE, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
					if((nA == cp->nToneType[T_FAX1]) || (nA == cp->nToneType[T_FAX2]))
					{
						if (nA == cp->nToneType[T_FAX1])
							RaiseEvents_ThreadSafe(EV_FAX_CNG, 0,0, cp_events.port,&port_mutex[cp_events.port-1]);
						else
							RaiseEvents_ThreadSafe(EV_FAX_CED, 0,0, cp_events.port,&port_mutex[cp_events.port-1]);

						RaiseEvents_ThreadSafe(EV_FAX, 0,0, cp_events.port,&port_mutex[cp_events.port-1]);
					}
					else
					if((nA == cp->nToneType[T_GTONE])  || (nA == cp->nToneType[T_GTONE2])||
					   (nA == cp->nToneType[T_GTONE3]) || (nA == cp->nToneType[T_GTONE4])||
					   (nA == cp->nToneType[T_GTONE5]))
						RaiseEvents_ThreadSafe(EV_GENERIC_TONE, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
					{
						if (cp->answer_enabled)
							RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
						else
							RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					}
					nSt = CP_ST_INIT; //restart
				}
				else
				if(nA == cp->nToneType[T_SILENCE])
				{
					tmr_h=set_cp_timeout(cp->port ,cp->ulCallingMaxSilTime+2000); //time to answer
					ulTimer1 = get_diff(cp); 	 //get tone time

					write_debug_cp(cp->port,"CP_ENABLE_ALL->1-ulTimer1 = %d",ulTimer1);

					for (i=3;i>0;i--) 		 //delay tone/silence time
						ulTone[i]=ulTone[i-1];
					ulTone[0]=ulTimer1;
					nCicles++;
					get_now(cp);
					//nAudio=0;
					nSt = CP_ST_MEASURING_SILENCE;
					write_debug_cp(cp->port,"CP_ENABLE_ALL->Mudou para CP_ST_MEASURING_SILENCE");
                }
				else
				if(nA == cp->nToneType[T_AUDIO])
				{
					if (cp->nAnswerSensitivity == 0 )
					{
						write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_MEASURING_TONE-> nAnswerSensitivity == 0");
						RaiseEvents_ThreadSafe(EV_ANSWERED,AUDIO_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					}
					else
					{
						write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_MEASURING_TONE-> nAnswerSensitivity <> 0");
						nAudio++;

						if(nAudio>=cp->nAnswerSensitivity)
						{
							cp->ulTimeStartAudio = digivoice_gettick();  //guarda tempo atual
							write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_MEASURING_TONE->AUDIO");
							tmr_haudio=set_audio_timeout(cp->port,cp->nAnswerSensitivityTime);  
							//????? nSt = CP_ST_INIT; //restart
						}
	
					}
				}
                        //else do nothing
			break;

			case CP_ST_MEASURING_SILENCE:
				//check for timeout
				if(timeout == tmr_h)
				{
					tmr_h=set_cp_timeout(cp->port,0); //stop timer
					if (cp->answer_enabled)
						RaiseEvents_ThreadSafe(EV_ANSWERED, TIMEOUT_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
					else
						RaiseEvents_ThreadSafe(EV_CALLPROGRESS_TIMEOUT, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);

					nSt = CP_ST_INIT; //restart
				}
				else
				if((nA == cp->nToneType[T_FAX1]) || (nA == cp->nToneType[T_FAX2]))
				{
					nSt=CP_ST_MEASURING_TONE;
					tmr_h=set_cp_timeout(cp->port,cp->nFaxToneTime);
					get_now(cp); //save tick count
					nAudio=0;
					write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_MEASURING_SILENCE - FAX (%x)",nA);
				}
				else
					if( (nA == cp->nToneType[T_BUSY]) || (nA == cp->nToneType[T_CALLING]) ||
					(nA == cp->nToneType[T_GTONE]) || (nA == cp->nToneType[T_GTONE2])||
					(nA == cp->nToneType[T_GTONE3]) || (nA == cp->nToneType[T_GTONE4]) ||
					(nA == cp->nToneType[T_GTONE5])||
 					(nA == cp->nToneType[T_LINE]))
					{
						write_debug_cp(cp->port,"CP_ENABLE_ALL->Mudou para CP_ST_MEASURING_TONE (%x)",nA);

						ulTimer1 = get_diff(cp);
						write_debug_cp(cp->port,"2-ulTimer1 = %d",ulTimer1);
						for (i=3;i>0;i--) //delay tone/silence time
							ulTone[i]=ulTone[i-1];
						ulTone[0]=ulTimer1;
						nCicles++;

						j=0;
						for (i=0;i<4;i++) //test cadence
						{
							write_debug_cp(cp->port,"CP_ENABLE_ALL->Testando candencia busy - ulTone[%d]=%d - MinBusy=%d MaxBusy=%d - cicles=%d",
										i,ulTone[i],cp->ulBusyMinTime,cp->ulBusyMaxTime, nCicles);

							if((ulTone[i]<cp->ulBusyMinTime) || (ulTone[i]>cp->ulBusyMaxTime))
								j=1;
						}
						if (j==0 && nCicles>2)	//tests for busy
						{
							tmr_h=set_cp_timeout(cp->port,0); //stop timer
							RaiseEvents_ThreadSafe(EV_BUSY, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
							write_debug_cp(cp->port,"CP_ENABLE_ALL->BUSY - (%d, %d ,%d, %d)",ulTone[0],ulTone[1],ulTone[2],ulTone[3]);

							nSt = CP_ST_INIT; //restart
						}
						else
						if (			//tests for calling
							((ulTone[0]>cp->ulCallingMinSilTime)&& (ulTone[0]<cp->ulCallingMaxSilTime) &&
							(ulTone[1]>cp->ulCallingMinToneTime) && (ulTone[1]<cp->ulCallingMaxToneTime)&&
							(ulTone[2]>cp->ulToneInterruptionMinTime)&& (ulTone[2]<cp->ulToneInterruptionMaxTime) &&
							(ulTone[3]>cp->ulCallingMinToneTime) && (ulTone[3]<cp->ulCallingMaxToneTime)) ||

							((ulTone[0]>cp->ulToneInterruptionMinTime)&& (ulTone[0]<cp->ulToneInterruptionMaxTime) &&
							(ulTone[1]>cp->ulCallingMinToneTime) && (ulTone[1]<cp->ulCallingMaxToneTime)&&
							(ulTone[2]>cp->ulCallingMinSilTime)&& (ulTone[2]<cp->ulCallingMaxSilTime) &&
							(ulTone[3]>cp->ulCallingMinToneTime) && (ulTone[3]<cp->ulCallingMaxToneTime)) ||


							((ulTone[0]>cp->ulCallingMinSilTime) &&  (ulTone[0]<cp->ulCallingMaxSilTime) &&
							(ulTone[1]>cp->ulCallingMinToneTime) && (ulTone[1]<cp->ulCallingMaxToneTime)))
						{
							write_debug_cp(cp->port,"CP_ENABLE_ALL->CALLING - (%d, %d ,%d, %d)",ulTone[0],ulTone[1],ulTone[2],ulTone[3]);
							tmr_h=set_cp_timeout(cp->port,0); //stop timer
							RaiseEvents_ThreadSafe(EV_CALLING, 0, 0,cp_events.port,&port_mutex[cp_events.port-1]);
							//nSt = CP_ST_INIT; //restart
							nSt=CP_ST_MEASURING_TONE;
							tmr_h=set_cp_timeout(cp->port,cp->ulLineToneMaxTime);
							get_now(cp); //save tick count
							nCicles=0;
							nAudio=0;

						}
						else
						if(		//tests for dial tone
							((ulTone[0]>cp->ulToneInterruptionMinTime) && (ulTone[0]<cp->ulToneInterruptionMaxTime)&&
							(ulTone[1]>cp->ulLineToneMinTime) && (ulTone[1]<cp->ulLineToneMaxTime)))
						{
								write_debug_cp(cp->port,"CP_ENABLE_ALL->TOM DE DISCAGEM - (%d, ,%d ,%d, %d)",ulTone[0],ulTone[1],ulTone[2],ulTone[3]);
								tmr_h=set_cp_timeout(cp->port,0); //stop timer

								RaiseEvents_ThreadSafe(EV_DIALTONE, 0,  0,cp_events.port,&port_mutex[cp_events.port-1]);
								nSt = CP_ST_INIT; //restart
						}
						else
						{
							nSt=CP_ST_MEASURING_TONE;
							tmr_h=set_cp_timeout(cp->port,cp->ulLineToneMaxTime);
							get_now(cp); //save tick count
							nAudio=0;

							write_debug_cp(cp->port,"ELSE de tudo - (%d, ,%d ,%d, %d)",ulTone[0],ulTone[1],ulTone[2],ulTone[3]);

						}
					}
					else
						if(nA == cp->nToneType[T_AUDIO])
						{
							if (cp->nAnswerSensitivity == 0 )
							{
								write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_MEASURING_SILENCE-> nAnswerSensitivity == 0");
								RaiseEvents_ThreadSafe(EV_ANSWERED,AUDIO_DETECTED, 0,cp_events.port,&port_mutex[cp_events.port-1]);
							}
							else
							{
								write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_MEASURING_SILENCE-> nAnswerSensitivity <> 0");
								nAudio++;
								if(nAudio>=cp->nAnswerSensitivity)
								{
									write_debug_cp(cp->port,"CP_ENABLE_ALL->CP_ST_MEASURING_SILENCE->AUDIO");	
									cp->ulTimeStartAudio = digivoice_gettick();  //guarda tempo atual
									tmr_haudio=set_audio_timeout(cp->port,cp->nAnswerSensitivityTime); 

									//???? nSt = CP_ST_INIT; //restart
								}
							}
						}
                // else do nothing
                break;
  		}//switch
		if (nSt==CP_ST_INIT)
		{
			nSt=CP_ST_UNDEFINED;
			tmr_h=set_cp_timeout(cp->port,cp->nCallProgressTimeout);//max time to wait tone
			nCicles=0;
			nAudio=-1;
	   		for(j=0;j<4;j++)
	      		ulTone[j]=0l;
		}

	} //if ALL


  }//fim fo while(1)
  //close fifos
  cp->thread_ready = 0;
#ifdef __LINUX__
    write_debug("CreateCallProgress (%d): After main while fifo_to_cp = %d",cp->port, ports_info[cp->port-1].fifo_to_cp);
    close(ports_info[cp->port-1].fifo_to_cp);
#else
	//destroi os eventos
	CloseHandle(ports_info[cp->port-1].cp_info.CPEvent.hEvent);
#endif

#ifdef __LINUX__
	close(fifo_cp);
#endif
	cp->thread_id = 0;
	cp->thread_ready=0;
}





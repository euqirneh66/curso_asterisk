
/***************************************************************************
 *                                                                         *
 *   VoicerLib - Linux Version                                             *
 *                                                                         *
 *   Copyright (c) 2004, Digivoice Tecnologia em Eletroica Ltda            *
 *                                                                         *
 *   Module:                                                               *
 *                                                                         *
 *   Description:                                                          *
 *                                                                         *
 *                                                                         *
 *                                                                         *
 *  This software is licensed under Digivoice Public License               *
 *                                                                         *
 *	Copyright (c) 2004, Digivoice Tecnologia em Eletroica Ltda             *
 *	All rights reserved.                                                   *
 *                                                                         *
 *	Redistribution and use in source and binary forms, with or without     *
 *	modification, are permitted provided that the following conditions     *
 *  are met:                                                               *
 *                                                                         *
 * - Redistributions of source code must retain the above copyright        *
 *   notice, this list of conditions and the following disclaimer.         *
 * - Redistributions in binary form must reproduce the above copyright     *
 *   notice, this list of conditions and the following disclaimer in the   *
 *   documentation and/or other materials provided with the distribution.  *
 * - Modifications must not alter or remove any copyright notices in       *
 *   the Software and related documents.                                   *
 * - Any modifications in the original source code or modified versions of *
 *   this library must be available under this license.                    *
 * - You may develop application programs, reusable components and other   *
 *   software items that link with the original or modified versions of    *
 *   this library and release them under the license you wish.             *
 * - Neither the name of the Digivoice Tecnologia em Eletr�ica Ltda,       *
 *   VoicerLib nor the names of its contributors may be used to endorse    *
 *   or promote products derived from this software without specific prior *
 *   written permission.                                                   *
 *                                                                         *
 *  DISCLAIMER                                                             *
 *                                                                         *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS    *
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT      *
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  *
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT   *
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  *
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT       *
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  *
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  *
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT    *
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE  *
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.   *
 *                                                                         *
 ***************************************************************************/

#ifndef __GSMHEADER_H__
#define __GSMHEADER_H__


#define OFF    0x0
#define ON     0x1

#define	NUMBER_SIZE			25

#define CR	0x0d
#define LF  0x0a

int set_gsm_timeout(int port, int t);
int set_gsm_wait_timeout(int port, int t);
int set_gsm_ClearAllSMS_timeout(int port, int t);
void gsm_dial(short port, char *szNumber);	//Hangup Method
void gsm_puts(short port, char *szCmd);
void gsm_putn(short port, char *szCmd,int len);
void gsm_puts_delayed(short port, char *szCmd);
void gsm_get_delayed(short port);

#endif

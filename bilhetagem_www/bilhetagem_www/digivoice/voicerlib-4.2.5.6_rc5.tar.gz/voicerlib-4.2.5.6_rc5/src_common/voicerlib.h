
/***************************************************************************
 *                                                                         *
 *   VoicerLib -                                                           *
 *                                                                         * 
 *   Copyright (c) 2004, Digivoice Tecnologia em Eletronica Ltda           *
 *                                                                         *
 *   Module: Main include file                                             *
 *                                                                         *
 *   Description: General definitions and functions prototype              *
 *                                                                         * 
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                       *
 *   desenvolvimento@digivoice.com.br                                      *
 *                                                                         * 
 *   This library is free software; you can redistribute it and/or         *
 *   modify it under the terms of the GNU Lesser General Public            *
 *   License as published by the Free Software Foundation; either          *  
 *   version 2.1 of the License, or (at your option) any later version.    * 
 *                                                                         *
 *   This library is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU     *
 *   Lesser General Public License for more details.                       *
 *                                                                         * 
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this library; if not, write to the Free Software   * 
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA         *
 *                                                                         * 
 ***************************************************************************/

#ifndef __VOICERLIB_H__
#define __VOICERLIB_H__

#ifdef WIN32
	#define DCDECL __cdecl
	#define DCALLBACK CALLBACK
	typedef unsigned int uintptr_t;
#else
	#define DCDECL
	#define DCALLBACK
#endif

#include <stdio.h>
#include "generic.h"

#ifdef WIN32
#include <process.h>
#include <windows.h>
#include <winver.h>
#endif

#ifdef __LINUX__
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
    
    //#include "vppci/vppci.h"
#endif

#include "vlibdef.h"
#include "e1.h"
#include "dg_wave.h"

//			pthread_mutex_lock(&debug_mutex);															
//		pthread_mutex_unlock(&debug_mutex);
//	pthread_mutex_t debug_mutex;		
	
	
//channel connection definition
#define CONMAXBUFF 16
//typedef unsigned char ConBuff[2][CONMAXBUFF][33];

#ifdef WIN32

#ifdef _DEBUG 

__forceinline int __cdecl dbg(short port,const char *s, ...)
{ 
	FILE *pdebug;
	time_t curSecs;
	struct tm *now;
	char szTemp[200];
	char szFileName[200];
	va_list argp;
	int retval=0;
	unsigned int tick;

	
	curSecs = time(NULL);				
	now = localtime(&curSecs);	
	tick = GetTickCount();
	sprintf(szTemp,"<%02d:%02d:%02d:%06d>",now->tm_hour, now->tm_min, now->tm_sec, tick);		

    va_start(argp, s);
	sprintf(szFileName,"c:\\log\\log-%d.log",port);
	pdebug=fopen(szFileName,"a+");
	if (pdebug!=NULL)                                              
	{                                                        
		fprintf(pdebug,"%s-",szTemp);       
		retval = vfprintf( pdebug, s, argp);
		fprintf(pdebug,"\n");
        //let somebody else do the work
		fclose(pdebug);                                            
	}																
	va_end(argp);

	return retval;
}

__forceinline int __cdecl write_debug(const char *s, ...) 
{ 
	FILE *pdebug;
	time_t curSecs;
	struct tm *now;
	char szTemp[200];
	va_list argp;
	int retval=0;
	unsigned int tick;
	static int last_tick;

	curSecs = time(NULL);				
	now = localtime(&curSecs);	
	tick = GetTickCount();
	sprintf(szTemp,"<%02d:%02d:%02d:%06d>",now->tm_hour, now->tm_min, now->tm_sec, tick-last_tick);		

	last_tick = tick;
    va_start(argp, s);
	pdebug=fopen("c:\\log\\voicerlib3.log","a+");
	if (pdebug!=NULL)                                              
	{                                                        
		fprintf(pdebug,"%s-",szTemp);       
		retval = vfprintf( pdebug, s, argp);
		fprintf(pdebug,"\n");
        //let somebody else do the work 
		fclose(pdebug);                                            
	}																
	va_end(argp);

	return retval;
}
#else
__forceinline void __cdecl write_debug(const char *s, ...)
{ 
}

/*__forceinline void __cdecl dbg(short port,const char *s, ...)
{
}*/
__forceinline int __cdecl dbg(short port,const char *s, ...)
{ 
	FILE *pdebug;
	time_t curSecs;
	struct tm *now;
	char szTemp[200];
	char szFileName[200];
	va_list argp;
	int retval=0;
	unsigned int tick;


	curSecs = time(NULL);
	now = localtime(&curSecs);
	tick = GetTickCount();
	sprintf(szTemp,"<%02d:%02d:%02d:%06d>",now->tm_hour, now->tm_min, now->tm_sec, tick);

	va_start(argp, s);
	sprintf(szFileName,"c:\\log\\log-%d.log",port);
	pdebug=fopen(szFileName,"a+");
	if (pdebug!=NULL)
	{
		fprintf(pdebug,"%s-",szTemp);
		retval = vfprintf( pdebug, s, argp);
		fprintf(pdebug,"\n");
        //let somebody else do the work
		fclose(pdebug);
	}
	va_end(argp);

	return retval;
}


#endif  //debug




typedef struct _SET_EVENT
{
	HANDLE  hEvent;
	short port;		//pass port to kernel to use with playback fifo notifications
	short card;		//pass port to kernel to use with playback fifo notifications
} SET_EVENT, *PSET_EVENT;

#endif  //win32

#define	FACTOR_TIMER		100 				//factor to timer

#define DG_MAX_PATH        255            //Default size to strings

#define DG_MAX_PLAY_QUEUE	30				//play queue max itenms

//---------------------------------------------------------------------------------
//Return CODES
//---------------------------------------------------------------------------------
#define DG_EXIT_SUCCESS						   0			//ex-DG_EXIT_SUCCESS
#define DG_EXIT_FAILURE						0x700
//startvoicerlib errors
#define DG_ERROR_MEMORY_ALLOCATION			0x400			//1024 ex-EXIT_DEFAULTERROR (-1)
#define DG_ERROR_MAXCARDS		  			0x401			//ex-ERROR_MAXCARDS (4)
#define DG_ERROR_FIRMWARE_NOT_FOUND			0x402			//ex-ERROR_CONFIGFILE (2)
#define DG_ERROR_FIRMWARE_IO_TIMEOUT		0x403			//I/O error - bus or card problem
#define DG_ERROR_READING_PORTCOUNT			0x404			//4/8 port reading error
#define DG_ERROR_LOADING_DEVICEDRIVER		0x405			//kernel plugin error
#define DG_ERROR_CREATING_EVENT				0x406			//error creating eventos - memory full?
                                                            // 
//global errors
#define DG_ERROR_DRIVER_CLOSED				0x450
#define DG_ERROR_CARD_OUT_OF_RANGE			0x451			//EX-ERROR_PARAM_OUTOFRANGE (-1)
#define DG_ERROR_PORT_OUT_OF_RANGE			0x452			//EX-ERROR_PARAM_OUTOFRANGE (-1)
#define DG_ERROR_PARAM_OUTOFRANGE			0x453			//EX-ERROR_PARAM_OUTOFRANGE (-1) all generic params
#define DG_ERROR_DRIVER_ALREADY_OPEN		0x454			//only when starting
#define DG_ERROR_CONFIGFILE_NOT_FOUND		0x455			//ex-ERROR_CONFIGFILE (2)
#define DG_FEATURE_NOT_SUPPORTED			0x456			//ex-ERROR_PARAM_OUTOFRANGE (-1)
#define DG_ERROR_RESOURCE_UNAVAILABLE		0x457			//ex-ERROR_RESOURCE_UNAVAILABLE (-1) 
#define DG_ERROR_RESOURCE_FULL				0x458			//EX-ERROR_RESOURCE_FULL (-2)
#define DG_ERROR_INVALIDPARAM				0x459			//ex-ERROR_INVALIDPARAM	(-2)
#define DG_WARNING_OLDFILEFORMAT			0x460			//
                                                            
//threads related errors
#define DG_ERROR_COULD_NOT_CREATE_THREAD	0x500			//ex-ERROR_THREAD (3)
#define DG_ERROR_THREAD_NOT_RUNNING			0x501			//ex-ERROR_THREAD_NOT_RUNNING (9)
#define DG_ERROR_FIFO_UNAVAILABLE			0x502			//ex-ERROR_FIFO_UNAVAILABLE (6)
#define DG_ERROR_THREAD_ALREADY_RUNNING		0x503			//ex-ERROR_THREAD_ALREADY_RUNNING (7)

//playback related errors
#define DG_ERROR_NOT_PLAYING					0x550
#define DG_ERROR_ALREADY_PLAYING				0x551
#define DG_ERROR_PLAY_OPENFILE					0x552
#define DG_ERROR_PLAY_EMPTYLIST					0x553
#define DG_ERROR_AUDIO_FORMAT_UNSUPPORTED		0x554
#define DG_ERROR_PLAY_INVALID_FILENAME			0x555
#define DG_ERROR_PLAY_BUFFER_FULL				0x556

//record related errors
#define DG_ERROR_REC_STOPPING					0x600		//EX- COD 3
#define DG_ERROR_REC_OPENFILE					0x601		//ex  cod -1
#define DG_ERROR_REC_ALREADY_RECORDING			0x602		//ex  cod 2
#define DG_ERROR_REC_NOT_RECORDING				0x603		//ex  cod 2

//conversion related errors
#define DG_ERROR_CONV_SOURCE					0x701							   
#define DG_ERROR_CONV_TARGET					0x702
#define DG_ERROR_CONV							0x703

//EEPROM related ERRORS
#define DG_ERROR_ADDRESS_OUT_OF_RANGE			0x770
#define DG_ERROR_EEPROM_PROTECTED				0x771

#define DG_ERROR_SERIAL_FAILURE					0x1000

//EEPROM address range
#define EEPROM_MIN_ADD							0x70
#define EEPROM_MAX_ADD							0x7f

//#define DG_EXIT_SUCCESS					0
//s#define EXIT_DEFAULTERROR				-1
//#define ERROR_CONFIGFILE				2
//#define ERROR_THREAD					3
//#define ERROR_MAXCARDS		  			4
//#define ERROR_UNKNOWNTYPE	  			5
//#define ERROR_FIFO_UNAVAILABLE			6
//#define ERROR_THREAD_ALREADY_RUNNING	7
//#define ERROR_STARTINGLIB				8
//#define ERROR_THREAD_NOT_RUNNING		9

//#define ERROR_PARAM_OUTOFRANGE			-1
//#define ERROR_INVALIDPARAM				-2
//#define ERROR_DRIVER_CLOSED				-3
//#define ERROR_RESOURCE_UNAVAILABLE		-1
//#define ERROR_RESOURCE_FULL				-2


#define TRUE			1
#define FALSE			0


/* gsm definitions */
#define ENCODE	1
#define DECODE  0 
#define FAST	1
#define USE_FLOAT_MUL
#define TAM_GSM	160
#define	GSM_TABLE_C

//---------------------------------------------------
// Defini�es para a discagem com supervisao
//---------------------------------------------------
/*#define		MK_INICIO						1
#define		MK_PICKINGUP					2
#define		MK_DIALPREFIX					3
#define		MK_STARTFLASH					4
#define		MK_WAITINGDIALTONE				5
#define		MK_DIALING						6
#define		MK_ANALYSING 					7
#define		MK_FLASHRETOMADAOCUPADO			8
#define		MK_FLASHRETOMADANAOATENDE		9
#define		MK_DIALRETOCUPDIGIT			   10
#define		MK_DIALRETNAOATDIGIT		   11
#define		MK_PLAYINGBUSYPHRASE           12
#define		MK_PLAYINGNAOATPHRASE          13
#define		MK_PLAYINGAFTERANSWER		   14
#define		MK_WAITINGPAUSEAFTERANSWER	   15	
enum EnumCallType {ctExternal, ctWithFlash};
*/

//status dos eventos OnPlayStop e OnRecordStop
typedef enum { ssNormal, ssDigitReceived, ssAbnormal, ssStopped } StopStatus;

typedef enum { dtDTMF=1, dtMFP } tDetectionType;

//Channel Status
typedef enum { spFlashing, spDialing, spNone, spWaitingDigits, spOffHook } EnumStatusPort;

//Dialtypes
enum EnumDialType { dtPulse, dtTone, dtMFT, dtMFF, dtCustomMF, dtCustonTone1,dtCustonTone2, dtDirectMF};

//File Format - moved to vlibdef.h
//enum EnumFileFormat {ffWaveULaw,ffSig,ffWavePCM,ffGsm610,ffWaveALaw};

//GetDigits States
typedef enum { edOff, edWaiting, edMaxDigits,edDigitTimeOut,
					edInterDigitTimeOut, edTermDigit, edDigitOverMessage} WaitDigit ;


//AskForGroupB types
enum {
		DG_A3_COMPELED,
		DG_A3_PULSED
};

//CONSTANTS of COMMANDS IN DG_CONFIG_E1_HANDLE
enum {
	E1CFG_SEIZURE_TIMEOUT,
	E1CFG_RETENTION_TIMEOUT,
	E1CFG_ANSWER_TIMEOUT,
	E1CFG_BLOCKING_ON,
	E1CFG_BLOCKING_OFF,
	E1CFG_MFT_TIMEOUT,
	E1CFG_MFF_TIMEOUT,
	E1CFG_MAXDIGITS_RX,			//numero maximo de digitos que o E1 ir�receber
	E1CFG_SEND_ID_AFTERDIGIT,	//indica apos que digito
	E1CFG_GROUP_B,
	E1CFG_GROUP_II,				//CATEGORIA
	SILENCE_THRESHOLD,
	SILENCE_THRESHOLD_AFTER,
	E1CFG_GENERATE_RINGBACK,
	E1CFG_R2_COUNTRY,
	E1CFG_SIGTYPE,
	E1CFG_MAX
};

//CONSTANTS of COMMANDS IN DG_CONFIG_GSM_HANDLE
enum {
	REC_UNREAD = 0,
	REC_READ,
	STO_UNSENT,
	STO_SENT,
	ALL
};

enum {
	GSM_RELEASE_CALLS=0,
	GSM_TERMINATE_AND_ACCEPT,
	GSM_PUT_ON_HOLD,
	GSM_CONFERENCE
};

enum
{
	GSM_AT_IDLE = 1,
	GSM_AT_RECEIVING,
	GSM_IDLE,
	GSM_EF,
	GSM_E0,
	GSM_IPR,
	GSM_CPIN,
	GSM_COPS,
	GSM_SNFS,
	GSM_SAIC,
	GSM_CLIP,
	GSM_CMEE,
	GSM_CLIR,
	GSM_CSCS,
	GSM_CSMS,
	GSM_CNMI,
	GSM_SMGO,
	GSM_CPMS,
	GSM_CMGF,
	GSM_Q3,
	GSM_ALL,
	GSM_SMS1,
	GSM_SMS2,
	GSM_SMS3,
	GSM_SYSSTART,	
	GSM_SIM_PIN,
	GSM_SIM_PUK,
	GSM_SIM_PIN2,
	GSM_SIM_PUK2,
	GSM_PHSIM_PIN,
	GSM_PHSIM_PUK,
	GSM_PHFSIM_PIN,
	GSM_PHFSIM_PUK,
	GSM_PHNET_PUK,
	GSM_PHNS_PIN,
	GSM_PHNS_PUK,
	GSM_PHSP_PIN,
	GSM_PHSP_PUK,
	GSM_PHC_PIN,
	GSM_PHC_PUK,
	GSM_CLEAR,
	GSM_CLEAR0,	
	GSM_LIST,
	GSM_SNFPT,
	GSM_CCWA,
	GSM_CUSD,
	GSM_SCKS,
	GSM_SSCONF,
	GSM_CSMP,
	GSM_CNMA,
	GSM_SNFO,
	GSM_SMS4,
	GSM_SMS5,
	GSM_SMS6,
	GSM_SMS1_WAIT,
	GSM_CLEAR0_WAIT
};

//constants for gsm sms listing command
enum {
	GSMCFG_DIGIT_TIMEOUT,
	GSMCFG_ID_RESTRICTION,
	GSMCFG_USSD_ENABLE,
	GSMCFG_CALL_WAITING_ENABLE,
	GSMCFG_RETRY_TIMEOUT,
	GSMCFG_ANSWER_TIMEOUT,
	GSMCFG_MESSAGE_CONFIRMATION,
	GSMCFG_FLASHSMS_ENABLE,
	GSMCFG_MAX,
	GSMCFG_DISPLAY_CALL_WAITING_ENABLE
};
//CONSTANTS OF COMMANDS IN DG_CONFIG_CUSTOMCAS
enum {
	CASCFG_RING,
	CASCFG_CALLER_HANGUP,
	CASCFG_IDLE,
	CASCFG_ANSWER,
	CASCFG_PICKUP,
	CASCFG_DROP_DELAY_BEFORE,
	CASCFG_DROP,
	CASCFG_FLASH1_CMD,
	CASCFG_FLASH1_DELAY,
	CASCFG_FLASH2_CMD,
	CASCFG_FLASH2_DELAY
};
//constants to configure call progress behaviour
enum {
	CPCFG_ANSWER_SENSITIVITY,
	CPCFG_ANSWER_SENSITIVITY_TIME,
	CPCFG_GENERICTONETIMEOUT ,
	CPCFG_GENERICTONETIME ,
	CPCFG_LINETONETIMEOUT ,
	CPCFG_LINETONETIME ,
	CPCFG_FAXTONETIMEOUT ,
	CPCFG_FAXTONETIME ,
	CPCFG_CALLPROGRESSTIMEOUT ,
	CPCFG_BUSYMINTIME ,
	CPCFG_BUSYMAXTIME ,
	CPCFG_CALLINGMINTONETIME ,
	CPCFG_CALLINGMAXTONETIME ,
	CPCFG_CALLINGMINSILTIME ,
	CPCFG_CALLINGMAXSILTIME ,
	CPCFG_TONEINTERRUPTIONMINTIME ,
	CPCFG_TONEINTERRUPTIONMAXTIME ,
	CPCFG_LINETONEMINTIME ,
	CPCFG_LINETONEMAXTIME,
	CPCFG_LINEFREQ,				//---- FREQUENCIES
	CPCFG_CALLINGFREQ,
	CPCFG_BUSYFREQ,
	CPCFG_GENERICFREQ,
	CPCFG_GENERICFREQ2,
	CPCFG_GENERICFREQ3,
	CPCFG_GENERICFREQ4,
	CPCFG_GENERICFREQ5,
	CPCFG_SILENCE,
	CPCFG_AUDIO,
	CPCFG_FAX1,
	CPCFG_FAX2,
    CPCFG_BUSYSENSIBILITY,
    CPCFG_MAX=999
};

enum {
	DG_DIGITAL_INTERFACE = 1,
	DG_FXO_INTERFACE = 2,
	DG_FX_INTERFACE = 3,
	DG_GSM_INTERFACE = 4,
	DG_FXS_INTERFACE = 5,	
	DG_UNKNOWN_INTERFACE = 99
};

/* VB0404FX type */
enum
{
	DG_FX_TYPE_NONE,
	DG_FX_TYPE_FXS,
	DG_FX_TYPE_FXO,
	DG_FX_TYPE_FXO2
};

//constants to use in OnLoggerEvent
enum {
	LOGGER_FREE_WITH_BILLING = 0x1,
	LOGGER_BUSY,
	LOGGER_NUMBER_CHANGED,
	LOGGER_CONGESTION,
	LOGGER_FREE_WITHOUT_BILLING,
	LOGGER_FREE_RETENTION,
	LOGGER_LEVEL_NUMBER_AVAILABLE,
	LOGGER_RESERVED_8,
	LOGGER_RESERVED_9,
	LOGGER_RESERVED_10,
	LOGGER_RESERVED_11,
	LOGGER_RESERVED_12,
	LOGGER_RESERVED_13,
	LOGGER_RESERVED_14,
	LOGGER_RESERVED_15,
	LOGGER_B_ENDCALL = 20,	//assinante B desligou durante conversa�o
	LOGGER_B_RETURN	= 21,	//assinante B retornou �liga�o.
	LOGGER_LINEREADY = 22,
	LOGGER_LINEOFF = 23,
	LOGGER_R2DMF = 100		//tipos de protocolo suportados
};

enum {
	AGC_TYPE_LOGGER = 1,
	AGC_TYPE_CONFERENCE = 2
};

//identification for alarms
enum
{
    ALARM_RSLIP		= 0x00000001,		//escorregamento
    ALARM_RAIS		= 0x00000002,		//alarme remoto
    ALARM_AISS		= 0x00000004,		//indica�o de alarme
    ALARM_AIS16S	= 0x00000008,		//indica�o de alarme canal  16
    ALARM_LOSS		= 0x00000010,		//perda de sinal
    ALARM_CRC4SYNC  = 0x00000020,		//reservado
    ALARM_MFSYNC	= 0x00000040,		//sincronismo de multiquadro
    ALARM_SYNC		= 0x00000080,		//sincronismo de quadro
    ALARM_LINKDOWN      = 0x00000100,           //Link ISDN
};


//conference directions to enable command
enum {
	CHAT_LISTEN,	//rx
	CHAT_TALK,
	CHAT_TALK_LISTEN
};

//commands to enable call progress
enum {
	CP_ENABLE_ALL = 1,					//all
	CP_ENABLE_GENERIC_TONE,			//only generic tone
	CP_ENABLE_LINETONE_OR_BUSY,		//line or busy - using before dial or afterflash
	CP_ENABLE_BUSY_OR_FAX,			//fax or busy - during conversation
	CP_DISABLE,
	CP_MAX
};

/* r2 country definitions */
enum {
	R2_COUNTRY_BR = 1,
	R2_COUNTRY_AR,
	R2_COUNTRY_MX
};

/* r2 type/signalling definitions */
enum {
	R2_TYPE_MFC = 1,
	R2_TYPE_CB_FXO,
	R2_TYPE_CB_FXS
};

enum{
 NOT_A_VALID_FILE=1,
 RIFF_NOT_FOUND,
 WAVE_NOT_FOUND,
 FMT_NOT_FOUND,
 FACT_NOT_FOUND,
 DATA_NOT_FOUND
};

#ifdef __LINUX__
  pthread_t  thread_timer;

#endif

  short timer_thread_running;
/* structures */
/* Structure used in callback event function */

typedef struct {
    unsigned short command;	/*char*/
    unsigned short data;
	unsigned short port;
	unsigned short data_aux;
	unsigned short card;
} dg_event_data_structure;


//structure to pass dial informations to dialthread
typedef struct {
	short port;
	char szNumber[DG_MAX_PATH];
	long pause_after_dial;
	short dialtype;
} dg_dialthread_structure;


//structure to pass flash informations to flashthread
typedef struct {
	short port;
	long pause_after_flash;	
	short flash_count;
	long flash_time;
} dg_flashthread_structure;


//--------------------------------------------------------
//GetDigits structure control
//--------------------------------------------------------
typedef struct {
    unsigned char NumDigRecebido;
    unsigned short MaxDigits;
    char TermDigits[DG_MAX_PATH];
    int DigitsTimeOut;
    int InterDigitsTimeOut;
    char RecDigitos[DG_MAX_PATH];
} stGetDigit;


//--------------------------------------------------------------------
//structure to pass and receive signal informations to E1
//--------------------------------------------------------------------
typedef struct
{
#ifdef __LINUX__
  pthread_t  thread_id;
  pthread_t   call_thread_id;
#endif

#ifdef WIN32

  HANDLE thread_id;
  //uintptr_t call_thread_id;
  //SET_EVENT CallControlEvent;
  SET_EVENT E1Event;
  //OVERLAPPED oOverlapControl;
  OVERLAPPED oOverlapE1;
#endif

  u8	enabled;
  unsigned short port;
//  sem_t semaforo;

  char category;

  char rx_digits[25];
  char rx_number_of_digits;   //numero de digitos de cada parte de A-1

  char rx_complete_digits[25];
  char rx_complete_count;   //numero de digitos de cada parte de A-1

  char rx_id_digits[25];
  char rx_id_number_of_digits; // enable caller ID

  char rx_total_remaining;		//contador de uso interno
  char rx_total_of_digits;	  //numero total de digitos que o E1 ira receber - Se for zero, nao trata nada internamente
  char send_id_digit_pos;		//a partir do digito <X>
  char group_b_id;				//identifica�o para o grupo B

  char ddc;   // habilita bloqueio chamada acobrar po dupla ocupacao

  char tx_id_digits[25];
  char tx_id_number_of_digits; // enable caller ID

  char bAtendido;		//0-desligado, 1-atendido

  short ring_event;		//controle de tom de ring
  short ring_generate_ringback;		//flag indicating if generates auto ring back or not

  short r2_country;                              //set r2 country definition
  short sigtype;                                 //set type/signalling

  /* R2 group A backward signals */
  int a_1;
  int a_2;
  int a_3;
  int a_4;
  int a_5;
  int a_6;
  int a_7;
  int a_8;
  int a_9;
  int a_10;
  int a_11;
  int a_12;
  int a_13;
  int a_14;
  int a_15;
  int a_send_next;
  int a_send_cat_prepare_group_b;
  int a_congestion;
  int a_send_cat_and_callerid;
  int a_send_dnis_nm2;
  int a_send_dnis_nm3;
  int a_send_dnis_nm1;
  int a_dnis_again;
  int a_address_complete_charge_setup;

  /* R2 group B backward signals */
  int b_1;
  int b_2;
  int b_3;
  int b_4;
  int b_5;
  int b_6;
  int b_7;
  int b_8;
  int b_9;
  int b_10;
  int b_11;
  int b_12;
  int b_13;
  int b_14;
  int b_15;
  int b_free_calling;
  int b_busy;
  int b_number_changed;
  int b_congestion;
  int b_free_withoutbilling;
  int b_collectcall;
  int b_number_unknown;
  int b_out_of_service;

  /* R2 group C backward signals - MEXICO */
  int c_1;
  int c_2;
  int c_3;
  int c_4;
  int c_5;
  int c_6;
  int c_7;
  int c_8;
  int c_9;
  int c_10;
  int c_11;
  int c_12;
  int c_13;
  int c_14;
  int c_15;
  int c_send_next_ani;
  int c_dnis_again_prepare_group_a;
  int c_send_cat_prepare_group_b;
  int c_send_next_dnis_prepare_group_a;
  int c_send_dnis_nm1_prepare_group_a;

  int group_i_end_of_ani;

  int timeout_ocupacao;     // 7s - 7000
  int timeout_retencao;     // 90s - 90000
  int timeout_atendimento;  // 75s - 75000
  int timeout_bloqueio_on;  // 1s - 1000
  int timeout_bloqueio_off; // 2s - 2000
  int timeout_mft;          // 30s - 30000
  int timeout_mff;          // 30s - 30000

  int silence_threshold_signaling;			//default -30 dBm
  int silence_threshold_after_signaling;	//default -30 dBm

  short bBlocked;				//bloqueia envio de dados para a thread no caso de alarmes

  char szFifoToE1[DG_MAX_PATH];
  //char szFifoToControl[DG_MAX_PATH];
} dg_signal_e1_thread_structure;

//--------------------------------------------------------------------
//structure to pass and receive signal informations to E1
//--------------------------------------------------------------------
typedef struct
{
#ifdef __LINUX__
  pthread_t	  thread_id;
  pthread_t   call_thread_id;
#endif
#ifdef WIN32
  uintptr_t thread_id;
  //uintptr_t call_thread_id;

  SET_EVENT LoggerEvent;
  OVERLAPPED oOverlapLogger;
#endif

  unsigned short target_port;
  unsigned short port2;	//porta + 30
  //....
  char szFifoToLogger[DG_MAX_PATH/2];

  char rx_digits[25];
  char rx_number_of_digits;   //numero de digitos - get e1 number

  char rx_complete_digits[25];
  char rx_complete_count;   //numero de digitos de cada parte de A-1

  char rx_id_digits[25];
  char rx_id_number_of_digits; // enable caller ID

  long chat_handle;

  short calltype;

  unsigned char thread_running;

  unsigned char enabled;

  int silence_threshold_signaling;			//default -30 dBm
  int silence_threshold_after_signaling;	//default -30 dBm

} dg_logger_thread_structure;


//--------------------------------------------------------------------
//structure to pass and receive signal informations to E1 - CCS
//--------------------------------------------------------------------
typedef struct
{
#ifdef __LINUX__
  pthread_t	  thread_id;
  //pthread_t   call_thread_id;
#else
  uintptr_t thread_id;
  //uintptr_t call_thread_id;

  SET_EVENT LoggerCCSEvent;
  OVERLAPPED oOverlapLoggerCCS;
#endif

  unsigned short target_port;
  unsigned short port2;	//porta + 30
  //....
  char szFifoToLoggerCCS[DG_MAX_PATH/2];

  char rx_digits[25];
  char rx_number_of_digits;   //numero de digitos - get e1 number

  char rx_complete_digits[25];
  char rx_complete_count;   //numero de digitos de cada parte de A-1

  char rx_id_digits[25];
  char rx_id_number_of_digits; // enable caller ID

  long chat_handle;

  short calltype;

  unsigned char thread_running;

  unsigned char enabled;

  int silence_threshold_signaling;			//default -30 dBm
  int silence_threshold_after_signaling;	//default -30 dBm

  int call_reference;
  int status;

} dg_logger_ccs_thread_structure;

//------------------------------------
//call progress parameters structure
//------------------------------------
typedef struct
{
#ifdef __LINUX__
	pthread_t  thread_id;
	pthread_t   call_thread_id;

#endif

#ifdef WIN32
	uintptr_t thread_id;
	SET_EVENT CPEvent;
	OVERLAPPED oOverlapCP;
#endif
    short  cptype;
	u8  enabled;
	u8  answer_enabled;
	u8  thread_ready;	//show if the thread is ready to receive commands
	int nToneType[15];  //associates the T_xxx tone types with card tone detections

	unsigned short port;
	unsigned long ulTimeNow;

	unsigned int ulTimeStartAudio;	//contador de tempo para audio

	int nGenericToneTimeout;	//max time to wait generic tone
	int nGenericToneTime;   	//time to confirm the generic tone presence

	int nLineToneTimeout;   	//max time to wait line tone
	int nLineToneTime;      	//time to confirm the line tone presence

	int nFaxToneTimeout;   		//max time to wait fax tone
	int nFaxToneTime;      		//time to confirm the lfax tone presence

	int nCallProgressTimeout;   	//max time to wait any one
	int nCallProgressToneTime;    //max time of any tone presence

	int nAnswerSensitivity;			//max number of audio detections
	int nAnswerSensitivityTime;			//min time of audio detections

	unsigned long ulBusyMinTime;  	//min busy tone or silence time
	unsigned long ulBusyMaxTime;  	//max busy tone or silence time
    int nBusySensibility;           //number of busy to raise event to app

	unsigned long ulCallingMinToneTime; //min Calling tone time
	unsigned long ulCallingMaxToneTime; //max Calling tone time
	unsigned long ulCallingMinSilTime;  //min Calling silence time
	unsigned long ulCallingMaxSilTime;  //max Calling silence time

	unsigned long ulToneInterruptionMinTime; //Tone interruption min time
	unsigned long ulToneInterruptionMaxTime; //Tone interruption max time

     	unsigned long ulLineToneMinTime;         //min line tone time
     	unsigned long ulLineToneMaxTime;         //max line tone time

  int timeout_ocupacao;     // 7s - 7000
  int timeout_retencao;     // 90s - 90000
  int timeout_atendimento;  // 75s - 75000
  int timeout_bloqueio_on;  // 1s - 1000
  int timeout_bloqueio_off; // 2s - 2000
  int timeout_mft;          // 30s - 30000
  int timeout_mff;          // 30s - 30000

  char szFifoToCP[DG_MAX_PATH];

} dg_call_progress_thread_structure;



//---------------------------------------
// Idle Structure
//---------------------------------------
typedef struct
{
#ifdef __LINUX__
	pthread_t  thread_id;
	pthread_t  idle_thread_id;
#endif

#ifdef WIN32
	uintptr_t thread_id;
	SET_EVENT IdleEvent;
	OVERLAPPED oOverlapIdle;
#endif

  unsigned short port;
  char szFifoToIdle[DG_MAX_PATH];

	//working variables
	u8		closing;
    u8		enabled;
	u8		bAutoPickUp;
	short   nRingsToAnswer;						//rings to answer
	short   nPauseAfterPickUp;					//pause after pickup

	u8		bWatchTrunkBefore;					//watch DTMF before answer
	u8		bWatchTrunkAfter;					//watch DTMF after answer

	short	nFormat;							//dtmf,  mfp, custom
	short	TimeOut;							//Timeout at�o ring
	short	nStringMaxSize;						//Max string size passed in getdigits function
	char	sTermDigit[DG_MAX_PATH];			//terminator digits


	short   nRingCount;							//used to count rings
	char	sDigitsDetected[DG_MAX_PATH];		//holds received digits
	char	sNameDetected[DG_MAX_PATH];			//holds received name
	u8		bHookOff;							//1 - Hooked Off, 0 - Hook On

} dg_idle_structure;

//---------------------------------------
// FSK Structure
//---------------------------------------
typedef struct
{
	//fsk variables
	char szRxMsg[512];
	int nRxCnt;
	dg_cmd_tx tx_command_fsk;
	int nMsgLength;
	int i;
	int nOffset;
	int enable;

}dg_fsk_structure;

//------------------------------------------------------------------------
// Structure that holds custom thread information
//------------------------------------------------------------------------
typedef struct
{
#ifdef __LINUX__
  pthread_t	  thread_id;
  pthread_t   call_thread_id;
#endif
#ifdef WIN32
  uintptr_t thread_id;
  SET_EVENT CASEvent;
  OVERLAPPED oOverlapCAS;
#endif
  unsigned short port;
  char szFifoToCAS[DG_MAX_PATH/2];

  //custom commands and events
  short		ring_signal;					//ring signal
  short		caller_hangup_signal;		//caller hangup singal
  short		idle_signal;					//idle signal
  short		answer_cmd;					//answer command
  short		pickup_cmd;					//pickup command
  short		drop_delay_before;			//delay to wait before send drop command
  short		drop_cmd;					//drop command

  short		flash1_cmd;					//first flash command
  long		flash1_delay;				//delay after first flash command
  short		flash2_cmd;					//first flash command
  long		flash2_delay;				//delay after second flash command

} dg_customCAS_structure;


//--------------------------------------------------------------------
// This structure holds all channel information
//--------------------------------------------------------------------
typedef struct
{
	short h100_enabled;
    short ChPos;
    short DSPPos;
    unsigned char ChFrame;
    unsigned char DSPFrame;
    unsigned char ChSlot;
    unsigned char DSPSlot;
    unsigned char PortRelativeE1;
    unsigned char PortRelativeDSP;
    unsigned char CardRelative;

} dg_h100_structure;

//------------------------------------
//silence detection structure
//------------------------------------
typedef struct
{
	short enabled;

	short last_signal;
	short silence_detected;	//0-no, 1-yes
	unsigned long silence_time;
	unsigned long audio_time;

	//unsigned long last_silence_time;
	unsigned long last_time;

} dg_silence_structure;

//-------------------------------------------------------------------------
//structure to pass and receive signal informations to GSM card's channels
//-------------------------------------------------------------------------
typedef struct
{
#ifdef __LINUX__
  pthread_t  thread_id;
  pthread_t   call_thread_id;
#endif

#ifdef WIN32
  HANDLE thread_id;
  SET_EVENT GSMEvent;
  OVERLAPPED oOverlapGSM;
#endif

  u8	enabled;
  unsigned short port;
  u8 thread_ready;
  
  int nDigitTimeout;
  int nIDRestriction;
  int nUSSDEnable;
  int nCallWaitingEnable;
  int nDisplayCallWaitingEnable;
  int nRetryTimeout;
  int nAnswerTimeout;

  char tx_digits[25];

  char szGSMMessage[256];	//stores all modules strings
  char szPinNumber[50];		//stores Pin Number
  char szNewPinNumber[50];	//stores Pin Number
  char szSQ[50];		//RX signal quality
  char szCQ[50];		//RX call quality
  char szIndexList[256];
  char szLastCommand[256];	

  char szDestNumber[50];	//SMS Destination number
  char szTxSMS[256];		//SMS Send Message
  
  char szRxSMS[256];            //SMS Receive Message
  char szIndex[20];             //SMS memory index  
  char szSMSConfirmation[256];
  char szUSSDMessage[256];

  char rx_id_digits[25];
  char rx_id_number_of_digits; // enable caller ID

  //char bAtendido;		//0-desligado, 1-atendido

  //short ring_event;		//ring tone control
  //short ring_generate_ringback;		//flag indicating if generates auto ring back or not
  int nDialFlag;
  int nHangupFlag;
  short bBlocked;				//bloqueia envio de dados para a thread no caso de alarmes
  char szFifoToGSM[DG_MAX_PATH];

  //variables to send delayed commands to GSM Modules.
  char szDelayedCmd[4][256];
  int  nDelayedCmdIndexW;
  int  nDelayedCmdIndexR;

  //variables to receive delayed commands to GSM Modules (only for receiving SMS).
  char szDelayedRx[16][256];
  int  nDelayedRxIndexW;
  int  nDelayedRxIndexR;

  int  nGSMStep;
  char szMemory[20];
  short flagClear;
  short nMessageConfirmation;
  int nFlashSMS;

  short ClearAllSMS_Enabled;
  int ClearAllSMS_Timeout_Id;
} dg_signal_gsm_thread_structure;

//strucutre
typedef struct
{
	u16		port;							//current port
	char	filename[DG_MAX_PATH];			//file to play with complete path
	char	term_digits[MAX_TX_DATA_LEN];	//digits that can cutoff playback
	char	detected_digit;					//detected digit to cutoff
	long	origin;							//from where offset starts to play
	short   return_code;							//return code
	FILE	*fPlay;							//file handle

}	dg_play_structure;

//--------------------------------------------------------------------
// This structure holds all channel information
//--------------------------------------------------------------------
typedef struct
{
	//short FCardType;       //indicates the card type of this channel
	/* file handles */
	//FILE *fPlay;
	FILE *fRec;
	short bAbortPlayBack;  			//signal to stop play into the thread
	short bAvoidEvent;				//avoids EV_PLAYSTOP

	short dial_abort_signal;			//flag to interrupt dialing/flashing, etc

	//logger control to know what is the targer_port
	short target_port;

	short dial_abort;

	//virtual ports structure
	short card;
	short card_channel;		
	
	//---
	short DetCmd;					//Detection command structure
	short FFastDetection;			//0 - OFF - 1 - ON

	/* play and record format id */
	short	FPlayFileFormat;
	short	FPlayFileFormat_Saved;	//formato salvo para uso no recurso de falar arquivo baseado na extensao

	short	FRecordFileFormat;
	EnumStatusPort FStatusPort;
	short  FDetectionType;
	short fx_type;

    u8      echocan_enabled;        // flag indicating if echo cancelation is enabled or not
	short   echocan_type;           // flag indicating the echo cancelation type (hardware or software)

	short   play_digit_cutoff;		// 0 - indica q nao recebeu digito durante o playback
									// 1 - indica q recebeu digito durante o playback
	short   rec_digit_cutoff;		// 0 - indica q nao recebeu digito durante a gravacao
									// 1 - indica q recebeu digito durante a gravacao

	short	bIsPlaying;     		//Variaveis globais
	short	bIsRecording;   		//que indicam se esta gravando ou reproduzindo
	short	bStopping;				//flag q indica q est�parando

	unsigned long lElapsedRecTime;		//elapsed record time
	short	bRecPaused;					//controls record pause
	long lRecFileSize;
	unsigned short nRecordGain;			//holds record gain
	short	FThreshold;       //answer limiar
	stGetDigit stDigits;
	WaitDigit nGetDigitsState;

	short play_streaming_on;			//flag to send play command to card
	short rec_streaming_on;			//flag

	//play_mode can be file or buffer
	short play_mode;

	//thread control
	short port_playthread;
	short port_recthread;
	short input_buffer_agc;				//save agc information
	char  FDigits[DG_MAX_PATH];			//String that holds digits information
	char FPlayEndDigits[DG_MAX_PATH];			//string that holds which digit will cancel playback
	char FRecEndDigits[DG_MAX_PATH];			//string that holds which digit will cancel playback

	//mailbox
	short mbDetec;
	short mbOldThreshold;
	short SilenceThreshold;
		
	//short fsk;

	//threads structures
	dg_fsk_structure					fsk_info;

	dg_signal_e1_thread_structure		e1_info;
	dg_logger_thread_structure			logger_info;
	dg_logger_ccs_thread_structure		logger_ccs_info;
	dg_dialthread_structure				dial_info;
	dg_flashthread_structure			flash_info;

	dg_customCAS_structure				cas_info;
	dg_call_progress_thread_structure	cp_info;
	dg_idle_structure					idle_info;
	dg_silence_structure				silence;

	dg_signal_gsm_thread_structure		gsm_info;

	dg_play_structure					play_info[DG_MAX_PLAY_QUEUE];
	u16									play_wp;								//insertion pointer
	u16									play_rp;								//remove pointer


	dg_h100_structure				h100info;	//structure that holds

	//connect data
	//short connect_wp;
	//short connect_rp;
	unsigned char  connect_buf[2][1024];
	short connect_index;
	short connect_size[2];
	short connect_port;
	//short connect_flag;

#ifdef __LINUX__

    FILE *fifo_to_debug;

	int fifo_to_e1,
		fifo_to_logger,
		fifo_to_cp,
		fifo_to_idle,
        fifo_to_cas,
        fifo_to_gsm;
#endif
#ifdef WIN32
	HANDLE fifo_to_e1,
			fifo_to_cp,
			fifo_to_idle,
			fifo_to_logger,
			fifo_to_cas,
            fifo_to_gsm,
			fifo_to_loggerCCS;
#endif

}  dg_portstructure;



//--------------------------------------------------------
//Estrutura de gerenciamento de conferencia
//--------------------------------------------------------
typedef struct
{
	long RoomHandle;
	short MaxPorts;
	short PortsCount;
	short PortState[MAX_CHANNELS_CARD];
} dg_chatstructure;

//Defines para a variavel PortState
#define	FREE			0
#define ALLOCATED		1
#define ENABLED			2

#define	MAX_CHATROOMS	30		//valor por placa!

dg_chatstructure	*stConf[MAX_CARDS][MAX_CHATROOMS];	//

#define WHEADER_SIZE			46
#define WHEADERFACT_SIZE		58
#define GSM_HEADER_SIZE		WHEADER_SIZE + 256
#define HEADER_SIZE				138

/* Custom Data Types */

/* Properties to pause symbols */
unsigned short		FCommaDelay;  //pausa 1
unsigned short		FDotDelay;  //pausa 2
unsigned short		FSemicolonDelay;  //pausa 3

//Constants to dg_setdigitfrequency and gain
enum {
	FREQ1,
	FREQ2,
	NONE
};


//extern DIGIVOICE_CRITICAL_SECTION event_mutex;



enum EnumAfterMakeCall { mkOK, 
						 mkNoDialTone,
						 mkDelivered,
						 mkNoAnswer,
						 mkBusy,
						 mkAnswered,
						 mkAborted,
						 mkDialToneAfterDial,
						 mkFaxDetected
						};

enum EnumStatusMakeCall { 
							csPlayingStartPhrase,	//falando frase inicial
							csPickingUp,			//iniciando discagem sem transf
							csInitialFlash,			//Dando flash inicial
							csDialingPrefix,		//prefixo apos o flash
							csStartAnalysis,     //iniciando supervisao
							csNoAnswerReturn,	//retomada em caso de nao atende
							csPlayingBusyPhrase, //falando frase de ret. caso ocupado
							csPlayingNoAnswerPhrase, //falando frase de ret. caso ocupado
							csWaitingDialTone,   //esperando tom de discagem
							csDialing,			 //Discando
							csCalling			 //Chamando


						};




int firmware_e1_version;


char szDeviceSignal[DG_MAX_PATH];
char szDeviceRead[DG_MAX_PATH];
char szDeviceWrite[DG_MAX_PATH];


//array that controls alarms state for each E1
unsigned int block_event[MAX_CARDS][2];  //block alarms after LOSS
unsigned char    e1_alarm[MAX_CARDS][2][8]; //each card has 2 E1 - 8 alarms
unsigned int     last_time[MAX_CARDS][2][8];	//last tickcount to use in alarm detection
unsigned char    e1_slip_cont[MAX_CARDS][2]; //each card has 2 E1

//creates the port structure that holds all runtime
//informations
dg_portstructure    ports_info[MAX_CHANNELS];

unsigned short		event_card[MAX_CARDS];		//variavel de controle para passar pra thread de eventos

unsigned short	reverse_ports[MAX_CARDS][MAX_CHANNELS_CARD];

short muLaw2Lin[256];							// table to convert mulaw to linear

char szConfigFile[DG_MAX_PATH]; // stores the path and filename of the configuration file
char szFirmwareFile[DG_MAX_PATH];   //Path to firmware file
char szDeviceName[DG_MAX_PATH];		//Name of inode
char szConfigurationPath[DG_MAX_PATH];	//Configuration Path

short FGSM_Mode;			//0 - GSM_DIGIVOICE , 1 - GSM_RAW

//handle do arquivo de recuperacao
//FILE		*fReset;
char szResetFile[DG_MAX_PATH];
short tempo_entre_reset;


short nCardsCount, nPortsCount, nCardNumberStartError;


void (DCALLBACK *SendEventsToApp)(void *);
void (DCALLBACK *SendAudioToAppPtr)(short *, int *, void *);			//audio streaming to app
															//params: port, size and data pointer

//void (DCALLBACK *SendAudioToCardPtr)(short *, int *, void *);			//audio streaming to app 
															//params: port, size and data pointer
//ccs log array
int nCCSLog[MAX_CARDS];

//structure to pass CCS frame to application
//card framer size, data
void (DCALLBACK *SendCCSToAppPtr)(short *, short *, int *, void *);	


dg_event_data_structure  *Events_Data;             /* Pointer to callback data structure */

short FDriverEnabled;                /*  flag to indicate if driver is enabled or not */

short FForcePlay;	//forces playback start - default must be FALSE

short FAutoClearDigits;							//holds AutoClearDigits property


//short	FAnswerFactor;									//answer sensibility


long    FDTMFDuration;          //Duracao do DTMF
long    FDTMFPause;             //Pausa interdigito DTMF
long    FDTMFAttenuatingHigh;        //  DTMF attenuating
long    FDTMFAttenuatingLow;        //  DTMF attenuating

short	FVolume;
short	FImpedance;



// Timers structures - Derived from windows version of class TTimer
typedef struct {
	unsigned short	Enabled;    
	long		Interval;	//must receive (msec/ FACTOR_TIMER)
	long		Counter;	
	unsigned short	TimerHandle;
	long		OldCounter;
} TTimer;

unsigned short nGlobalTimerCount;	//contador global para dispositivo de timer

//function that enable/disable timer
unsigned short SetEnableTimer(TTimer *stimer, unsigned short Enable);
//timers
TTimer		tmrTimeOutBina[MAX_CHANNELS];
TTimer		tmrTimeRec[MAX_CHANNELS];
TTimer		tmrAfterDial[MAX_CHANNELS];
TTimer		tmrAfterFlash[MAX_CHANNELS]; 
TTimer		tmrAfterPickUp[MAX_CHANNELS]; 
TTimer		tmrDigit[MAX_CHANNELS]; 
TTimer		tmrInterDigit[MAX_CHANNELS]; 
TTimer		tmr_E1[MAX_CHANNELS];
TTimer		tmr_GSM[MAX_CHANNELS];
TTimer		tmr_GSM_Wait[MAX_CHANNELS];
TTimer		tmr_GSM_ClearAllSMS[MAX_CHANNELS];
TTimer		tmrRing[MAX_CHANNELS];
TTimer		tmrCallProgress[MAX_CHANNELS];
TTimer		tmr_CPThread[MAX_CHANNELS];
TTimer		tmr_CP_AudioCtrl[MAX_CHANNELS];
TTimer		tmr_IdleThread[MAX_CHANNELS];
TTimer		tmr_Silence[MAX_CHANNELS];
TTimer		tmr_CPStart[MAX_CHANNELS];


TTimer		tmrReset;

void write_command(unsigned short port,unsigned short command, unsigned short data_count, unsigned short* wdata);

/* Functions Declarations */
void HandleDigits(dg_event_data_structure *received, short det_type);
void HandleAlarms(dg_event_data_structure *received);
void HandleSilenceDetection(dg_event_data_structure *received);

//threads
void Signal_E1_Thread(void *signal_e1_info);
void Signal_GSM_Thread(void *signal_e1_info);
void Signal_CB_Thread(void *signal_e1_info);
//void Logger_Thread(void *signal_logger_info);
void Call_Progress_Thread(void *signal_e1_info);
void CustomCAS_Thread(void *signal_cas_info);
void Idle_Thread(void *idle_info);

void RecordCloseProcedure(short port);
void RaiseEvents_ThreadSafe(unsigned short command, unsigned short data, unsigned short data_aux, unsigned short port,DIGIVOICE_CRITICAL_SECTION *mtx);
short GetPlayStatus(short port);
short SetPlayStatus(short port, short status);
short SetInputBufferStatus(short port, short status);
short GetInputBufferStatus(short port);
short GetRecBufSize(short port);
void SaveHeaderWave(short Port, FILE *f, unsigned long size, short FileFormat);
int  ReadHeaderWave(FILE *f, void *hd, short FileFormat);
short port2CardChannel(short abs_channel, short *card, short *card_channel);
void InputBufferThread(void *device_info);

#ifdef WIN32
  #ifdef _EXPORTING
	#define CLASS_DECLSPEC    __declspec( dllexport )
	#define	IMPORT_DEF
  #else
	#define CLASS_DECLSPEC    __declspec( dllimport )
	#define	IMPORT_DEF		 extern "C"
  #endif
#else	//linux
	#define CLASS_DECLSPEC 
	#define	IMPORT_DEF		 
#endif


#ifndef __KERNELPLUGIN__

short DebugEnabled;		//global flag
short GSMDebugEnabled;	//global flag

//------------------------------------------------------------------------------------------------------------
// Funcoes publicas
//------------------------------------------------------------------------------------------------------------
//IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_insert_callctrl_fifo(unsigned short port, unsigned short command, unsigned short data);

IMPORT_DEF CLASS_DECLSPEC void dg_port2cardchannel(unsigned int  total_channels,short abs_channel, short *card, short *card_channel);


IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_InsertE1Fifo(unsigned short port,unsigned  short command, unsigned short data);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_InsertGSMFifo(unsigned short port,unsigned  short command, unsigned short data);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_InsertLoggerFifo(unsigned short port,unsigned  short command, unsigned short data);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_R2AskForId(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_R2AskForGroupII(short port, short type);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_R2SendGroupB(short port, short groupb_type);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_R2SendBackwardSignal(short port, short signal);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ReSync(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ResetError(short card, short flag);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetVerboseLevel(short card, short level);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetCardDetections(short card, short type, float value1, float value2);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DriverEnabled(void);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SendR2Command(short port, int r2);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_send_command(short card, short param1,short param2,short param3,short param4,short param5,short param6);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_StartVoicerlib(char *szConfigPath);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ShutdownVoicerlib(void);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ForceSingleSpan(void);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableAutoFramers(void);		//v4.0.7.4
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetCardsCount(void);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetPortsCount(void);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetPortStatus(short);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetCardNumberStartError(void);//v4.0.9.4

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetSpansCount(short card);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetTest(short card);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_PickUp(short port, long pause_after_pickup);	//Pickup method
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_HangUp(short port);	//Hangup Method

IMPORT_DEF CLASS_DECLSPEC void WCDECL dg_SetCCSCallback(void *ptrFunc);

IMPORT_DEF CLASS_DECLSPEC void  WCDECL dg_SetAudioInputCallback(void *ptrFunc);
IMPORT_DEF CLASS_DECLSPEC void  WCDECL dg_SetEventCallback(void *ptrFunc, void *context_data);   //Register a callback function

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetFrequency(short , short );
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_Dial(short , char *, long, short);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DialAbort(short );
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetDialDelays(unsigned short CommaDelay, unsigned short DotDelay, unsigned short SemicolonDelay); //sets delays symbols for dialer

//IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetDetectionType(short port, short DetectionType); //fast ou normal
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetRecordGain(short port, short gain);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetPortGain(short port, short rx_tx,  short value);
//IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableBusyDetection(short port);	//doc
//IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableBusyDetection(short port);  //doc


//CCS - ISDN Support
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableCCSMode(short card, short framer);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SendCCSBuffer(short card, short framer, void *ccs_data, short ccs_size, int *remaining_size);

//Framer functions
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableFramer(short card, short framer);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableFramer(short card, short framer);


//callprogress functions
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CreateCallProgress(short port, char *ConfigFile);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyCallProgress(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ConfigCallProgress(short port, short command, int value);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_InsertCPFifo(unsigned short port,unsigned  short command, unsigned short data);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableCallProgress(short port, short cptype);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableCallProgress(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableSilenceDetection(short port, int silence_time, short audio_time);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableSilenceDetection(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetGSMMode(short mode);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_PlayFile(short port, char *FileName, char *TermDigits, long Origin);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_StopPlayFile(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_StopPlayFileWithoutEvent(short port);

//streaming functions
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_PlayBuffer(short port, void *Samples, short samples_size, int *remaining_size);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_StopPlayBuffer(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_PauseInputBuffer(short port, short paused);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableInputBuffer(short port, short agc_enable);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableInputBuffer(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_RecordFile(short port, char *FileName, char *TermDigits);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_RecordPause(short port, short paused);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_StopRecordFile(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetPlayFormat(short port, enum EnumFileFormat);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetRecordFormat(short port, enum EnumFileFormat file_format);
//
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetRecordFormat(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetPlayFormat(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetDetectionType(short port, short command, short enable); //ex-dg_enabledetections
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetFastDetection(short port, short enable);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_Flash(short port, short flash_count, long msec, long pauseafterflash);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableAnswerDetection(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableAnswerDetection(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisablePulseDetection(short port);	//pulse
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnablePulseDetection(short port, short sensibility);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetDtmfConfig(long duration, long pause);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetFaxFrequencies(short first, short second);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ClearDigits(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ReadDigits(short port, char *szDigits);


IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CancelGetDigits(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetDigits(short port, short maxdigits,
								   char *termdigits, long digitstimeout, 
								   long interdigitstimeout) ;

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_IsPlaying(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_IsRecording(short port);

//---
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetCardSyncMode(unsigned short card, unsigned short SyncMode);


//E1 R2D Thread Control
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CreateE1Thread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyE1Thread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ConfigE1Thread(short port, short command, int value);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableE1Thread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableE1Thread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetE1ThreadStatus(short port);
IMPORT_DEF CLASS_DECLSPEC dg_signal_e1_thread_structure *WCDECL dg_GetE1ThreadPointer(short port);

//GSM card functions
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CreateGSMThread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyGSMThread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ConfigGSMThread(short port, short command, int value);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableGSMThread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableGSMThread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetSMS(short port, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMSendCommand(short port, char *szCommand);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetMessage(short port, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMSetPinNumber(short port, char *szPIN, char *szNewPIN);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMSendSMS(short port, char *szNumber, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMCheckSignalQuality(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetSignalQuality(short port, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetCallQuality(short port, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetIndexList(short port, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMRestartPort(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMDeleteSMS(short port, short index);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMReadAndDeleteSMS(short port, short index);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMListSMS(short port, short status);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMClearAllSMS(short port, short flagClear);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMCallControl(short port, short command, short call);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetLastCommand(short port, char *szCommand);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetMemory(short port, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetSMSConfirmation(short port, char *szMessage);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GSMGetUSSD(short port, char *szMessage);
//GSM Debug
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableGSMDebug(void);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableGSMDebug(void);

//Logger control thread
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CreateLoggerControl(short port, short type);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyLoggerControl(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CreateLoggerCCS(short port, short type);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyLoggerCCS(short port);

//ChannelBank thread
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CreateCBThread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyCBThread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ConfigCBThread(short port, short command, int value);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableCBThread(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableCBThread(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetCallerId(short port, char *szCallerID);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetNameId(short port, char *szNameID);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetE1Number(short port, char *szNumber);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetLoggerCallType(short port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetLoggerSilenceThreshold(short port, short silence);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetPortId(short port, char *szID);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetStartE1RxCount(short port, short count);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetNextE1RxCount(short port, short count);


IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetVersion(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetLECInfo(short card);


IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetSilenceThreshold(short port, short value);

//generic function that allow developer to enable several detection types under E1 card


//IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetToneValues(short card, short type, short value);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GenerateMF(short port, short type, char cDig);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetAlarmStatus(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetAlarmMode(short card, short mode);

//IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableDTMF20(short port, short enable);//removido na versao 4.0.7.4

//port management functions

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetCardPortsCount(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetRelativeChannelNumber(short absoluteport);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetCardNumber(short absoluteport);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetAbsolutePortNumber(short card, short relativeport);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetCardType(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetCardInterface(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetPortInterface(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetPortCardType(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DefinePortResource(short port, short card, short card_channel);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ResetPortResource(void);



IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetFramerLoop(short card , short device, short loop_type);

IMPORT_DEF CLASS_DECLSPEC unsigned int WCDECL dg_GetCardSlot(short card);
IMPORT_DEF CLASS_DECLSPEC unsigned int WCDECL dg_GetCardBus(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableAgc(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableAgc(short port);

//idle functions
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_IdleSettings(short Port, u8 AutoPickUp, short RingCount,
													   short PauseAfterPickUp,
													   u8 WatchTrunkBefore, u8 WatchTrunkAfter,
													   short Format, short TimeOut, short Max, char *TermDigits);


IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_IdleStart(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_IdleAbort(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_InsertIdleFifo(unsigned short port,unsigned  short command, unsigned short data);

//twist
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetTwist(short port, short twist1, short twist2);

//-----------------------------
//funcoes de comutacao via H100
//-----------------------------
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_AllocPort(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_EnablePort(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_HalfDuplexConnect(short port_source, short port_target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_FullDuplexConnect(short port1, short port2);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_HalfDuplexDisconnect(short port_source, short port_target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_FullDuplexDisconnect(short port1, short port2);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_GetFreePortByRange(short port_start, short port_end);	//range

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_SetDefault(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_h100_DisconnectAll(short card);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_LocalBridgeConnect(short port1, short port2);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_LocalBridgeDisconnect(short port1, short port2);



//Custom CAS Thread
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CreateCustomCAS(short port, char *ConfigFile);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyCustomCAS(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ConfigCustomCAS(short port, short command, short value);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_InsertCASFifo(unsigned short port,unsigned  short command, unsigned short data);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetCustomMF(short card, short freqindex, short digit, float value);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DestroyChatRoom(short card, unsigned int Handle);
IMPORT_DEF CLASS_DECLSPEC long WCDECL dg_CreateChatRoom(short card, short maxports);

//IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_setmixer(short port , short port_mixed, short enable);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetPortChatLog(short port , long handle, short enable);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ChatAddPort(long Handle, short Port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ChatRemovePort(long Handle, short Port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ChatEnablePort(long Handle, short Port, short Direction);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ChatDisablePort(long Handle, short Port);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableDTMFFilter(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableDTMFFilter(short port);

#ifdef K_ECHO
	IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableEchoCancelation(short port, short type, short taps, short training, short nlp);
#else//#ifdef K_ECHO
	IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableEchoCancelation(short port, short taps, short training, short nlp);
#endif//#ifdef K_ECHO

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableEchoCancelation(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetEchoCancelationAdapt(short port, short subcommand, short param1, short param2);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ReadCmdCounter(short card);

//functions exported from winapi.h
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableDebug(short UdpPort);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableDebug(void);
short dg_write_rcvd_msg(void *rx_command);

//specific E1 functions
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ConnectBus(unsigned short card, unsigned char conn_type, unsigned char param1,
									unsigned char param2,unsigned char param3);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisconnectBus(unsigned short card, unsigned char conn_type, unsigned char param1,
									unsigned char param2,unsigned char param3);


IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetH100(unsigned short card, unsigned char h100type,
									unsigned char param1,unsigned char param2);


IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetDigitGain(short card, short command, float gain_value);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetDigitFrequency(short card, short command, short frequency,
                                                            char cDigit, int frequency_value);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetE1CRC4Option(short card, short e1, short enable);

//fx card functions
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetRing(short Port, short Enable, short RingType);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetFlash(short Port, short FlashMinTime, short FlashMaxTime);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetFXCardType(short Port, short Type);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_SetFXCardImpedance(short Port, short Impedance);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_WriteFXTypeCode(short Port, short Type);

//new audio functions
IMPORT_DEF CLASS_DECLSPEC	int WCDECL dg_GsmEncode	(unsigned char *linear_source, unsigned char *gsm_target);
IMPORT_DEF CLASS_DECLSPEC	int WCDECL dg_GsmDecode	(unsigned char *gsm_source,    unsigned char *linear_target);
IMPORT_DEF CLASS_DECLSPEC	int WCDECL dg_GsmInit(void);
IMPORT_DEF CLASS_DECLSPEC   int WCDECL dg_GsmDestroy(void);
IMPORT_DEF CLASS_DECLSPEC	int WCDECL dg_GsmEncode49(unsigned char *gsm_source, unsigned char *gsm_target);
IMPORT_DEF CLASS_DECLSPEC	int WCDECL dg_GsmDecode49(unsigned char *gsm_source, unsigned char *gsm_target);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_WaveToGsm(char *Source, char *Target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_Wave49ToGsm(char *Source, char *Target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_Wave49ToGsmRaw(char *Source, char *Target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GsmToWave(char *Source, char *Target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GsmToWave49(char *Source, char *Target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GsmRawToWave49(char *Source, char *Target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GsmRawToWave(char *Source, char *Target);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_WaveToGsmRaw(char *Source, char *Target);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_CheckCode(short wCard, short *wData);//dg_ReadEEPROM
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ReadCode( short wCard, short *wData);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_WriteCode(short wCard,/*short *wOldData,*/ short *wNewData);//dg_WriteCode
IMPORT_DEF CLASS_DECLSPEC void  dg_ReturnCodeToString(short wReturn, char *s);
IMPORT_DEF CLASS_DECLSPEC void  dg_ReturnCodeGSMToString(short wReturn, char *s);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableFSKDetection(short Port, short Enable, short Type);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_GetLibVersion( char* szVersion, short nInfo);

IMPORT_DEF CLASS_DECLSPEC short DCALLBACK dg_ConnectAudioCallback(short port, int size, void *SampleData);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisconnectAudioChannels(short port1,short port2);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ConnectAudioChannels(short port1,short port2);

IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_EnableMailBoxDetection(short port, short silencetime, short audiotime, short threshold);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_DisableMailBoxDetection(short port);
#ifdef __LINUX__
	IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_ReadIRQNumber(short wCard, char *wData);
#endif//#ifdef __LINUX__
IMPORT_DEF CLASS_DECLSPEC short dg_WriteMemory(short card, short addr, short value);
IMPORT_DEF CLASS_DECLSPEC short dg_ReadMemory(short card, short addr);

/* secure string operations
 * taken from OpenBSD. thanks.
 */
size_t strlcpy(char *, const char *, size_t);
size_t strlcat(char *, const char *, size_t);

//make call functions
/*IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_setcallringlimit(short port, short ringcount);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_setcallafteranswer(short port, char *filename, short Pause, short AutoHangUp);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_abortcall(short port);
IMPORT_DEF CLASS_DECLSPEC short WCDECL dg_iscallinprogress(short port) ;
*/
/*short dg_lineartomi(char *szSource, char *Target);*/

#endif //_kernel

/* passos do MFC*/


#endif /* _VOICERLIB_H */


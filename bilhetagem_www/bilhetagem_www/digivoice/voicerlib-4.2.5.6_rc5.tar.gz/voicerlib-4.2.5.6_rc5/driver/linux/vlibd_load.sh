#!/bin/bash

is26=`uname -a | grep 2\.6`

[ "${is26}" ] && KERNELVERSION=26 || KERNELVERSION=3

if [ ${KERNELVERSION} -eq 3 ];
then
	echo "Kernel 3.x....";
	module="vlibd.ko"
	device="vlibd"
	mode=666
else
	echo "Kernel 2.6....";
	module="vlibd.ko"
	device="vlibd"
	mode=666
fi

#eventually unload previous driver
rmmod $module 2> /dev/null

#invoke insmod
echo "Loading $module..."
/sbin/depmod -a
/sbin/modprobe $device $* || exit 1

#remove stale inodes
rm -f /dev/${device}
rm -f /dev/${device}shm
rm -f /dev/${device}_s*
rm -f /dev/${device}_rs
rm -f /dev/${device}_ps
rm -f /dev/${device}_r*
rm -f /dev/${device}_p*
rm -f /dev/${device}_ccs*
rm -f /dev/vlibdshm_ccs

major=`awk "\\$2==\"/dev/$device\" {print \\$1}" /proc/devices`
echo "Allocating major number = $major"

echo "Creating /dev/${device}..."
mknod -m ${mode} /dev/${device} c $major 0
mknod -m ${mode} /dev/vlibdshm c $major 1
mknod -m ${mode} /dev/vlibdshm_ccs c $major 2
#mknod -m ${mode} /dev/vlibd_s c $major 2
###########################################################
# Create Signal inodes
###########################################################
echo "Creating signal inodes..."
PORTS=7
COUNT=0
MINOR=10
while [ ${COUNT} -lt ${PORTS} ]; do
    mknod /dev/${device}_s${COUNT}  c  $major ${MINOR}
    chmod a+w /dev/${device}_s${COUNT}
    COUNT=$[${COUNT}+1]
    MINOR=$[${MINOR}+1]
done

###########################################################
# Create CCS signalling inodes
###########################################################
echo "Creating ccs signalling inodes..."
PORTS=7
COUNT=0
MINOR=30
while [ ${COUNT} -lt ${PORTS} ]; do
    mknod /dev/${device}_ccs${COUNT}  c  $major ${MINOR}
    chmod a+w /dev/${device}_ccs${COUNT}
    COUNT=$[${COUNT}+1]
    MINOR=$[${MINOR}+1]
done

###########################################################
# Create tmp rec inodes
###########################################################
echo "Creating tmp rec inodes..."
PORTS=7
COUNT=0
MINOR=50
while [ ${COUNT} -lt ${PORTS} ]; do
    mknod /dev/${device}_rs${COUNT}  c  $major ${MINOR}
    chmod a+w /dev/${device}_rs${COUNT}
    COUNT=$[${COUNT}+1]
    MINOR=$[${MINOR}+1]
done


###########################################################
# Create tmp play inodes
###########################################################
echo "Creating tmp play inodes..."
PORTS=7
COUNT=0
MINOR=70
while [ ${COUNT} -lt ${PORTS} ]; do
    mknod /dev/${device}_ps${COUNT}  c  $major ${MINOR}
    chmod a+w /dev/${device}_ps${COUNT}
    COUNT=$[${COUNT}+1]
    MINOR=$[${MINOR}+1]
done

###########################################################
# Create Record inodes
# Must be defined based on MAX_REC_GROUP (vlibdef.h)
###########################################################
echo "Creating record inodes..."
PORTS=60
COUNT=0
MINOR=90
while [ ${COUNT} -lt ${PORTS} ]; do
    mknod /dev/${device}_r${COUNT}  c  $major ${MINOR}
    chmod a+w /dev/${device}_r${COUNT}
    COUNT=$[${COUNT}+1]
    MINOR=$[${MINOR}+1]
done

###########################################################
# Create PlayBack inodes
###########################################################
echo "Creating playback inodes..."
PORTS=72
COUNT=0
MINOR=160
while [ ${COUNT} -lt ${PORTS} ]; do
    mknod /dev/${device}_p${COUNT}  c  $major ${MINOR}
    chmod a+w /dev/${device}_p${COUNT}
    COUNT=$[${COUNT}+1]
    MINOR=$[${MINOR}+1]
done

echo "Done!"

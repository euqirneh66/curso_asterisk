
/************************************************************************************
 *                                                                                  *
 *   VoicerLib Linux Device Driver                                                  *
 *                                                                                  *
 *   For cards VoicerBox E1 3060, PCI 0408                                          *
 *                                                                                  *
 *   Copyright (c) 2005 DigiVoice Eletronica                                        *
 *                                                                                  *
 *   Author: DigiVoice Tecnologia em Eletronica Ltda                                *
 *   desenvolvimento@digivoice.com.br                                               *
 *                                                                                  *
 *   ChangeLog:                                                                     *
 *                                                                                  *
 *   29/05/2006 - funcao remap_pfn_range introduzida no kernel 2,6,9. O ifdef foi   *
 *                adequado para evitar erros de compilação no kernel 2.6.8          *
 *                                                                                  *
 *                                                                                  *
 *   This library is free software; you can redistribute it and/or                  *
 *   modify it under the terms of the GNU Lesser General Public                     *
 *   License as published by the Free Software Foundation; either                   *
 *   version 2.1 of the License, or (at your option) any later version.             *
 *                                                                                  *
 *   This library is distributed in the hope that it will be useful,                *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of                 *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU               *
 *   Lesser General Public License for more details.                                *
 *                                                                                  *
 *   You should have received a copy of the GNU Lesser General Public               *
 *   License along with this library; if not, write to the Free Software            *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA   *
 *                                                                                  *
 ************************************************************************************/

//#define USE_DGDUMMY 1

#ifdef USE_DGDUMMY
	//YOU MUST INSTALL THE ZAPTEL AND CREATE A SYMBOLIC LINK TO '/usr/src/zaptel/'
	/*************** ZAPTEL 1.2.X ***************/
		//#include "/usr/src/zaptel/zaptel.h"
		//#include "/usr/src/zaptel/ztdummy.h"
	/*************** ZAPTEL 1.2.X ***************/

	//YOU MUST INSTALL THE ZAPTEL AND CREATE A SYMBOLIC LINK TO '/usr/src/zaptel/'
	/*************** ZAPTEL 1.4.X ***************/
		//#include "/usr/src/zaptel/kernel/zaptel.h"
		//#include "/usr/src/zaptel/kernel/ztdummy.h"
	/*************** ZAPTEL 1.4.X ***************/

	//YOU MUST INSTALL THE DAHDI LINUX AND CREATE A SYMBOLIC LINK TO '/usr/src/dahdi-linux/'
	/*************** DAHDI-LINUX 2.X.X ***************/
		//#include "kernel.h"
		//#define USE_DAHDI 1
	/*************** DAHDI-LINUX 2.X.X ***************/
#endif//#ifdef USE_DGDUMMY

#define CCS_ENABLE 1

#define DRIVER_VERSION "4.2.5.6_rc5"

//DEVELOPMENT ONLY
//#define DEBUG_LEVEL 1

#include <linux/module.h>
#include <linux/init.h>

MODULE_LICENSE("Dual BSD/GPL");

#include <linux/version.h>
#include <linux/errno.h>
#include <linux/fs.h>
#include <linux/mm.h>
#include <linux/interrupt.h>
#include <linux/sched.h>
#include <asm/uaccess.h>
#include <asm/io.h>
#include <linux/vmalloc.h>
#include <linux/mman.h>


#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
  #include <linux/wrapper.h>
#endif


#include <linux/slab.h>

#include <linux/types.h>
#include <linux/fcntl.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/timer.h>

#include <linux/pci.h>
#include <linux/ioport.h>
#include <linux/delay.h>
#include <linux/spinlock.h>
#include <linux/file.h>

#include <asm/irq.h>
#include <asm/bitops.h>
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
	#include <asm/system.h>
#endif//#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
#include <asm/atomic.h>


#include "../../src_common/generic.h"
#include "../../src_common/shmem.h"
#include "vlibdrv.h"

#ifdef K_ECHO
    #include "ec/echo.h"
    echo_can_state_t *ec[MAX_CARDS][MAX_CHANNELS_CARD];
    short ec_rout[MAX_CARDS][MAX_CHANNELS_CARD][SAMPLES_SIZE];
#endif//#ifdef K_ECHO

#ifdef DEBUG
#define xprintk(s, args...)   printk (s, ## args)
#else
#define xprintk(s, args...)   ;
#endif


const char senoide[] = { 0xd5, 0xed, 0x9d, 0x84, 0x83, 0x8f, 0x88, 0x8a, 0x8a, 0x8a, 0x88, 0x8f, 0x83, 0x84, 0x9d, 0xed, 
                         0x55, 0x6d, 0x1d, 0x04, 0x03, 0x0f, 0x08, 0x0a, 0x35, 0x0a, 0x08, 0x0f, 0x03, 0x04, 0x1d, 0x6d};

const unsigned char _gsm_cleanaudio[0x34] = { 0xd0, 0x60, 0xa2, 0xe1, 0x5a, 0x50, 0x00, 0x46, 0xdb, 0x6d, 0xb6, 0xdb, 0x50, 
	                                          0x00, 0x36, 0xdb, 0x6d, 0xb6, 0xdb, 0x50, 0x00, 0x46, 0xdb, 0x6d, 0xb6, 0xdb, 
	                                          0x50, 0x00, 0x36, 0xdb, 0x6d, 0xb6, 0xdb, 0x00 };

//Macros para definir o remap_page_range de acordo com diversas opcoes existentes
//em versoes de kernel


#ifdef RH3AS
    //O remap_page_range no RH3AS/EL 3 ou CentOS-3 utiliza o prototipo do kernel 2.6
    #define REMAP(a,b,c,d,e) remap_page_range((a), (b),(c),(d),(e));
#else
  #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    #define REMAP(a,b,c,d,e) remap_page_range((b),(c),(d),(e));
  #else
    //remap_pfn_range was introduces in kernel 2.6.10  - check http://lwn.net/Articles/104333/ for details
    #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)	
	#define REMAP(a,b,c,d,e) remap_page_range((a),(b),(c),(d),(e));    
    #else
	#define REMAP(a,b,c,d,e) remap_pfn_range((a),(b),(c) >> PAGE_SHIFT ,(d),(e));
    #endif
  #endif
#endif


/* 
 * old remap_page_range was not able to address >32bit memory areas.
 * check http://lwn.net/Articles/104333/ for details
 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
#define remap_range(dummy, from, to, size, prot)\
	remap_page_range((from), (to), (size), (prot))
#else
#define remap_range(vma, from, start, size, prot)\
	remap_page_range((vma), (from), (start), (size), (prot))
#endif /* 2.6.0 */
#else
#define remap_range(vma, from, pfn, size, prot)\
	remap_pfn_range((vma), (from), (pfn) >> PAGE_SHIFT, (size), (prot))
#endif /* 2.6.10 */




#define MAX_CMDS_TX                                                     63
#define MAX_CMDS_RX                                                     64

//minor numbers
#define MINOR_MMAP_MAIN                                                 1

#define MINOR_CCS_MMAP_MAIN                                             2

#define MINOR_SIGNAL_INODE_MIN                                          10
#define MINOR_SIGNAL_INODE_MAX                                          (MINOR_SIGNAL_INODE_MIN + MAX_CARDS)

#define MINOR_CCS_SIGNAL_MIN                                            30
#define MINOR_CCS_SIGNAL_MAX                                            (MINOR_CCS_SIGNAL_MIN + MAX_CARDS)

#define MINOR_REC_INODE_MIN                                             50                                              //used only for wakeup rec threads
#define MINOR_REC_INODE_MAX                                             (MINOR_REC_INODE_MIN + MAX_CARDS)               //used only for wakeup rec threads

#define MINOR_PLAY_INODE_MIN                                            70                                              //used only for wakeup PLAY threads
#define MINOR_PLAY_INODE_MAX                                            (MINOR_PLAY_INODE_MIN + MAX_CARDS)              //used only for wakeup PLAY threads

#define MINOR_REC_START                                                 90                                              //initial and end value for minor
#define MINOR_REC_END                                                   (MINOR_REC_START + MAX_REC_GROUP)               // number range for vlibd_r? inodes

#define MINOR_PLAY_START                                                160                                             //initial and end value for minor
#define MINOR_PLAY_END                                                  (MINOR_PLAY_START + MAX_PLAY_GROUP)             //number range for vlibd_p? inodes

#define SIGNAL_BUFFER_SIZE                                              200

u8 closed_gracefully = 1;			             //flag indicating if vlib closes de driver correctly
u16 nGlobalCardsCount=0;                         //used only in "vlib_release, close without shutdown"
u16 nGlobalCardType[MAX_CARDS];                  //used only in "vlib_release, close without shutdown"

#define VLIB_DEVICE_MODULE "vlibd"
int buffer[MAX_CARDS][1024];
u8 	contador_comandos[MAX_CARDS];


u8	SetKernelEvent[MAX_CARDS];
u8	SetRecEvent[MAX_CARDS*MAX_CHANNELS_CARD];
u8	SetPlayEvent[MAX_CARDS*MAX_CHANNELS_CARD];	/* todo: retirar */


u16	gsm_buffer[MAX_CARDS*MAX_CHANNELS_CARD][SAMPLES_GSM_LEN];

unsigned int conta_isr_play[MAX_CARDS*MAX_CHANNELS_CARD];	//contador de irq

//wait queue 
wait_queue_head_t signal_queue[MAX_CARDS];
struct semaphore sem_signal[MAX_CARDS];

//ccs signalling queue
wait_queue_head_t signal_ccs[MAX_CARDS];
struct semaphore sem_signal_ccs[MAX_CARDS];

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
	int flag_signal_queue[MAX_CARDS];
    int flag_ccs_queue[MAX_CARDS];
#endif

void force_cleanup(void);

int irqflag=0;

unsigned int buffer_size[MAX_CARDS*MAX_CHANNELS_CARD];

/* PCI ID table
 * VoicePhone VENDOR_ID and DEVICE_ID
 */
static struct pci_device_id plx_pci_id_table[] = //__devinitdata =
  {
    {0x10b5, 0x9030, PCI_ANY_ID, PCI_ANY_ID,},
    {0x10b5, 0x9056, PCI_ANY_ID, PCI_ANY_ID,},
    {0,},
  };

short major_number = 0;

short driver_opened = 0;
short shutdown_started = 0;

u8  contador_global[MAX_CARDS*MAX_CHANNELS_CARD];

//shared memory pointers
DG_SHAREDMEMORY *sm;	//pointer to shared memory
DG_PLAYBACKMEM	*pmk[MAX_CARDS*MAX_CHANNELS_CARD];
DG_RECMEM		*rmk[MAX_CARDS*MAX_CHANNELS_CARD];
DG_CCS_MEMORY   *ccsm;

DG_GROUPED_RECMEM *grmk[MAX_REC_GROUP];
DG_GROUPED_PLAYMEM *gpmk[MAX_REC_GROUP];

/*Buffer to record signaling to userland*/
struct rec_signal_buffer
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
  int flag_rec_queue;
#endif
  wait_queue_head_t record_signal_queue;
  unsigned char port[SIGNAL_BUFFER_SIZE];
  int  rp;
  int  wp;
  struct semaphore sem;
};
struct play_signal_buffer
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
  int flag_play_queue;
#endif
  wait_queue_head_t play_signal_queue;
  unsigned char port[SIGNAL_BUFFER_SIZE];
  int  rp;
  int  wp;
  struct semaphore sem;
};

struct rec_signal_buffer rec_signal[MAX_CARDS]; /*Buffer variable to store the readed signals*/
struct play_signal_buffer play_signal[MAX_CARDS];

//Shared memory pointers
static char *kmalloc_area = NULL;
static char *kmalloc_ptr = NULL;
unsigned long virt_addr;

static char *ccs_area = NULL;
static char *ccs_ptr = NULL;



//REC structure
static char *rec_ptr[MAX_REC_GROUP];
static char *rec_area[MAX_REC_GROUP];

//PLAY structure
static char *play_ptr[MAX_PLAY_GROUP];
static char *play_area[MAX_PLAY_GROUP];


short nCardIndex=0;

unsigned char TXContadorGlobal[MAX_CARDS],
			   TXContadorAnterior[MAX_CARDS];
unsigned short Contador7636[MAX_CARDS];


/****************************************/
/*struct that describe the driver functions
 *and parameters. Needed to call pci_register_driver
 */

static struct pci_driver plx_driver = 
  {
    .name = VLIB_DEVICE_MODULE,                  //Device Name
    .id_table = plx_pci_id_table,     //Table of the suported devices
    .probe = plx_probe,               //The probe function name
	
    
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    .remove = plx_close,             //the close function name
#else
	#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
		.remove = __devexit_p(plx_close),
	#else//#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
		.remove = plx_close,
	#endif//#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
	#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,11)
		.shutdown = NULL,
	#endif
#endif

  };
/*
static struct pci_driver plx_driver = 
  {
    name: VLIB_DEVICE_MODULE,                  //Device Name
    probe: plx_probe,               //The probe function name
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
    remove: plx_close,             //the close functio name
#else
    remove: __devexit_p(plx_close),
#endif
    suspend: NULL,
    resume: NULL,
    id_table: plx_pci_id_table,     //Table of the suported devices
  };
*/

#ifdef DEBUG
	static char *GetCardName(short nCard)
	{
		switch(nCard)
		{
			case VBE13060PCI:
				return "VBE13060 rv.1\0";
			case VB0408PCI:
				return "VB0408PCI FXO\0";
			case VBE13060PCI_R:
				return "VBE13060 rv.2\0";
			case VBE16060PCI:
			case VBE16060PCI_R:
				return "VBE16060\0";
	        case VBE13030PCI:
	            return "VBE13030\0";
			case VB0404FX:
				return "VB0404FX FXS\0";
			case VB0404FX_R:
				return "VB0404FX FXS rv.2\0";			
			case VB6060PCIE:
				return "VB6060PCIe\0";
	        case VB3030PCIE:
	            return "VB3030PCIe\0";
	        case VB0404GSM:
	        	return "VB0404GSM\0";
	        case VB0408PCIE:
	        	return "VB0408PCIe\0";
	        case VB1224PCIE:
	        	return "VB1224PCIe\0";
	        case VB1200PCIE:
	            return "VB1200PCIe\0";
			case DGV_2E1F:
				return "DGV-2E1F\0";
	        case DGV_1E1F:
	            return "DGV-1E1F\0";
			default:
				return "Unknown type - is it a DigiVoice Card!?!?";
		}
	}
#endif

#ifdef USE_DGDUMMY
	#ifndef USE_DAHDI
		#define dg_register(a, b) zt_register(a, b)
		#define dg_receive(a)     zt_receive(a) 
		#define dg_transmit(a)    zt_transmit(a)
		#define dg_unregister(a)  zt_unregister(a)	
	#else//#ifndef USE_DAHDI
		struct ztdummy
		{
			struct dahdi_span span;
			struct dahdi_chan _chan;
			struct dahdi_chan *chan;
			unsigned int counter;
		};
		#define dg_register(a, b) dahdi_register(a, b)
		#define dg_receive(a)     dahdi_receive(a) 
		#define dg_transmit(a)    dahdi_transmit(a)
		#define dg_unregister(a)  dahdi_unregister(a)
	#endif//#ifndef USE_DAHDI
	
	static struct ztdummy *dgd;
	short dgd_initialized = 0;

	static int dgdummy_initialize(struct ztdummy *dgd)
	{
		/* Zapata/DAHDI stuff */
	#ifdef USE_DAHDI
			dgd->chan = &dgd->_chan;
	#endif//#ifdef USE_DAHDI
		printk("vlibd: Registering dgdummy driver\n");
		sprintf(dgd->span.name, "DGDUMMY/1");
		sprintf(dgd->span.desc, "%s %d", dgd->span.name, 1);
	#ifndef USE_DAHDI
			sprintf(dgd->chan.name, "DGDUMMY/%d/%d", 1, 0);
			dgd->chan.chanpos = 1;
			dgd->span.deflaw = ZT_LAW_MULAW;
			dgd->chan.pvt = dgd;
	#else//#ifndef USE_DAHDI
			sprintf(dgd->chan->name, "DGDUMMY/%d/%d", 1, 0);
			dgd->chan->chanpos = 1;
			dgd->span.deflaw = DAHDI_LAW_MULAW;
			dgd->chan->pvt = dgd;
	#endif//#ifndef USE_DAHDI		
		dgd->span.chans = &dgd->chan;
		dgd->span.channels = 0;		/* no channels on our span */		
		init_waitqueue_head(&dgd->span.maintq);
		dgd->span.pvt = dgd;		
		dgd_initialized = 1;
		if (dg_register(&dgd->span, 0))		
			return -1;
		return 0;
	}
#endif//#ifdef USE_DGDUMMY

//--------------------------------------------------------------------------------
// Function called when module is unloaded
// or a request region failed
//--------------------------------------------------------------------------------
void plx_close(struct pci_dev *pdev)
{
  int i;

  
  i = plx_getdeviceindex(pdev);
  
  if (i!=-1)
  {
	nCardIndex = i;
    if (pdev->irq)
    {
    	/* first disables irq before release it */
        vlib_interrupt_disable(pdev);
        dsp_hold_reset(pdev);    
#ifdef DEBUG
			xprintk("Releasing IRQ %d from card %d\n",pdev->irq,sm->Cards[nCardIndex].irq_vars.Index);
#endif
        free_irq(pdev->irq,&(sm->Cards[nCardIndex].irq_vars.Index));
    }
    /*If addr_baseo is registred
    *it must be release before unload module
    */
    if (sm->Cards[nCardIndex].addr_base0)
    {
        release_mem_region(sm->Cards[nCardIndex].addr_base0, sm->Cards[nCardIndex].addr_base0_len);
#ifdef DEBUG
			xprintk("plx_close: Releasing BAR0 from card %d\n",nCardIndex);
#endif
    }
    
    /*If addr_base2 is registred
    *it must be release before unload module
    */
    if (sm->Cards[nCardIndex].addr_base2)
    {
        release_mem_region(sm->Cards[nCardIndex].addr_base2, sm->Cards[nCardIndex].addr_base2_len);
        iounmap((unsigned long *)sm->dwMemSpace[nCardIndex]);
#ifdef DEBUG
			xprintk("plx_close: Releasing BAR2 from card %d\n",nCardIndex);
#endif
    }
    
    /* frees memory allocated to channels */
/*    for(j=0;j<card_array[i].numchannels;j++)
	{
		kfree(card_array[i].channels[j]);
	}	
*/
    /*Disable device*/
    pci_disable_device(pdev);

#ifdef DEBUG
		xprintk("plx_close: DigiVoice Driver Unloaded.\n");
#endif
   }
}

/****************************************/
/*Probe Function for pci_register_driver*/
int plx_probe(struct pci_dev *pdev, const struct pci_device_id *ent)
{
	int err;
	int i;

	printk("vlibd->plx_probe: ->Starting probing card number %d\n",nCardIndex);
	err = pci_enable_device(pdev); /*Try to Enable Device*/
	if (err)
	{
		/*If there is no device*/
		nCardIndex++;
		return -EIO;
	}

	/*Take the base address to local configuration registers
	*for memory access mode (BAR0)  */
	sm->Cards[nCardIndex].addr_base0=pci_resource_start(pdev,0);
	sm->Cards[nCardIndex].addr_base0_len=pci_resource_len(pdev,0);
	if (!request_mem_region(sm->Cards[nCardIndex].addr_base0,
				sm->Cards[nCardIndex].addr_base0_len , VLIB_DEVICE))
	{
			//If is where, the region is already in use
			//The module should close device and fail
#ifdef DEBUG
				xprintk(KERN_ERR "plx BAR0: Memory  at 0x%lx-0x%lx busy\n",
								sm->Cards[nCardIndex].addr_base0,sm->Cards[nCardIndex].addr_base0 + sm->Cards[nCardIndex].addr_base0_len - 1);
#endif
			sm->Cards[nCardIndex].addr_base0 = 0;
			plx_close(pdev);
			nCardIndex++;
			return -EBUSY;
	}
	//Remap the address space region in a virtual memory
	sm->dwRegSpace[nCardIndex] = (unsigned long)
				     ioremap(sm->Cards[nCardIndex].addr_base0,
                             sm->Cards[nCardIndex].addr_base0_len);
#ifdef DEBUG
		xprintk("plx_probe: ->Placa %d BAR0 at %x \n",nCardIndex,sm->dwRegSpace[nCardIndex]);
#endif

	//------------------------------------------------------------------
	/*Take the base address to local configuration registers
	*for memory access mode (BAR2)  */
	sm->Cards[nCardIndex].addr_base2=pci_resource_start(pdev,2);
	sm->Cards[nCardIndex].addr_base2_len=pci_resource_len(pdev,2);
	if (!request_mem_region(sm->Cards[nCardIndex].addr_base2,
				sm->Cards[nCardIndex].addr_base2_len , VLIB_DEVICE))
	{
			//If is where, the region is already in use
			//The module should close device and fail
#ifdef DEBUG
				xprintk(KERN_ERR "plx BAR2: Memory  at 0x%lx-0x%lx busy\n",
								sm->Cards[nCardIndex].addr_base2,sm->Cards[nCardIndex].addr_base2 + sm->Cards[nCardIndex].addr_base2_len - 1);
#endif

			sm->Cards[nCardIndex].addr_base2 = 0;
			plx_close(pdev);
			nCardIndex++;
			return -EBUSY;
	}
	//Remap the address space region in a virtual memory
	sm->dwMemSpace[nCardIndex] = (unsigned long)ioremap(sm->Cards[nCardIndex].addr_base2, sm->Cards[nCardIndex].addr_base2_len);
#ifdef DEBUG
		xprintk("plx_probe: ->Placa %d BAR2 at %x \n",nCardIndex,sm->dwMemSpace[nCardIndex]);
#endif
	//----------------------------------------------------

	/* the last parameter avoid Bad Boy warning and it's required for shared interrupts*/
	sm->Cards[nCardIndex].irq_vars.Index = nCardIndex; /* Saves card index  */
	sm->Cards[nCardIndex].irq_vars.thiscard = nCardIndex;
	sm->Cards[nCardIndex].irq_vars.irq = pdev->irq;
	//--------------------------------------
	// Alocates IRQ with shared attribute 	
	//--------------------------------------
	if(request_irq(pdev->irq, vlib_interrupt, VLIB_IRQ_SHARED, VLIB_DEVICE, 
				&(sm->Cards[nCardIndex].irq_vars)))
	{
			printk(KERN_ERR "vlibd->plx_probe: ERROR - Cannot allocate IRQ %d.\n",
							pdev->irq);
			plx_close(pdev);
			nCardIndex++;
			return -EBUSY;
	}
	else
	{
#ifdef DEBUG
				xprintk(KERN_ERR "plx_probe: Card %d Successfully allocate IRQ %d - dev_id=%x.\n",
                                        nCardIndex,pdev->irq,(u32)&(sm->Cards[nCardIndex].irq_vars));
#endif
	}

	/*make a device struct copy.*/
	sm->Cards[nCardIndex].digivoice_dev=pdev;
	if (nCardIndex == 0)
		for (i = 1; i < MAX_CARDS; i++)
			sm->Cards[i].digivoice_dev = NULL;
	
	//E1 initialization
	//plx_writemem(nCardIndex,0x8079c300,E1_CNTRL);
	//plx_writemem(nCardIndex,0x00800007,E1_LAS0BRD);

	dsp_hold_reset(pdev);
	vlib_interrupt_disable(pdev); /*Disable PLX Interrupt. Security reasons*/

    /* go to next position in array*/
	nCardIndex++;

	printk("vlibd->plx_probe: ->Ending probing card number %d\n",(nCardIndex-1));

	return 0;
}


/****************************************/
/*Function called when the module is loaded*/
#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
	static int __devinit init_plx(void)
#else//#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
	static int init_plx(void)
#endif//#if LINUX_VERSION_CODE < KERNEL_VERSION(3,6,0)
{
	int i;
#ifdef K_ECHO
	int j;
#endif//#ifdef K_ECHO
	int cards_count=0;
	
	//nTotalChannels = 0;  //reset total channels counter
	printk("vlibd->init_plx: Probing Device Name: %s\n",VLIB_DEVICE_MODULE);

#ifdef K_ECHO
		printk("vlibd->init_plx: K_ECHO feature enabled!!!\n");
#endif//#ifdef K_ECHO

	nCardIndex= 0;
	/*Search for suported devices*/

    cards_count=0;
    cards_count=plx_countcards(0x9030);
	printk("vlibd->init_plx: Counting 9030 cards: %d Card(s) Found.\n",cards_count);
    sm->nCardsCount=cards_count;
    cards_count=plx_countcards(0x9056);
	printk("vlibd->init_plx: Counting 9056 cards: %d Card(s) Found.\n",cards_count);
    sm->nCardsCount+=cards_count;

	nGlobalCardsCount = sm->nCardsCount;
	printk("vlibd->init_plx: Counting cards: %d Total Card(s) Found.\n",sm->nCardsCount);
	
	if (closed_gracefully==2)
	{
        printk("vlibd->plx_countcards: Calling force_cleanup before.\n");
		force_cleanup();
		pci_unregister_driver(&plx_driver);		
	}
	
	i = pci_register_driver(&plx_driver);
	if (!sm->nCardsCount || i<0)
	{
		/*If where, there is no suported device*/
#ifdef DEBUG
			xprintk("vlibd->init_plx: Error probing: %s\n",VLIB_DEVICE_MODULE);
#endif
		//pci_unregister_driver(&plx_driver);
		return -ENODEV;
	}
	else
	{
		
	   //printk("Total Channels: %d", nTotalChannels);
		for (i = 0; i < MAX_CARDS; i++)
		{
	   	//reset rec signal pointers
	   		rec_signal[i].wp=0;
	   		rec_signal[i].rp=0;

	   	//reset play signal pointers
	   		play_signal[i].wp=0;
	   	    play_signal[i].rp=0;
		}

		printk("vlibd->init_plx: Initializing card mutexes\n");
		//inicia os Mutex para vlib_read
		for (i = 0; i < MAX_CARDS; i++)
		{
#ifndef init_MUTEX
			sema_init(&rec_signal[i].sem,1);	//rec
			sema_init(&play_signal[i].sem,1);//play
			sema_init(&sem_signal[i],1);		//sinal from card
			sema_init(&sem_signal_ccs[i],1);		//ccs sinal
#else
			init_MUTEX(&rec_signal[i].sem);	//rec
			init_MUTEX(&play_signal[i].sem);//play
			init_MUTEX(&sem_signal[i]);		//sinal from card
			init_MUTEX(&sem_signal_ccs[i]);		//ccs sinal
#endif
		}

		for (i = 0; i < MAX_CARDS; i++)
		{
			TXContadorGlobal[i]=0;
			TXContadorAnterior[i]=0;
		}

		//initializes structures to null
		for (i=0; i < MAX_REC_GROUP; i++)
			rec_ptr[i] = NULL;

		//initializes structures to null
		for (i=0; i < MAX_PLAY_GROUP; i++)
			play_ptr[i] = NULL;
		
#ifdef K_ECHO
			//initializes echo canceler pointers
			for (i = 0; i < MAX_CARDS; i++)
			{
				for (j = 0; j < MAX_CHANNELS_CARD; j++)
				{
					ec[i][j] = NULL;
					sm->Cards[i].ec[j] = 0;
				}
			}
#endif//#ifdef K_ECHO
  	}
#ifdef DEBUG
		xprintk("init_plx: exiting routine %s\n",VLIB_DEVICE_MODULE);
#endif
  	return 0;
}
/****************************************/
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	void vlib_interrupt(int irq, void *dev_id, struct pt_regs *regs)
#else
	#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,19)
		static irqreturn_t vlib_interrupt(int irq, void *dev_id)
	#else
		static irqreturn_t vlib_interrupt(int irq, void *dev_id, struct pt_regs *regs)
	#endif
#endif
{
	struct local_irq_structure *local = (struct local_irq_structure *) dev_id;

	//unsigned long flags=0;/*u32*/
	u16 	nCardsCount=0;
	u16 	wCard=0;
	u16 	ptrTemp;
	u32 	count_rx = 0;
#ifdef CCS_ENABLE

    STFIFO_CCS_TX       *ccs_tx;        //local pointer to clarify code
    STFIFO_CCS_RX       *ccs_rx;        //local pointer to clarify code
    //ccs local variables rx
    u32     ccs_rx_ctrl=0;
    u32     ccs_rx_frame_addr=0;
    u32     ccs_rx_ctr_addr=0;
    //ccs local variables tx
    u16     ccs_tx_ctrl=0;
    u32     ccs_tx_frame_addr=0;
    u32     ccs_tx_ctr_addr=0;
    u16     *pWord;
#endif    
    u32	    wp_temp=0;
    
	u32 	tmp1;
	u16 	cmds;
	short 	tmp3;
	u16 	nCh;
	u16 	port=0;
	u8		*pChar;
        
	u8 cbuffer[SAMPLES_SIZE_GSM + 1];
	
#ifdef K_ECHO
		u8 ec_rx[MAX_CHANNELS_CARD][SAMPLES_SIZE];
		u8 ec_tx[MAX_CHANNELS_CARD][SAMPLES_SIZE];

		int ec_ssi;
		short ec_rin, ec_sin, ec_sout;
#endif//#ifdef K_ECHO

#ifdef USE_DGDUMMY	
		short nForCards;
#endif//#ifdef USE_DGDUMMY	

	//just to check
	if (local==NULL)
	{
            printk("vlibdrv: dev_id==NULL!!! \n");
			return IRQ_NONE;
		
	}
	wCard = local->thiscard;

	//check if the interrupt belongs to correct hardware
	//spin_lock_irqsave(&irq_lock,flags);
	//local = (local_irq_structure *)(dev_id);
	//spin_unlock_irqrestore(&irq_lock, (unsigned long)flags);

	if (sm==NULL)
	{
		printk("vlibdrv: sm==NULL!!!!!!\n");
		return IRQ_NONE;
	}

	if ( sm->Cards[local->thiscard].CardType == VBE13060PCI || sm->Cards[local->thiscard].CardType == VB0408PCI ||
             sm->Cards[local->thiscard].CardType == VBE13060PCI_R  || sm->Cards[local->thiscard].CardType == VBE16060PCI ||
             sm->Cards[local->thiscard].CardType == VBE16060PCI_R || sm->Cards[local->thiscard].CardType == VBE13030PCI ||
             sm->Cards[local->thiscard].CardType == VB0404FX || sm->Cards[local->thiscard].CardType == VB0404FX_R)//9030
	{
		//check if interrupt belongs to card
		local->tmp32 = plx_readmem((local->thiscard), VLIB_INTCSR);
		if (!(local->tmp32 & 0x04))
		{
			//suspicious interrupt
			if(irqflag==1)
				xprintk("vlibdrv: --isr handle card pci (%x) - not yet\n",local->thiscard);

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
				return;
#else
				return IRQ_NONE;
#endif
		}
	}
	else //9056
	{
		if ( sm->Cards[local->thiscard].CardType == VB3030PCIE || sm->Cards[local->thiscard].CardType == VB6060PCIE ||
	         sm->Cards[local->thiscard].CardType == DGV_1E1F || sm->Cards[local->thiscard].CardType == DGV_2E1F ||
             sm->Cards[local->thiscard].CardType == VB0404GSM  || sm->Cards[local->thiscard].CardType == VB0408PCIE ||
             sm->Cards[local->thiscard].CardType == VB1224PCIE )//9056
		{
			//check if interrupt belongs to card
			local->tmp32 = plx_readmem((local->thiscard), VLIB_INTCSRE);
			if (!(local->tmp32 & 0x8000))
			{
				//suspicious interrupt
				if(irqflag==1)
					xprintk("vlibdrv: --isr handle card pcie (%x) - not yet\n",local->thiscard);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
				return;
#else
				return IRQ_NONE;
#endif
			}
		}
		else
		{
			printk("vlibdrv: isr handle - not mine!!!\n");
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
				return;
#else
				return IRQ_NONE;
#endif
		}
	}

	//copy to local variable
	wCard = local->thiscard;
	nCardsCount = (unsigned short)sm->nCardsCount;

	//interrupt ack
	dg_kernel_write(sm->dwMemSpace[wCard],HPIC,(unsigned long)0x0005);

    if (!driver_opened)
    {
#ifdef DEBUG
			xprintk("vlibdrv: --isr handle card (%x) - driver still closed\n",local->thiscard);
#endif
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
       return;
#else
       return IRQ_HANDLED;;
#endif

    }
    
#ifdef USE_DGDUMMY
    if (dgd_initialized == 0)
    	if (dgdummy_initialize(dgd)) 
    	{
    		printk("vlibd: Unable to initialize dgdummy driver\n");

    		for (nForCards = 0; nForCards < nCardsCount; nForCards++)
    			sm->Cards[nForCards].dgdummy_interrupt = 0;
    	}

    if (sm->Cards[wCard].dgdummy_interrupt)
    {
    	//printk("vlibdrv send zt_receive/transmit card (%d)\n", wCard);
	    dg_receive(&dgd->span);
	    dg_transmit(&dgd->span);
	
	    dg_receive(&dgd->span);
	    dg_transmit(&dgd->span);
    }
    //else
    	//printk("vlibdrv do not send dg_receive/transmit card (%d)\n", wCard);
#endif//#ifdef USE_DGDUMMY

	//PLACA_NOVA
	//--------------------------------------------------------------------------------
	//Placas modelo novo com retrabalho
	//--------------------------------------------------------------------------------
	//handle interrupt procedure to exchange data between card and app reads control data
    dg_kernel_write(sm->dwMemSpace[wCard],HPIA,CMD_CTR_DSP);
	count_rx = dg_kernel_read(sm->dwMemSpace[wCard],HPID);
	//number of commands
	if (((unsigned short)count_rx == 0x40a))
		local->num_cmds = 999;
	else
	{
		local->num_cmds = (u16)(count_rx & 0x7f);
		if ((count_rx & 0x8000))
		{
			xprintk("vlibdrv: card (%d) - Buffer Overflow\n", wCard);
			//sets flag to allow send error to application
			local->bBufferOverflow = 1;
		}
	}  //4a0
	//Are there commands?
	//---------------------------------------------------------
	// Read command from card PLACA_NOVA
	//---------------------------------------------------------
	if (local->num_cmds > 0 && local->num_cmds <= MAX_CMDS_RX)
	{
		//there are commands and/or errors 	//set active buffer
		local->addr_buffer = (u16)((unsigned short)count_rx & BIT8);
		if (local->addr_buffer==0)
			local->addr_buffer = CMD_DSP_HOST0;
		else
			local->addr_buffer = CMD_DSP_HOST1;

#ifdef DEBUG_KERNEL
			xprintk("vlibdrv: card (%d) - local->num_cmds = %d\n", wCard, local->num_cmds);
			xprintk("vlibdrv: mylog - wCard [%d].%d, %lx,%x, %d\n", wCard, sm->Cards[wCard].CardType, sm->dwMemSpace[wCard],HPIA, local->addr_buffer);
#endif

		//get all data
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
			dg_memcpy_fromio(buffer[wCard], (void *)HPID_AINC, (local->num_cmds * CMD_SIZE_RX), local->addr_buffer, wCard);
#else
			dg_kernel_write(sm->dwMemSpace[wCard],HPIA, local->addr_buffer);
			memcpy_fromio(buffer[wCard],(void *)(sm->dwMemSpace[wCard] + HPID_AINC), local->num_cmds * CMD_SIZE_RX);
#endif

		//check if there is an error pending
		if (local->bBufferOverflow && (local->num_cmds < MAX_CMDS_RX))
		{
			//insert one more command
			tmp1 = local->num_cmds;
			buffer[wCard][tmp1] = C_ERROR;
			buffer[wCard][tmp1+1] = ERROR_CMD_OVERFLOW;
			local->num_cmds++;
			local->bBufferOverflow = 0;
		}
#ifdef DEBUG_KERNEL
			xprintk("vlibdrv: cardscount=%d card (%d) - type: %x - num_channels: %d\n", sm->nCardsCount, wCard, sm->Cards[wCard].CardType, sm->Cards[wCard].numchannels);
#endif
		for (cmds=0; cmds < local->num_cmds ; cmds++)
		{
#ifdef DEBUG_KERNEL
					for (tmp1=0; tmp1 < CMD_SIZE_RX; tmp1++)
						xprintk("vlibdrv: mylog - buffer[%d][%d][%d]=%x\n", wCard, cmds, tmp1, ((buffer[wCard][cmds])>>(8*tmp1))&0xff);
#endif

				//----------------------------------------
				//Put it into FIFO
				//----------------------------------------
				//Calcula proximo item
				ptrTemp = sm->Cards[wCard].Fifo_Cmd_Rx.wp+(CMD_SIZE_RX+1);

				if (ptrTemp > (TAM_FIFO_CMD_RX-1))
					ptrTemp = 0l;
				//se o proximo item for diferente do buffer de retirada, entao pode inserir
				if (ptrTemp != sm->Cards[wCard].Fifo_Cmd_Rx.rp)
				{
					char *cbuf;
					cbuf = (char *)(&buffer[wCard][cmds]);
					//insere
					memcpy_fromio(&sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[sm->Cards[wCard].Fifo_Cmd_Rx.wp], cbuf, CMD_SIZE_RX);
					sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp + (CMD_SIZE_RX)] = (u8)contador_comandos[wCard];

/*
					//--------
					printk("->(%d) vlibe1: FiFo_CMD_RX -> cmd= %02x-%02x-%02x - wp=%d - rp=%x\n",
																					local->ContaInt,
																					sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp]&0xff,
																					sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp+1]&0xff,
																					sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp+2]&0xff,
											sm->Cards[wCard].Fifo_Cmd_Rx.wp,sm->Cards[wCard].Fifo_Cmd_Rx.rp);

					//teste -retirar
					if ((sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp]&0xff)==0x2 &&
			(sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp+2]&0xff) == 0x9) {
						//pra de gravar
						sm->Cards[wCard].input_buffer[0]=INPUT_BUFFER_ENDING;
						printk("->(%d) vlibe1: Para de gravar\n", local->ContaInt);

					}
					//--------
*/
#ifdef DEBUG_LEVEL
						if (sm->Cards[wCard].debug_level > 3)
						{
							printk("vlibdrv: Fifo_Cmd_Rx - [card %d, cmds %d, cmd %x, p1 %x, p2 %x, p3 %x, wp %d, rp %x\n",
								   wCard, local->num_cmds,
								   sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp]&0xff,
								   sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp+1]&0xff,
								   sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp+2]&0xff,
								   sm->Cards[wCard].Fifo_Cmd_Rx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Rx.wp+3]&0xff,
								   sm->Cards[wCard].Fifo_Cmd_Rx.wp,
								   sm->Cards[wCard].Fifo_Cmd_Rx.rp);
						}
#endif//#ifdef DEBUG_LEVEL

					sm->Cards[wCard].Fifo_Cmd_Rx.wp += (CMD_SIZE_RX+1);
					contador_comandos[wCard]++;
					//faz buffer rodar
					if (sm->Cards[wCard].Fifo_Cmd_Rx.wp > (TAM_FIFO_CMD_RX-1))
					{
						sm->Cards[wCard].Fifo_Cmd_Rx.wp = 0l;

#ifdef DEBUG_LEVEL							
							if (sm->Cards[wCard].debug_level > 3)
							{
								printk("vlibdrv: Fifo_Cmd_Rx - Buffer reset - [card: %d]", wCard);
							}
#endif//#ifdef DEBUG_LEVEL
					}
#ifdef DEBUG_KERNEL
					xprintk("->(%d) vlibe1: FiFo_CMD_RX -> cmd= %02x,%02x,%02x - wp=%d - rp=%x\n",   local->ContaInt, buffer[wCard][cmds]&0xff,
																				   buffer[wCard][cmds+1]&0xff,
																				   buffer[wCard][cmds+2]&0xff,
											sm->Cards[wCard].Fifo_Cmd_Rx.wp,sm->Cards[wCard].Fifo_Cmd_Rx.rp);

#endif
				}
				else
				{
					xprintk("->vlibe1: FiFo_CMD_RX overflow!\n");

#ifdef DEBUG_LEVEL
						if (sm->Cards[wCard].debug_level > 3)
						{
							printk("vlibdrv: Fifo_Cmd_Rx - FiFo_CMD_RX overflow - [card: %d]", wCard);
						}
#endif//#ifdef DEBUG_LEVEL
				}
				//----------------------------------------
				//Fim poe na FIFO
				//----------------------------------------
				//obs.: cmds+3 is reserved for future use
		} //for cmds
		//at finish - reset control byte to allow dsp to put more data
		dg_kernel_write(sm->dwMemSpace[wCard],HPIA,CMD_CTR_DSP);
		dg_kernel_write(sm->dwMemSpace[wCard],HPID,0x40A);

		//set event to app
		SetKernelEvent[wCard] = 1;	//avisa que DPC dever gerar evento
		local->CallDPC = TRUE;

		//If the read interrupt is waiting for data, wake it up
#ifdef DEBUG_KERNEL
			xprintk("->vlibe1: Waking Up Read function!\n");
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
		flag_signal_queue[wCard]=1;
#endif
		wake_up_interruptible(&signal_queue[wCard]);
	
	} //num_cmds RX

	//---------------------------------------------------------
	// Send commands to card - PLACA_NOVA
	//---------------------------------------------------------
	//check control register
	dg_kernel_write(sm->dwMemSpace[wCard],HPIA,CMD_CTR_HOST);
	local->tmp32 = dg_kernel_read(sm->dwMemSpace[wCard],HPID);

	if (local->tmp32==0x205)
	{
		cmds = 0;
		local->num_cmds = 0;
#ifdef DEBUG_KERNEL
		dg_kernel_write(sm->dwMemSpace[wCard],HPIA,0x7636);
		dg_kernel_read(sm->dwMemSpace[wCard],HPID,local->tmp32);
		if (local->tmp32 != Contador7636[wCard])
		{
				xprintk("-> (%d)* * * * * ERRO DE TRATAMENTO - lido:%d / transmitido:%d\n", wCard,local->tmp32,Contador7636[wCard]);
		}
#endif

		//pega numero de comandos a transmitir, arrendondado-se de 7
		if (sm->Cards[wCard].Fifo_Cmd_Tx.wp >= sm->Cards[wCard].Fifo_Cmd_Tx.rp)
			cmds = sm->Cards[wCard].Fifo_Cmd_Tx.wp - sm->Cards[wCard].Fifo_Cmd_Tx.rp;
		else
			cmds = (TAM_FIFO_CMD_TX - sm->Cards[wCard].Fifo_Cmd_Tx.rp) + sm->Cards[wCard].Fifo_Cmd_Tx.wp;

		cmds = cmds / (CMD_SIZE_TX+1);

		tmp3 = CMD_HOST_DSP;	//guarda endereco inicial da placa

		//percorre os canais da placa
		while(cmds > 0)
		{
			cmds--;
			//Escreve endereco da HPIA
			dg_kernel_write(sm->dwMemSpace[wCard],HPIA, tmp3);

			writel(*(u32 *)&sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp ],
							(void *)(sm->dwMemSpace[wCard] + HPID_AINC));

#ifdef DEBUG_KERNEL
			if (sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp ]==0xf) {
			  printk("->Cmd TX (%d)-> card:%d  count: %d cmd: %x p1:%x p2:%x p3:%x p4:%x\n", local->ContaInt, wCard,cmds,
									sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp ],
									sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 1],
									sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 2],
									sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 3],
									sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 4]);
			}
#endif

#ifdef DEBUG_LEVEL
				if (sm->Cards[wCard].debug_level > 2)
					printk("vlibdrv: Fifo_Cmd_Tx - [card %d, cmds %d, cmd %x, p1 %x, p2 %x, p3 %x, p4 %x, p5 %x, p6 %x\n",
						   wCard, cmds,
						   sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp ],
						   sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 1],
						   sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 2],
						   sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 3],
						   sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 4],
						   sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 5],
						   sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 6]);
#endif//#ifdef DEBUG_LEVEL

				dg_kernel_write(sm->dwMemSpace[wCard],HPIA, tmp3+2);

			writel(*(u32 *)&sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp+4],
							(void *)sm->dwMemSpace[wCard] + HPID_AINC);
			tmp3 += 3;

			local->num_cmds++;

			TXContadorGlobal[wCard] = sm->Cards[wCard].Fifo_Cmd_Tx.Cmd[ sm->Cards[wCard].Fifo_Cmd_Tx.rp + 6];   //.wContador;

			//soma ponteiro de retirada
			sm->Cards[wCard].Fifo_Cmd_Tx.rp += (CMD_SIZE_TX+1); //VALOR CORRESPONDE

			//faz buffer rodar
			if (sm->Cards[wCard].Fifo_Cmd_Tx.rp > (TAM_FIFO_CMD_TX-1))
			{
				sm->Cards[wCard].Fifo_Cmd_Tx.rp = 0l;
			}
			//get all commands and insert into buffer to transfer to dsp
			if (TXContadorGlobal[wCard] != TXContadorAnterior[wCard]+1)
			{
				if (TXContadorGlobal[wCard]>0)
				{
					xprintk("->(%d) (Pl.Nova) CONTADOR TX INVALIDO %d %d\n\n",local->ContaInt,TXContadorGlobal[wCard],TXContadorAnterior[wCard]);
				}

			}
			TXContadorAnterior[wCard] = TXContadorGlobal[wCard];

			if (local->num_cmds==MAX_CMDS_TX)
			{
				xprintk("(%d) ->Placa Nova %d - Estourou comandos TX (%d) - Na fifo: %d\n", local->ContaInt,wCard,local->num_cmds,sm->Cards[wCard].Fifo_Cmd_Tx.wp-sm->Cards[wCard].Fifo_Cmd_Tx.rp);
				break;
			}

		} //while

		//PLACA_NOVA
		if (local->num_cmds > 0)			//commands to send to card
		{
			//zera contador
			dg_kernel_write(sm->dwMemSpace[wCard],HPIA,0x7636);
			dg_kernel_write(sm->dwMemSpace[wCard],HPID,0);
			//guarda numero de comandos a serem enviados
			Contador7636[wCard] = local->num_cmds&0xff;
#ifdef DEBUG_KERNEL
				xprintk("vlibdrv: Sent %d commands to card %d\n", (u16)local->num_cmds&0xff, wCard);
#endif
			//send number of commands
				dg_kernel_write(sm->dwMemSpace[wCard],HPIA,CMD_CTR_HOST);
				dg_kernel_write(sm->dwMemSpace[wCard],HPID,(u16)local->num_cmds&0xff);

		}
	} //end of tmp32==0


	//------------------------------------------------------------
	// CCS controle enabled - only for E1 cards
	//------------------------------------------------------------
	//
	//
	//
#ifdef CCS_ENABLE

	/*if ((local->ContaInt%0x1ff)==0) {
	   printk("ISR (%d): plca %x Dentro do if de ccs - estado do ccs=%x %x\n", local->ContaInt, sm->Cards[wCard].CardType,
														   sm->Cards[wCard].ccs_enabled[0],
														   sm->Cards[wCard].ccs_enabled[1]);
	} */


	if (sm->Cards[wCard].CardType == VBE13060PCI_R || sm->Cards[wCard].CardType == VBE16060PCI ||
		sm->Cards[wCard].CardType == VBE16060PCI_R || sm->Cards[wCard].CardType == VBE13030PCI ||
		sm->Cards[wCard].CardType == VB3030PCIE    || sm->Cards[wCard].CardType == VB6060PCIE  ||
		sm->Cards[wCard].CardType == DGV_1E1F    || sm->Cards[wCard].CardType == DGV_2E1F  )
	{



		if (sm->Cards[wCard].ccs_enabled[0] || sm->Cards[wCard].ccs_enabled[1])
		{

			ccs_rx_ctr_addr = CCS1_CTR_DSP;  //set first frame
			ccs_rx_frame_addr = CCS1_DSP_HOST0;
			ccs_tx_ctr_addr = CCS1_CTR_HOST;  //set first frame
			ccs_tx_frame_addr =  CCS1_HOST_DSP0;

			for (nCh=0 ; nCh < 2; nCh++)
			{

				if (sm->Cards[wCard].ccs_enabled[nCh])
				{

					//printk("(%d) Step 1 CCS no framer %d - buffer %04x - addr=%x\n",local->ContaInt,nCh+1,ccs_rx_ctrl, ccs_rx_frame_addr);
					//---------------------
					// Receive Frames
					//---------------------
					dg_kernel_write(sm->dwMemSpace[wCard],HPIA,ccs_rx_ctr_addr);
					ccs_rx_ctrl = dg_kernel_read(sm->dwMemSpace[wCard],HPID);
					//number of commands
					if (((unsigned short)ccs_rx_ctrl != 0x400a))
					{
						//copy structure pointer to make code more clean
						ccs_rx = &(ccsm->Cards[wCard].Fifo_CCS_Rx[nCh]);

						// number of bytes
						local->num_cmds=ccs_rx_ctrl&0xff;

						//check active buffer
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
#else
							if (ccs_rx_ctrl&CCS_BUF1)
								dg_kernel_write(sm->dwMemSpace[wCard],HPIA, ccs_rx_frame_addr+0x10); //CCSx_DSP_HOST1
							else
								dg_kernel_write(sm->dwMemSpace[wCard],HPIA, ccs_rx_frame_addr); //CCSx_DSP_HOST0
#endif

#ifdef DEBUG_KERNEL
						xprintk("(%d) Recebeu CCS no framer %d - cmds=%d - buffer %04x (%d)\n",local->ContaInt,nCh+1,local->num_cmds, ccs_rx_ctrl,ccs_rx_ctrl&CCS_BUF1);
#endif
						if (ccs_rx_ctrl&CCS_BAD)  // bad frame received - drop it
						{
							if (ccs_rx_ctrl&CCS_LAST)  //it s the LAST part
								printk("vlibd: (%d) WARN - CCS received a CCS_BAD + CCS_LAST frame in framer %d - size=%d\n",local->ContaInt, nCh+1,(int)local->num_cmds);
							else
								printk("vlibd: (%d) WARN - CCS received a CCS_BAD frame in framer %d - size=%d\n",local->ContaInt, nCh+1,(int)local->num_cmds);

#ifdef DEBUG_KERNEL			    
							xprintk("(%d) Recebeu CCS BAD frame in framer %d - size=%d\n",local->ContaInt, nCh+1,local->num_cmds);
#endif
							//ccsm->Cards[wCard].Fifo_CCS_Rx[nCh].partial = 0;
							ccs_rx->partial = 0;
						}
						else
						{
							//check status bits
							if (ccs_rx_ctrl&CCS_FIRST)  //it s the first (may last, too) part
							{
								ccs_rx->partial = 0;
								ccs_rx->frame_size[ccs_rx->wp] = 0;

#ifdef DEBUG_KERNEL
									xprintk("(%d) Recebeu CCS FIRST frame in framer %d - size=%d\n",local->ContaInt, nCh+1,local->num_cmds);
#endif
							}

							if ((ccs_rx->partial + CCS_FRAME_SIZE) > CCS_DATA_SIZE)
							{
								printk("vlibd: (%d) WARN - CCS detected a CCS_OVERFLOW, our CCS_DATA_SIZE is %d and ccs_rx->partial + CCS_FRAME_SIZE will be %d\n",
									   local->ContaInt, CCS_DATA_SIZE, ccs_rx->partial + CCS_FRAME_SIZE);

								ccs_rx->partial = 0;
								ccs_rx->frame_size[ccs_rx->wp] = 0;
							}

							//get all data
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
							if (ccs_rx_ctrl&CCS_BUF1)
								dg_memcpy_fromio(&ccs_rx->data[ccs_rx->wp][ccs_rx->partial], (void *)HPID_AINC, CCS_FRAME_SIZE, ccs_rx_frame_addr+0x10, wCard); //CCSx_DSP_HOST1
							else
								dg_memcpy_fromio(&ccs_rx->data[ccs_rx->wp][ccs_rx->partial], (void *)HPID_AINC, CCS_FRAME_SIZE, ccs_rx_frame_addr, wCard); //CCSx_DSP_HOST0
#else
							memcpy_fromio(&ccs_rx->data[ccs_rx->wp][ccs_rx->partial], (void *)(sm->dwMemSpace[wCard] + HPID_AINC), CCS_FRAME_SIZE);
#endif

							ccs_rx->partial += local->num_cmds;

#ifdef DEBUG_KERNEL
							xprintk("(%d) ccs_data: partial=%d - data: ", local->ContaInt, ccs_rx->partial);
							for (tmp3=0;tmp3<ccs_rx->partial;tmp3++)
							{
								xprintk("%02x ",(u8)(ccs_rx->data[ ccs_rx->wp ][tmp3]) );
							}
							xprintk("\n");
#endif

							if (ccs_rx_ctrl&CCS_LAST)  //it s the LAST part
							{
#ifdef DEBUG_KERNEL
								xprintk("(%d) Recebeu CCS LAST frame in framer %d - size=%d wp=%d - partial=%d\n",local->ContaInt, nCh+1,local->num_cmds,
												ccs_rx->wp, ccs_rx->partial);

								/*xprintk("(%d) ccs_data: partial=%d - data: ", local->ContaInt,ccs_rx->partial);
								for (tmp3=0;tmp3<ccs_rx->partial;tmp3++)
								{
									xprintk("%02x ",(u8)(ccs_rx->data[ ccs_rx->wp ][tmp3]) );
								}
								xprintk("\n");*/
#endif


								//save frame size
								ccs_rx->frame_size[ccs_rx->wp] = ccs_rx->partial;
								ccs_rx->partial = 0;

								ccs_rx->wp++;
								//rotate buffer
								if (ccs_rx->wp>=CCS_LINES)
								{
									ccs_rx->wp = 0;
								}

								//put signal to thread read it

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
								flag_ccs_queue[wCard]=1;
#endif
								wake_up_interruptible(&signal_ccs[wCard]);

							}
						}

						//reset control address
						dg_kernel_write(sm->dwMemSpace[wCard],HPIA,ccs_rx_ctr_addr);
						dg_kernel_write(sm->dwMemSpace[wCard],HPID,0x400a);

					}  //400a -- ccs receive

					//---------------------
					// Transmit Frames
					//---------------------
					ccs_tx = &(ccsm->Cards[wCard].Fifo_CCS_Tx[nCh]);
					if (ccs_tx->wp >= ccs_tx->rp)
								cmds = ccs_tx->wp - ccs_tx->rp;
							else
								cmds = (CCS_LINES - ccs_tx->rp) + ccs_tx->wp;
					if (cmds>0)
					{
						//check control register
						dg_kernel_write(sm->dwMemSpace[wCard],HPIA,ccs_tx_ctr_addr);
						ccs_tx_ctrl = dg_kernel_read(sm->dwMemSpace[wCard],HPID);
						if (((unsigned short)ccs_tx_ctrl)==0x2005)  //address free to receive new frame_data
						{



							//set correct address buffer
							if (ccs_tx->last_buffer == CCS_BUF1)
							{//sets 1st buffer
								dg_kernel_write(sm->dwMemSpace[wCard],HPIA,ccs_tx_frame_addr);
								ccs_tx->last_buffer = CCS_BUF0;
								//copy structure pointer to make code more clean
#ifdef DEBUG_KERNEL
									xprintk("-->>> (%d) CCS buf1 Preparing TX ccs_data for card %d framer %d - addr=%x\n", local->ContaInt, wCard, nCh+1, ccs_tx_frame_addr);
#endif
							}
							else
							{
								dg_kernel_write(sm->dwMemSpace[wCard],HPIA,ccs_tx_frame_addr+0x10);
#ifdef DEBUG_KERNEL
									xprintk("-->>> (%d) CCS buf0 Preparing TX ccs_data for card %d framer %d - addr=%x\n", local->ContaInt, wCard, nCh+1, ccs_tx_frame_addr+0x10);
#endif
								ccs_tx->last_buffer = CCS_BUF1;
							}


							if (ccs_tx->partial==0) //first part
							{
								if (ccs_tx->wp >= ccs_tx->rp)
									cmds = ccs_tx->wp - ccs_tx->rp;
								else
									cmds = (CCS_LINES - ccs_tx->rp) + ccs_tx->wp;

								if (cmds > 0 && ccs_tx->frame_size[ccs_tx->rp])
								{

									if (ccs_tx->frame_size[ccs_tx->rp] > CCS_FRAME_SIZE/2+4)
									{//send the first part

										//todo:send data!!!!!!!!
										//......
										pWord = (u16 *)ccs_tx->data[ ccs_tx->rp];

										memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC),
													pWord , CCS_FRAME_SIZE/2+4) ;   //send always even bytes

#ifdef DEBUG_KERNEL
											xprintk("-->>> (%d) CCS FIRST_PART card %d framer %d, cmds=%d\n", local->ContaInt, wCard, nCh+1,cmds);
#endif

										//set as a start frame, buffer and size
										ccs_tx_ctrl = CCS_FIRST | ccs_tx->last_buffer | (CCS_FRAME_SIZE/2+4);
										//update partial
										ccs_tx->partial += CCS_FRAME_SIZE/2+4;

#ifdef DEBUG_KERNEL
										xprintk("-->>> (%d) CCS First part 2 card %d framer %d, ctrl=%04x addr=%x\n", local->ContaInt, wCard, nCh+1, ccs_tx_ctrl, ccs_tx_ctr_addr);
										for (tmp3=0;tmp3<CCS_FRAME_SIZE/2+4;tmp3++)
										{
											printk("%02x ",(ccs_tx->data[ ccs_tx->rp ][tmp3])&0xff);
										}
										printk("\n");
#endif
										//---------

									}
									else
									{//all data at once

										//todo:send data!!!!!!!!

										pWord = (u16 *)ccs_tx->data[ ccs_tx->rp];

										memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), pWord , CCS_FRAME_SIZE/2+4);

										ccs_tx_ctrl = CCS_FIRST | CCS_LAST | ccs_tx->last_buffer |
														ccs_tx->frame_size[ccs_tx->rp];

										ccs_tx->partial = 0;

										//---------
#ifdef DEBUG_KERNEL
										xprintk("-->> (%d) TX ALL ccs_data: last_buf: %x ctrl=%x rp=%d sz=%d - data: \n", local->ContaInt,
																						ccs_tx->last_buffer,
																						ccs_tx_ctrl,
																						ccs_tx->rp,
																						ccs_tx->frame_size[ccs_tx->rp]);

										for (tmp3=0;tmp3<16;tmp3++)
										{
											printk("%02x ",(ccs_tx->data[ ccs_tx->rp ][tmp3])&0xff);
										}
										printk("\n");
										//---------
#endif
										ccs_tx->rp++;
										if (ccs_tx->rp>=CCS_LINES)
										{
											ccs_tx->rp=0;
										}


									}
									//write control data
									dg_kernel_write(sm->dwMemSpace[wCard],HPIA,ccs_tx_ctr_addr);
									dg_kernel_write(sm->dwMemSpace[wCard],HPID, ccs_tx_ctrl);

								} //cmds>0
							}
							else
							{
								//continuing ...
#ifdef DEBUG_KERNEL
									xprintk("-->>> (%d) CCS CONTINUING card %d framer %d, partial=%d frame=%d\n", local->ContaInt, wCard, nCh+1,ccs_tx->partial, ccs_tx->frame_size[ccs_tx->rp]);
#endif
								if ( (ccs_tx->frame_size[ccs_tx->rp] - ccs_tx->partial)  > CCS_FRAME_SIZE/2+4)
								{
									pWord = (u16 *)(ccs_tx->data[ ccs_tx->rp]+ccs_tx->partial);

									//still need to send part of frame
									memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC),
												pWord, CCS_FRAME_SIZE/2+4 ) ;   //send always even bytes


									//buffer and size
									ccs_tx_ctrl = ccs_tx->last_buffer | (CCS_FRAME_SIZE/2+4);
									//update partial
									ccs_tx->partial += CCS_FRAME_SIZE/2+4;

								}
								else
								{
									//end of frame
									//todo:send data!!!!!!!!
									//
									pWord = (u16 *)(ccs_tx->data[ ccs_tx->rp]+ccs_tx->partial);

									memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), pWord,CCS_FRAME_SIZE/2+4);


									ccs_tx_ctrl = CCS_LAST | ccs_tx->last_buffer |
												  ((ccs_tx->frame_size[ccs_tx->rp] - ccs_tx->partial));

									ccs_tx->partial = 0;

									ccs_tx->rp++;
									if (ccs_tx->rp>=CCS_LINES)
									{
										ccs_tx->rp=0;
									}
#ifdef DEBUG_KERNEL
										xprintk("-->>> (%d) CCS END card %d framer %d, ctrl=%x - addr=%x\n", local->ContaInt, wCard, nCh+1, ccs_tx_ctrl, ccs_tx_ctr_addr);
#endif
								}
								//write control data
								dg_kernel_write(sm->dwMemSpace[wCard],HPIA,ccs_tx_ctr_addr);
								dg_kernel_write(sm->dwMemSpace[wCard],HPID, ccs_tx_ctrl);


							} //else do continue
						} //0x2005
						else
						{
							printk("vlibd: (%d) WARN - CCS detected address not free to transmit data!\n", local->ContaInt);
						}
					}   //end of cmds

				} // end ofif (sm->Cards[wCard].ccs_enabled[nCh])
				//change to CCS2
				ccs_rx_ctr_addr = CCS2_CTR_DSP;
				ccs_rx_frame_addr = CCS2_DSP_HOST0;
				//change to CCS2 host to dsp
				ccs_tx_ctr_addr = CCS2_CTR_HOST;
				ccs_tx_frame_addr =  CCS2_HOST_DSP0;

			} //for

		}//cards
	}
#endif

	//------------------------------------------------------------
	// Check ActiveBuffer PLACA_NOVA
	// and gsm sync
	//------------------------------------------------------------
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
		dg_memcpy_fromio(local->sync, (void *)HPID_AINC, 8, GSM_SYNC, wCard);
#else
		dg_kernel_write(sm->dwMemSpace[wCard], HPIA, GSM_SYNC);
		memcpy_fromio(local->sync, (void *)(sm->dwMemSpace[wCard] + HPID_AINC), 8);
#endif

	//Sincronismo de gravacao
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
		dg_memcpy_fromio(local->sync_rec, (void *)HPID_AINC, 8, GSM_SYNC_REC, wCard);
#else
		dg_kernel_write(sm->dwMemSpace[wCard], HPIA, GSM_SYNC_REC);
		memcpy_fromio(local->sync_rec ,(void *)(sm->dwMemSpace[wCard] + HPID_AINC), 8);
#endif

	//-------------------
	//check active buffer
	//-------------------
	dg_kernel_write(sm->dwMemSpace[wCard],HPIA,SAMPLES_ACTIVE_BUFFER);
	local->tmp32 = dg_kernel_read(sm->dwMemSpace[wCard],HPID);
	//active buffer guarda o inverso do que eh lido no endereco
	//para poder multiplicar pelo fator 8, mais adiante, no caso do wave
	local->active_buffer = ((u8)local->tmp32 & 0x1);
	local->addr_buffer = SAMPLES_DSP_HOST0;			//record
	local->addr_buffer_play = SAMPLES_HOST_DSP0; 	//playback

	//---------------------------------------------------------------------------------------------------------
	// Recording/Playback routines PLACA_NOVA -
	// the order record/play has been changed to play/record (K_ECHO)
	//---------------------------------------------------------------------------------------------------------
	for (nCh=0 ; nCh <sm->Cards[wCard].numchannels; nCh++)
	{
#ifdef K_ECHO
		//test if is to create an echo canceller
		//sm->Cards[wCard].ec[nCh] &0xf -> ec state
		//sm->Cards[wCard].ec[nCh] >>4  -> ec size
		switch(sm->Cards[wCard].ec[nCh]&0xf)
		{
			case 0://idle
				break;
			case 1://create
				//create echo canceler to this channel
				ec[wCard][nCh] = echo_can_create(1<<((sm->Cards[wCard].ec[nCh] >>4)+4), 0);
#ifdef DEBUG_KERNEL
					xprintk("-->>> echo_can_create = ec[%d][%d] = %x\n", wCard, nCh, ec[wCard][nCh]);
#endif
				echo_can_adaption_mode(ec[wCard][nCh],ECHO_CAN_USE_ADAPTION | ECHO_CAN_USE_NLP | ECHO_CAN_USE_CLIP | ECHO_CAN_USE_TX_HPF | ECHO_CAN_USE_RX_HPF );

				//change state to 2
				sm->Cards[wCard].ec[nCh] = (sm->Cards[wCard].ec[nCh]&0xf0)+2;
				break;
			case 2://running
				break;
			case 3://clearing
#ifdef DEBUG_KERNEL
					xprintk("-->>> echo_can_free = ec[%d][%d] = %x\n", wCard, nCh, ec[wCard][nCh]);
#endif
				echo_can_free(ec[wCard][nCh]);
				ec[wCard][nCh] = NULL;

				//change state to 0
				sm->Cards[wCard].ec[nCh] = sm->Cards[wCard].ec[nCh]&0xf0;
				break;
		}
#endif//#ifdef K_ECHO

		//-------------------------
		// Audio playback PLACA_NOVA
		//-------------------------
		if(sm->Cards[wCard].playing[nCh] != PLAY_OFF)
		{
			//pega valor absoluto do canal
			port  = sm->Cards[wCard].abs_port[nCh];

			//inicial - zera ponteiros
			if(sm->Cards[wCard].playing[nCh] == PLAY_START)
			{
				SetPlayEvent[port-1] = 0;
				//zera ponteiros
				pmk[port-1]->rp = 0;
				pmk[port-1]->wp = 0;
#ifdef DEBUG
				xprintk("plx_isr: stating port %d wp=%d - rp=%d\n",port,pmk[port-1]->wp,pmk[port-1]->rp);
#endif

				sm->Cards[wCard].playing[nCh] = PLAY_STARTING;
			}

			if (sm->Cards[wCard].playing[nCh] == PLAY_ON || sm->Cards[wCard].playing[nCh] == PLAY_ENDING)
			{
				//tratamento wave
				if (sm->Cards[wCard].gsm_state_play[nCh]==GSM_OFF)
				{

					if (pmk[port-1]->play_mode==PLAY_FILE || pmk[port-1]->rp!=pmk[port-1]->wp)
					{
#ifdef K_ECHO
						if(ec[wCard][nCh] != NULL)
						{
							//copy samples from shared memory to temporary tx buffer
							memcpy(&ec_tx[nCh],
									&(pmk[port-1]->data[ pmk[port-1]->rp ]), SAMPLES_SIZE);

							//process echo canceler
							for(ec_ssi=0;ec_ssi<SAMPLES_SIZE;ec_ssi++)
							{
								//****************************************************
								//we need to process tx dc filter first to get rout
								//****************************************************
								switch(pmk[port-1]->format)
								{
									case ffWavePCM:
									case ffWaveULaw:
										//convert sample to linear
										ec_rin = uLaw2Lin[ec_tx[nCh][ec_ssi]];
										//printk("-->>> echo_can_hpf_tx PCM and ULaw = ec[%d][%d]\n", wCard, nCh);
										ec_rout[wCard][nCh][ec_ssi] = echo_can_hpf_tx(ec[wCard][nCh], ec_rin);
										//convert back to ulaw
										ec_tx[nCh][ec_ssi] = Lin2uLaw[(ec_rout[wCard][nCh][ec_ssi]>>2)+0x2000];
										break;
									case ffWaveALaw:
										//convert sample to linear
										ec_rin = ALaw2Lin[ec_tx[nCh][ec_ssi]];
										//printk("-->>> echo_can_hpf_tx ALaw = ec[%d][%d]\n", wCard, nCh);
										ec_rout[wCard][nCh][ec_ssi] = echo_can_hpf_tx(ec[wCard][nCh], ec_rin);
										//convert back to alaw
										ec_tx[nCh][ec_ssi] = Lin2ALaw[(ec_rout[wCard][nCh][ec_ssi]>>3)+0x1000];
										break;
									default:
										break;
								}
							}
							dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17)+ (8*local->active_buffer) );
							memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), ec_tx[nCh], SAMPLES_SIZE);
							pmk[port-1]->rp++;
						}
						else
						{
							dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17)+ (8*local->active_buffer) );
							memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), &(pmk[port-1]->data[ pmk[port-1]->rp ]), SAMPLES_SIZE);
							pmk[port-1]->rp++;
						}

#else//#ifdef K_ECHO

						dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17)+ (8*local->active_buffer) );


/*							for (tmp3=0; tmp3< SAMPLES_SIZE; tmp3++)
							pmk[port-1]->data[  pmk[port-1]->rp ][tmp3] = port;*/

						//copy all at once
						memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC),
								&(pmk[port-1]->data[ pmk[port-1]->rp ]),
								SAMPLES_SIZE);
						pmk[port-1]->rp++;
#endif//#ifdef K_ECHO
					}
					else
					{
						if ((pmk[port-1]->rp == pmk[port-1]->wp) && (pmk[port-1]->play_mode==PLAY_BUFFER))
						{
#ifdef DEBUG
							printk("play_wave (%d): nao tinha nada pra mandar rp=%d wp=%d\n",port, pmk[port-1]->rp, pmk[port-1]->wp);
#endif
							dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17)+ (8*local->active_buffer) );

							switch(pmk[port-1]->format)
							{
								case ffWavePCM:
								case ffWaveULaw:
									memset((char *)(cbuffer), 0xff, SAMPLES_SIZE);
									break;
								case ffWaveALaw:
									memset((char *)(cbuffer), 0x55, SAMPLES_SIZE);
									break;
								default:
									break;
							}
							memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), &cbuffer[0], SAMPLES_SIZE);
						}
					}

					if (pmk[port-1]->rp >= WRITE_BUFFER_LINES) //nao pode ser maior que buffer_lines
					{
						//gira o buffer
						pmk[port-1]->rp = 0;
						//acorda thread de leitura - apenas como recurso extra
						SetPlayEvent[port-1] = 1;
						local->CallDPC = TRUE;
					}

					if (sm->Cards[wCard].playing[nCh] == PLAY_ENDING)
					{
						if (pmk[port-1]->rp == pmk[port-1]->wp)
							sm->Cards[wCard].playing[nCh] = PLAY_OFF;
					}
				} //wave
				else
				{
					//PLACA_NOVA
					//tratamento GSM read gsm bit sync
					// if is set indicates that you need to send the first frame part
					local->tmp32 = nCh/32;
					local->bit = nCh - local->tmp32*32;
					sm->Cards[wCard].gsm_ready[nCh] = (unsigned int)local->sync[local->tmp32] & (unsigned int)(0x1L << local->bit);
					if (sm->Cards[wCard].gsm_ready[nCh])
					{
						if (pmk[port-1]->play_mode==PLAY_FILE || pmk[port-1]->rp!=pmk[port-1]->wp)
						{
							//le todas as 33 amostras de uma vez
							pChar = (u8 *)buffer[wCard];
							memcpy(pChar, &(pmk[port-1]->data[pmk[port-1]->rp]) ,SAMPLES_SIZE_GSM);

							//No caso do GSM tem que passar primeiro 32 amostras e depois a 33a.
							//Isso para manter a eficiencia de se passar 32bits por vez, ja que eh
							//assim que o PCI funciona mais otimizadamente
							//insere na placa
							dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17));
							//copy all at once
							memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), buffer[wCard], 32);

							//ultima amostra
							//dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17) + 16);
							dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17) + 15);
							//copy all at once
							//memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), &buffer[wCard][8], 2);
							//memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), (void *)(&buffer[wCard][8])-(void *)2, 4);
							memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), (void *)((u8)(&buffer[wCard][8])-2), 4);

							pmk[port-1]->rp++;
							if (pmk[port-1]->rp >= WRITE_BUFFER_LINES)
							{
								//gira o buffer
								pmk[port-1]->rp = 0;
								//acorda thread de leitura - apenas como recurso extra
								SetPlayEvent[port-1] = 1;
								local->CallDPC = TRUE;

							}
							sm->Cards[wCard].gsm_ready[nCh] = 0;
						}
						else
						{
							if ((pmk[port-1]->rp == pmk[port-1]->wp) && (pmk[port-1]->play_mode==PLAY_BUFFER))
							{
#ifdef DEBUG
								printk("play_gsm (%d): nao tinha nada pra mandar rp=%d wp=%d\n",port, pmk[port-1]->rp, pmk[port-1]->wp);
#endif
								memcpy(cbuffer, _gsm_cleanaudio, SAMPLES_SIZE_GSM + 1);

								//No caso do GSM tem que passar primeiro 32 amostras e depois a 33a.
								//Isso para manter a eficiencia de se passar 32bits por vez, ja que eh
								//assim que o PCI funciona mais otimizadamente
								//insere na placa
								dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17));
								//copy all at once
								//memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), &cbuffer[0], 32);
								memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), buffer[wCard], 32);

								//ultima amostra
								//dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17) + 16);
								dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer_play + (nCh*17) + 15);
								//copy all at once
								//memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), &cbuffer[32], 2);
								//memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), (void *)(&buffer[wCard][8])-(void *)2, 4);
								memcpy_toio((void *)(sm->dwMemSpace[wCard] + HPID_AINC), (void *)((u8)(&buffer[wCard][8])-2), 4);

								sm->Cards[wCard].gsm_ready[nCh] = 0;
							}
						}
					} //gsm_ready
					if (sm->Cards[wCard].playing[nCh] == PLAY_ENDING)
					{
						if (pmk[port-1]->rp == pmk[port-1]->wp)
							sm->Cards[wCard].playing[nCh] = PLAY_OFF;
					}
				}
			} //else do playstart
		} //audio playback

		//-------------------------------------------------------------------------
		// RECORDING
		//All samples are always avaiable into card buffer but we will
		//transfer it to application only if the command is passed
		//-------------------------------------------------------------------------
		//resets buffer before start
		if (sm->Cards[wCard].input_buffer[nCh] == INPUT_BUFFER_INITIAL)
		{
				//port  = (u16)(nCh + (wCard*MAX_CHANNELS_CARD) ) + 1;
				port  = sm->Cards[wCard].abs_port[nCh];

				if (sm->Cards[wCard].gsm_state_rec[nCh]==GSM_OFF)	//wave
					buffer_size[port-1] = SAMPLES_SIZE * 10;		//20ms
				else
					buffer_size[port-1] = SAMPLES_GSM_LEN;

				//inicia double-buffer
				rmk[port-1]->ub_readed = 0;
				rmk[port-1]->kb = 0;
				rmk[port-1]->ub = 1;
				rmk[port-1]->wp[rmk[port-1]->kb] = 0;
				rmk[port-1]->wp[!rmk[port-1]->kb] = 0;

				SetRecEvent[port-1] = 0;

				sm->Cards[wCard].input_buffer[nCh] = INPUT_BUFFER_ON;
				sm->Cards[wCard].recording_stop[nCh] = 0;


#ifdef DEBUG
			xprintk("->INPUT_BUFFER_INITIAL (Nova) - Placa - %d nCh = %d - tmpport %d buffer=%d\n",
									wCard,nCh,port, buffer_size[port-1]);
#endif
		}



		//PLACA_NOVA
		if (sm->Cards[wCard].input_buffer[nCh]==INPUT_BUFFER_ON ||
				sm->Cards[wCard].input_buffer[nCh]==INPUT_BUFFER_ENDING)
		{ //1
			//pega valor absoluto do canal
			port  = sm->Cards[wCard].abs_port[nCh];
#ifdef DEBUG_KERNEL
			xprintk("-->input_buffer port:%d - pl/ch %d/%d val=%d\n",port,wCard, nCh, sm->Cards[wCard].input_buffer[nCh]);
#endif
			//check frame part of the GSM or not
			if (sm->Cards[wCard].gsm_state_rec[nCh]==GSM_OFF)	//wave
			{//3
				//start fifo flushing and stop read from card
				//handle wave samples read all data and put into buffer
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
#else
				dg_kernel_write(sm->dwMemSpace[wCard], HPIA, local->addr_buffer + (nCh*17) + (8*local->active_buffer));
#endif

#ifdef K_ECHO
				if(ec[wCard][nCh] != NULL)
				{
					//copy samples to temporary rx buffer
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
						dg_memcpy_fromio(&ec_rx[nCh], (void *)HPID_AINC, SAMPLES_SIZE, local->addr_buffer + (nCh*17) + (8*local->active_buffer), wCard);
#else
						memcpy_fromio(&ec_rx[nCh], (void *)(sm->dwMemSpace[wCard] + HPID_AINC), SAMPLES_SIZE);
#endif

					//process echo canceler
					for(ec_ssi=0;ec_ssi<SAMPLES_SIZE;ec_ssi++)
					{
						//****************************************************
						//we need to process tx dc filter first to get rout
						//****************************************************
						switch(pmk[port-1]->format)
						{
							case ffWavePCM:
							case ffWaveULaw:
								//convert sample to linear
								ec_sin = (uLaw2Lin[(int)ec_rx[nCh][ec_ssi]])>>2;
								//printk("-->>> echo_can_update uLaw = ec[%d][%d]\n", wCard, nCh);
								ec_sout = (echo_can_update(ec[wCard][nCh], ec_rout[wCard][nCh][ec_ssi], ec_sin))<<2;
								//convert back to ulaw
								ec_rx[nCh][ec_ssi] = Lin2uLaw[(ec_sout>>2)+0x2000];
								break;
							case ffWaveALaw:
								//convert sample to linear
								ec_sin = (ALaw2Lin[(int)ec_rx[nCh][ec_ssi]])>>2;
								//printk("-->>> echo_can_update ALaw = ec[%d][%d]\n", wCard, nCh);
								ec_sout = (echo_can_update(ec[wCard][nCh], ec_rout[wCard][nCh][ec_ssi], ec_sin))<<2;
								//convert back to alaw
								ec_rx[nCh][ec_ssi] = Lin2ALaw[(ec_sout>>3)+0x1000];
								break;
							default:
								break;
						}
					}
					memcpy(&rmk[port-1]->data[ rmk[port-1]->kb ][rmk[port-1]->wp[rmk[port-1]->kb]] ,
							ec_rx[nCh], SAMPLES_SIZE);
				}
				else
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
						dg_memcpy_fromio(&rmk[port-1]->data[ rmk[port-1]->kb ][rmk[port-1]->wp[rmk[port-1]->kb]], (void *)HPID_AINC, SAMPLES_SIZE, local->addr_buffer + (nCh*17) + (8*local->active_buffer), wCard);
#else
						memcpy_fromio(&rmk[port-1]->data[ rmk[port-1]->kb ][rmk[port-1]->wp[rmk[port-1]->kb]], (void *)(sm->dwMemSpace[wCard] + HPID_AINC), SAMPLES_SIZE);
#endif

#else//#ifdef K_ECHO
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
					dg_memcpy_fromio(&rmk[port-1]->data[rmk[port-1]->kb][rmk[port-1]->wp[rmk[port-1]->kb]], HPID_AINC, SAMPLES_SIZE, local->addr_buffer + (nCh*17) + (8*local->active_buffer), wCard);
#else
					memcpy_fromio(&rmk[port-1]->data[rmk[port-1]->kb][rmk[port-1]->wp[rmk[port-1]->kb]], (void *)(sm->dwMemSpace[wCard] + HPID_AINC), SAMPLES_SIZE);
#endif

#endif//#ifdef K_ECHO
				/*
				for (tmp3=0; tmp3< SAMPLES_SIZE; tmp3++)
					rmk[port-1]->data[ rmk[port-1]->kb ][rmk[port-1]->wp[rmk[port-1]->kb]+tmp3] = contador_global[port-1]++;
				*/

				rmk[port-1]->wp[rmk[port-1]->kb] += SAMPLES_SIZE;

				if( (rmk[port-1]->wp[rmk[port-1]->kb]>=buffer_size[port-1] &&
					rmk[port-1]->ub_readed==0 ) )/* ||
						sm->Cards[wCard].recording_stop[nCh])*/  //TODO: recolocar
				{

#ifdef DEBUG_KERNEL
					xprintk("-->INVERTEU BUFFER port:%d - k:%x u:%x - buf_size=%d - wp=%d recording_stop=%x\n",port, rmk[port-1]->kb,

					if (rmk[port-1]->ub == rmk[port-1]->kb)
						xprintk("-->BUFFER IGUAIS port:%d - k:%x u:%x - buf_size=%d - wp=%d recording_stop=%x\n",port, rmk[port-1]->kb,
									rmk[port-1]->ub , buffer_size[port-1], rmk[port-1]->wp[rmk[port-1]->kb],
									sm->Cards[wCard].recording_stop[nCh]);

#endif

					/* check if wp > buffer_size*/
					if (rmk[port-1]->wp[rmk[port-1]->kb] > buffer_size[port-1])
					{
						//save multiples of 160 samples
						wp_temp = (rmk[port-1]->wp[rmk[port-1]->kb]/buffer_size[port-1]) * buffer_size[port-1];

#ifdef DEBUG_KERNEL
						xprintk("(%d) Envio de buffer elastico - kb=%d - wp=%d - wp_temp=%d\n",
								local->ContaInt,
								rmk[port-1]->kb,
								rmk[port-1]->wp[rmk[port-1]->kb],
								wp_temp);
#endif
						//copy ramaining bytes to another buffer
						memcpy(&rmk[port-1]->data[ !rmk[port-1]->kb ],
							rmk[port-1]->data[ rmk[port-1]->kb ]+wp_temp,
							rmk[port-1]->wp[rmk[port-1]->kb]-wp_temp);

#ifdef DEBUG_KERNEL
						xprintk("(%d) Copiando pro buffer %d = amostras=%d\n",
								local->ContaInt, !rmk[port-1]->kb,
								rmk[port-1]->wp[rmk[port-1]->kb]- wp_temp);
#endif

						//set another buffer wp pointer
						rmk[port-1]->wp[!rmk[port-1]->kb] = rmk[port-1]->wp[rmk[port-1]->kb]-wp_temp;

						//set current buffer size with multiples of 160
						rmk[port-1]->wp[rmk[port-1]->kb] = wp_temp;

					}
					else
					{
						//reset another buffer's  wp if it has no samples
						rmk[port-1]->wp[!rmk[port-1]->kb] = 0;

					}

					//troca o buffer ativo e avisa a thread de gravacao
					rmk[port-1]->ub = rmk[port-1]->kb;
					rmk[port-1]->ub_readed=1;	//espera ler
					rmk[port-1]->kb = !rmk[port-1]->kb;
					//seta evento
					SetRecEvent[port-1] = 1;
					local->CallDPC = TRUE;

					//insert the current port into buffer to send to userland
					rec_signal[wCard].port[rec_signal[wCard].wp] = port;
					rec_signal[wCard].wp++;

					if (rec_signal[wCard].wp>=SIGNAL_BUFFER_SIZE)
						rec_signal[wCard].wp=0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
					rec_signal[wCard].flag_rec_queue = 1;
#endif
					wake_up_interruptible(&rec_signal[wCard].record_signal_queue);
					
				}
				else
				{
					/*if( (rmk[port-1]->wp[rmk[port-1]->kb]>=buffer_size[port-1] && rmk[port-1]->ub_readed ) )
					{
						printk("-->Usando elastico port=%d - containt=%d wp=%d\n",port, local->ContaInt, rmk[port-1]->wp[rmk[port-1]->kb]);
					}*/

					if (rmk[port-1]->wp[rmk[port-1]->kb]>=READ_BUFFER_SIZE)
					{
						rmk[port-1]->ub_readed = 0;
						rmk[port-1]->kb = 0;
						rmk[port-1]->ub = 1;
						rmk[port-1]->wp[rmk[port-1]->kb] = 0;
						rmk[port-1]->wp[!rmk[port-1]->kb] = 0;
#ifdef DEBUG_KERNEL
						
#endif
					}
					else
					{
#ifdef DEBUG_KERNEL						
							if (rmk[port-1]->wp[rmk[port-1]->kb] >  buffer_size[port-1])
							{
						
						xprintk("--> (%d) Buffer Elastico port=%d - wp=%d buffer_size=%d\n",local->ContaInt, port,
								rmk[port-1]->wp[rmk[port-1]->kb],  buffer_size[port-1]);
						}
#endif

					}
					
				}

				if (sm->Cards[wCard].input_buffer[nCh]==INPUT_BUFFER_ENDING)
				{
					sm->Cards[wCard].input_buffer[nCh] = INPUT_BUFFER_FLUSHING;
#ifdef DEBUG_KERNEL
					xprintk("-->INPUT_BUFFER_FLUSHING port:%d \n",port);
#endif

				}
			} //3
			else
			{//4 -  ********** tratamento gsm ************* PLACA_NOVA
				//se esta parando de gravar ja nao faz mais nada
				if (sm->Cards[wCard].input_buffer[nCh]==INPUT_BUFFER_ENDING)
				{
					sm->Cards[wCard].input_buffer[nCh] = INPUT_BUFFER_FLUSHING;
					//marca pra gerar evento no DPC
					if (SetRecEvent[port-1]==0)
					{
						SetRecEvent[port-1] = 1;
						local->CallDPC = TRUE;
						//insert the current port into buffer to send to userland
						rec_signal[wCard].port[rec_signal[wCard].wp] = port;
						rec_signal[wCard].wp++;
						if (rec_signal[wCard].wp>=SIGNAL_BUFFER_SIZE)
							rec_signal[wCard].wp=0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
						rec_signal[wCard].flag_rec_queue = 1;
#endif
						wake_up_interruptible(&rec_signal[wCard].record_signal_queue);
					}
				}

				//tratamento GSM read gsm bit sync
				// if is set indicates that you need to send the first frame part
				local->tmp32 = nCh/32;
				local->bit = nCh - local->tmp32*32;
				local->gsm_ct[nCh] = (unsigned int)local->sync_rec[local->tmp32] & (unsigned int)(0x1L << local->bit);

				if (local->gsm_ct[nCh])
				{
					//read all 33 bytes
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
						dg_memcpy_fromio((&buffer[wCard]), (void *)HPID_AINC, 36, local->addr_buffer + (nCh*17), wCard);
#else
						dg_kernel_write(sm->dwMemSpace[wCard],HPIA,local->addr_buffer + (nCh*17));
						//verificar se tem que passar com o type cast (unsigned int*)
						memcpy_fromio((&buffer[wCard]), (void *)(sm->dwMemSpace[wCard] + HPID_AINC), 36); //33 arredondado de dword
#endif
					
					pChar = (u8 *)buffer[wCard];
					memcpy(&rmk[port-1]->data[ rmk[port-1]->kb  ][rmk[port-1]->wp[rmk[port-1]->kb] ] ,
									pChar,SAMPLES_GSM_LEN);

					rmk[port-1]->wp[rmk[port-1]->kb] += SAMPLES_GSM_LEN;

					if( (rmk[port-1]->wp[rmk[port-1]->kb]>=buffer_size[port-1] && rmk[port-1]->ub_readed==0 ))  //TODO: recolocar 33
					{
						//troca o buffer ativo e avisa a thread de gravacao
						rmk[port-1]->ub = rmk[port-1]->kb;
						rmk[port-1]->ub_readed=1;	//espera ler
						rmk[port-1]->kb = !rmk[port-1]->kb;
						rmk[port-1]->wp[rmk[port-1]->kb] = 0; //zera novo buffer
						//seta evento
						SetRecEvent[port-1] = 1;
						local->CallDPC = TRUE;

#ifdef DEBUG_KERNEL
							xprintk("-->INVERTEU BUFFER GSM port:%d - k:%x u:%x - buf_size=%d - rec_signal.wp=%d\n",port, rmk[port-1]->kb,
										rmk[port-1]->ub , buffer_size[port-1], atomic_read(&rec_signal.wp));
#endif

						//insert the current port into buffer to send to userland
						rec_signal[wCard].port[rec_signal[wCard].wp] = port;
						rec_signal[wCard].wp++;
						if (rec_signal[wCard].wp>=SIGNAL_BUFFER_SIZE)
							rec_signal[wCard].wp=0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
						rec_signal[wCard].flag_rec_queue = 1;
#endif
						wake_up_interruptible(&rec_signal[wCard].record_signal_queue);
					}
					else
					{
							if (rmk[port-1]->wp[rmk[port-1]->kb]>=READ_BUFFER_SIZE)
							{
								rmk[port-1]->ub_readed = 0;
								rmk[port-1]->kb = 0;
								rmk[port-1]->ub = 1;
								rmk[port-1]->wp[rmk[port-1]->kb] = 0;
								rmk[port-1]->wp[!rmk[port-1]->kb] = 0;
#ifdef DEBUG_KERNEL
								xprintk("-->estourou gsm port=%d - containt=%d\n",port, local->ContaInt);
#endif
							}
							else
							{
#ifdef DEBUG_KERNEL
								xprintk("-->Nao preparado gsm port:%d k:%x u:%x - buf_size=%d - ub_readed=%d\n",port,
											rmk[port-1]->kb, rmk[port-1]->ub , buffer_size[port-1], rmk[port-1]->ub_readed);
#endif
								//force insertion of the current port into buffer to send to userland
								rec_signal[wCard].port[rec_signal[wCard].wp] = port;
								rec_signal[wCard].wp++;
								if(rec_signal[wCard].wp>=SIGNAL_BUFFER_SIZE)
									rec_signal[wCard].wp=0;
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
								rec_signal[wCard].flag_rec_queue = 1;
#endif
								wake_up_interruptible(&rec_signal[wCard].record_signal_queue);
							}
					}
				}
			}//4
		}
		else
		{
			//FLUSHING  eh tratado no DPC - Placa nova
			if (sm->Cards[wCard].input_buffer[nCh] == INPUT_BUFFER_FLUSHING)
			{
				//p
				//port  = (u16)(nCh + (wCard*MAX_CHANNELS_CARD) ) + 1;
				port  = sm->Cards[wCard].abs_port[nCh];

				SetRecEvent[port-1] = 1;
				local->CallDPC = TRUE;

				//printk("Rec-> Flushing\n");
				//fica esperando a thread dormir
				if (rmk[port-1]->rec_thread == SLEEPING)
				{
					//last buffer
					if (rmk[port-1]->wp[rmk[port-1]->kb] > 0)
					{
						rmk[port-1]->ub = rmk[port-1]->kb;
						rmk[port-1]->kb = !rmk[port-1]->kb;
						rmk[port-1]->wp[rmk[port-1]->kb] = 0;
					}

					//insert the current port into buffer to send to userland
					rec_signal[wCard].port[rec_signal[wCard].wp] = port;
					rec_signal[wCard].wp++;
					if (rec_signal[wCard].wp>=SIGNAL_BUFFER_SIZE)
						rec_signal[wCard].wp=0;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
						rec_signal[wCard].flag_rec_queue = 1;
#endif
					wake_up_interruptible(&rec_signal[wCard].record_signal_queue);
				}
			}
		} //1 - INPUT_BUFFER_ON
	} //for play/rec placa nova
	local->ContaInt++;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	return;
#else
	return IRQ_HANDLED;
#endif
}

/****************************************/
/*Keep DSP reset cleaning the PLX_CNTRL BIT2 */
// Hold puts the card in reset state
/****************************************/
void dsp_hold_reset(struct pci_dev *pdev)
{
	u32 tmp,i;
	i = plx_getdeviceindex(pdev);
	if (i!=-1)
	{
#ifdef DEBUG
			xprintk ("Holding Reset on card %d!\n",i);
#endif
		if (pdev->device == 0x9030)
		{
			//Code extracted from SetResetxx functions.
			//In the future may be separated into 3 functions
				//------- 1.Set_HCS ----------
			//reads GPIO register
			tmp = plx_readmem(i,E1_GPIOC);
			tmp = tmp | 0xc00; //bit 11 and 12
			plx_writemem(i,tmp,E1_GPIOC);
			//------- 2.Set_Reset ----------
			tmp = plx_readmem(i,E1_GPIOC);
			tmp = tmp | 0x20;
			plx_writemem(i,tmp,E1_GPIOC);
			//------- 3.Set_Reset2 ----------
			tmp = plx_readmem(i,E1_GPIOC);
			tmp = tmp & 0xffffffbf; //clear bit 6
			tmp = tmp | 0x180; //set bit 7 e 8
			plx_writemem(i,tmp,E1_GPIOC);
		}
		else
		{
			//------- Set_Reset ----------
			tmp = plx_readmem(i,0x6c); //GPIOC
			tmp |= 0x00080000; //set bit 19
			tmp &=~0x00010000; //reset bit 16
			plx_writemem(i,tmp,0x6c); //GPIOC
		}
  }
  else
		xprintk("Hold Device not found %d.!\n",i);

}

/*Disable PLX interrup cleaning the VLIB_INTCSR register
 *BIT1 and BIT6
 */
void vlib_interrupt_disable(struct pci_dev *pdev)
{
	u32 tmp,i;
	
	i = plx_getdeviceindex(pdev);
  
	if (i!=-1)
	{  
#ifdef DEBUG
			xprintk("Disabling Interrupt for device %d!\n",i);
#endif
		if(pdev->device == 0x9030)
		{
			tmp=plx_readmem(i,VLIB_INTCSR); /*read VLIB_INTCSR*/
			tmp &= ~(BIT0|BIT6);                     /*Clear BIT0 and BIT6*/
			plx_writemem(i,tmp,VLIB_INTCSR);/*Write tmp to VLIB_INTCSR*/
	        tmp=plx_readmem(i,VLIB_INTCSR); /*read VLIB_INTCSR*/
	        printk ("vlib_interrupt_disable : tmp=%04x offset %x on card %d\n",tmp,VLIB_INTCSR,i);			
		}
		else
		{
			tmp=plx_readmem(i,VLIB_INTCSRE); /*read VLIB_INTCSRE*/
			tmp &= ~(BIT8|BIT11);                     /*Clear BIT8 and BIT11*/
			plx_writemem(i,tmp,VLIB_INTCSRE);/*Write tmp to VLIB_INTCSRE*/
	        tmp=plx_readmem(i,VLIB_INTCSRE); /*read VLIB_INTCSRE*/
	        printk ("vlib_interrupt_disable : tmp=%04x offset %x on card %d\n",tmp,VLIB_INTCSRE,i);
		}
	}
	
#ifdef USE_DGDUMMY
		if (dgd_initialized == 1)
		{
			dg_unregister(&dgd->span);
			printk("vlibd: dgdummy driver unregistered\n");
			dgd_initialized = 0;
		}
#endif//#ifdef USE_DGDUMMY	
}

//----------------------------------------------------------------------------
// open function - called when the "file" /dev/vbe1 is opened in userspace
//----------------------------------------------------------------------------
static int vlib_open (struct inode *inode, struct file *file) 
{
	//xprintk("vlib_open - %s\n", VLIB_SHM_DEVICE);
	// we could do some checking on the flags supplied by "open"
	// i.e. O_NONBLOCK
	// -> set some flag to disable interruptible_sleep_on in vlib_read

	return 0;
}

//----------------------------------------------------------------------------
// close function - called when the "file" /dev/vlib is closed in userspace  
//----------------------------------------------------------------------------
static int vlib_release(struct inode *inode, struct file *file) 
{
	int i;
	u32 tmp;
	
	if (shutdown_started == 1)
	{
		printk("vlib_release - Do not reset cards (nGlobalCardsCount %d)\n", nGlobalCardsCount);
	}
	else
	{
		if ((nGlobalCardsCount > 0) && (nGlobalCardsCount <= MAX_CARDS))
		{
			for (i=0; i<nGlobalCardsCount; i++)
			{
				printk("vlib_release - nGlobalCardsType[%d] =  %x\n",i,nGlobalCardType[i]);

				if ( nGlobalCardType[i] == VBE13030PCI || nGlobalCardType[i] == VBE16060PCI ||
					 nGlobalCardType[i] == VBE16060PCI_R || nGlobalCardType[i] == VB0404FX_R  ||
					 nGlobalCardType[i] == VB0404FX  || nGlobalCardType[i] == VB0408PCI ||
					 nGlobalCardType[i] == VB1224PCIE )
				{
					printk("vlib_release: reseting card %d(0x9030).\n", i);

					//------- 1.Set_HCS ----------
					//reads GPIO register
					tmp = plx_readmem(i,E1_GPIOC);
					tmp = tmp | 0xc00; //bit 11 and 12
					plx_writemem(i,tmp,E1_GPIOC);
					//------- 2.Set_Reset ----------
					tmp = plx_readmem(i,E1_GPIOC);
					tmp = tmp | 0x20;
					plx_writemem(i,tmp,E1_GPIOC);
					//------- 3.Set_Reset2 ----------
					tmp = plx_readmem(i,E1_GPIOC);
					tmp = tmp & 0xffffffbf; //clear bit 6
					tmp = tmp | 0x180; //set bit 7 e 8
					plx_writemem(i,tmp,E1_GPIOC);
				}
				else
					if ( nGlobalCardType[i] == VB3030PCIE || nGlobalCardType[i] == VB6060PCIE ||
					     nGlobalCardType[i] == DGV_1E1F || nGlobalCardType[i] == DGV_2E1F ||
						 nGlobalCardType[i] == VB0404GSM  || nGlobalCardType[i] == VB0408PCIE ||
						 nGlobalCardType[i] == VB1224PCIE )
					{
						printk("vlib_release: reseting card %d(0x9056).\n", i);

						//------- Set_Reset ----------
						tmp = plx_readmem(i,0x6c); //GPIOC
						tmp |= 0x00080000; //set bit 19
						tmp &=~0x00010000; //reset bit 16
						plx_writemem(i,tmp,0x6c); //GPIOC
					}
			}
		}
	}

	nGlobalCardsCount = 0;

	return 0;
}

//----------------------------------------------------------------------------
// read function called when from /dev/vlib is read
//----------------------------------------------------------------------------
static ssize_t vlib_read (struct file *filp, char *buf, size_t count, loff_t *ppos)
{

	//get local_minor_number
	short local_minor_number = MINOR(filp->f_dentry->d_inode->i_rdev);
	int ret=0;
	int local_signal_wp=0;
	const char szVal = '1';
	unsigned short data_transfer;

	if (driver_opened == 0) return 0;

	if (shutdown_started) return 99; /* change default return value to signal the thread to kill "itself" */

	//if (local_minor_number==MINOR_SIGNAL_INODE)
	if (local_minor_number>=MINOR_SIGNAL_INODE_MIN && local_minor_number<=MINOR_SIGNAL_INODE_MAX)
	{
		//wait event
#ifdef DEBUG_KERNEL
			xprintk("vlib_read (%d)- MINOR=%d going to sleep....\n",local_minor_number-MINOR_SIGNAL_INODE_MIN,local_minor_number);
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
		interruptible_sleep_on(&signal_queue[local_minor_number-MINOR_SIGNAL_INODE_MIN]);
#else
		if(wait_event_interruptible(signal_queue[local_minor_number-MINOR_SIGNAL_INODE_MIN],flag_signal_queue[local_minor_number-MINOR_SIGNAL_INODE_MIN]!=0))
			return -ERESTARTSYS;

		flag_signal_queue[local_minor_number-MINOR_SIGNAL_INODE_MIN]=0;
#endif
		if (down_interruptible(&sem_signal[local_minor_number-MINOR_SIGNAL_INODE_MIN]))
		{
			printk("vlib_read - down falhou - signal");
					return -ERESTARTSYS;
		}

		//xprintk("vlib_read (%d)- MINOR=%d waking up\n",local_minor_number-MINOR_SIGNAL_INODE_MIN,local_minor_number);
		if (driver_opened)
		{
			ret = copy_to_user(buf,&szVal,1);
#ifdef DEBUG_KERNEL
				xprintk("vlib_read - copy_to_user events %x\n",ret);
#endif
		}
		up(&sem_signal[local_minor_number-MINOR_SIGNAL_INODE_MIN]);
//		printk("vlib_read->Signal End. local_minor_number %d\n",local_minor_number);

	}	//end switch
	else
		if (local_minor_number>=MINOR_REC_INODE_MIN && local_minor_number<=MINOR_REC_INODE_MAX)
		{
			//used to transfer signal to VLIB_DEVICE_REC_SIGNAL	(/dev/vlibd_rs)

			if (down_interruptible(&rec_signal[local_minor_number-MINOR_REC_INODE_MIN].sem))
			{
				printk("vlib_read - down falhou - 1 record");
					return -ERESTARTSYS;
			}
			local_signal_wp = rec_signal[local_minor_number-MINOR_REC_INODE_MIN].wp;

			
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
				if (rec_signal[local_minor_number-MINOR_REC_INODE_MIN].rp)==local_signal_wp)
				{
					up(&rec_signal[local_minor_number-MINOR_REC_INODE_MIN].sem)

					interruptible_sleep_on(&rec_signal[local_minor_number-MINOR_REC_INODE_MIN].record_signal_queue);

					if (down_interruptible(&rec_signal[local_minor_number-MINOR_REC_INODE_MIN].sem))
					{
						printk("vlib_read - down falhou - 2 record");
						return -ERESTARTSYS;
					}
				}
#else
				if (rec_signal[local_minor_number-MINOR_REC_INODE_MIN].rp==local_signal_wp)
			{
					up(&rec_signal[local_minor_number-MINOR_REC_INODE_MIN].sem);
				//xprintk("vlib_read - MINOR_REC_INODE going to sleep....flag=%d\n",rec_signal.flag_rec_queue);
					
					if(wait_event_interruptible(rec_signal[local_minor_number-MINOR_REC_INODE_MIN].record_signal_queue, rec_signal[local_minor_number-MINOR_REC_INODE_MIN].flag_rec_queue!=0))
						return -ERESTARTSYS;

					if (down_interruptible(&rec_signal[local_minor_number-MINOR_REC_INODE_MIN].sem))
					{
						printk("vlib_read - down falhou - 2 record");
						return -ERESTARTSYS;
			}
				}
				rec_signal[local_minor_number-MINOR_REC_INODE_MIN].flag_rec_queue = 0;
#endif
			
				data_transfer = rec_signal[local_minor_number-MINOR_REC_INODE_MIN].port[rec_signal[local_minor_number-MINOR_REC_INODE_MIN].rp];
			
				rec_signal[local_minor_number-MINOR_REC_INODE_MIN].rp++;
				if (rec_signal[local_minor_number-MINOR_REC_INODE_MIN].rp>=SIGNAL_BUFFER_SIZE)
						rec_signal[local_minor_number-MINOR_REC_INODE_MIN].rp=0;
					
			//copy data to userland
			if (driver_opened) {

                    ret = copy_to_user(buf,&data_transfer,2);
#ifdef DEBUG_KERNEL
						xprintk("vlib_read - record copy_to_user port %d ret=%d wp=%d rp=%d....\n",data_transfer,ret, local_signal_wp,atomic_read(&rec_signal.rp));
#endif
			}
				up(&rec_signal[local_minor_number-MINOR_REC_INODE_MIN].sem);
//				printk("vlib_read->Rec End. local_minor_number %d\n",local_minor_number);

		}
		else	
			if (local_minor_number>=MINOR_PLAY_INODE_MIN && local_minor_number<=MINOR_PLAY_INODE_MAX)
			{
				//used to transfer signal to VLIB_DEVICE_PLAY_SIGNAL	(/dev/vlibd_ps)
#ifdef DEBUG_KERNEL
					xprintk("vlib_read - MINOR_PLAY_INODE going to sleep....\n");
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
				interruptible_sleep_on(&play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].play_signal_queue);

				if (down_interruptible(&play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].sem))
				{
					printk("vlib_read - down falhou - play");
					return -ERESTARTSYS;
				}
#else
				if(wait_event_interruptible(play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].play_signal_queue, play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].flag_play_queue != 0))
					return -ERESTARTSYS;
 

				if (down_interruptible(&play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].sem))
				{
					printk("vlib_read - down falhou - play");
					return -ERESTARTSYS;
				}

				play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].flag_play_queue = 0;
#endif
	
				data_transfer = play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].port[play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].rp];
				
				play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].rp++;
				if (play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].rp>=SIGNAL_BUFFER_SIZE)
						play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].rp=0;					
						
				//copy data to userland
				if (driver_opened) {
					ret = copy_to_user(buf,&data_transfer,2);
#ifdef DEBUG_KERNEL
						xprintk("vlib_read - play copy_to_user port %d ret=%d....\n",data_transfer,ret);
#endif
				}
				up(&play_signal[local_minor_number-MINOR_PLAY_INODE_MIN].sem);
//				printk("vlib_read->Play End. local_minor_number %d\n",local_minor_number);

			}
            else
                if (local_minor_number>=MINOR_CCS_SIGNAL_MIN && local_minor_number<=MINOR_CCS_SIGNAL_MAX)
                {
                    //singals to wake signalling thread
                    
                    //wait event
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
                   interruptible_sleep_on(&signal_ccs[local_minor_number-MINOR_CCS_SIGNAL_MIN]);

	   			    if (down_interruptible(&sem_signal_ccs[local_minor_number-MINOR_CCS_SIGNAL_MIN]))
					{
						printk("vlib_read - down falhou - ccs");
						return -ERESTARTSYS;
					}

#else
                   // printk("vlib_read - ccs copy_to_user going to sleep... local: %d - %d = index %d\n",
                   //             local_minor_number,
                   //             MINOR_CCS_SIGNAL_MIN,
                   //             (local_minor_number-MINOR_CCS_SIGNAL_MIN));

                    if(wait_event_interruptible(signal_ccs[local_minor_number-MINOR_CCS_SIGNAL_MIN],
                    		                flag_ccs_queue[local_minor_number-MINOR_CCS_SIGNAL_MIN] != 0))
							return -ERESTARTSYS;

					if (down_interruptible(&sem_signal_ccs[local_minor_number-MINOR_CCS_SIGNAL_MIN]))
					{
						printk("vlib_read - down falhou - ccs");
						return -ERESTARTSYS;
					}

                    //printk("vlib_read - ccs copy_to_user waked up ....\n");
                    flag_ccs_queue[local_minor_number-MINOR_CCS_SIGNAL_MIN]=0;
#endif

                    if (driver_opened)
                    {

                        ret = copy_to_user(buf,&szVal,1);
#ifdef DEBUG_KERNEL
							xprintk("vlib_read - ccs copy_to_user ret=%d....\n",ret);
#endif

                    }
					up(&sem_signal_ccs[local_minor_number-MINOR_CCS_SIGNAL_MIN]);
                }

	if (shutdown_started)
		return 99;
	else
		return 0;
}
//----------------------------------------------------------------------------
// write function called when to /dev/vlib is written
//----------------------------------------------------------------------------
static ssize_t vlib_write (struct file *file, const char *buf,
		size_t count, loff_t *ppos) 
{
#ifdef DEBUG_KERNEL
		xprintk("vlib_write\n");
#endif
	return count;
}

//----------------------------------------------------------------------------
// ioctl - I/O control
//----------------------------------------------------------------------------
static int vlib_ioctl(struct inode *inode, struct file *file,
		unsigned int cmd, unsigned long arg) 
{
	int retval = 0;
	int LEN = sizeof(DG_SHAREDMEMORY);
	struct MEM_CMD	 *stcmd;
	ALLOC_STRUCT 	 *mem_data;
	unsigned char *pval;
	unsigned char card;

	u32 dwRet = 0L;
	u16 wVal;

	short nForCards;

	switch ( cmd ) 
	{
		case VLIB_IOCTL_ENABLE_ISR:		//calls vlib_interruptenable
			pval = (unsigned char *)arg;
			card  = *pval;
			printk("vlib_ioctl(%d)->VLIB_IOCTL_ENABLE_ISR\n",card);
			//vlib_interrupt_enable(sm->Cards[card].digivoice_dev);
			closed_gracefully = 2;	//set flag false 
            if ( (card+1) == sm->nCardsCount )
            {
#ifdef DEBUG_KERNEL
					xprintk("Enable Interrupt: card %d - type %x - enabling global driver handle\n",card, sm->Cards[card].CardType);
#endif
                driver_opened = 1;
                shutdown_started = 0;
				for(wVal=0;wVal<sm->nCardsCount;wVal++) 
					vlib_interrupt_enable(sm->Cards[wVal].digivoice_dev);
            }
            
#ifdef DEBUG
            	printk("vlibd->vlib_ioctl: ->setting nGlobalCardType on %d, CardType: %x\n", card, sm->Cards[card].CardType);
#endif
       		nGlobalCardType[card] = sm->Cards[card].CardType;
			break;
		case VLIB_IOCTL_DISABLE_ISR: 	//calls vlib_interruptdisable
			pval = (unsigned char *)arg;
			card  = *pval;
			printk("vlib_ioctl(%d)-> VLIB_IOCTL_DISABLE_ISR\n",card);
			vlib_interrupt_disable(sm->Cards[card].digivoice_dev);
			closed_gracefully = 1;	//set true to avoid unload module cleanup
            driver_opened = 0;
			break;
		case VLIB_IOCTL_COUNTCARDS:
			wVal = plx_countcards(arg);
#ifdef DEBUG_KERNEL
				xprintk("VLIB_IOCTL_COUNTCARDS: wVal = %d\n",wVal);
#endif
			return wVal;
			break;
		case VLIB_IOCTL_READU32:			/* read dword value */
			stcmd = (struct MEM_CMD *)arg;
			if (stcmd->dwAddrSpace==VLIB_AD_BAR0)
			{
				//printk("READDWORD 1: card=%d Addr: %x offset=%x ret = %x\n",stcmd->card,sm->dwRegSpace[stcmd->card],stcmd->dwOffSet,dwRet);
				dwRet = readl((int *)(sm->dwRegSpace[stcmd->card] + stcmd->dwOffSet));
				//printk("READDWORD 1,5: card=%d Addr: %x offset=%x ret = %x\n",stcmd->card,sm->dwRegSpace[stcmd->card],stcmd->dwOffSet,dwRet);
				
			}
			else
				if (stcmd->dwAddrSpace==VLIB_AD_BAR2)		
				{
					//printk("READDWORD 2: card=%d Addr: %x offset=%x ret = %x\n",stcmd->card,sm->dwRegSpace[stcmd->card],stcmd->dwOffSet,dwRet);
					dwRet = readl((int *)(sm->dwMemSpace[stcmd->card] + stcmd->dwOffSet));
				}
			//printk("READDWORD 3: card=%d Addr: %x offset=%x ret = %x\n",stcmd->card,sm->dwRegSpace[stcmd->card],stcmd->dwOffSet,dwRet);
			stcmd->dwData = dwRet;
			
			return dwRet;

			break;
		case VLIB_IOCTL_WRITEU32:			/* write dword value */
			
			stcmd = (struct MEM_CMD *)arg;
			if (stcmd->dwAddrSpace==VLIB_AD_BAR0)
			{
				writel(stcmd->dwData, (void *)(sm->dwRegSpace[stcmd->card] + stcmd->dwOffSet));
			}
			else
				if (stcmd->dwAddrSpace==VLIB_AD_BAR2)
				{
					writel(stcmd->dwData, (void *)(sm->dwMemSpace[stcmd->card] + stcmd->dwOffSet));
				}
			
			//xprintk("WRITEU32: card=%d Ad.Space=%x Addr: %x offset=%x data=%x\n",stcmd->card,stcmd->dwAddrSpace,sm->dwRegSpace[stcmd->card],stcmd->dwOffSet,stcmd->dwData);
			break;
		case VLIB_IOCTL_WRITEU16:			/* write word value */
			
			stcmd = (struct MEM_CMD *)arg;
			wVal = (u16)stcmd->dwData;

			if (stcmd->dwAddrSpace==VLIB_AD_BAR0)
			{
				writew(wVal, (void *)(sm->dwRegSpace[stcmd->card] + stcmd->dwOffSet));
			}
			else
				if (stcmd->dwAddrSpace==VLIB_AD_BAR2)
				{
					writew(wVal, (void *)(sm->dwMemSpace[stcmd->card] + stcmd->dwOffSet));
				}

			//xprintk("WRITEU16: card=%d Ad.Space=%x Addr: %x offset=%x data=%x\n",stcmd->card,stcmd->dwAddrSpace,sm->dwRegSpace[stcmd->card],stcmd->dwOffSet,wVal);
			break;
		case VLIB_IOCTL_OPENBOARDS:			/* open boards */
#ifdef DEBUG_KERNEL
				xprintk("OPENBOARDS: starting - handle=%x\n",sm->hWD_Global);
#endif
			if (sm->hWD_Global>0) {
				//locate and open boards
				retval = init_plx();
#ifdef DEBUG_KERNEL
					xprintk("OPENBOARDS: retval=%x\n",retval);
#endif
				if (retval >= 0) {
#ifdef DEBUG_KERNEL
						xprintk("OPENBOARDS: Open plx.%x.retval=%x\n",(unsigned int)&plx_driver,retval);
#endif
					//driver_opened = 1;
				}
				else
					return -EINVAL;
			}
			else
			{
#ifdef DEBUG_KERNEL
					xprintk("OPENBOARDS: ERROR retval=%x\n",retval);
#endif
				return -EINVAL;
			}
			break;
		case VLIB_IOCTL_CLOSEBOARDS:		/* close boards */
			if (sm->hWD_Global>0) {
				pci_unregister_driver(&plx_driver);
#ifdef DEBUG_KERNEL
					xprintk("CLOSEBOARDS: Closing plx..%x OK\n",(unsigned int)&plx_driver);
#endif
				//driver_opened = 0;
				retval = 0;
			}
			else
			{
				retval = -EINVAL;
			}
			break;
        case VLIB_IOCTL_CCS_LOCK:   // shared memory for ccs signalling
            if (ccs_ptr == NULL)
            {
#ifdef DEBUG_KERNEL
					xprintk("vlib: starting ccs shared memory.\n");
#endif
                ccs_ptr = kmalloc(sizeof(DG_CCS_MEMORY) + 2 * PAGE_SIZE, GFP_KERNEL);
                if (ccs_ptr==NULL)
                {
                    printk("vlib->ioctl ERROR allocating ccs shared memory.\n");
                    return -EINVAL;
                }				
                ccs_area = (char *)(((unsigned long)ccs_ptr + PAGE_SIZE -1) & PAGE_MASK);
                for (virt_addr=(unsigned long)ccs_area; virt_addr < (unsigned long)ccs_area + sizeof(DG_CCS_MEMORY);
                            virt_addr+=PAGE_SIZE) 
                {
                    // reserve all pages to make them remapable
                    //mem_map_reserve(virt_to_page(virt_addr));
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
                    mem_map_reserve(virt_to_page(virt_addr));
#else
                    SetPageReserved(virt_to_page(virt_addr));
#endif
                }
                //assume struct pointer
                ccsm = (DG_CCS_MEMORY *)ccs_ptr;
                //initializes values
                retval = 0;
#ifdef DEBUG_KERNEL
					xprintk("CCS DMALOCK: Done..\n");
#endif
            }
            else
            {
#ifdef DEBUG_KERNEL
					xprintk("CCS DMALOCK: Memoria alocada previamente.....\n");
#endif
                //retval = -EINVAL;
                retval = 0;
            }

            break;
        case VLIB_IOCTL_CCS_UNLOCK:   // shared memory for ccs signalling
            //Deallocates shared memory
            //frees allocated memory 
            if (ccs_ptr!=NULL) 
            {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#ifdef DEBUG_KERNEL
					xprintk("VLIB_IOCTL_CCS_UNLOCK: Cleaning memorymap structure!\n");
#endif
                for (virt_addr=(unsigned long)ccs_area; virt_addr < (unsigned long)ccs_area + sizeof(DG_CCS_MEMORY);
                        virt_addr+=PAGE_SIZE) {
                    // clear all pages
                    ClearPageReserved(virt_to_page(virt_addr));
                }
#endif
                kfree(ccs_ptr);
                ccs_ptr = NULL;
#ifdef DEBUG_KERNEL
					xprintk("VLIB_IOCTL_CCS_UNLOCK: CCS Shared memory closed!\n");
#endif
            }
            retval = 0;

            break;

		case VLIB_IOCTL_DMALOCK:
			//Allocates shared memory to exchange data with usermode
			// reserve memory with kmalloc - Allocating Memory in the Kernel
			if (kmalloc_ptr == NULL)
			{
#ifdef DEBUG_KERNEL
					xprintk("DMALOCK: Allocating memory - size %d..\n", (int)(LEN + 2 * PAGE_SIZE) );
#endif
				kmalloc_ptr = kmalloc(LEN + 2 * PAGE_SIZE, GFP_KERNEL);
				if (kmalloc_ptr==NULL)
				{
				    printk("vlib: ERROR allocating shared memory.\n");
				    return -EINVAL;
				}				
				kmalloc_area = (char *)(((unsigned long)kmalloc_ptr + PAGE_SIZE -1) & PAGE_MASK);
				for (virt_addr=(unsigned long)kmalloc_area; virt_addr < (unsigned long)kmalloc_area + LEN;
							virt_addr+=PAGE_SIZE) 
				{
					// reserve all pages to make them remapable
					//mem_map_reserve(virt_to_page(virt_addr));
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
					mem_map_reserve(virt_to_page(virt_addr));
#else
					SetPageReserved(virt_to_page(virt_addr));
#endif
				}
				//assume struct pointer
				sm = (DG_SHAREDMEMORY *)kmalloc_ptr;
				//xprintk("DMALOCK: %d bytes allocated\n", sizeof(sm));
				//initializes values
				sm->hWD_Global = 1;
				sm->nCardsCount = 0;
				retval = 0;
#ifdef DEBUG_KERNEL
					xprintk("DMALOCK: Done..\n");
#endif
			}
			else
			{
#ifdef DEBUG_KERNEL
					xprintk("DMALOCK: Memoria alocada previamente.....\n");
#endif
				//retval = -EINVAL;
				retval = 0;
			}

			break;
		case VLIB_IOCTL_DMAUNLOCK:
			//Deallocates shared memory
			//frees allocated memory 
			if (kmalloc_ptr!=NULL) 
			{
#ifdef DEBUG_KERNEL
					xprintk("DMAUNLOCK: Doing..\n");
#endif

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
				for (virt_addr=(unsigned long)kmalloc_area; virt_addr < (unsigned long)kmalloc_area + LEN;
						virt_addr+=PAGE_SIZE) {
					// clear all pages
					ClearPageReserved(virt_to_page(virt_addr));
				}
#endif
				kfree(kmalloc_ptr);
				kmalloc_ptr = NULL;
				printk("vlibd: All resources closed!\n");
			}
			retval = 0;
			break;
		//----------------- RECORD MEMORY FUNCTIONS ----------------------------------------------------			
		case VLIB_IOCTL_REC_LOCK:			//alloc rec dma buffer
			mem_data = (ALLOC_STRUCT *)arg;
			if (rec_ptr[mem_data->group] == NULL)
			{
				//create, alloc, etc	
				
				rec_ptr[mem_data->group] = kmalloc(mem_data->size + 2 * PAGE_SIZE, GFP_KERNEL);
				if (rec_ptr[mem_data->group]!=NULL)
				{
					rec_area[mem_data->group] = (char *)(((unsigned long)rec_ptr[mem_data->group] + PAGE_SIZE -1) & PAGE_MASK);
					for (virt_addr=(unsigned long)rec_area[mem_data->group]; virt_addr < (unsigned long)rec_area[mem_data->group] + mem_data->size;
								virt_addr+=PAGE_SIZE) 
					{
						// reserve all pages to make them remapable
						//mem_map_reserve(virt_to_page(virt_addr));
	#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
						mem_map_reserve(virt_to_page(virt_addr));
	#else
						SetPageReserved(virt_to_page(virt_addr));
	#endif
	
					}
#ifdef DEBUG_KERNEL
						xprintk("REC DMALOCK: Allocating memory size %d for group %d - addr=%x..\n",mem_data->size, mem_data->group, (unsigned int)rec_ptr[mem_data->group]);
#endif
					//assume struct pointer
					grmk[mem_data->group] = (DG_GROUPED_RECMEM *)rec_ptr[mem_data->group];
					
					//initializes with default values and insert the first port
					grmk[mem_data->group]->max_port = 0;
					grmk[mem_data->group]->ch[ grmk[mem_data->group]->max_port ] = mem_data->port;
					//set rmk pointer to make compatibility with windows part
					rmk[mem_data->port-1] = &grmk[mem_data->group]->rec[grmk[mem_data->group]->max_port];
					//increase counter
					grmk[mem_data->group]->max_port++;
	
#ifdef DEBUG_KERNEL
						xprintk("REC DMALOCK: Port %d inserted into group %d - rmk = %x. Done!\n", mem_data->port,mem_data->group, (int)rmk[mem_data->port-1]);
#endif
					
					retval = 0;					
				}
				else 
				{
					printk("vlib: ERROR Port %d - Couldn't allocate more memory for REC!!\n",mem_data->port);
					retval = -EINVAL;
				}
			}
			else
			{

				//if (closed_gracefully!=2)
				//{
					//include another port	
					if (grmk[mem_data->group]->max_port < MAX_REC_PORTS_PER_GROUP)
					{
#ifdef DEBUG_KERNEL
							xprintk("REC DMALOCK: Group %d already exists. Inserting port %d\n",mem_data->group,mem_data->port);
#endif
						grmk[mem_data->group]->ch[ grmk[mem_data->group]->max_port  ] = mem_data->port;
						
						rmk[mem_data->port-1] = &grmk[mem_data->group]->rec[grmk[mem_data->group]->max_port];
						
						grmk[mem_data->group]->max_port++;
					}
					else
						retval = -EINVAL;
				//}
				//else
				//{
				//	printk("REC: Alocado previamente\n");
				//	retval = 0;
				//}
			}
			break;
		case VLIB_IOCTL_REC_UNLOCK:			//frees rec dma buffers
			mem_data = (ALLOC_STRUCT *)arg;
			if (rec_ptr[mem_data->group] != NULL)
			{
#ifdef DEBUG_KERNEL
					xprintk("REC DMAUNLOCK: Free group %d at address %x of size %d\n", mem_data->group, (unsigned int)rec_ptr[mem_data->group],mem_data->size);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
				for (virt_addr=(unsigned long)rec_area[mem_data->group]; virt_addr < (unsigned long)rec_area[mem_data->group] + mem_data->size;
							virt_addr+=PAGE_SIZE) {

					// clear all pages
					ClearPageReserved(virt_to_page(virt_addr));
				}
#endif

				kfree(rec_ptr[mem_data->group]);
				rec_ptr[mem_data->group] = NULL;
			}
			retval = 0;
			break;
		//----------------- PLAY MEMORY FUNCTIONS ----------------------------------------------------
		case VLIB_IOCTL_PLAY_LOCK:			//alloc play dma buffer
			mem_data = (ALLOC_STRUCT *)arg;
#ifdef DEBUG_KERNEL
				xprintk("VLIB_IOCTL_PLAY_LOCK - port %d - group %d\n", mem_data->port, mem_data->group);
#endif
			if (play_ptr[mem_data->group] == NULL)
			{
				//create, alloc, etc
#ifdef DEBUG_KERNEL
					xprintk("PLAY DMALOCK: Allocating memory for group %d size %d ..\n",mem_data->group,mem_data->size);
#endif
				play_ptr[mem_data->group] = kmalloc(mem_data->size + 2 * PAGE_SIZE, GFP_KERNEL);

				if (play_ptr[mem_data->group]!=NULL)
				{
					play_area[mem_data->group] = (char *)(((unsigned long)play_ptr[mem_data->group] + PAGE_SIZE -1) & PAGE_MASK);
					for (virt_addr=(unsigned long)play_area[mem_data->group]; virt_addr < (unsigned long)play_area[mem_data->group] + mem_data->size;
								virt_addr+=PAGE_SIZE) 
					{
						// reserve all pages to make them remapable
						//mem_map_reserve(virt_to_page(virt_addr));
	#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
						mem_map_reserve(virt_to_page(virt_addr));
	#else
						SetPageReserved(virt_to_page(virt_addr));
	#endif
	
					}
					//assume struct pointer
					gpmk[mem_data->group] = (DG_GROUPED_PLAYMEM *)play_ptr[mem_data->group];

					//initializes with default values and insert the first port
					gpmk[mem_data->group]->max_port = 0;
					gpmk[mem_data->group]->ch[ gpmk[mem_data->group]->max_port ] = mem_data->port;
					//set rmk pointer to make compatibility with windows part
					pmk[mem_data->port-1] = &gpmk[mem_data->group]->play[gpmk[mem_data->group]->max_port];
					//increase counter
					gpmk[mem_data->group]->max_port++;

#ifdef DEBUG_KERNEL
						xprintk("PLAY DMALOCK: Port %d inserted into group %d - rmk = %x. Done!\n", mem_data->port,mem_data->group, (int)pmk[mem_data->port-1]);
#endif
				
					retval = 0;						
				}
				else
				{
					printk("vlib: ERROR Port %d - Couldn't allocate more memory for PLAY!!\n",mem_data->port);
					retval = -EINVAL;
				}
			}
			else
			{
				//if (closed_gracefully!=2)
				//{
					//include another port	
					if (gpmk[mem_data->group]->max_port < MAX_PLAY_PORTS_PER_GROUP)
					{
#ifdef DEBUG_KERNEL
							xprintk("PLAY DMALOCK: Group %d already exists. Inserting port %d\n",mem_data->group,mem_data->port);
#endif
						gpmk[mem_data->group]->ch[ gpmk[mem_data->group]->max_port  ] = mem_data->port;
						
						pmk[mem_data->port-1] = &gpmk[mem_data->group]->play[gpmk[mem_data->group]->max_port];
						
						gpmk[mem_data->group]->max_port++;
					}
					else
						retval = -EINVAL;
				//} 
				//else 
				//{ 
				//	printk("PLAY: Alocado previamente\n");
				//	retval = 0;
				//}
			}
			break;
			
		case VLIB_IOCTL_PLAY_UNLOCK:			//frees play dma buffers
			mem_data = (ALLOC_STRUCT *)arg;
			if (play_ptr[mem_data->group] != NULL)
			{
#ifdef DEBUG_KERNEL
					xprintk("PLAY DMAUNLOCK: Free group %d\n", mem_data->group);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
				for (virt_addr=(unsigned long)play_area[mem_data->group]; virt_addr < (unsigned long)play_area[mem_data->group] + mem_data->size;
							virt_addr+=PAGE_SIZE) 
				{

					// clear all pages
					ClearPageReserved(virt_to_page(virt_addr));
				}
#endif

				kfree(play_ptr[mem_data->group]);
				play_ptr[mem_data->group] = NULL;
			}
			retval = 0;
			break;
			
		case VPPCI_IOCTL_VERSION:
			/* reads firmware version
			 * arg: card number
			 */

			dg_kernel_write(sm->dwMemSpace[(int)arg], HPIA, 0x7638);
			retval = dg_kernel_read(sm->dwMemSpace[(int)arg], HPID);
		
			break;
		case VLIB_IOCTL_END_THREADS:
			shutdown_started = 1;

    		for (nForCards = 0; nForCards < sm->nCardsCount; nForCards++)
    		{
#ifdef DEBUG_KERNEL
					xprintk("->vlibe1[%d]: Waking Up All Read Functions!\n", nForCards);
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
					flag_signal_queue[nForCards]=1;
					flag_ccs_queue[nForCards]=1;
#endif
				wake_up_interruptible(&signal_queue[nForCards]);
				wake_up_interruptible(&signal_ccs[nForCards]);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
				rec_signal[nForCards].flag_rec_queue = 1;
				play_signal[nForCards].flag_play_queue = 1;
#endif
			wake_up_interruptible(&rec_signal[nForCards].record_signal_queue);
			wake_up_interruptible(&play_signal[nForCards].play_signal_queue);
			}
			retval = 0;
			break;
		default:
			retval = -EINVAL;
	}
	return retval;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36)
	static DEFINE_MUTEX(klock_mutex);
	static long vlib_unlocked_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
	{
			long ret;
			//lock_kernel();
			mutex_lock(&klock_mutex);
			ret = vlib_ioctl(file->f_path.dentry->d_inode, file, cmd, arg);
			//unlock_kernel();
			mutex_unlock(&klock_mutex);
			return ret;
	}
#endif

//----------------------------------------------------------------------------
// MMap function
//----------------------------------------------------------------------------
static int vlib_mmap(struct file * filp, struct vm_area_struct * vma) 
{
	int ret=0;
	int local_minor_number = MINOR(filp->f_dentry->d_inode->i_rdev);
	
#ifdef DEBUG_KERNEL
		xprintk("vlib_mmap for minor %d\n", local_minor_number);
#endif
	if (local_minor_number == MINOR_MMAP_MAIN)   //main shared memory
	{

		/*ret = REMAP(vma,vma->vm_start,virt_to_phys((void*)((unsigned long)kmalloc_area)),
			vma->vm_end-vma->vm_start,
			PAGE_SHARED);*/


/* #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)

	#ifdef RH3AS
				//only for redhat 3 AS
				ret = remap_page_range(vma,
				vma->vm_start,
				virt_to_phys((void*)((unsigned long)kmalloc_area)),
				vma->vm_end-vma->vm_start,
				PAGE_SHARED);
	
	#else
			ret = remap_page_range(vma->vm_start,
				virt_to_phys((void*)((unsigned long)kmalloc_area)),
				vma->vm_end-vma->vm_start,
				PAGE_SHARED);
	#endif

#else
			//remap_pfn_range was introduces in kernel 2.6.10  - check http://lwn.net/Articles/104333/ for details
  #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)	
			ret = remap_page_range(vma,
			vma->vm_start,
			virt_to_phys((void*)((unsigned long)kmalloc_area)),
			vma->vm_end-vma->vm_start,
			PAGE_SHARED);

  #else
			ret = remap_pfn_range(vma,
			vma->vm_start,
			virt_to_phys((void*)((unsigned long)kmalloc_area)) >> PAGE_SHIFT,
			vma->vm_end-vma->vm_start,
			PAGE_SHARED);

  #endif

#endif
*/
		ret = remap_range(vma, vma->vm_start, virt_to_phys((void *)((unsigned long)kmalloc_area)), vma->vm_end - vma->vm_start, PAGE_SHARED);
	
		if(ret != 0) {
		        printk("ERRO na MMAP");
			return -EAGAIN;
		}

	}
	else
		if (local_minor_number>=MINOR_REC_START && local_minor_number<=MINOR_REC_END)	//REC MMAP
		{
		    /*ret = REMAP(vma,
					vma->vm_start,	
					virt_to_phys((void*)((unsigned long)rec_area[local_minor_number-MINOR_REC_START])),
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);*/

		
			//shared memory for recording
/* #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)

	#ifdef RH3AS
				ret = remap_page_range(vma,
					vma->vm_start,	
					virt_to_phys((void*)((unsigned long)rec_area[local_minor_number-MINOR_REC_START])),
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);

	#else
			ret = remap_page_range(vma->vm_start,
					virt_to_phys((void*)((unsigned long)rec_area[local_minor_number-MINOR_REC_START])),
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);
	#endif

#else
  #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)	
				ret = remap_page_range(vma,
					vma->vm_start,	
					virt_to_phys((void*)((unsigned long)rec_area[local_minor_number-MINOR_REC_START])),
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);

  #else
    				ret = remap_pfn_range(vma,
					vma->vm_start,	
					virt_to_phys((void*)((unsigned long)rec_area[local_minor_number-MINOR_REC_START])) >> PAGE_SHIFT,
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);

  #endif

#endif*/
			ret = remap_range(vma, vma->vm_start, virt_to_phys((void *)((unsigned long)
							rec_area[local_minor_number - MINOR_REC_START])),
							vma->vm_end - vma->vm_start,
							PAGE_SHARED);
			if(ret != 0) {
				return -EAGAIN;
			}
		}
		else
			if (local_minor_number>=MINOR_PLAY_START && local_minor_number<=MINOR_PLAY_END)	//PLAY MMAP
			{
				//shared memory for recording

				/*ret = REMAP(vma,
					vma->vm_start,	
					virt_to_phys((void*)((unsigned long)play_area[local_minor_number-MINOR_PLAY_START])),
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);			*/

/*
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,0)
	#ifdef RH3AS
				//only for RH 3 AS
				ret = remap_page_range(vma,vma->vm_start,
						virt_to_phys((void*)((unsigned long)play_area[local_minor_number-MINOR_PLAY_START])),
						vma->vm_end-vma->vm_start,
						PAGE_SHARED);
	#else
				ret = remap_page_range(vma->vm_start,
						virt_to_phys((void*)((unsigned long)play_area[local_minor_number-MINOR_PLAY_START])),
						vma->vm_end-vma->vm_start,
						PAGE_SHARED);
	#endif
#else
  #if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,10)	
				ret = remap_page_range(vma,
					vma->vm_start,	
					virt_to_phys((void*)((unsigned long)play_area[local_minor_number-MINOR_PLAY_START])),
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);

  #else
				ret = remap_pfn_range(vma,
					vma->vm_start,	
					virt_to_phys((void*)((unsigned long)play_area[local_minor_number-MINOR_PLAY_START])) >> PAGE_SHIFT,
					vma->vm_end-vma->vm_start,
					PAGE_SHARED);

  #endif
#endif
*/
				ret = remap_range(vma, vma->vm_start, virt_to_phys((void *)((unsigned long)
								play_area[local_minor_number - MINOR_PLAY_START])),
						vma->vm_end - vma->vm_start,
						PAGE_SHARED);
			
				if(ret != 0) {
					return -EAGAIN;
				}
			}
            else
                if (local_minor_number==MINOR_CCS_MMAP_MAIN)
                {
                    //shared memory for CCS signalling
#ifdef DEBUG_KERNEL
						xprintk("CCS_MMAP: Starting memory map\n");
#endif
                    ret = remap_range(vma, vma->vm_start, virt_to_phys((void *)((unsigned long)ccs_area)), vma->vm_end - vma->vm_start, PAGE_SHARED);

                    if(ret != 0) {
                            printk("ERRO na MMAP CCS");
                        return -EAGAIN;
                    }

                }
		
	return 0;
}

// define which file operations are supported
struct file_operations vlib_fops = {
	.owner	=	THIS_MODULE,
	.llseek	=	NULL,
	.read		=	vlib_read,
	.write	=	vlib_write,
	.poll		=	NULL,
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,36)
        .unlocked_ioctl = vlib_unlocked_ioctl,
#else
        .ioctl = vlib_ioctl,
#endif
	.mmap		=	vlib_mmap,
	.open		=	vlib_open,
	.flush	=	NULL,
	.release	=	vlib_release,
	.fsync	=	NULL,
	.fasync	=	NULL,
	.lock		=	NULL,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
	.readv	=	NULL,
	.writev	=	NULL,
#endif
};

static int __init vlib_init_module (void) 
{
	short i;

#ifdef USE_DGDUMMY	
		dgd = kmalloc(sizeof(struct ztdummy), GFP_KERNEL);
    	if (dgd == NULL) 
    	{
    		printk("vlibd: Unable to allocate dgdummy memory\n");
    		return - EIO;
    	}

    	memset(dgd, 0x0, sizeof(struct ztdummy));
#endif//#ifdef USE_DGDUMMY

	printk("vlibd: vlib_init_module - Starting loading driver...\n");
	major_number = register_chrdev (0, VLIB_DEVICE, &vlib_fops);
	if (major_number < 0) {
		printk("vlibd: Could not register %s - cod %x\n",VLIB_DEVICE,major_number); 
		return - EIO;
	}
	printk("vlibd: Module %s using major number %d\n",VLIB_DEVICE,major_number);

	/* initialize signal wait queue */
	for (i=0;i<MAX_CARDS;i++)
	{
		init_waitqueue_head(&signal_queue[i]);	
        init_waitqueue_head(&signal_ccs[i]);	

#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)			
		flag_signal_queue[i]=0;
        flag_ccs_queue[i]=0;
#endif
	init_waitqueue_head(&rec_signal[i].record_signal_queue);
	init_waitqueue_head(&play_signal[i].play_signal_queue);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)	
	play_signal[i].flag_play_queue = 0;
	rec_signal[i].flag_rec_queue = 0;
#endif
	}
	printk("vlibd: Driver Version: %s\n",DRIVER_VERSION);
	printk("vlibd: VoicerLib Device Driver was loaded successfully!\n");
#ifdef USE_DGDUMMY
		printk("vlibd: dgdummy option enabled!\n");	
#endif//#ifdef USE_DGDUMMY	
	return 0; 
}

static void __exit vlib_cleanup_module (void) 
{ 
	int i;

	printk("vlibd: vlib_cleanup_module: unloading voicerlib module.\n");

#ifdef USE_DGDUMMY
    	kfree(dgd);
#endif//#ifdef USE_DGDUMMY

	//check opened resources and close them
	if (closed_gracefully==2)
	{
		for (i=0; i<sm->nCardsCount; i++) {
			printk("vlibd: vlib_cleanup_module: disabling interrupt card %d.\n", i);
			vlib_interrupt_disable(sm->Cards[i].digivoice_dev);
			dsp_hold_reset(sm->Cards[i].digivoice_dev);    
			//unmap all shared memory
		}
		//release rec shared memory
		for (i=0; i < MAX_REC_GROUP; i++)
		{
			if (rec_ptr[i] != NULL)
			{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
				printk("vlibd: Clean REC mmmap %d.\n", i);
				for (virt_addr=(unsigned long)rec_area[i]; virt_addr < (unsigned long)rec_area[i] + sizeof(DG_GROUPED_RECMEM);
							virt_addr+=PAGE_SIZE) 
				{
					// clear all pages
					ClearPageReserved(virt_to_page(virt_addr));
				}
#endif
				kfree(rec_ptr[i]);
				rec_ptr[i] = NULL;
			}
		}	

		//release play shared memory
		for (i=0; i < MAX_PLAY_GROUP; i++)
		{
			if (play_ptr[i] != NULL)
			{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
				printk("vlibd: Clean PLAY mmmap %d.\n", i);
				for (virt_addr=(unsigned long)play_area[i]; virt_addr < (unsigned long)play_area[i] + sizeof(DG_GROUPED_PLAYMEM);
							virt_addr+=PAGE_SIZE) 
				{
					// clear all pages
					ClearPageReserved(virt_to_page(virt_addr));
				}
#endif
				kfree(play_ptr[i]);
				play_ptr[i] = NULL;
			}
		}

        if (ccs_ptr!=NULL) 
        {
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
            for (virt_addr=(unsigned long)ccs_area; virt_addr < (unsigned long)ccs_area + sizeof(DG_CCS_MEMORY);
                    virt_addr+=PAGE_SIZE) {
                // clear all pages
                ClearPageReserved(virt_to_page(virt_addr));
            }
#endif
            kfree(ccs_ptr);
            ccs_ptr = NULL;
            printk("VLIB_IOCTL_CCS_UNLOCK: CCS Shared memory closed!\n");
        }


		//frees allocated memory sm
		if (kmalloc_ptr!=NULL) 
		{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
			for (virt_addr=(unsigned long)kmalloc_area; virt_addr < (unsigned long)kmalloc_area + sizeof(DG_SHAREDMEMORY);
					virt_addr+=PAGE_SIZE) {
				// clear all pages
				ClearPageReserved(virt_to_page(virt_addr));
			}
			printk("vlibd: Clean main shared mmmap.\n");
#endif
			kfree(kmalloc_ptr);
			kmalloc_ptr = NULL;
		}
		closed_gracefully = 1;		
	
	}
	printk("vlibd: Unregistering %s with major = %d\n",VLIB_DEVICE,major_number ); 
	unregister_chrdev (major_number, VLIB_DEVICE);
	printk("vlibd: VoicerLib Device Driver Unloaded!\n"); 
	
}


void force_cleanup(void)
{
	int i;

	for (i=0; i<sm->nCardsCount; i++) {
#ifdef DEBUG_KERNEL
			xprintk("vlibd: force_cleanup: disabling interrupt card %d.\n", i);
#endif
		vlib_interrupt_disable(sm->Cards[i].digivoice_dev);
		dsp_hold_reset(sm->Cards[i].digivoice_dev);    
		//unmap all shared memory
	}
	//release rec shared memory
	for (i=0; i < MAX_REC_GROUP; i++)
	{
		if (rec_ptr[i] != NULL)
		{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#ifdef DEBUG_KERNEL
				xprintk("vlibd: force_cleanup Clean REC mmmap %d.\n", i);
#endif
			for (virt_addr=(unsigned long)rec_area[i]; virt_addr < (unsigned long)rec_area[i] + sizeof(DG_GROUPED_RECMEM);
						virt_addr+=PAGE_SIZE) 
			{
				// clear all pages
				ClearPageReserved(virt_to_page(virt_addr));
			}
#endif
			kfree(rec_ptr[i]);
			rec_ptr[i] = NULL;
		}
	}	

	//release play shared memory
	for (i=0; i < MAX_PLAY_GROUP; i++)
	{
		if (play_ptr[i] != NULL)
		{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
#ifdef DEBUG_KERNEL
				xprintk("vlibd: force_cleanup Clean PLAY mmmap %d.\n", i);
#endif
			for (virt_addr=(unsigned long)play_area[i]; virt_addr < (unsigned long)play_area[i] + sizeof(DG_GROUPED_PLAYMEM);
						virt_addr+=PAGE_SIZE) 
			{
				// clear all pages
				ClearPageReserved(virt_to_page(virt_addr));
			}
#endif
			kfree(play_ptr[i]);
			play_ptr[i] = NULL;
		}
	}
	//frees allocated memory sm
	/*if (kmalloc_ptr!=NULL) 
	{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,0)
		for (virt_addr=(unsigned long)kmalloc_area; virt_addr < (unsigned long)kmalloc_area + sizeof(DG_SHAREDMEMORY);
				virt_addr+=PAGE_SIZE) {
			// clear all pages
			ClearPageReserved(virt_to_page(virt_addr));
		}
		printk("vlibd: Clean main shared mmmap.\n");
#endif
		//kfree(kmalloc_ptr);
		//kmalloc_ptr = NULL;
	}*/

}

/****************************************/
// PLX access through memory (BAR0) -write
/****************************************/
void plx_writemem(unsigned short card, u32 val,unsigned int addr)
{
	writel(val, (void *)(sm->dwRegSpace[card] + addr));
}

/****************************************/
// PLX access through memory (BAR0) - read
/****************************************/
u32 plx_readmem(unsigned short card, unsigned int addr)
{
	return readl((void *)(sm->dwRegSpace[card] + addr));
}


/****************************************/

/****************************************
 Find index for desired device pdev
 start from 0
**************************************-*/
short plx_getdeviceindex(struct pci_dev *pdev)
{
	int i;  
	/* locate device information structure  */
	
	//for (i=0;i<sm->nCardsCount;i++)
	for (i=0;i<MAX_CARDS;i++)
	{
		if (pdev == sm->Cards[i].digivoice_dev)
		{
#ifdef DEBUG_KERNEL
				xprintk("plx_getdeviceindex: Found %d of %d\n", i+1, sm->nCardsCount);
#endif
			break;
		}
	}

	//if (i == sm->nCardsCount)
	if (i == MAX_CARDS)
		return -1;        //error
	else
		return i;
}


/****************************************/
/*enable PLX interrup seting the VLIB_INTCSR register
 *BIT1 and BIT6 */
void vlib_interrupt_enable(struct pci_dev *pdev)
{
	u32 tmp,i;
	i = plx_getdeviceindex(pdev);
  
#ifdef DEBUG_KERNEL
		xprintk ("vlib_interrupt_enable: card %d\n",i);
#endif
	
	if (i!=-1)
	{
		if(pdev->device == 0x9030)
		{		
			tmp=plx_readmem(i,VLIB_INTCSR); /*read VLIB_INTCSR*/
#ifdef DEBUG_KERNEL
				xprintk ("vlib_interrupt_enable antes: tmp=%x offset %x on card %d\n",tmp,VLIB_INTCSR,i);
#endif
			tmp |= (BIT0|BIT6);                       /*Sets BIT0 and BIT6 - same as plx9052*/
#ifdef DEBUG_KERNEL
				xprintk ("vlib_interrupt_enable: tmp=%x offset %x on card %d\n",tmp,VLIB_INTCSR,i);
#endif
			plx_writemem(i,tmp,VLIB_INTCSR);/*Write tmp to VLIB_INTCSR*/
		}
		else
		{
			tmp=plx_readmem(i,VLIB_INTCSRE); /*read VLIB_INTCSRE*/
#ifdef DEBUG_KERNEL
				xprintk ("vlib_interrupt_enable antes: tmp=%x offset %x on card %d\n",tmp,VLIB_INTCSRE,i);
#endif
			tmp |= (BIT8|BIT11);                       /*Sets BIT8 and BIT11 */
#ifdef DEBUG_KERNEL
				xprintk ("vlib_interrupt_enable: tmp=%x offset %x on card %d\n",tmp,VLIB_INTCSRE,i);
#endif
			plx_writemem(i,tmp,VLIB_INTCSRE);/*Write tmp to VLIB_INTCSRE*/
		}
	}
}
/****************************************/

u16 plx_countcards(u32 dwDeviceID)
{
	u16 wVal;
	int i;
	struct pci_dev *d_pci;
	d_pci = NULL;
	wVal = 0;	

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,22)
		/* pci_find_device is deprecated */
		d_pci = pci_find_device(0x10b5,dwDeviceID,NULL);
#else
		d_pci = pci_get_device(0x10b5,dwDeviceID,NULL);
#endif

	while(d_pci!=NULL)
	{
		wVal++;

		i = plx_getdeviceindex(d_pci);
		if (i!=-1)
			sm->Cards[i].PlxType = dwDeviceID;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,22)
			/* pci_find_device is deprecated */
			d_pci = pci_find_device(0x10b5,dwDeviceID,d_pci);
#else
			d_pci = pci_get_device(0x10b5,dwDeviceID,d_pci);
#endif
	}
	return wVal;
}

/****************************************
This function writes the data in the data variable
 *in the DSP memory address in the addr variable.
 *It is used to write the firmware into the DSP
***************************************/
//int dg_kernel_write(short card,unsigned int addr, unsigned int data)
void dg_kernel_write(unsigned long addr_space, unsigned long offset, unsigned long data)
{
	//this card *must* write to data each time 
	//if you don't do that I don't know what will happens....
	writew((unsigned short)data, (void *)(addr_space + offset));
}

/****************************************/
/*This function read the data from addr */
/****************************************/
//unsigned int read_data(short card,unsigned int addr)
unsigned int dg_kernel_read(unsigned long addr_space, unsigned long offset)
{
	u16 wData;

	wData = readw((void *)(addr_space + offset));
	return wData;
}

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,34)) && defined (K_ARCH64)
	u32 KERNEL_DWREAD(unsigned long addr_space, unsigned long offset)
	{
		u32 wData;

		wData = __raw_readl((void *)(addr_space + offset));
		return wData;
	}

	void dg_memcpy_fromio(u32 *dst, unsigned long *src, size_t count, u16 addr, int Card)
	{
		int cmds;
		u32 retdwread;
		int rest = count%4;

		if (count/4 > 0)
		{
			for (cmds = 0; cmds < (count/4); cmds++)
			{
				dg_kernel_write(sm->dwMemSpace[Card], HPIA, addr);
				addr+=2;

                retdwread = KERNEL_DWREAD(sm->dwMemSpace[Card], src);
#ifdef DEBUG_KERNEL
					printk("vlibdrv: my_memcpy 4 - for %d - retdwread %08x, wCard %d\n", cmds, retdwread, Card);
#endif

				*(u32 *)dst = retdwread;
				dst++;

#ifdef DEBUG_KERNEL
					int tmp;
					for (tmp=0; tmp < 4; tmp++)
						printk("vlibdrv: my_memcpy - buffer[%d][%d][%d]=%x\n", Card, cmds, tmp, ((buffer[Card][cmds])>>(8*tmp))&0xff);
#endif
			}
		}

		if (rest!=0)
			printk("vlibd: (%d) WARN - dg_memcpy_fromio(received count = %d), rest = %d\n", Card, (int)count, rest);
	}
#endif

module_init(vlib_init_module);
module_exit(vlib_cleanup_module);

MODULE_AUTHOR("www.digivoice.com.br");
MODULE_DESCRIPTION("Linux Device Driver VoicerLib");
MODULE_VERSION("4.2.5.6_rc5");
